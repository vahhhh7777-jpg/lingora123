# Course completeness matrix (generated from the built-in catalog, `buildSeed()`)

Counts are real. "Quality" is NOT verified for any language: no native-speaker review has been done.

| Language | Level | Status in app | Units | Lessons | Exercises | Per lesson | Distinct words | Shown to learners |
|---|---|---|---|---|---|---|---|---|
| English (for Armenian speakers) | A1 | Full A1 course | 8 | 24 | 280 | 9–13 | 64 | yes |
| French, German, Italian, Turkish, Azerbaijani, Russian | A1 | Draft, awaiting native review | 8 | 24 | 280 | 9–13 | 64 | yes, labelled «Սևագիր»/Draft |
| Spanish, Japanese, Korean, Chinese, Portuguese, Arabic, Armenian | A1 | Sample only | 1 | 2 | 26 | 13 | 8 | no (hidden from the course list) |

Automatic checks: all multiple-choice questions contain their correct answer (0 broken).

## Not present anywhere
- Levels A2, B1, B2, C1, C2 for any language.
- Grammar explanations, per-lesson objectives and example-sentence notes in the built-in A1 units (the admin editor has fields for them; they are empty).
- Native-recorded audio (lessons use voice synthesis).
- Reviewed, native-verified content for any language other than the original author's English course.

## Why nothing was added
Writing hundreds of lessons in 13 languages without a native reviewer would produce unverified, possibly unnatural content. It was not generated. Add content through Admin → Lessons, have a native speaker review it, then publish.
