/* Lingora theme boot: runs before first paint (no flash of the wrong theme). Mirrors applyTheme()/applyPrefs() in src/js. Must stay a separate file: CSP forbids inline scripts. */
(function () {
  try {
    var j = JSON.parse(localStorage.getItem('lingora.v1') || 'null') || {};
    var r = document.documentElement, c = r.classList;
    var sd = !!(window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    var th = j.theme === 'light' ? 'light' : j.theme === 'system' ? (sd ? 'dark' : 'light') : 'dark';
    r.setAttribute('data-theme', th);
    if (j.dense) c.add('dense');
    if (j.hc) c.add('hc');
    if (j.noanim) c.add('no-anim');
    if (j.fs === 112) c.add('fs112');
    if (j.fs === 125) c.add('fs125');
    var dk = th === 'dark';
    var mc = document.querySelector('meta[name=theme-color]');
    if (mc) mc.content = dk ? '#101827' : '#F3F7FE';
  } catch (e) {}
})();
