// Lingora settings. Fill in the two Supabase values (see README.md), then upload again.
window.EE_CONFIG = {
  // Supabase dashboard -> Project Settings -> API
  SUPABASE_URL: "",        // e.g. "https://abcdxyz.supabase.co"
  SUPABASE_ANON_KEY: "",   // the public "anon" key (safe to keep here)

  // Shown to people who want VIP. Payments are accepted by you directly;
  // after you receive a payment, open the Admin tab and press +30 / +90 / +365 days.
  PRICE_TEXT: {
    hy: "VIP-ը՝ 1 ամիս՝ 2000 ֏, 1 տարի՝ 18000 ֏։ Գրիր մեզ, և մենք կուղարկենք վճարման տվյալները։",
    en: "VIP: 1 month 2000 AMD, 1 year 18000 AMD. Message us and we will send the payment details."
  },
  // Online card payments (Stripe). Keep false until the create-checkout and stripe-webhook functions are deployed with real
  // secrets and a vip_plans row has price_cents + provider_price (see README). Manual payments above keep working either way.
  ONLINE_PAYMENTS: false,

  // Gems are NOT free: VIP members earn them (lessons + a daily bonus) and everybody can buy a pack.
  // You receive the payment yourself, then press +gems next to the user in the Admin tab.
  // Prices below are examples: change them to your real prices.
  GEM_PACKS: [
    { gems: 100, price: "1000 ֏" },
    { gems: 300, price: "2500 ֏" },
    { gems: 700, price: "5000 ֏" }
  ],
  GEM_TEXT: {
    hy: "Գրիր մեզ, ընտրիր փաթեթը, վճարիր, և ակնեղենը կավելանա քո հաշվին։",
    en: "Message us, pick a pack, pay, and the gems are added to your account."
  },
  // Your own Terms of Use / Privacy Policy pages (https only). The sign-up checkbox links to them.
  // I have not written legal text for you: publish your own pages and paste the links here.
  TERMS_URL: "",
  PRIVACY_URL: "",

  CONTACT_URL: "",         // e.g. "https://t.me/yourname" or "https://wa.me/374XXXXXXXX"
  // Set to true after deploying the `tts` Edge Function (see supabase/functions/tts). Browser voices remain the fallback.
  NEURAL_TTS: false,

  CONTACT_LABEL: "Telegram"
};
