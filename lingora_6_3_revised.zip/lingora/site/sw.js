// Lingora offline support. The app registers this only for VIP members and admins.
const CACHE = 'ee-v28';
const SHELL = ['./', 'index.html', 'config.js', 'app.js', 'theme-boot.js', 'styles.css', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'icon-maskable-512.png'];

self.addEventListener('install', e => {
  // 6.3: {cache:'reload'} makes the install fetch skip the browser's HTTP cache. Plain c.add(u) re-cached the OLD app.js / styles.css on hosts that send a max-age
  // (GitHub Pages, Cloudflare Pages defaults), so a new release kept running the old files until that max-age ran out.
  e.waitUntil(caches.open(CACHE).then(c => Promise.all(SHELL.map(u => c.add(new Request(u, { cache: 'reload' })).catch(() => null)))).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(ks.filter(k => k.indexOf('ee-') === 0 && k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  // Account and course data go straight to the network; the app keeps its own offline copy.
  if (url.hostname.endsWith('supabase.co') || url.hostname.endsWith('supabase.in')) return;
  const sameOrigin = url.origin === self.location.origin;
  const assetHost = ['cdn.jsdelivr.net', 'fonts.googleapis.com', 'fonts.gstatic.com'].indexOf(url.hostname) >= 0;
  if (!sameOrigin && !assetHost) return;
  e.respondWith(
    caches.open(CACHE).then(cache =>
      cache.match(req, { ignoreSearch: true }).then(hit => {
        // 6.3: same-origin files are revalidated with the server (conditional request) instead of being answered from the HTTP cache
        const net = fetch(sameOrigin ? new Request(req, { cache: 'no-cache' }) : req).then(res => {
          if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone());
          return res;
        }).catch(() => hit || (req.mode === 'navigate' ? cache.match('index.html') : undefined));
        return hit || net;
      })
    )
  );
});
