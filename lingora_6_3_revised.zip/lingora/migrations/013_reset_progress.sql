-- Lingora 4.0 migration 013 (B-006 + gem-farming guard). Additive and idempotent: safe to run more than once.
--
-- (a) reset_my_progress(): a REAL server-side "reset my progress". Before this, "Reset progress" in cloud mode cleared only the
--     browser copy; player_state / lesson_completions are authoritative on the server and were simply re-applied on the next sync
--     (B-006: "old progress comes back"). The function clears XP, streak, finished lessons, the mistake book, story stars and this
--     week's XP events for the CALLER only (auth.uid(); no user id is accepted).
--     It deliberately KEEPS everything that is money-like or a one-time reward, so a reset can never be used to farm them:
--     gems, hearts, freezes, boosts, VIP, streak milestones (player_state.milestones), achievements, quest claims, gem ledger,
--     lesson attempts (daily completion limits keep counting).
-- (b) complete_lesson(): the first-completion gem reward is now keyed by LESSON (reason 'lesson_first'), not by attempt id, so it
--     is paid once per lesson per account even if the lesson is completed again after a reset. The result now reports the gems
--     that were really paid (0 when none), instead of the configured amount.
-- Rollback: drop function public.reset_my_progress(); and re-run the previous complete_lesson from SETUP.sql (migration 010/008 block).

create or replace function public.reset_my_progress() returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); wk date;
begin
  if uid is null then raise exception 'denied'; end if;
  if public.is_suspended() then raise exception 'suspended'; end if;
  perform private.ps_get(uid);                      -- make sure the state row exists
  wk := private.week_start(uid);
  delete from public.lesson_completions where user_id = uid;
  delete from public.mistake_book where user_id = uid;
  delete from public.story_progress where user_id = uid;
  delete from public.xp_events where user_id = uid and day >= wk;   -- this week only: the weekly leaderboard sums these
  update public.player_state set xp = 0, streak = 0, best_streak = 0, last_day = null, day = null, day_xp = 0, updated_at = now()
   where user_id = uid;
  insert into public.progress (user_id, data, updated_at) values (uid, '{}'::jsonb, now())
  on conflict (user_id) do update set data = '{}'::jsonb, updated_at = now();
  insert into public.audit_log (actor, actor_role, action, entity, entity_id, detail)
  values (uid, 'user', 'progress_reset', 'user', uid::text, '{}'::jsonb);
  return private.state_json(uid);
end $$;
revoke all on function public.reset_my_progress() from public, anon;
grant execute on function public.reset_my_progress() to authenticated;

-- complete_lesson (the hardened 008 version: answers must be recorded by the server) with the per-lesson first-completion reward
create or replace function public.complete_lesson(p_attempt uuid, p_mistakes int) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare
  uid uuid := auth.uid(); a public.lesson_attempts; cfg jsonb := private.cfg(); ps public.player_state; l public.lessons;
  mis int := least(greatest(coalesce(p_mistakes, 0), 0), 60); stars int; first_time boolean; raw int; mult numeric := 1; xp int; g int := 0;
  lv0 int; lv1 int; unit_done boolean := false; today_xp int; cap int; d date := private.local_day(uid);
  ev jsonb; ach jsonb; goal_hit boolean := false; res jsonb; gmult jsonb; star_xp int := (cfg->'xp'->>'star')::int;
  done_today int; wrong_rows int; has_rows boolean; need_answers boolean := coalesce((cfg->'answers'->>'required')::boolean, true);
begin
  if uid is null then raise exception 'denied'; end if;
  select * into a from public.lesson_attempts where id = p_attempt and user_id = uid for update;
  if not found then raise exception 'not_found'; end if;
  if a.status = 'done' then return a.result; end if;        -- repeated call: same answer, no second reward
  if a.kind <> 'lesson' then raise exception 'invalid'; end if;
  if extract(epoch from (now() - a.started_at)) < a.questions * (cfg->'xp'->>'sec_per_question')::numeric then raise exception 'too_fast'; end if;
  select count(*) into done_today from public.lesson_attempts where user_id = uid and kind = 'lesson' and status = 'done' and finished_day = d;
  if done_today >= (cfg->'xp'->>'completions_per_day')::int then raise exception 'rate_limited'; end if;

  select count(*) filter (where not correct), count(*) > 0 into wrong_rows, has_rows from public.exercise_attempts where attempt_id = a.id;
  if need_answers and exists (
       select 1 from public.questions q
       where q.lesson_id = a.lesson_id and q.type <> 'intro' and q.published and private.q_valid(q.type, q.data)
         and not exists (select 1 from public.exercise_attempts e where e.attempt_id = a.id and e.question_id = q.id and e.correct)) then
    raise exception 'incomplete';          -- every exercise must have a correct, server-recorded answer
  end if;
  if has_rows then mis := least(greatest(wrong_rows, a.misses), 60); end if;
  ps := private.ps_get(uid);
  select * into l from public.lessons where id = a.lesson_id;
  lv0 := private.level_of(ps.xp);
  select exists (select 1 from public.lesson_completions where user_id = uid and lesson_id = a.lesson_id) into first_time; first_time := not first_time;
  stars := case when mis = 0 then 3 when mis <= 2 then 2 else 1 end;

  if first_time then
    raw := coalesce(l.xp, 8) + stars * star_xp;
  else
    raw := (cfg->'xp'->>'repeat')::int;
  end if;

  insert into public.lesson_completions (user_id, lesson_id, best_stars) values (uid, a.lesson_id, stars)
  on conflict (user_id, lesson_id) do update set best_stars = greatest(lesson_completions.best_stars, excluded.best_stars),
        times = lesson_completions.times + 1, last_at = now();

  if first_time then
    unit_done := exists (select 1 from public.lessons x where x.unit_id = l.unit_id and x.published)
      and not exists (select 1 from public.lessons x where x.unit_id = l.unit_id and x.published
                      and not exists (select 1 from public.lesson_completions c where c.user_id = uid and c.lesson_id = x.id));
    if unit_done then raw := raw + (cfg->'xp'->>'unit')::int; end if;
  end if;
  raw := least(raw, (cfg->'xp'->>'max_lesson_xp')::int);

  -- XP multipliers: admin event and personal boost, never stacked
  gmult := cfg->'multiplier';
  if coalesce((gmult->>'value')::numeric, 1) > 1 and (coalesce(gmult->>'until', '') = '' or (gmult->>'until')::timestamptz > now()) then mult := (gmult->>'value')::numeric; end if;
  if ps.boost_until is not null and ps.boost_until > now() then mult := greatest(mult, ps.boost_mult); end if;
  xp := round(raw * mult)::int;
  cap := (cfg->'xp'->>'daily_cap')::int;
  select coalesce(sum(amount), 0) into today_xp from public.xp_events where user_id = uid and day = d and kind in ('lesson','practice');
  xp := greatest(0, least(xp, cap - today_xp));

  ev := private.touch_streak(uid);
  perform private.xp_add(uid, xp, 'lesson', a.lesson_id, jsonb_build_object('stars', stars, 'mistakes', mis, 'words', a.words, 'speaking', a.speaking));

  update public.lesson_attempts set status = 'done', finished_at = now(), finished_day = d, mistakes = mis where id = a.id;
  if first_time then
    g := (cfg->'gems'->>'lesson')::int + case when stars = 3 then (cfg->'gems'->>'perfect')::int else 0 end + case when unit_done then (cfg->'gems'->>'unit')::int else 0 end;
    -- ONE first-completion reward per lesson per account: the key is the lesson, not the attempt, so it survives
    -- reset_my_progress() and a reset + replay can no longer farm gems. g reports what was really paid (0 if nothing was paid).
    if not private.gem_add(uid, g, 'lesson_first', a.lesson_id, jsonb_build_object('lesson', a.lesson_id, 'attempt', a.id)) then g := 0; end if;
  else
    g := (cfg->'gems'->>'repeat')::int;
    perform private.gem_add(uid, g, 'lesson', a.id::text, jsonb_build_object('lesson', a.lesson_id));
  end if;

  -- daily goal reward, once per local day
  select * into ps from public.player_state where user_id = uid;
  if ps.day = d and ps.day_xp >= ps.goal then
    goal_hit := private.gem_add(uid, (cfg->'gems'->>'goal')::int, 'goal', d::text, '{}'::jsonb);
    if goal_hit then g := g + (cfg->'gems'->>'goal')::int; end if;
  end if;

  ach := private.check_achievements(uid);
  select * into ps from public.player_state where user_id = uid;
  lv1 := private.level_of(ps.xp);

  res := jsonb_build_object('xp', xp, 'raw', raw, 'mult', mult, 'stars', stars, 'gems', g, 'first', first_time, 'unit_done', unit_done,
    'goal_hit', goal_hit, 'level_up', case when lv1 > lv0 then lv1 end, 'streak_event', ev, 'achievements', ach, 'accuracy_mistakes', mis,
    'state', private.state_json(uid));
  update public.lesson_attempts set result = res where id = a.id;
  return res;
end $$;
