-- Lingora Phase 1 migration 014 (stability). Additive and idempotent: three function bodies are replaced in place; no table, column or row changes.
--  P1-02 private.touch_streak / public.claim_daily_reward: a client-reported time zone that moves the local date BACKWARDS no longer counts as a new day.
--        Before: flipping the reported zone (get_my_state(p_tz) accepts any value in -840..840) pushed the streak forward several times per real day
--        and collected streak-milestone gems / XP / freezes. Same flip allowed several daily-reward claims.
--  P1-05 public.admin_list_users: the 'free' filter now means "no ACTIVE VIP" (matches the 'vip' filter). A VIP that is scheduled for the future
--        was in neither list.
-- Rollback: re-run the three definitions from the previous SETUP.sql section.
create or replace function private.touch_streak(uid uuid) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare ps public.player_state; d date := private.local_day(uid); miss int; ev jsonb := '{}'::jsonb; cfg jsonb := private.cfg();
        m jsonb; mx int := coalesce((cfg->'streak'->>'max_freeze')::int, 2);
begin
  select * into ps from public.player_state where user_id = uid for update;
  -- P1-02: `>=`, not `=`. A client that reports an earlier time zone makes today's local date older than last_day; that used to count
  -- as a new day (streak +1, milestone gems) and let the streak be pushed forward several times per real day.
  if ps.last_day is not null and ps.last_day >= d then return ev; end if;
  if ps.last_day is null then ps.streak := 1;
  else
    miss := (d - ps.last_day) - 1;
    if miss <= 0 then ps.streak := ps.streak + 1;
    elsif miss <= ps.freezes then ps.freezes := ps.freezes - miss; ps.streak := ps.streak + 1; ev := jsonb_build_object('froze', miss);
    else ps.streak := 1;
    end if;
  end if;
  ps.last_day := d; ps.best_streak := greatest(ps.best_streak, ps.streak);
  update public.player_state set streak = ps.streak, best_streak = ps.best_streak, last_day = d, freezes = ps.freezes where user_id = uid;
  -- streak milestones, once each
  select x into m from jsonb_array_elements(coalesce(cfg->'streak'->'milestones', '[]'::jsonb)) x where (x->>'d')::int = ps.streak limit 1;
  if m is not null and (ps.milestones->>(ps.streak::text)) is null then
    update public.player_state set milestones = milestones || jsonb_build_object(ps.streak::text, extract(epoch from now())::bigint) where user_id = uid;
    if coalesce((m->>'xp')::int, 0) > 0 then perform private.xp_add(uid, (m->>'xp')::int, 'streak', ps.streak::text, '{}'::jsonb); end if;
    if coalesce((m->>'freeze')::int, 0) > 0 then
      update public.player_state set freezes = least(mx, freezes + (m->>'freeze')::int) where user_id = uid;
    end if;
    if coalesce((m->>'boost')::int, 0) > 0 then
      update public.player_state set boost_until = now() + make_interval(mins => (m->>'boost')::int), boost_mult = 2 where user_id = uid;
    end if;
    if coalesce((m->>'gems')::int, 0) > 0 then perform private.gem_add(uid, (m->>'gems')::int, 'streak', ps.streak::text, '{}'::jsonb); end if;
    ev := ev || jsonb_build_object('milestone', m);
  end if;
  return ev;
end $$;

create or replace function public.claim_daily_reward() returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); ps public.player_state; d date := private.local_day(uid); cfg jsonb := private.cfg(); arr jsonb := cfg->'gems'->'daily';
        n int; amt int; ok boolean;
begin
  if uid is null then raise exception 'denied'; end if;
  ps := private.ps_get(uid);
  if ps.login_day is not null and ps.login_day >= d then raise exception 'already_claimed'; end if;   -- P1-02: `>=` (time-zone flip guard)
  n := case when ps.login_day = d - 1 then ps.login_streak + 1 else 1 end;
  amt := (arr->>(((n - 1) % jsonb_array_length(arr))::int))::int;
  ok := private.gem_add(uid, amt, 'daily', d::text, jsonb_build_object('day', n));
  if not ok then raise exception 'already_claimed'; end if;
  update public.player_state set login_day = d, login_streak = n where user_id = uid;
  return jsonb_build_object('gems', amt, 'day', n, 'state', private.state_json(uid));
end $$;

create or replace function public.admin_list_users(p_q text default '', p_filter text default 'all', p_sort text default 'created',
  p_dir text default 'desc', p_limit int default 25, p_offset int default 0) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare q text := private.like_pat(p_q); tot int; rows jsonb; lim int := least(greatest(coalesce(p_limit, 25), 1), 100);
        asc_ boolean := lower(coalesce(p_dir, 'desc')) = 'asc';
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  with base as (
    select p.id, p.email, p.name, p.username, p.role, p.suspended, p.created_at, p.vip_until, p.vip_from,
           (p.vip_until is not null and p.vip_until > now() and (p.vip_from is null or p.vip_from <= now())) as vip_active,
           coalesce(s.xp, 0) as xp, coalesce(s.streak, 0) as streak, s.last_day,
           (select count(*) from public.lesson_completions lc where lc.user_id = p.id) as lessons_done
    from public.profiles p left join public.player_state s on s.user_id = p.id
    where (btrim(coalesce(p_q, '')) = '' or lower(p.email) like q escape E'\\' or lower(p.name) like q escape E'\\' or lower(coalesce(p.username, '')) like q escape E'\\' or p.id::text = btrim(p_q))
      and case coalesce(p_filter, 'all')
        when 'vip' then p.vip_until is not null and p.vip_until > now() and (p.vip_from is null or p.vip_from <= now())
        when 'expired' then p.vip_until is not null and p.vip_until <= now()
        when 'free' then not (p.vip_until is not null and p.vip_until > now() and (p.vip_from is null or p.vip_from <= now()))
        when 'staff' then p.role <> 'user'
        when 'suspended' then p.suspended
        else true end
  )
  , numbered as (
    select b.*, count(*) over () as tot, row_number() over (order by
        case when p_sort = 'xp' and not asc_ then b.xp end desc nulls last, case when p_sort = 'xp' and asc_ then b.xp end asc nulls last,
        case when p_sort = 'name' and not asc_ then lower(b.name) end desc nulls last, case when p_sort = 'name' and asc_ then lower(b.name) end asc nulls last,
        case when p_sort = 'vip_until' and not asc_ then b.vip_until end desc nulls last, case when p_sort = 'vip_until' and asc_ then b.vip_until end asc nulls last,
        case when p_sort not in ('xp','name','vip_until') and asc_ then b.created_at end asc, case when p_sort not in ('xp','name','vip_until') and not asc_ then b.created_at end desc,
        b.id) as rn
    from base b)
  select coalesce(max(n.tot), 0), coalesce(jsonb_agg((to_jsonb(n) - 'tot' - 'rn') order by n.rn) filter (where n.rn > greatest(coalesce(p_offset, 0), 0) and n.rn <= greatest(coalesce(p_offset, 0), 0) + lim), '[]'::jsonb)
    into tot, rows from numbered n;
  return jsonb_build_object('total', tot, 'rows', rows);
end $$;
