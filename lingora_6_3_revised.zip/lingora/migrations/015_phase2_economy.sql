-- Lingora Phase 2 migration 015: the coin economy and individual VIP-lesson unlocks.
-- Additive and idempotent (safe to run twice). No existing balance, purchase or progress row is changed.
--  1. Every learner earns Lingora Coins (gems) from learning. Before, only VIP members did (005_gem_policy). The owner can still switch
--     it off again with Admin > Settings economy.gems.free_earn = false. Earning stays bounded: first completion of each lesson only (key = lesson),
--     the daily goal once a day, streak milestones once each, quests once per period, and now practice sessions at most gems.practice_daily_cap (default 5) per rolling 24 h.
--  2. lessons.vip lessons (in a free unit / free course) can be unlocked one by one for coins: table lesson_unlocks (own rows readable, writes only through
--     public.unlock_lesson), public.shop_lessons() for the Shop, owned lessons are readable through the same RLS as VIP and startable through start_lesson.
--  3. state_json carries "unlocked" (the lesson ids the account owns) so the client never has to guess.
-- Price: lessons.unlock_price, else economy.shop.lesson_unlock, else 80 coins.

alter table public.lessons add column if not exists unlock_price int check (unlock_price is null or (unlock_price between 1 and 100000));

create table if not exists public.lesson_unlocks (
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id text not null references public.lessons(id) on delete cascade,
  price int not null check (price >= 0),
  created_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);
alter table public.lesson_unlocks enable row level security;
drop policy if exists "own unlocks" on public.lesson_unlocks;
create policy "own unlocks" on public.lesson_unlocks for select using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.lesson_unlocks from anon, authenticated;

create or replace function public.owns_lesson(p_lesson text) returns boolean
language sql stable security definer set search_path = public as $$
  select auth.uid() is not null and exists (select 1 from public.lesson_unlocks where user_id = auth.uid() and lesson_id = p_lesson)
$$;
grant execute on function public.owns_lesson(text) to anon, authenticated;

-- gem_add: free accounts earn (unless the owner switched it off); practice coins are capped per rolling 24 h
create or replace function private.gem_add(uid uuid, delta int, p_reason text, p_ref text, p_meta jsonb) returns boolean
language plpgsql security definer set search_path = public, private as $$
declare bal int; ins bigint; cap int; got int;
begin
  if delta = 0 then return false; end if;
  if delta > 0 and p_reason not in ('admin','purchase','vip_daily') and not private.is_vip(uid)
     and not coalesce((private.cfg()->'gems'->>'free_earn')::boolean, true) then
    return false;   -- the owner turned free earning off
  end if;
  if delta > 0 and p_reason = 'practice' then
    cap := coalesce((private.cfg()->'gems'->>'practice_daily_cap')::int, 5);
    select coalesce(sum(g.delta), 0) into got from public.gem_transactions g
      where g.user_id = uid and g.reason = 'practice' and g.created_at > now() - interval '24 hours';
    delta := least(delta, greatest(cap - got, 0));
    if delta <= 0 then return false; end if;
  end if;
  insert into public.gem_transactions (user_id, delta, reason, ref, balance_after, meta)
  values (uid, delta, p_reason, coalesce(p_ref, ''), 0, coalesce(p_meta, '{}'::jsonb))
  on conflict (user_id, reason, ref) do nothing returning id into ins;
  if ins is null then return false; end if;
  update public.player_state set gems = gems + delta, updated_at = now() where user_id = uid returning gems into bal;
  if bal is null then raise exception 'no_state'; end if;
  update public.gem_transactions set balance_after = bal where id = ins;
  return true;
exception when check_violation then
  raise exception 'not_enough_gems';
end $$;

-- who can read a lesson / its questions: staff, VIP, or (for a lesson-level VIP flag only) the account that unlocked it
drop policy if exists "lessons read" on public.lessons;
create policy "lessons read" on public.lessons for select using (
  public.is_editor()
  or (published and exists (select 1 from public.units u join public.courses c on c.id = u.course_id
        where u.id = lessons.unit_id and u.published and c.published and not c.archived
          and (not (u.vip or c.vip or lessons.vip) or public.is_vip() or (not (u.vip or c.vip) and public.owns_lesson(lessons.id)))))
);
drop policy if exists "questions read" on public.questions;
create policy "questions read" on public.questions for select using (
  public.is_editor()
  or (published and exists (select 1 from public.lessons l join public.units u on u.id = l.unit_id join public.courses c on c.id = u.course_id
        where l.id = questions.lesson_id and l.published and u.published and c.published and not c.archived
          and (not (u.vip or c.vip or l.vip) or public.is_vip() or (not (u.vip or c.vip) and public.owns_lesson(l.id)))))
);

create or replace function public.locked_lessons() returns jsonb
language sql stable security definer set search_path = public as $$
  select case when public.is_vip() then '[]'::jsonb else coalesce((
    select jsonb_agg(jsonb_build_object('id', l.id, 'unit_id', l.unit_id, 'title', l.title, 'position', l.position) order by l.position)
    from public.lessons l join public.units u on u.id = l.unit_id join public.courses c on c.id = u.course_id
    where l.published and u.published and c.published and not c.archived and (u.vip or c.vip or l.vip)
      and not (not (u.vip or c.vip) and public.owns_lesson(l.id))), '[]'::jsonb) end
$$;
grant execute on function public.locked_lessons() to authenticated;

create or replace function public.start_lesson(p_lesson text, p_kind text default 'lesson', p_questions int default null) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); ps public.player_state; l public.lessons; u public.units; c public.courses; n int; w int; sp int; att_id uuid;
        unl boolean; isvip boolean;
begin
  if uid is null then raise exception 'denied'; end if;
  if exists (select 1 from public.profiles where id = uid and suspended) then raise exception 'denied'; end if;
  perform private.rl('start', 240, 3600);
  ps := private.ps_get(uid);
  isvip := private.is_vip(uid);
  unl := isvip or (ps.unlimited_until is not null and ps.unlimited_until > now());
  if p_kind = 'practice' then
    n := least(greatest(coalesce(p_questions, 8), 3), 40); w := 0; sp := 0;
  elsif p_kind = 'lesson' then
    select * into l from public.lessons where id = p_lesson;
    if not found then raise exception 'not_found'; end if;
    select * into u from public.units where id = l.unit_id;
    select * into c from public.courses where id = u.course_id;
    if not (public.is_editor() or (l.published and u.published and c.published and not c.archived and (not (u.vip or c.vip or l.vip) or isvip or (not (u.vip or c.vip) and public.owns_lesson(l.id))))) then
      raise exception 'denied';
    end if;
    select count(*), count(*) filter (where type = 'intro'), count(*) filter (where type in ('speak','listen')) into n, w, sp
      from public.questions where lesson_id = l.id;
    if n = 0 then raise exception 'empty_lesson'; end if;
    if ps.hearts <= 0 and not unl then raise exception 'no_hearts'; end if;
  else
    raise exception 'invalid';
  end if;
  insert into public.lesson_attempts (user_id, lesson_id, kind, questions, words, speaking)
  values (uid, case when p_kind = 'lesson' then p_lesson end, p_kind, n, w, sp) returning lesson_attempts.id into att_id;
  return jsonb_build_object('attempt_id', att_id, 'questions', n, 'state', private.state_json(uid));
end $$;

create or replace function private.state_json(uid uuid) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare ps public.player_state; cfg jsonb := private.cfg(); iv numeric := (cfg->'hearts'->>'regen_minutes')::numeric * 60;
        mx int := (cfg->'hearts'->>'max')::int; d date := private.local_day(uid); alive boolean; vip boolean := private.is_vip(uid);
        unl boolean; unl_l jsonb; lv jsonb; dl jsonb := cfg->'gems'->'daily'; claim boolean; nexti int; ach jsonb; comp jsonb;
begin
  select * into ps from public.player_state where user_id = uid;
  alive := ps.last_day is not null and ps.last_day >= d - 1 - ps.freezes;
  unl := vip or (ps.unlimited_until is not null and ps.unlimited_until > now());
  lv := private.xp_to_next(ps.xp);
  claim := ps.login_day is distinct from d;
  nexti := case when ps.login_day = d then ps.login_streak
                when ps.login_day = d - 1 then ps.login_streak else 0 end;
  select coalesce(jsonb_object_agg(achievement_id, extract(epoch from earned_at) * 1000), '{}'::jsonb) into ach from public.user_achievements where user_id = uid;
  select coalesce(jsonb_agg(lesson_id order by lesson_id), '[]'::jsonb) into unl_l from public.lesson_unlocks where user_id = uid;
  select coalesce(jsonb_object_agg(lesson_id, best_stars), '{}'::jsonb) into comp from public.lesson_completions where user_id = uid;
  return jsonb_build_object(
    'xp', ps.xp, 'gems', ps.gems, 'level', lv,
    'hearts', case when unl then mx else ps.hearts end, 'hearts_max', mx, 'unlimited', unl,
    'unlimited_until', ps.unlimited_until, 'vip', vip,
    'next_heart_at', case when not unl and ps.hearts < mx then ps.hearts_at + make_interval(secs => iv) end,
    'regen_minutes', (cfg->'hearts'->>'regen_minutes')::int, 'refill_gems', (cfg->'hearts'->>'refill_gems')::int,
    'streak', case when alive then ps.streak else 0 end, 'best_streak', ps.best_streak, 'streak_today', ps.last_day = d,
    'freezes', ps.freezes, 'boost_until', case when ps.boost_until > now() then ps.boost_until end, 'boost_mult', ps.boost_mult,
    'goal', ps.goal, 'day', d, 'day_xp', case when ps.day = d then ps.day_xp else 0 end,
    'daily', jsonb_build_object('can_claim', claim, 'day_index', case when claim then (nexti % jsonb_array_length(dl)) else ((nexti - 1) % jsonb_array_length(dl)) end,
                                'rewards', dl, 'streak', case when claim and ps.login_day < d - 1 then 0 else ps.login_streak end),
    'achievements', ach, 'done', comp, 'unlocked', unl_l, 'server_time', now());
end $$;



-- the lessons a learner can buy with coins: VIP-flagged lessons inside a free unit of a free course
create or replace function public.shop_lessons() returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); dflt int;
begin
  if uid is null then raise exception 'denied'; end if;
  dflt := coalesce((private.cfg()->'shop'->>'lesson_unlock')::int, 80);
  return coalesce((select jsonb_agg(jsonb_build_object('id', l.id, 'title', l.title, 'unit', u.title, 'course_id', c.id, 'xp', l.xp,
            'price', coalesce(l.unlock_price, dflt), 'owned', exists (select 1 from public.lesson_unlocks k where k.user_id = uid and k.lesson_id = l.id),
            'questions', (select count(*) from public.questions q where q.lesson_id = l.id))
          order by c.position, u.position, l.position)
     from public.lessons l join public.units u on u.id = l.unit_id join public.courses c on c.id = u.course_id
     where l.vip and l.published and u.published and c.published and not c.archived and not u.vip and not c.vip), '[]'::jsonb);
end $$;
grant execute on function public.shop_lessons() to authenticated;

-- unlock_lesson: the only way a lesson unlock is created. Price is read from the database, never from the browser; the player row is locked
-- first, so two parallel taps cannot both pay; a second call for a lesson already owned changes nothing; the balance can never go below zero.
create or replace function public.unlock_lesson(p_lesson text, p_idem text) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); l public.lessons; u public.units; c public.courses; ps public.player_state; price int; ok boolean;
begin
  if uid is null then raise exception 'denied'; end if;
  if exists (select 1 from public.profiles where id = uid and suspended) then raise exception 'denied'; end if;
  if p_idem is null or length(p_idem) < 8 or length(p_idem) > 80 or p_lesson is null then raise exception 'invalid'; end if;
  perform private.rl('unlock', 60, 3600);
  perform private.ps_get(uid);
  select * into ps from public.player_state where user_id = uid for update;
  if exists (select 1 from public.lesson_unlocks where user_id = uid and lesson_id = p_lesson) then
    return jsonb_build_object('duplicate', true, 'lesson', p_lesson, 'state', private.state_json(uid));
  end if;
  select * into l from public.lessons where id = p_lesson;
  if not found then raise exception 'not_found'; end if;
  select * into u from public.units where id = l.unit_id;
  select * into c from public.courses where id = u.course_id;
  if not (l.published and u.published and c.published and not c.archived) then raise exception 'not_found'; end if;
  if not l.vip or u.vip or c.vip then raise exception 'not_unlockable'; end if;
  if private.is_vip(uid) then raise exception 'already_vip'; end if;
  price := coalesce(l.unlock_price, coalesce((private.cfg()->'shop'->>'lesson_unlock')::int, 80));
  if ps.gems < price then raise exception 'not_enough_gems'; end if;
  insert into public.lesson_unlocks (user_id, lesson_id, price) values (uid, l.id, price);
  ok := private.gem_add(uid, -price, 'unlock', l.id, jsonb_build_object('lesson', l.id, 'idem', p_idem));
  if price > 0 and not ok then raise exception 'duplicate'; end if;
  return jsonb_build_object('lesson', l.id, 'price', price, 'state', private.state_json(uid));
end $$;
grant execute on function public.unlock_lesson(text, text) to authenticated;
