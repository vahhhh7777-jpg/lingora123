-- Lingora 4.0 migration 012. Additive and idempotent: safe to run more than once, deletes and rewrites no data.
--
-- (a) ai_release(): give back an AI coach call when the model did not answer.
--     ai_reserve() counts a call BEFORE the model is asked (so limits cannot be bypassed). If the provider then fails or
--     times out, the learner must not lose one of the free daily calls. Only the server (service role) can call this.
-- (b) service-role check compatibility. ai_record(), coach_context() and apply_payment() decided "is this the server?" with
--     current_setting('request.jwt.claim.role'). Current PostgREST versions only set the JSON setting request.jwt.claims, so
--     on a current Supabase project the check can fail with 'denied' and the server could not record AI cost, read the
--     coach context or apply a verified payment. auth.role() understands both forms. The functions are patched in place
--     from their stored definitions (no other line changes); a database created from the new SETUP.sql is already patched.

create or replace function public.ai_release(p_user uuid) returns void
language plpgsql security definer set search_path = public, private as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then raise exception 'denied'; end if;
  update public.ai_usage set calls = greatest(calls - 1, 0) where user_id = p_user and day = current_date;
end $$;
revoke all on function public.ai_release(uuid) from public, anon, authenticated;
grant execute on function public.ai_release(uuid) to service_role;

do $$
declare f record; def text;
  old_chk constant text := 'current_setting(''request.jwt.claim.role'', true) is distinct from ''service_role''';
  new_chk constant text := 'coalesce(auth.role(), '''') <> ''service_role''';
begin
  for f in select p.oid from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.proname in ('ai_record', 'coach_context', 'apply_payment') loop
    def := pg_get_functiondef(f.oid);
    if position(old_chk in def) > 0 then
      execute replace(def, old_chk, new_chk);
    end if;
  end loop;
end $$;
