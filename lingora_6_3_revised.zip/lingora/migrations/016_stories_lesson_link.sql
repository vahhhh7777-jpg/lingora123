-- Lingora 6.3 migration 016: connect each story to one curriculum lesson.
-- Additive and idempotent; existing stories remain intact and unassigned until an editor links them.
alter table public.stories add column if not exists lesson_id text;
create index if not exists stories_lesson_idx on public.stories (lesson_id, published);
