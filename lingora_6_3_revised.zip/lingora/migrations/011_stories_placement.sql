-- Lingora 2.1 migration 011: stories, story progress, placement results.
-- Additive and idempotent: safe to run more than once, touches no existing table or row.
-- Requires the helpers already created by SETUP.sql: public.is_editor() (admins and editors).

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  language text not null check (language ~ '^[a-z]{2,3}$'),          -- course language code, for example 'en', 'fr'
  level text not null check (level in ('A1','A2','B1','B2','C1','C2')),
  title jsonb not null,                                              -- {"hy":"...","en":"..."}
  emoji text not null default '📖' check (char_length(emoji) <= 8),
  paragraphs jsonb not null default '[]'::jsonb,                     -- [{"t":"text","tr":"translation","audio":"https://..."}]
  vocab jsonb not null default '[]'::jsonb,                          -- [{"w":"word","tr":"translation"}]
  questions jsonb not null default '[]'::jsonb,                      -- [{"p":0,"q":"?","a":"answer","o":["wrong","wrong"],"x":"explanation"}]
  published boolean not null default false,
  position int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint stories_arrays check (jsonb_typeof(paragraphs)='array' and jsonb_typeof(vocab)='array' and jsonb_typeof(questions)='array'),
  -- a story can only be published when it has text and at least one question (no empty or broken stories)
  constraint stories_publish_ready check (not published or (jsonb_array_length(paragraphs) > 0 and jsonb_array_length(questions) > 0))
);
create index if not exists stories_lang_idx on public.stories (language, published, position);
alter table public.stories enable row level security;
drop policy if exists "stories read" on public.stories;
create policy "stories read" on public.stories for select using (published or public.is_editor());
drop policy if exists "stories staff write" on public.stories;
create policy "stories staff write" on public.stories for all using (public.is_editor()) with check (public.is_editor());

create table if not exists public.story_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  story_id uuid not null references public.stories(id) on delete cascade,
  stars int not null check (stars between 1 and 3),
  completed_at timestamptz not null default now(),
  primary key (user_id, story_id)
);
alter table public.story_progress enable row level security;
drop policy if exists "story progress own read" on public.story_progress;
create policy "story progress own read" on public.story_progress for select using (user_id = auth.uid());
-- no direct insert/update policy: rows are written only through record_story_progress()

create or replace function public.record_story_progress(p_story uuid, p_stars int)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if p_stars is null or p_stars < 1 or p_stars > 3 then raise exception 'invalid'; end if;
  if not exists (select 1 from public.stories s where s.id = p_story and s.published) then raise exception 'not_found'; end if;
  insert into public.story_progress (user_id, story_id, stars) values (auth.uid(), p_story, p_stars)
  on conflict (user_id, story_id) do update set stars = greatest(public.story_progress.stars, excluded.stars), completed_at = now();
end $$;
revoke all on function public.record_story_progress(uuid, int) from public;
grant execute on function public.record_story_progress(uuid, int) to authenticated;

create table if not exists public.placement_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  language text not null check (language ~ '^[a-z]{2,3}$'),
  cefr text not null check (cefr in ('A1','A2','B1','B2','C1','C2')),
  score int not null check (score >= 0),
  total int not null check (total > 0 and score <= total),
  created_at timestamptz not null default now()
);
create index if not exists placement_user_idx on public.placement_results (user_id, language, created_at desc);
alter table public.placement_results enable row level security;
drop policy if exists "placement own read" on public.placement_results;
create policy "placement own read" on public.placement_results for select using (user_id = auth.uid() or public.is_editor());

create or replace function public.record_placement(p_language text, p_cefr text, p_score int, p_total int)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if p_cefr not in ('A1','A2','B1','B2','C1','C2') or p_total is null or p_total < 1 or p_total > 60 or p_score < 0 or p_score > p_total or p_language !~ '^[a-z]{2,3}$' then raise exception 'invalid'; end if;
  -- at most 10 saved results per learner per hour (stops table spam)
  if (select count(*) from public.placement_results where user_id = auth.uid() and created_at > now() - interval '1 hour') >= 10 then raise exception 'limit'; end if;
  insert into public.placement_results (user_id, language, cefr, score, total) values (auth.uid(), p_language, p_cefr, p_score, p_total);
end $$;
revoke all on function public.record_placement(text, text, int, int) from public;
grant execute on function public.record_placement(text, text, int, int) to authenticated;
