# Lingora — Phase 1 report (stability & bug fixes)

Baseline: the untouched project passed all existing suites. Phase 1 added new tests first, proved they fail on the original, then fixed.

## Tests actually executed (final build)
| Suite | Result |
|---|---|
| SQL on PostgreSQL 16 (`tests/sql/run.sh`, incl. migration 014 applied twice) | 109 PASS, 0 FAIL (86 old + 23 new) |
| e2e against real PostgreSQL via bridge (`tests/e2e/run.sh`) | 43/43 |
| Stripe handler / AI coach unit tests | 19/19, 26/26 |
| Browser UI (Chromium): sync, mediacopy, reset, pay, admin | 21, 26, 17, 7, 8 passed |
| Contrast audit | 32 screens, 0 low-contrast |
| **New** `tests/ui/phase1.mjs` | 22/22 (incl. intro-screen and flag regressions) |
| **New** `tests/e2e/monkey.mjs` (admin + phone learner: every tab, ~254 controls clicked, 14 admin sections, leak check over 8 tab cycles) | all pass: 0 JS/console/5xx errors; intervals 2→2, listeners 43→43, DOM stable |
| New SQL `40_phase1.sql` on ORIGINAL SQL | 5 FAIL (S2, S3, D1, A1, A2) → all pass after migration 014 |

## Verified OK without changes
RLS enabled on every public table; learners cannot write is_admin/role/VIP/gems; all SECURITY DEFINER functions pin search_path; anon cannot call privileged functions; hearts (loss, regen, cap, refill price, idempotency), gems ledger = balance, XP ledger = balance, freeze logic; route guard for `#/admin`; admin tab performance.

## Remaining problems (not fixed — be aware)
1. **Real Supabase / Stripe / Edge Functions were never run** — only a PostgreSQL 16 + PostgREST-style stand-in. Run `SETUP.sql` (or migration 014 on an existing project) on a real project and smoke-test.
2. The client reports its own time zone; daily XP cap and completions/day are per reported local day, so a malicious client can still gain up to roughly 2 days of cap per 24h. Streak/daily-reward abuse is closed; a server-side time-zone change limit is a design decision for later.
3. Unsynced-progress snapshot after offline sign-out stays in this browser's localStorage (progress only, 30 days) until that account signs in again.
4. Speaking/listening answers are not server-verifiable (client claim) by design.
5. `e_other` is overridden by the economy text ("Could not save…") so unknown sign-in errors read oddly.
6. TRUNCATE privilege is granted to API roles by Supabase defaults; PostgREST does not expose it, so not exploitable via the API.
7. Service-worker cache bumped to `ee-v22`; users get new code on second load (stale-while-revalidate).

## Added after visual review of phone screenshots
- P1-10 blank intro screen (fixed-position content trapped by an animated container) and P1-11 flags shown as SVG text. Both are visual bugs that error-count tests cannot see; all main tabs, a lesson, and the dialogs were then screenshot-reviewed at 390px and look correct.
- Not done: a full visual review of every admin screen and every exercise type; test coverage there is functional (no errors), not pixel review.
