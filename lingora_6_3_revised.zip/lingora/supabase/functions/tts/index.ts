// Lingora neural TTS proxy (Supabase Edge Function, Deno).
// Keys live ONLY in Supabase secrets. Deploy:  supabase functions deploy tts
// Secrets:  supabase secrets set TTS_PROVIDER=openai OPENAI_API_KEY=...        (default provider)
//       or: supabase secrets set TTS_PROVIDER=google GOOGLE_TTS_API_KEY=...    (per-language neural voices)
// JWT verification stays ON (default): only signed-in users can call it.
const CORS = {
  'Access-Control-Allow-Origin': Deno.env.get('ALLOWED_ORIGIN') || '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (o: unknown, status = 400) =>
  new Response(JSON.stringify(o), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

// Google neural voice names per BCP-47 tag: [female, male]
const GOOGLE: Record<string, [string, string]> = {
  'en-US': ['en-US-Neural2-F', 'en-US-Neural2-D'], 'en-GB': ['en-GB-Neural2-A', 'en-GB-Neural2-B'],
  'es-ES': ['es-ES-Neural2-A', 'es-ES-Neural2-B'], 'fr-FR': ['fr-FR-Neural2-A', 'fr-FR-Neural2-B'],
  'de-DE': ['de-DE-Neural2-F', 'de-DE-Neural2-B'], 'it-IT': ['it-IT-Neural2-A', 'it-IT-Neural2-C'],
  'pt-PT': ['pt-PT-Wavenet-A', 'pt-PT-Wavenet-B'], 'pt-BR': ['pt-BR-Neural2-A', 'pt-BR-Neural2-B'],
  'ja-JP': ['ja-JP-Neural2-B', 'ja-JP-Neural2-C'], 'ko-KR': ['ko-KR-Neural2-A', 'ko-KR-Neural2-C'],
  'zh-CN': ['cmn-CN-Wavenet-A', 'cmn-CN-Wavenet-B'], 'ru-RU': ['ru-RU-Wavenet-A', 'ru-RU-Wavenet-B'],
  'tr-TR': ['tr-TR-Wavenet-A', 'tr-TR-Wavenet-B'],
};
const GOOGLE_LANGCODE: Record<string, string> = { 'zh-CN': 'cmn-CN' };

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json({ error: 'method' }, 405);
  let b: { text?: string; lang?: string; gender?: string; speed?: number };
  try { b = await req.json(); } catch { return json({ error: 'bad_json' }); }
  const text = String(b.text || '').trim();
  const lang = String(b.lang || 'en-US');
  if (!text || text.length > 400) return json({ error: 'bad_text' });
  if (!/^[a-z]{2,3}(-[A-Za-z]{2,4})?$/.test(lang)) return json({ error: 'bad_lang' });
  const speed = Math.max(0.6, Math.min(1.3, Number(b.speed) || 0.95));
  const provider = (Deno.env.get('TTS_PROVIDER') || 'openai').toLowerCase();
  try {
    if (provider === 'google') {
      const key = Deno.env.get('GOOGLE_TTS_API_KEY');
      if (!key) return json({ error: 'not_configured' }, 503);
      const pair = GOOGLE[lang] || GOOGLE[Object.keys(GOOGLE).find((k) => k.startsWith(lang.slice(0, 2))) || ''];
      if (!pair) return json({ error: 'lang_unsupported' }, 422);
      const code = Object.keys(GOOGLE).find((k) => GOOGLE[k] === pair)!;
      const r = await fetch('https://texttospeech.googleapis.com/v1/text:synthesize?key=' + key, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          input: { text },
          voice: { languageCode: GOOGLE_LANGCODE[code] || code, name: pair[b.gender === 'm' ? 1 : 0] },
          audioConfig: { audioEncoding: 'MP3', speakingRate: speed },
        }),
      });
      if (!r.ok) return json({ error: 'provider_error' }, 502);
      const j = await r.json();
      const bin = Uint8Array.from(atob(j.audioContent), (c) => c.charCodeAt(0));
      return new Response(bin, { headers: { ...CORS, 'Content-Type': 'audio/mpeg', 'Cache-Control': 'private, max-age=86400' } });
    }
    // openai (multilingual voices; language is inferred from the text)
    const key = Deno.env.get('OPENAI_API_KEY');
    if (!key) return json({ error: 'not_configured' }, 503);
    const r = await fetch('https://api.openai.com/v1/audio/speech', {
      method: 'POST', headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: Deno.env.get('OPENAI_TTS_MODEL') || 'gpt-4o-mini-tts',
        voice: b.gender === 'm' ? 'onyx' : 'nova', input: text, speed, response_format: 'mp3',
      }),
    });
    if (!r.ok) return json({ error: 'provider_error' }, 502);
    return new Response(r.body, { headers: { ...CORS, 'Content-Type': 'audio/mpeg', 'Cache-Control': 'private, max-age=86400' } });
  } catch {
    return json({ error: 'tts_failed' }, 502);
  }
});
