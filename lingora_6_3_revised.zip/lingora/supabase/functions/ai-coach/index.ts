// @ts-nocheck  (Deno runtime; the logic lives in ../_shared/coach.js and is unit-tested under Node)
// Lingora AI coach Edge Function.
//   supabase functions deploy ai-coach            (JWT verification stays ON: only signed-in users can call it)
//   supabase secrets set ANTHROPIC_API_KEY=... AI_MODEL=claude-haiku-4-5 ALLOWED_ORIGIN=https://your-site.example
// SUPABASE_URL, SUPABASE_ANON_KEY and SUPABASE_SERVICE_ROLE_KEY are injected by Supabase automatically.
import { handle } from '../_shared/coach.js';
Deno.serve((req: Request) => handle(req, (k: string) => Deno.env.get(k) ?? undefined));
