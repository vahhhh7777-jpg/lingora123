// @ts-nocheck  (Deno runtime; the logic lives in ../_shared/stripe.js and is unit-tested under Node)
// Lingora checkout-session creator. JWT verification stays ON (only signed-in learners can start a checkout).
//   supabase functions deploy create-checkout
//   supabase secrets set STRIPE_SECRET_KEY=sk_live_... SITE_URL=https://your-site.example ALLOWED_ORIGIN=https://your-site.example
import { handleCheckout } from '../_shared/stripe.js';
Deno.serve((req: Request) => handleCheckout(req, (k: string) => Deno.env.get(k) ?? undefined));
