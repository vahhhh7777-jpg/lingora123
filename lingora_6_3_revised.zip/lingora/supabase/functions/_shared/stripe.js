// Lingora payments: all logic of the `create-checkout` and `stripe-webhook` Edge Functions.
// Plain ES module with no Deno-only APIs (Web Crypto + fetch only), so the same file runs in Supabase (Deno) and in the Node tests.
//
// Security model
//  * The browser never says what a payment is worth. create-checkout takes only a plan id, re-reads the plan from the database
//    and the price from Stripe, refuses when they disagree, and binds the session to the VERIFIED caller (client_reference_id).
//  * stripe-webhook trusts nothing it has not verified: HMAC-SHA256 signature over the raw body (constant-time compare, 5 minute
//    tolerance), then the amount is compared with the plan, then public.apply_payment() (service role only) is called.
//    apply_payment is idempotent on (provider, provider_ref), so a replayed or duplicated event never grants VIP twice.
//  * STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET and SUPABASE_SERVICE_ROLE_KEY exist only in Supabase function secrets.
//  * Without those secrets both functions answer 503 "not_configured" and do nothing. Nothing here enables real payments by itself.

const enc = new TextEncoder();
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const PLAN = /^[a-z0-9_-]{2,24}$/;
export const LIMITS = { webhookBytes: 262144, checkoutBytes: 2048, toleranceSec: 300, timeoutMs: 15000 };

const CORS = (env) => ({
  'Access-Control-Allow-Origin': env('ALLOWED_ORIGIN') || '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Vary': 'Origin',
});
const reply = (env, obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { ...CORS(env), 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });

/* ---------- signature ---------- */
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
function safeEqual(a, b) {               // constant-time for equal-length strings
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0;
}
export async function hmacHex(secret, message) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return hex(await crypto.subtle.sign('HMAC', key, enc.encode(message)));
}
/* Stripe-Signature: t=<unix>,v1=<hex>[,v1=<hex>...]   -> { ok, reason } */
export async function verifyStripeSignature(rawBody, header, secret, nowSec = Math.floor(Date.now() / 1000), tolerance = LIMITS.toleranceSec) {
  if (!secret) return { ok: false, reason: 'no_secret' };
  if (typeof header !== 'string' || !header) return { ok: false, reason: 'no_header' };
  let t = null; const v1 = [];
  for (const part of header.split(',')) {
    const i = part.indexOf('='); if (i < 1) continue;
    const k = part.slice(0, i).trim(), v = part.slice(i + 1).trim();
    if (k === 't') t = v; else if (k === 'v1') v1.push(v);
  }
  if (!t || !/^\d{1,12}$/.test(t) || !v1.length) return { ok: false, reason: 'malformed' };
  if (Math.abs(nowSec - Number(t)) > tolerance) return { ok: false, reason: 'stale' };   // replay of an old, validly signed request
  const want = await hmacHex(secret, `${t}.${rawBody}`);
  return v1.some((s) => safeEqual(s, want)) ? { ok: true } : { ok: false, reason: 'mismatch' };
}

/* ---------- event interpretation (pure) ----------
   -> { action: 'grant' | 'fail' | 'refund' | 'ignore', ... }.  Never grants anything that Stripe has not marked as paid. */
const metaOf = (o) => (o && o.metadata) || {};
export function interpretEvent(ev) {
  if (!ev || typeof ev !== 'object' || !ev.type || !ev.data || !ev.data.object) return { action: 'ignore', why: 'shape' };
  const o = ev.data.object;
  switch (ev.type) {
    case 'checkout.session.completed':
    case 'checkout.session.async_payment_succeeded': {
      if (o.mode === 'subscription') return { action: 'ignore', why: 'subscription_uses_invoice_paid' };   // else the first period would be granted twice
      if (o.payment_status !== 'paid') return { action: 'ignore', why: 'not_paid_yet' };                  // async methods: wait for async_payment_succeeded
      return { action: 'grant', user: o.client_reference_id || metaOf(o).user_id, plan: metaOf(o).plan, ref: String(o.payment_intent || o.id || ''),
               paid: o.amount_total, expected: o.amount_subtotal != null ? o.amount_subtotal : o.amount_total, currency: o.currency };
    }
    case 'checkout.session.async_payment_failed':
      return { action: 'fail', user: o.client_reference_id || metaOf(o).user_id, plan: metaOf(o).plan, ref: 'failed:' + String(o.id || ''), paid: 0, expected: 0, currency: o.currency };
    case 'invoice.paid': {
      if (!o.amount_paid) return { action: 'ignore', why: 'zero_amount_invoice' };
      const sd = (o.subscription_details && o.subscription_details.metadata) || (o.parent && o.parent.subscription_details && o.parent.subscription_details.metadata)
        || (o.lines && o.lines.data && o.lines.data[0] && o.lines.data[0].metadata) || {};
      return { action: 'grant', user: sd.user_id, plan: sd.plan, ref: String(o.id || ''), paid: o.amount_paid, expected: o.subtotal != null ? o.subtotal : o.amount_paid, currency: o.currency };
    }
    case 'invoice.payment_failed': {
      const sd = (o.subscription_details && o.subscription_details.metadata) || (o.lines && o.lines.data && o.lines.data[0] && o.lines.data[0].metadata) || {};
      // the ref carries the attempt number: a later successful retry of the same invoice must still be able to be recorded as 'succeeded'
      return { action: 'fail', user: sd.user_id, plan: sd.plan, ref: 'failed:' + String(o.id || '') + ':' + (o.attempt_count || 0), paid: 0, expected: 0, currency: o.currency };
    }
    case 'charge.refunded': {
      if (!o.refunded) return { action: 'ignore', why: 'partial_refund' };                                 // only a full refund takes VIP away
      return { action: 'refund', ref: String(o.invoice || o.payment_intent || '') };
    }
    default: return { action: 'ignore', why: 'event_type' };         // customer.subscription.deleted etc.: paid periods stay valid until vip_until
  }
}

/* ---------- small helpers ---------- */
async function timed(fetchFn, url, init, ms) {
  const c = new AbortController(), t = setTimeout(() => c.abort(), ms);
  try { return await fetchFn(url, { ...init, signal: c.signal }); } finally { clearTimeout(t); }
}
const svcHeaders = (svc) => ({ apikey: svc, Authorization: 'Bearer ' + svc, 'Content-Type': 'application/json' });
const form = (o) => Object.entries(o).map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(String(v))).join('&');
export const validSiteUrl = (u) => /^https:\/\/[a-z0-9.-]+(:\d+)?(\/[^\s?#]*)?$/i.test(u || '') || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?(\/[^\s?#]*)?$/i.test(u || '');

/* ---------- stripe-webhook ---------- */
export async function handleWebhook(request, env, deps = {}) {
  const fetchFn = deps.fetch || fetch, now = deps.now ? deps.now() : Math.floor(Date.now() / 1000);
  const log = deps.log || ((...a) => console.error('[stripe-webhook]', ...a));
  if (request.method !== 'POST') return reply(env, { error: 'method' }, 405);
  const secret = env('STRIPE_WEBHOOK_SECRET'), url = env('SUPABASE_URL'), svc = env('SUPABASE_SERVICE_ROLE_KEY');
  if (!secret || !url || !svc) return reply(env, { error: 'not_configured' }, 503);

  const raw = await request.text();
  if (raw.length > LIMITS.webhookBytes) return reply(env, { error: 'too_large' }, 413);
  const sig = await verifyStripeSignature(raw, request.headers.get('stripe-signature'), secret, now);
  if (!sig.ok) { log('signature rejected:', sig.reason); return reply(env, { error: 'bad_signature' }, 400); }
  let ev; try { ev = JSON.parse(raw); } catch { return reply(env, { error: 'bad_json' }, 400); }

  const x = interpretEvent(ev);
  if (x.action === 'ignore') return reply(env, { received: true, ignored: x.why });

  try {
    if (x.action === 'refund') {
      if (!x.ref) return reply(env, { received: true, ignored: 'no_ref' });
      const r = await timed(fetchFn, `${url}/rest/v1/payments?provider=eq.stripe&provider_ref=eq.${encodeURIComponent(x.ref)}&select=user_id,plan_id,status&limit=1`, { headers: svcHeaders(svc) }, LIMITS.timeoutMs);
      if (!r.ok) { log('payment lookup failed', r.status); return reply(env, { error: 'lookup_failed' }, 500); }
      const row = (await r.json())[0];
      if (!row) return reply(env, { received: true, ignored: 'unknown_payment' });
      return await apply(row.user_id, row.plan_id, x.ref, 0, 'usd', 'refunded');
    }
    // grant / fail: everything about the payment must be self-consistent before the database is asked to change anything
    if (!UUID.test(String(x.user || '')) || !PLAN.test(String(x.plan || '')) || !x.ref) { log('event without a usable user/plan/ref', ev.id); return reply(env, { received: true, rejected: 'missing_metadata' }); }
    const pr = await timed(fetchFn, `${url}/rest/v1/vip_plans?id=eq.${encodeURIComponent(x.plan)}&select=id,price_cents,currency&limit=1`, { headers: svcHeaders(svc) }, LIMITS.timeoutMs);
    if (!pr.ok) { log('plan lookup failed', pr.status); return reply(env, { error: 'lookup_failed' }, 500); }
    const plan = (await pr.json())[0];
    if (!plan) { log('unknown plan', x.plan); return reply(env, { received: true, rejected: 'unknown_plan' }); }
    if (x.action === 'grant') {
      if (plan.price_cents == null) { log('plan has no online price', x.plan); return reply(env, { received: true, rejected: 'plan_not_online' }); }
      if (Number(x.expected) !== Number(plan.price_cents) || String(x.currency || '').toLowerCase() !== String(plan.currency).toLowerCase()) {
        log('amount/currency mismatch', ev.id, x.expected, x.currency, 'plan wants', plan.price_cents, plan.currency);
        return reply(env, { received: true, rejected: 'amount_mismatch' });       // 200: Stripe retrying will not make the amount right
      }
    }
    return await apply(x.user, x.plan, x.ref, x.paid || 0, String(x.currency || plan.currency).toLowerCase(), x.action === 'grant' ? 'succeeded' : 'failed');
  } catch (e) {
    log('webhook failed', String(e && e.message || e).slice(0, 160));
    return reply(env, { error: 'temporary' }, 500);                                 // network/timeouts: Stripe retries with backoff
  }

  async function apply(user, planId, ref, amount, currency, status) {
    const r = await timed(fetchFn, `${url}/rest/v1/rpc/apply_payment`, { method: 'POST', headers: svcHeaders(svc),
      body: JSON.stringify({ p_user: user, p_plan: planId, p_provider: 'stripe', p_ref: ref, p_amount: amount, p_currency: currency, p_status: status, p_raw: { event: ev.id, type: ev.type } }) }, LIMITS.timeoutMs);
    const j = await r.json().catch(() => ({}));
    if (r.ok) return reply(env, { received: true, status: j.status, duplicate: !!j.duplicate });
    const msg = String((j && (j.message || j.error)) || '');
    if (r.status >= 500) { log('apply_payment 5xx', r.status); return reply(env, { error: 'temporary' }, 500); }
    log('apply_payment refused:', msg.slice(0, 80));                                // e.g. invalid transition / unknown user: not retryable
    return reply(env, { received: true, rejected: msg.slice(0, 40) || 'refused' });
  }
}

/* ---------- create-checkout ---------- */
export async function handleCheckout(request, env, deps = {}) {
  const fetchFn = deps.fetch || fetch;
  const log = deps.log || ((...a) => console.error('[create-checkout]', ...a));
  if (request.method === 'OPTIONS') return new Response('ok', { headers: CORS(env) });
  if (request.method !== 'POST') return reply(env, { error: 'method' }, 405);
  const stripeKey = env('STRIPE_SECRET_KEY'), site = (env('SITE_URL') || '').replace(/\/+$/, ''), url = env('SUPABASE_URL'), anon = env('SUPABASE_ANON_KEY');
  if (!stripeKey || !url || !anon || !validSiteUrl(site)) return reply(env, { error: 'not_configured' }, 503);

  const raw = await request.text();
  if (raw.length > LIMITS.checkoutBytes) return reply(env, { error: 'bad_request' }, 413);
  let body; try { body = JSON.parse(raw); } catch { return reply(env, { error: 'bad_request' }, 400); }
  const plan = body && typeof body.plan === 'string' ? body.plan : '';
  if (!PLAN.test(plan)) return reply(env, { error: 'bad_request', field: 'plan' }, 400);

  const m = /^Bearer\s+(\S+)$/i.exec(request.headers.get('Authorization') || '');
  if (!m) return reply(env, { error: 'unauthorized' }, 401);
  const jwt = m[1];
  try {
    const ur = await timed(fetchFn, url + '/auth/v1/user', { headers: { apikey: anon, Authorization: 'Bearer ' + jwt } }, 8000);
    if (!ur.ok) return reply(env, { error: 'unauthorized' }, 401);
    const user = await ur.json();
    if (!user || !UUID.test(String(user.id || ''))) return reply(env, { error: 'unauthorized' }, 401);

    const hdr = { apikey: anon, Authorization: 'Bearer ' + jwt };
    const pr = await timed(fetchFn, `${url}/rest/v1/vip_plans?id=eq.${encodeURIComponent(plan)}&active=eq.true&select=id,price_cents,currency,provider_price&limit=1`, { headers: hdr }, 8000);
    const row = pr.ok ? (await pr.json())[0] : null;
    if (!row || row.price_cents == null || !row.provider_price || !/^price_[A-Za-z0-9]+$/.test(row.provider_price)) return reply(env, { error: 'plan_unavailable' }, 404);
    const sr = await timed(fetchFn, `${url}/rest/v1/profiles?id=eq.${user.id}&select=suspended&limit=1`, { headers: hdr }, 8000);
    const prof = sr.ok ? (await sr.json())[0] : null;
    if (prof && prof.suspended) return reply(env, { error: 'suspended' }, 403);

    // the price Stripe will actually charge must equal the price our database promises for this plan
    const sh = { Authorization: 'Bearer ' + stripeKey };
    const pq = await timed(fetchFn, 'https://api.stripe.com/v1/prices/' + row.provider_price, { headers: sh }, LIMITS.timeoutMs);
    if (!pq.ok) { log('stripe price lookup', pq.status); return reply(env, { error: 'provider_error' }, 502); }
    const price = await pq.json();
    if (!price.active || Number(price.unit_amount) !== Number(row.price_cents) || String(price.currency).toLowerCase() !== String(row.currency).toLowerCase()) {
      log('price mismatch for plan', plan); return reply(env, { error: 'price_mismatch' }, 409);
    }
    const recurring = price.type === 'recurring';
    const p = { mode: recurring ? 'subscription' : 'payment', 'line_items[0][price]': row.provider_price, 'line_items[0][quantity]': 1,
      client_reference_id: user.id, 'metadata[user_id]': user.id, 'metadata[plan]': plan,
      success_url: site + '/?paid=1', cancel_url: site + '/?paid=0' };
    if (user.email) p.customer_email = user.email;
    if (recurring) { p['subscription_data[metadata][user_id]'] = user.id; p['subscription_data[metadata][plan]'] = plan; }
    const cr = await timed(fetchFn, 'https://api.stripe.com/v1/checkout/sessions', { method: 'POST', headers: { ...sh, 'Content-Type': 'application/x-www-form-urlencoded' }, body: form(p) }, LIMITS.timeoutMs);
    if (!cr.ok) { log('stripe session', cr.status); return reply(env, { error: 'provider_error' }, 502); }
    const s = await cr.json();
    if (!s.url || !/^https:\/\/checkout\.stripe\.com\//.test(s.url)) return reply(env, { error: 'provider_error' }, 502);
    return reply(env, { url: s.url });
  } catch (e) {
    log('checkout failed', String(e && e.message || e).slice(0, 120));
    return reply(env, { error: 'provider_error' }, 502);
  }
}
