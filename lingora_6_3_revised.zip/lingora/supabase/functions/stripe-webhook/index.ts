// @ts-nocheck  (Deno runtime; the logic lives in ../_shared/stripe.js and is unit-tested under Node)
// Lingora Stripe webhook. NOT verified against real Stripe yet (no credentials were available): see README / BUG_TRACKER.
//   supabase functions deploy stripe-webhook --no-verify-jwt      (Stripe cannot send a Supabase JWT; the Stripe signature is the authentication)
//   supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_... SUPABASE_SERVICE_ROLE_KEY is injected automatically
import { handleWebhook } from '../_shared/stripe.js';
Deno.serve((req: Request) => handleWebhook(req, (k: string) => Deno.env.get(k) ?? undefined));
