# BUG_TRACKER

## Phase 1 (stability) — see PHASE1_REPORT.md
| ID | Severity | Status | Description | Files |
|---|---|---|---|---|
| P1-01 | High | FIXED, browser-tested (`tests/ui/phase1.mjs`) | Signing out wiped progress that had not reached the server yet (offline / failing sync): permanent loss | 13, 34, 19 |
| P1-02 | High | FIXED, SQL-tested (`40_phase1.sql` S2/S3/D1) | Changing the reported time zone moved the local date backwards and counted as a new day: streak (+milestone XP, freezes) could be advanced several times per real day; daily reward claimable repeatedly | migrations/014 |
| P1-03 | Medium | FIXED, browser-tested | If the sign-out request failed (offline) the app looked signed out but the session stayed stored and came back on reload | 12, 34 |
| P1-04 | Medium | FIXED, browser-tested | Client treated a VIP that starts in the future as active (server did not) | 11 |
| P1-05 | Low | FIXED, SQL-tested | Admin "free" filter hid scheduled-VIP accounts from both free and VIP lists | migrations/014 |
| P1-06 | Medium | FIXED, browser-tested | "Email not confirmed" (Supabase default) showed a generic unrelated error; rate-limit errors too | 11, 01 |
| P1-07 | High | FIXED, browser-tested | If the profile could not be read right after a correct password, the app stayed half signed in (onboarding screen, no way to retry) | 13 |
| P1-10 | High | FIXED, browser-tested | The intro screen showed only a "Skip" button on a blank purple screen: the page-enter animation (`fill-mode: both`) kept a transform on the page container, which made `position:fixed` children relative to the (tall) page instead of the screen, so the intro content sat below the fold. Automation hides the intro, so no earlier test saw it. Fix: `backwards` fill mode (styles.css) | styles.css |
| P1-11 | High | FIXED, browser-tested | Flags on the onboarding / language lists were printed as SVG source text (flag HTML was escaped twice) | 17, 18, 22, 25 |
| P1-09 | Low | FIXED, browser-tested (goal) | Fire-and-forget server calls (heart loss, goal, notifications, story/placement results, league, UI overrides) failed silently; now logged, goal save also tells the user | 11, 14, 19, 29, 31, 33, 37, 41 |


## Session 4 (full audit, PostgreSQL 16 + Chromium available): see AUDIT_REPORT.md
| ID | Severity | Status | Description | Root cause | Files |
|---|---|---|---|---|---|
| B-004 | Critical | FIXED + browser-verified (`tests/ui/admin.mjs`, `mediacopy.mjs`) | Opening the Admin tab froze, then crashed Chromium | `p3loadStats` is called from inside the render function and a failed/empty `admin_stats` reply never marked the load as final, so every render re-requested forever (fetch -> render -> fetch). Same shape in `p3loadPay`. Also `readAll` could loop forever on a non-array reply | 29-part-3-admin..., 12-backends |
| B-006 | High | FIXED + browser-verified (`tests/ui/reset.mjs`) + SQL (`30_reset_progress.sql`) | Reset progress was fake in cloud mode: only the browser copy was cleared; server XP/lessons were re-applied on the next sync | no server-side reset existed; `SYNC.overwrite` lived in memory only | migrations/013, 13-cache-offline-and-sync, 14-..., 12-backends |
| B-007 | High | FIXED | "Reset progress" button was not rendered anywhere (handlers and texts existed) | row lost from Settings > Manage | 19-settings-... |
| B-008 | High | FIXED (SQL-tested) | Reset + replay would have let a player collect the first-completion gems again | gem reward was keyed by attempt id | migrations/013 (`complete_lesson`) |
| B-001 | Medium | FIXED for real now (26/26 in Chromium) | Admin Media "copy URL" dead | the earlier fix was never reachable: the `mediacopy` case sat inside a switch behind `if(a.slice(0,2)!=='p3')return false` | 29-part-3-admin... |
| B-009 | High | FIXED | Admin user/progress list always failed against real PostgREST | `readAll` ordered `progress` by a non-existent `id` column | 12-backends |
| B-010 | High | FIXED (code + 19 tests; real Stripe NOT verified) | README documented `create-checkout`, `stripe-webhook`, `_shared/stripe_sig.js`; none of them existed in the project | missing files | supabase/functions/* |
| B-011 | Low | FIXED | Admin-controlled course `flag` field was inserted into HTML unescaped | missing `esc()` | 17, 18, 22 |
| B-002 | Low | Fixed (static) | Progress-sync failures were silently swallowed | empty catch handlers | 13-cache-offline-and-sync |
| B-003 / B-005 | - | as before | admin progress-load banner; dark-theme contrast (re-run: 32 screens, 0 low-contrast) | | |

---- Older notes below ----

## Session 2026-11-14 (quick pass, no PostgreSQL/Chromium in this environment)
| ID | Severity | Status | Description | Root cause | Files |
|---|---|---|---|---|---|
| B-001 | Medium | Fixed (static; not browser-verified) | Admin > Media "copy URL" button did nothing | `data-a="mediacopy"` had no handler in the action dispatcher | src/js/29-part-3-admin-server-side-users-vip-manag.js (+ rebuilt site/app.js) |
| B-002 | Low | Fixed (static) | Progress-sync failures were silently swallowed | empty catch handlers | src/js/13-cache-offline-and-sync.js |

## Tests this session
- PASS: `node build.mjs`, `node build.mjs --check`, `node --check` on every src/js file and site/app.js.
- PASS: static scan, every `data-a` action in the source has a handler (after B-001).
- NOT RUN (environment): `tests/sql/run.sh`, `tests/ai/coach.test.mjs`, `tests/e2e/run.sh`, `tests/live/smoke.mjs`. They need a local PostgreSQL server (and Chromium for e2e); neither is installed and the network is disabled. `coach.test.mjs` failed with ECONNREFUSED 127.0.0.1:54321 because the bridge server (needs PostgreSQL) was not running. Not an app bug.
- Unverified: real Supabase, real model, TTS deployment, email flows.

## Open / not fixed
- Swallowed errors: `saveProgress`/`pushProgress` failures now log a console warning (B-002, Low, fixed; no user-visible retry UI yet). `27-admin...:365` still swallows: OPEN, Low.
- Dark-theme `.chip` contrast outside the AI chat: OPEN, Low.

## Checkpoint 2026-11-14 (round 3, INTERMEDIATE package)
Status legend: FIXED+TESTED / FIXED, NOT RE-TESTED / KNOWN / BLOCKED / NOT IMPLEMENTED
| ID | Status | Notes |
|---|---|---|
| B-001 admin media copy buttons | FIXED, NOT TESTED in browser | Shared `copyMediaUrl` helper (both buttons). `tests/ui/mediacopy.mjs` has NOT run: see B-004. |
| B-002 sync recovery | FIXED+TESTED against in-memory stub only (21/21, 4 runs) | Run happened before the copyMediaUrl change; re-run required. Not verified against real Supabase. |
| B-003 admin progress-load error swallowed (27-admin:365) | FIXED, NOT TESTED in browser | Banner + Retry (`admretry`). Blocked by B-004. |
| B-004 Chromium "Target crashed" when opening Admin tab in stub cloud mode | KNOWN, OPEN, ROOT CAUSE UNKNOWN | Could be an app loop/memory issue or a stub artifact. First task next session. |
| B-005 dark-theme chip / contrast | FIXED+TESTED for 32 non-admin screens (0 failures; gradients not measurable) | Admin, active AI chat, modals NOT covered. |
| B-006 reset-progress failure + reload can bring old server progress back | KNOWN, OPEN | `SYNC.overwrite` is not persisted. Needs a persisted pending-reset marker + tests. |
