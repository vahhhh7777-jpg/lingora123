# LINGORA 6.3 — Accessibility verification checklist

Status legend
- **VERIFIED (automated)** – executed in headless Chromium during 6.3; the test name is given. Automation finds structural problems only.
- **NOT VERIFIED** – needs a human with a real screen reader / device. **No result is claimed.** Tick and date the box when someone really does it.

No NVDA, JAWS, VoiceOver, TalkBack, or physical phone/tablet was available during 6.3. Every screen-reader and device row below is therefore NOT VERIFIED.

## A. What was verified automatically
| # | Item | Status | Evidence |
|---|------|--------|----------|
| A1 | Skip link is the first Tab stop and moves focus to `<main>` | VERIFIED (automated) | `tests/ui/a11y62.mjs` |
| A2 | Each main screen has a heading and a unique document title | VERIFIED (automated) | `a11y62.mjs` |
| A3 | Exactly one `h1` per screen, no skipped heading level (390 px and 1280 px, 12 screens) | VERIFIED (automated) | `tests/ui/a11y63.mjs` A4 |
| A4 | Notifications dialog: focus moves in, Tab / Shift+Tab stay inside, Escape closes, focus returns to the bell | VERIFIED (automated) | `a11y62.mjs` |
| A5 | Every button/link has an accessible name; every input has a label; every image has `alt`; no clickable non-button without role/tabindex | VERIFIED (automated) | `tests/ui/audit62.mjs` (572 screen states, 0 problems) |
| A6 | Text contrast (WCAG AA) on 28 screens, both themes | VERIFIED (automated) | `tests/ui/contrast.mjs` (0 low-contrast text elements). Non-text contrast (icons, focus ring, borders) is NOT covered |
| A7 | `prefers-reduced-motion: reduce` stops every looping animation (12 screens) | VERIFIED (automated) | `a11y63.mjs` A1–A3 |
| A8 | No horizontal scroll / content hidden behind the bottom nav at 11 viewports × 2 themes | VERIFIED (automated) | `audit62.mjs`, `layout.mjs` |
| A9 | Keyboard-only: dialogs other than notifications (quit-lesson sheet, shop confirm, profile edit, admin dialogs) trap and restore focus | **NOT VERIFIED** | only the notifications dialog is tested |

## B. Manual checklist (not executed in 6.3)
For each row: tester, device, browser, date, result.

### B1. Screen reader — NVDA + Firefox/Chrome (Windows) — NOT VERIFIED
- [ ] Page title and `h1` announced on every tab change (Home, Learn, Stories, AI, Me)
- [ ] Toasts / "correct / wrong" feedback in a lesson are announced once (live region), not repeated
- [ ] Lesson question: question text, options (count/position), selected state, and the result are all read
- [ ] Word-order (tile) and matching exercises are operable and understandable without sight
- [ ] Hearts / XP / gem counters read with meaningful labels (not "5" alone)
- [ ] Notifications and quit-lesson dialogs announce their title when opened
- [ ] Armenian (hy) text is read with a suitable voice; language attribute switches with the UI language

### B2. Screen reader — VoiceOver iOS (Safari) — NOT VERIFIED
- [ ] Bottom navigation is reachable by swipe; current tab announced as selected
- [ ] Rotor → Headings lists each screen's headings in order
- [ ] Lesson exercises operable by double-tap; no controls hidden behind the bottom bar
- [ ] Safe-area (notch / home indicator) never overlaps a control (also needs a physical device)

### B3. Screen reader — VoiceOver macOS (Safari), TalkBack Android (Chrome) — NOT VERIFIED
- [ ] Same checks as B1/B2

### B4. Keyboard only (no mouse), desktop browser — partly automatable, manual run NOT VERIFIED
- [ ] Complete a whole lesson with Tab / Shift+Tab / Enter / Space / arrows only
- [ ] Visible focus ring on every control in light and dark theme
- [ ] Opening the quit-lesson sheet moves focus into it; Escape closes it; focus returns to the Quit button
- [ ] Shop purchase confirmation: same focus behaviour
- [ ] No keyboard trap anywhere; Tab order follows visual order
- [ ] Skip link visible when focused

### B5. Zoom / text size / forced colours — NOT VERIFIED
- [ ] 200 % browser zoom and 320 px width: no content loss (layout is tested at 320 px, not at zoom)
- [ ] OS "larger text" (iOS Dynamic Type / Android font scale 1.3)
- [ ] Windows High Contrast / forced-colors mode: buttons and focus ring remain visible

### B6. Physical devices — NOT VERIFIED
- [ ] One low-end Android phone, one iPhone, one tablet, in portrait and landscape
- [ ] Touch targets ≥ 44 × 44 px in the lesson and bottom nav (measure on device)
- [ ] Device-level reduced-motion setting honoured (the CSS is verified; the OS signal path is not)

## C. Known limitations
- Automated checks cannot judge whether a label is *meaningful*, whether announcements are well-timed, or whether the reading order makes sense. Those are the point of section B.
- Non-text contrast and focus-ring contrast were not measured.
