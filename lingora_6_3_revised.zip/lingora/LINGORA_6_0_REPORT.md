# Lingora 6.0: navigation, Home and in-lesson review

## Pages and design
All screens already shared one token set (colours, radii, type, light/dark). 6.0 adds a final design layer in `site/styles.css`
(section "LINGORA 6.0 design layer") and restructures navigation, so phone / tablet / desktop share one language:
- Phone: 5-item bottom bar with labels (Home, Learn, Stories, AI Coach, Profile), safe-area aware.
- Tablet: slim rail. Desktop (>=1024px): 248px sidebar with labels, wider two-column Home.
- Landing, login, registration, onboarding, language/course selection, lessons, completion, words, flashcards, stories, listening/speaking,
  AI coach/roleplay, friends, leaderboard, quests, achievements, shop, VIP, profile, statistics, mistake book, settings, notifications, admin
  all inherit the new layer; none was rewritten page by page (see "Not done").
- Sub-pages without a bar item (Leaderboard, Friends, Shop, Words, Courses, World) get a Back button; Home and Profile link to them.

## Home
Continue learning hero, 4 stat tiles (streak, XP, hearts, gems; level in local mode), daily goal ring, course progress, AI Coach card,
recommended lessons (finished with <3 stars), daily quests, recommended practice, quick links (Leaderboard, Friends, Shop, Badges).

## Repetition section removed
Removed: Practice tab + route, `practiceHub()`, the review hero/hub page, Home review card, `rvStart/rvDone/rvLog/rvSummaryHtml`, the
`data-px=rvgo/rvextra` actions, their strings and ~33 CSS lines. Old `#/practice` links now open Learn.
Kept: user progress (`S.srs`, `S.miss`, `S.rv` counters, server tables, `practice` attempt kind used by mistake practice).
No migration was needed; no database structure was dropped (nothing was verified safe to drop, and none was required).

## Review integrated into lessons (`src/js/36b-phase2-review-engine.js`)
- Every lesson with earlier material gets 1-4 extra steps (`mixReview`), picked by the old priority (difficult > forgotten > due > new > strong),
  from words met and questions of completed lessons, never from the current lesson, placed after the intro steps.
- They move the spaced-repetition box and mistake counters, are judged locally (never sent to the server as answers of that lesson)
  and do NOT cost hearts, stars or accuracy, so server XP/stars rules are untouched.
- Review steps carry a "Review" tag; the completion screen shows "Reinforced from earlier lessons" and a Flashcards shortcut when cards are due.
- Flashcards, listening, speaking, mistake book, vocabulary and placement test are tools at the top of Learn.

## Bugs fixed
- AI Coach tab froze the page when `aiUsage` returned null (infinite async re-render). Fixed.
- `tests/ui/layout.mjs` silently skipped screens with no bar item (it stayed on the previous screen); it now navigates by hash and covers
  Home, Stories, Leaderboard too (13 screens x 7 viewports x 2 themes = 182).
- Review/Practice hub removal also removed duplicate routes and dead buttons (`tests/static/actions.mjs`: 194 actions, all handled).

## Tests actually run (Chromium, local + in-memory Supabase stand-in)
layout 182 screens 0 problems; new `review.mjs` 18/18; complete 34/34; contrast 28 screens 0 issues; phase1 22/22; admin 8/8; sync 21/21;
reset 17/17; pay 7/7; mediacopy 26/26; static actions OK; `node build.mjs --check` OK.

## NOT run / not done
- `tests/sql`, `tests/e2e`, `tests/ai`, `tests/stripe`, `tests/live`: need PostgreSQL / live services. `tests/e2e/phase2.mjs` still opens the removed
  `practice` tab and must be updated before it is run.
- Real Supabase login, Stripe, TTS and AI provider were not exercised; the cloud path for in-lesson review (locally judged steps inside a server attempt)
  is reasoned from the SQL (`start_lesson`, `complete_lesson` count only lesson answers) but untested against a live database.
- No page-by-page visual rewrite of each of the ~35 screens: the new layer restyles them through shared components. Admin on phones was checked
  only via layout/overflow audits and screenshots of the shell.
- No Android/iOS device testing; no native packaging (PWA only).

## Configuration still needed
Unchanged: `site/config.js` (Supabase URL/anon key), Stripe + AI keys per `.env.example` / `AI_COACH_SETUP.md`. Service-worker cache bumped to `ee-v26`.
