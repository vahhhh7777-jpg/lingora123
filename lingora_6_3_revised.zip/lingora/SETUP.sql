-- Lingora: ամբողջական բազայի տեղադրում (001..010 միասին). Supabase -> SQL Editor -> New query -> տեղադրել ամբողջը -> Run։ Անվտանգ է կրկնելու համար։

-- ===== supabase/migrations/001_base.sql =====
-- Lingora: Supabase database setup (version 2).
-- Run once: Supabase dashboard -> SQL Editor -> New query -> paste this file -> Run.
-- Safe to run again. If you used the old EasyEnglish version, its topic tables are replaced
-- (accounts, VIP dates and learner progress are kept). Re-import the built-in course from the Admin tab afterwards.

-- 0. Remove the old single-table course structure, if present.
drop table if exists public.unit_content;
do $$ begin
  if exists (select 1 from information_schema.tables where table_schema = 'public' and table_name = 'units')
     and not exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'units' and column_name = 'course_id') then
    drop table public.units cascade;
  end if;
end $$;

-- 1. Profiles (one per account). Created automatically on sign-up.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  name text not null default '',
  is_admin boolean not null default false,
  vip_until timestamptz,
  created_at timestamptz not null default now()
);

-- 1b. Roles and account suspension (safe to re-run).
alter table public.profiles add column if not exists suspended boolean not null default false;
alter table public.profiles add column if not exists role text not null default 'user';
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check check (role in ('user','editor','admin'));
update public.profiles set role = 'admin' where is_admin and role = 'user';

-- 2. Catalog: languages > courses > units > lessons > questions.
create table if not exists public.languages (
  id text primary key,
  code text not null,
  name jsonb not null,
  descr jsonb not null default '{}'::jsonb,
  flag text not null default '',
  difficulty text not null default 'easy',
  tts text not null default 'en-US',
  active boolean not null default true,
  position int not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.courses (
  id text primary key,
  language_id text not null references public.languages(id) on delete cascade,
  source text not null default 'hy',
  title jsonb not null,
  descr jsonb not null default '{}'::jsonb,
  difficulty text not null default 'easy',
  tint text not null default 'blue',
  months int not null default 3,
  sample boolean not null default false,
  published boolean not null default false,
  position int not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.units (
  id text primary key,
  course_id text not null references public.courses(id) on delete cascade,
  title jsonb not null,
  descr jsonb not null default '{}'::jsonb,
  tint text not null default 'blue',
  vip boolean not null default false,
  published boolean not null default false,
  position int not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.lessons (
  id text primary key,
  unit_id text not null references public.units(id) on delete cascade,
  title jsonb not null,
  descr jsonb not null default '{}'::jsonb,
  xp int not null default 8,
  published boolean not null default false,
  position int not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.questions (
  id text primary key,
  lesson_id text not null references public.lessons(id) on delete cascade,
  type text not null check (type in ('intro','mc','image','listen','read','type','match','order','fill')),
  data jsonb not null default '{}'::jsonb,
  position int not null default 0,
  created_at timestamptz not null default now()
);
-- Safe migrations for databases created by an earlier version of this file.
alter table public.courses add column if not exists level text not null default 'A1';
alter table public.lessons add column if not exists difficulty text not null default 'easy';
alter table public.courses add column if not exists category text not null default '';
alter table public.courses add column if not exists cover text not null default '';
alter table public.courses add column if not exists archived boolean not null default false;
alter table public.lessons add column if not exists objectives text not null default '';
alter table public.lessons add column if not exists grammar text not null default '';
alter table public.lessons add column if not exists summary text not null default '';
alter table public.lessons add column if not exists minutes int not null default 5;
alter table public.lessons add column if not exists review text not null default 'draft';
alter table public.lessons add column if not exists cover text not null default '';
alter table public.lessons add column if not exists blocks jsonb not null default '[]'::jsonb;
alter table public.questions drop constraint if exists questions_type_check;
alter table public.questions add constraint questions_type_check
  check (type in ('intro','mc','image','listen','read','type','match','order','fill','speak','tf','fix'));

create index if not exists courses_language_idx on public.courses(language_id);
create index if not exists units_course_idx on public.units(course_id);
create index if not exists lessons_unit_idx on public.lessons(unit_id);
create index if not exists questions_lesson_idx on public.questions(lesson_id);

-- 3. Learner progress (one row per user). XP, streak, finished lessons, mistakes, achievements.
create table if not exists public.progress (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- Helper functions used by the access rules (run with owner rights so they can read profiles).
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from public.profiles where id = auth.uid()), false)
$$;
create or replace function public.is_vip() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin or (vip_until is not null and vip_until > now())
                   from public.profiles where id = auth.uid()), false)
$$;

-- Editors can manage lessons and courses but nothing else (users, gamification settings, broadcasts stay admin-only).
create or replace function public.is_editor() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select (is_admin or role in ('editor','admin')) and not suspended
                   from public.profiles where id = auth.uid()), false)
$$;
create or replace function public.is_suspended() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select suspended from public.profiles where id = auth.uid()), false)
$$;

-- Lets a signed-in user rename themselves without being able to touch is_admin or vip_until.
create or replace function public.set_my_name(n text) returns void
language sql security definer set search_path = public as $$
  update public.profiles set name = left(coalesce(n, ''), 24) where id = auth.uid()
$$;
grant execute on function public.set_my_name(text) to authenticated;

-- Weekly leaderboard: real, active learners only. Returns names, XP and league, never emails or ids.
drop function if exists public.leaderboard();
create or replace function public.leaderboard() returns table(name text, xp bigint, me boolean, league int)
language sql stable security definer set search_path = public as $$
  select coalesce(nullif(p.name, ''), 'Learner') as name,
         coalesce(sum((e->>'xp')::int), 0)::bigint as xp,
         (p.id = auth.uid()) as me,
         coalesce(nullif(g.data->'league'->>'tier', '')::int, 0) as league
  from public.progress g
  join public.profiles p on p.id = g.user_id and not p.suspended
  cross join lateral jsonb_array_elements(coalesce(g.data->'log', '[]'::jsonb)) e
  where (e->>'t')::bigint >= (extract(epoch from now()) * 1000)::bigint - 7 * 86400000
  group by p.id, p.name, g.data
  order by xp desc
  limit 50
$$;
grant execute on function public.leaderboard() to authenticated;

-- Create a profile whenever someone signs up.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'name', ''))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- 4. Access rules (Row Level Security).
alter table public.profiles enable row level security;
alter table public.languages enable row level security;
alter table public.courses enable row level security;
alter table public.units enable row level security;
alter table public.lessons enable row level security;
alter table public.questions enable row level security;
alter table public.progress enable row level security;

drop policy if exists "profiles read" on public.profiles;
create policy "profiles read" on public.profiles for select using (id = auth.uid() or public.is_admin());
drop policy if exists "profiles admin update" on public.profiles;
create policy "profiles admin update" on public.profiles for update using (public.is_admin()) with check (public.is_admin());

-- Everyone reads what is active or published. Admins read and write everything.
drop policy if exists "languages read" on public.languages;
create policy "languages read" on public.languages for select using (active or public.is_editor());
drop policy if exists "languages admin write" on public.languages;
create policy "languages admin write" on public.languages for all using (public.is_editor()) with check (public.is_editor());

drop policy if exists "courses read" on public.courses;
create policy "courses read" on public.courses for select using (published or public.is_editor());
drop policy if exists "courses admin write" on public.courses;
create policy "courses admin write" on public.courses for all using (public.is_editor()) with check (public.is_editor());

drop policy if exists "units read" on public.units;
create policy "units read" on public.units for select using (published or public.is_editor());
drop policy if exists "units admin write" on public.units;
create policy "units admin write" on public.units for all using (public.is_editor()) with check (public.is_editor());

-- Lessons and questions of VIP topics only reach VIP members and admins, so they cannot be unlocked from the browser.
drop policy if exists "lessons read" on public.lessons;
create policy "lessons read" on public.lessons for select using (
  public.is_editor()
  or (published and exists (select 1 from public.units u
        where u.id = unit_id and u.published and (not u.vip or public.is_vip())))
);
drop policy if exists "lessons admin write" on public.lessons;
create policy "lessons admin write" on public.lessons for all using (public.is_editor()) with check (public.is_editor());

drop policy if exists "questions read" on public.questions;
create policy "questions read" on public.questions for select using (
  public.is_editor()
  or exists (select 1 from public.lessons l join public.units u on u.id = l.unit_id
        where l.id = lesson_id and l.published and u.published and (not u.vip or public.is_vip()))
);
drop policy if exists "questions admin write" on public.questions;
create policy "questions admin write" on public.questions for all using (public.is_editor()) with check (public.is_editor());

-- Learners read and write their own progress. Admins can read everyone's for the dashboard.
drop policy if exists "progress own" on public.progress;
create policy "progress own" on public.progress for all using (user_id = auth.uid())
  with check (user_id = auth.uid() and not public.is_suspended());
drop policy if exists "progress admin read" on public.progress;
create policy "progress admin read" on public.progress for select using (public.is_admin());

-- 5. Make yourself the admin AFTER you have created your account in the app.
-- Replace the address with your own email and run this line alone:
--   update public.profiles set is_admin = true where email = 'you@example.com';

-- ---------- Storage for lesson images and audio (run once) ----------
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('media','media',true,5242880,array['image/jpeg','image/png','image/webp','image/gif','audio/mpeg','audio/mp3','audio/ogg','audio/wav','audio/webm','audio/mp4'])
on conflict (id) do update set public=true,file_size_limit=5242880;
drop policy if exists media_read on storage.objects;
create policy media_read on storage.objects for select using (bucket_id='media');
drop policy if exists media_admin_write on storage.objects;
create policy media_admin_write on storage.objects for insert to authenticated with check (bucket_id='media' and public.is_editor());
drop policy if exists media_admin_delete on storage.objects;
create policy media_admin_delete on storage.objects for delete to authenticated using (bucket_id='media' and public.is_editor());


-- ---------- Platform settings, announcements, banners, notifications, mascot messages ----------
-- settings: one row per key ('game' = gamification rules, 'brand' = name, colors, mascot images). Everyone may read, only admins write.
create table if not exists public.settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
-- site_content: kind = announcement | banner | notification | mascot (context says when the mascot says it).
create table if not exists public.site_content (
  id text primary key,
  kind text not null check (kind in ('announcement','banner','notification','mascot')),
  context text not null default '',
  title jsonb not null default '{}'::jsonb,
  body jsonb not null default '{}'::jsonb,
  link text not null default '',
  active boolean not null default true,
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists site_content_kind_idx on public.site_content(kind);
alter table public.settings enable row level security;
alter table public.site_content enable row level security;
drop policy if exists "settings read" on public.settings;
create policy "settings read" on public.settings for select using (true);
drop policy if exists "settings admin write" on public.settings;
create policy "settings admin write" on public.settings for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists "site_content read" on public.site_content;
create policy "site_content read" on public.site_content for select using (
  public.is_admin() or (active and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now())));
drop policy if exists "site_content admin write" on public.site_content;
create policy "site_content admin write" on public.site_content for all using (public.is_admin()) with check (public.is_admin());

-- ===== supabase/migrations/002_economy.sql =====
-- Lingora 2.0, migration 002: server-authoritative economy.
-- XP, gems, hearts, streaks, quests, achievements and the shop live in tables that browsers can READ but never WRITE.
-- Every change goes through the SECURITY DEFINER functions below, which validate the request.
-- Safe to run more than once.

create schema if not exists private;
revoke all on schema private from public, anon, authenticated;

-- ---------------------------------------------------------------------------------------------
-- 0. Small helpers
-- ---------------------------------------------------------------------------------------------
create or replace function private.jmerge(a jsonb, b jsonb) returns jsonb
language plpgsql immutable as $$
declare k text; r jsonb := coalesce(a, '{}'::jsonb);
begin
  if b is null or jsonb_typeof(b) <> 'object' then return r; end if;
  for k in select jsonb_object_keys(b) loop
    if jsonb_typeof(r->k) = 'object' and jsonb_typeof(b->k) = 'object' then
      r := jsonb_set(r, array[k], private.jmerge(r->k, b->k));
    else
      r := jsonb_set(r, array[k], b->k);
    end if;
  end loop;
  return r;
end $$;

-- Rules the admin can change in Admin > Settings (table settings, key 'economy'); these are the defaults.
create or replace function private.cfg() returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare
  d jsonb := $j${
    "hearts":{"max":5,"regen_minutes":60,"refill_gems":50,"practice_reward_per_day":3},
    "gems":{"lesson":5,"perfect":3,"unit":20,"goal":10,"practice":1,"repeat":0,
            "daily":[5,5,10,10,15,15,30],"invite":20,"welcome":10},
    "xp":{"star":4,"practice":5,"unit":20,"repeat":5,"sec_per_question":1.5,"max_lesson_xp":150,"daily_cap":3000,"completions_per_day":150},
    "streak":{"max_freeze":2,"milestones":[{"d":3,"xp":15,"freeze":0,"boost":0,"gems":5},{"d":7,"xp":40,"freeze":1,"boost":15,"gems":15},{"d":14,"xp":80,"freeze":1,"boost":30,"gems":30},{"d":30,"xp":200,"freeze":2,"boost":60,"gems":100}]},
    "multiplier":{"value":1,"until":""},
    "league":{"size":30,"promote":7,"demote":5,"min_group_to_demote":8,"rewards":[50,30,20]},
    "friends":{"max":200,"pending_max":50},
    "ai":{"daily_messages":40}
  }$j$::jsonb;
  g jsonb; e jsonb;
begin
  select value into g from public.settings where key = 'game';
  select value into e from public.settings where key = 'economy';
  -- the older 'game' rules (xp per star, event multiplier, streak rewards) stay the single source for those values
  if g is not null then
    d := private.jmerge(d, jsonb_build_object(
      'xp', coalesce(g->'xp', '{}'::jsonb),
      'multiplier', coalesce(g->'multiplier', '{}'::jsonb)));
    if jsonb_typeof(g->'streak'->'milestones') = 'array' then
      d := jsonb_set(d, '{streak,milestones}', g->'streak'->'milestones');
    end if;
    if g->'streak'->'maxFreeze' is not null then
      d := jsonb_set(d, '{streak,max_freeze}', g->'streak'->'maxFreeze');
    end if;
  end if;
  return private.jmerge(d, e);
end $$;

-- Each account may call a guarded action only so many times per window. Raises 'rate_limited'.
create table if not exists public.rate_limits (
  user_id uuid not null,
  bucket text not null,
  window_start timestamptz not null,
  n int not null default 0,
  primary key (user_id, bucket)
);
create or replace function private.rl(p_bucket text, p_max int, p_seconds int) returns void
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); r public.rate_limits;
begin
  if uid is null then raise exception 'denied'; end if;
  insert into public.rate_limits as x (user_id, bucket, window_start, n) values (uid, p_bucket, now(), 1)
  on conflict (user_id, bucket) do update set
    n = case when x.window_start < now() - make_interval(secs => p_seconds) then 1 else x.n + 1 end,
    window_start = case when x.window_start < now() - make_interval(secs => p_seconds) then now() else x.window_start end
  returning * into r;
  if r.n > p_max then raise exception 'rate_limited'; end if;
end $$;

-- ---------------------------------------------------------------------------------------------
-- 1. Profile columns used by the economy and the social features
-- ---------------------------------------------------------------------------------------------
alter table public.profiles add column if not exists tz_offset_min int not null default 0;
alter table public.profiles add column if not exists friend_code text;
alter table public.profiles add column if not exists privacy jsonb not null default '{"searchable":true,"show_activity":true,"profile":"friends"}'::jsonb;
alter table public.profiles drop constraint if exists profiles_tz_check;
alter table public.profiles add constraint profiles_tz_check check (tz_offset_min between -840 and 840);

create or replace function private.gen_friend_code() returns text
language plpgsql volatile as $$
declare alphabet text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; c text; i int;
begin
  loop
    c := '';
    for i in 1..8 loop c := c || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1); end loop;
    exit when not exists (select 1 from public.profiles where friend_code = c);
  end loop;
  return c;
end $$;

update public.profiles set friend_code = private.gen_friend_code() where friend_code is null;
create unique index if not exists profiles_friend_code_key on public.profiles(friend_code);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public, private as $$
begin
  insert into public.profiles (id, email, name, friend_code)
  values (new.id, new.email, left(coalesce(new.raw_user_meta_data->>'name', ''), 24), private.gen_friend_code())
  on conflict (id) do nothing;
  return new;
end $$;

-- a progress blob is for learning data only (done lessons, favourites ...), keep it small
alter table public.progress drop constraint if exists progress_size_check;
alter table public.progress add constraint progress_size_check check (octet_length(data::text) < 400000) not valid;

-- ---------------------------------------------------------------------------------------------
-- 2. Tables
-- ---------------------------------------------------------------------------------------------
create table if not exists public.player_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  xp bigint not null default 0 check (xp >= 0),
  gems int not null default 0 check (gems >= 0),
  hearts int not null default 5 check (hearts >= 0),
  hearts_at timestamptz not null default now(),
  unlimited_until timestamptz,
  streak int not null default 0,
  best_streak int not null default 0,
  last_day date,
  freezes int not null default 0 check (freezes >= 0),
  boost_until timestamptz,
  boost_mult numeric not null default 2,
  goal int not null default 20 check (goal between 5 and 500),
  day date,
  day_xp int not null default 0,
  login_day date,
  login_streak int not null default 0,
  milestones jsonb not null default '{}'::jsonb,
  practice_heart_day date,
  practice_hearts int not null default 0,
  legacy_imported boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.xp_events (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  amount int not null,
  kind text not null,
  ref text not null default '',
  day date not null,
  meta jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists xp_events_user_time_idx on public.xp_events(user_id, created_at desc);
create index if not exists xp_events_time_idx on public.xp_events(created_at);

create table if not exists public.gem_transactions (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  delta int not null,
  reason text not null,
  ref text not null default '',
  balance_after int not null,
  meta jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique (user_id, reason, ref)
);
create index if not exists gem_tx_user_idx on public.gem_transactions(user_id, created_at desc);

create table if not exists public.lesson_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id text,
  kind text not null default 'lesson' check (kind in ('lesson','practice')),
  questions int not null default 0,
  words int not null default 0,
  speaking int not null default 0,
  started_at timestamptz not null default now(),
  finished_at timestamptz,
  finished_day date,
  misses int not null default 0,
  mistakes int,
  status text not null default 'open' check (status in ('open','done')),
  result jsonb
);
create index if not exists lesson_attempts_user_idx on public.lesson_attempts(user_id, started_at desc);

create table if not exists public.lesson_completions (
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id text not null,
  best_stars int not null default 1 check (best_stars between 0 and 3),
  times int not null default 1,
  first_at timestamptz not null default now(),
  last_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);

create table if not exists public.achievement_defs (
  id text primary key,
  metric text not null check (metric in ('lessons','xp','best_streak','perfect','units','level','practice','friends')),
  threshold int not null check (threshold > 0),
  icon text not null default 'star',
  title jsonb not null,
  descr jsonb not null default '{}'::jsonb,
  reward_gems int not null default 0 check (reward_gems >= 0),
  reward_xp int not null default 0 check (reward_xp >= 0),
  active boolean not null default true,
  position int not null default 0
);
create table if not exists public.user_achievements (
  user_id uuid not null references auth.users(id) on delete cascade,
  achievement_id text not null references public.achievement_defs(id) on delete cascade,
  earned_at timestamptz not null default now(),
  primary key (user_id, achievement_id)
);

create table if not exists public.quest_defs (
  id text primary key,
  period text not null check (period in ('daily','weekly','monthly')),
  metric text not null check (metric in ('xp','lessons','perfect','practice','words','speaking','days')),
  target int not null check (target > 0),
  reward_gems int not null default 0 check (reward_gems >= 0),
  reward_xp int not null default 0 check (reward_xp >= 0),
  title jsonb not null,
  active boolean not null default true,
  starts_at timestamptz,
  ends_at timestamptz,
  position int not null default 0
);
create table if not exists public.quest_claims (
  user_id uuid not null references auth.users(id) on delete cascade,
  quest_id text not null references public.quest_defs(id) on delete cascade,
  period_key date not null,
  claimed_at timestamptz not null default now(),
  primary key (user_id, quest_id, period_key)
);

create table if not exists public.shop_items (
  id text primary key,
  kind text not null check (kind in ('heart_refill','streak_freeze','xp_boost','unlimited_hearts')),
  price_gems int not null check (price_gems >= 0),
  payload jsonb not null default '{}'::jsonb,
  icon text not null default 'gem',
  title jsonb not null,
  descr jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  position int not null default 0
);
create table if not exists public.purchases (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  item_id text not null,
  price_gems int not null,
  idem_key text not null,
  created_at timestamptz not null default now(),
  unique (user_id, idem_key)
);

-- ---------------------------------------------------------------------------------------------
-- 3. Access rules: browsers may read their own rows, nothing else. Writes only through functions.
-- ---------------------------------------------------------------------------------------------
alter table public.rate_limits enable row level security;
alter table public.player_state enable row level security;
alter table public.xp_events enable row level security;
alter table public.gem_transactions enable row level security;
alter table public.lesson_attempts enable row level security;
alter table public.lesson_completions enable row level security;
alter table public.achievement_defs enable row level security;
alter table public.user_achievements enable row level security;
alter table public.quest_defs enable row level security;
alter table public.quest_claims enable row level security;
alter table public.shop_items enable row level security;
alter table public.purchases enable row level security;

drop policy if exists "ps own" on public.player_state;
create policy "ps own" on public.player_state for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "xpe own" on public.xp_events;
create policy "xpe own" on public.xp_events for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "gtx own" on public.gem_transactions;
create policy "gtx own" on public.gem_transactions for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "att own" on public.lesson_attempts;
create policy "att own" on public.lesson_attempts for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "comp own" on public.lesson_completions;
create policy "comp own" on public.lesson_completions for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "uach own" on public.user_achievements;
create policy "uach own" on public.user_achievements for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "qcl own" on public.quest_claims;
create policy "qcl own" on public.quest_claims for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "pur own" on public.purchases;
create policy "pur own" on public.purchases for select using (user_id = auth.uid() or public.is_admin());

-- definitions: everybody reads the active ones, admins write
drop policy if exists "adef read" on public.achievement_defs;
create policy "adef read" on public.achievement_defs for select using (active or public.is_admin());
drop policy if exists "adef write" on public.achievement_defs;
create policy "adef write" on public.achievement_defs for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists "qdef read" on public.quest_defs;
create policy "qdef read" on public.quest_defs for select using (active or public.is_admin());
drop policy if exists "qdef write" on public.quest_defs;
create policy "qdef write" on public.quest_defs for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists "shop read" on public.shop_items;
create policy "shop read" on public.shop_items for select using (active or public.is_admin());
drop policy if exists "shop write" on public.shop_items;
create policy "shop write" on public.shop_items for all using (public.is_admin()) with check (public.is_admin());

-- defence in depth: even if a policy were added by mistake, these tables stay read-only for browsers
revoke insert, update, delete, truncate on public.rate_limits, public.player_state, public.xp_events, public.gem_transactions,
  public.lesson_attempts, public.lesson_completions, public.user_achievements, public.quest_claims, public.purchases
  from anon, authenticated;
revoke all on public.rate_limits from anon, authenticated;

-- ---------------------------------------------------------------------------------------------
-- 4. Core helpers (never exposed through the API: schema private)
-- ---------------------------------------------------------------------------------------------
create or replace function private.local_day(uid uuid) returns date
language sql stable security definer set search_path = public as $$
  select ((now() at time zone 'UTC') + make_interval(mins => coalesce((select tz_offset_min from public.profiles where id = uid), 0)))::date
$$;

create or replace function private.is_vip(uid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin or (vip_until is not null and vip_until > now()) from public.profiles where id = uid), false)
$$;

create or replace function private.level_of(p_xp bigint) returns int
language plpgsql immutable as $$
declare l int := 1; need bigint := 60; x bigint := p_xp;
begin
  while x >= need loop x := x - need; l := l + 1; need := need + 40; end loop;
  return l;
end $$;

create or replace function private.xp_to_next(p_xp bigint) returns jsonb
language plpgsql immutable as $$
declare l int := 1; need bigint := 60; x bigint := p_xp;
begin
  while x >= need loop x := x - need; l := l + 1; need := need + 40; end loop;
  return jsonb_build_object('level', l, 'cur', x, 'need', need);
end $$;

-- Locks the player's row (creating it on first use), settles heart regeneration and returns it.
create or replace function private.ps_get(uid uuid) returns public.player_state
language plpgsql security definer set search_path = public, private as $$
declare ps public.player_state; cfg jsonb := private.cfg(); mx int := (cfg->'hearts'->>'max')::int;
        iv numeric := (cfg->'hearts'->>'regen_minutes')::numeric * 60; n int; welcome int := (cfg->'gems'->>'welcome')::int;
begin
  insert into public.player_state (user_id, hearts, goal) values (uid, mx, 20) on conflict (user_id) do nothing;
  if found and welcome > 0 then
    perform private.gem_add(uid, welcome, 'welcome', 'welcome', '{}'::jsonb);
  end if;
  select * into ps from public.player_state where user_id = uid for update;
  if not ps.legacy_imported then
    perform private.import_legacy(uid);
    select * into ps from public.player_state where user_id = uid for update;
  end if;
  if ps.hearts >= mx then
    if ps.hearts > mx then ps.hearts := mx; end if;
    ps.hearts_at := now();
  elsif iv > 0 then
    n := floor(extract(epoch from (now() - ps.hearts_at)) / iv)::int;
    if n > 0 then
      ps.hearts := least(mx, ps.hearts + n);
      ps.hearts_at := case when ps.hearts >= mx then now() else ps.hearts_at + make_interval(secs => n * iv) end;
    end if;
  end if;
  update public.player_state set hearts = ps.hearts, hearts_at = ps.hearts_at, updated_at = now() where user_id = uid;
  return ps;
end $$;

create or replace function private.gem_add(uid uuid, delta int, p_reason text, p_ref text, p_meta jsonb) returns boolean
language plpgsql security definer set search_path = public, private as $$
declare bal int; ins bigint;
begin
  if delta = 0 then return false; end if;
  insert into public.gem_transactions (user_id, delta, reason, ref, balance_after, meta)
  values (uid, delta, p_reason, coalesce(p_ref, ''), 0, coalesce(p_meta, '{}'::jsonb))
  on conflict (user_id, reason, ref) do nothing returning id into ins;
  if ins is null then return false; end if;   -- duplicate reward: ignored
  update public.player_state set gems = gems + delta, updated_at = now() where user_id = uid returning gems into bal;
  if bal is null then raise exception 'no_state'; end if;
  update public.gem_transactions set balance_after = bal where id = ins;
  return true;
exception when check_violation then
  raise exception 'not_enough_gems';
end $$;

create or replace function private.xp_add(uid uuid, amount int, p_kind text, p_ref text, p_meta jsonb) returns void
language plpgsql security definer set search_path = public, private as $$
declare d date := private.local_day(uid);
begin
  if amount <= 0 then return; end if;
  insert into public.xp_events (user_id, amount, kind, ref, day, meta) values (uid, amount, p_kind, coalesce(p_ref, ''), d, coalesce(p_meta, '{}'::jsonb));
  update public.player_state set
    xp = xp + amount,
    day_xp = case when day = d then day_xp + amount else amount end,
    day = d,
    updated_at = now()
  where user_id = uid;
end $$;

-- Moves the streak forward once per local day, spending streak freezes for missed days.
create or replace function private.touch_streak(uid uuid) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare ps public.player_state; d date := private.local_day(uid); miss int; ev jsonb := '{}'::jsonb; cfg jsonb := private.cfg();
        m jsonb; mx int := coalesce((cfg->'streak'->>'max_freeze')::int, 2);
begin
  select * into ps from public.player_state where user_id = uid for update;
  if ps.last_day = d then return ev; end if;
  if ps.last_day is null then ps.streak := 1;
  else
    miss := (d - ps.last_day) - 1;
    if miss <= 0 then ps.streak := ps.streak + 1;
    elsif miss <= ps.freezes then ps.freezes := ps.freezes - miss; ps.streak := ps.streak + 1; ev := jsonb_build_object('froze', miss);
    else ps.streak := 1;
    end if;
  end if;
  ps.last_day := d; ps.best_streak := greatest(ps.best_streak, ps.streak);
  update public.player_state set streak = ps.streak, best_streak = ps.best_streak, last_day = d, freezes = ps.freezes where user_id = uid;
  -- streak milestones, once each
  select x into m from jsonb_array_elements(coalesce(cfg->'streak'->'milestones', '[]'::jsonb)) x where (x->>'d')::int = ps.streak limit 1;
  if m is not null and (ps.milestones->>(ps.streak::text)) is null then
    update public.player_state set milestones = milestones || jsonb_build_object(ps.streak::text, extract(epoch from now())::bigint) where user_id = uid;
    if coalesce((m->>'xp')::int, 0) > 0 then perform private.xp_add(uid, (m->>'xp')::int, 'streak', ps.streak::text, '{}'::jsonb); end if;
    if coalesce((m->>'freeze')::int, 0) > 0 then
      update public.player_state set freezes = least(mx, freezes + (m->>'freeze')::int) where user_id = uid;
    end if;
    if coalesce((m->>'boost')::int, 0) > 0 then
      update public.player_state set boost_until = now() + make_interval(mins => (m->>'boost')::int), boost_mult = 2 where user_id = uid;
    end if;
    if coalesce((m->>'gems')::int, 0) > 0 then perform private.gem_add(uid, (m->>'gems')::int, 'streak', ps.streak::text, '{}'::jsonb); end if;
    ev := ev || jsonb_build_object('milestone', m);
  end if;
  return ev;
end $$;

-- ---------------------------------------------------------------------------------------------
-- 5. Achievements
-- ---------------------------------------------------------------------------------------------
create or replace function private.metric(uid uuid, p_metric text) returns numeric
language plpgsql stable security definer set search_path = public, private as $$
begin
  return case p_metric
    when 'lessons' then (select count(*) from public.lesson_completions where user_id = uid)
    when 'perfect' then (select count(*) from public.lesson_completions where user_id = uid and best_stars >= 3)
    when 'xp' then (select xp from public.player_state where user_id = uid)
    when 'level' then (select private.level_of(xp) from public.player_state where user_id = uid)
    when 'best_streak' then (select best_streak from public.player_state where user_id = uid)
    when 'practice' then (select count(*) from public.lesson_attempts where user_id = uid and kind = 'practice' and status = 'done')
    when 'units' then (
      select count(*) from public.units u
      where u.published
        and exists (select 1 from public.lessons l where l.unit_id = u.id and l.published)
        and not exists (select 1 from public.lessons l where l.unit_id = u.id and l.published
                        and not exists (select 1 from public.lesson_completions c where c.user_id = uid and c.lesson_id = l.id)))
    when 'friends' then (select count(*) from information_schema.tables where false)   -- replaced in migration 003
    else 0 end;
end $$;

create or replace function private.check_achievements(uid uuid) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare a public.achievement_defs; got jsonb := '[]'::jsonb; ins int;
begin
  for a in select * from public.achievement_defs where active order by position, id loop
    continue when exists (select 1 from public.user_achievements where user_id = uid and achievement_id = a.id);
    if private.metric(uid, a.metric) >= a.threshold then
      insert into public.user_achievements (user_id, achievement_id) values (uid, a.id) on conflict do nothing;
      get diagnostics ins = row_count;
      if ins > 0 then
        if a.reward_gems > 0 then perform private.gem_add(uid, a.reward_gems, 'achievement', a.id, '{}'::jsonb); end if;
        if a.reward_xp > 0 then perform private.xp_add(uid, a.reward_xp, 'achievement', a.id, '{}'::jsonb); end if;
        got := got || jsonb_build_array(jsonb_build_object('id', a.id, 'icon', a.icon, 'title', a.title, 'descr', a.descr, 'gems', a.reward_gems, 'xp', a.reward_xp));
      end if;
    end if;
  end loop;
  return got;
end $$;

-- ---------------------------------------------------------------------------------------------
-- 6. One-time import of the old client-side progress (accounts that existed before this migration)
-- ---------------------------------------------------------------------------------------------
insert into public.settings (key, value) values ('economy_start', to_jsonb(now())) on conflict (key) do nothing;

create or replace function private.import_legacy(uid uuid) returns void
language plpgsql security definer set search_path = public, private as $$
declare p jsonb; created timestamptz; started timestamptz; k text; v jsonb; xpv bigint; stv int; lastd date;
begin
  update public.player_state set legacy_imported = true where user_id = uid;
  select created_at into created from public.profiles where id = uid;
  select (value #>> '{}')::timestamptz into started from public.settings where key = 'economy_start';
  if created is null or started is null or created >= started then return; end if;   -- brand-new accounts start at zero
  select data into p from public.progress where user_id = uid;
  if p is null then return; end if;
  xpv := least(greatest(coalesce((p->>'xp')::numeric, 0), 0), 50000)::bigint;
  stv := least(greatest(coalesce((p->>'best')::int, 0), 0), 3650);
  begin lastd := nullif(p->>'last', '')::date; exception when others then lastd := null; end;
  update public.player_state set
    xp = xpv,
    best_streak = stv,
    streak = case when lastd >= private.local_day(uid) - 1 then least(greatest(coalesce((p->>'streak')::int, 0), 0), stv) else 0 end,
    last_day = case when lastd >= private.local_day(uid) - 1 then lastd else null end,
    freezes = least(greatest(coalesce((p->>'freeze')::int, 0), 0), 2),
    goal = case when (p->>'goal') ~ '^\d+$' and (p->>'goal')::int between 5 and 500 then (p->>'goal')::int else goal end
  where user_id = uid;
  if jsonb_typeof(p->'done') = 'object' then
    for k, v in select * from jsonb_each(p->'done') loop
      if jsonb_typeof(v) = 'number' and exists (select 1 from public.lessons where id = k) then
        insert into public.lesson_completions (user_id, lesson_id, best_stars) values (uid, k, least(greatest((v #>> '{}')::int, 1), 3)) on conflict do nothing;
      end if;
    end loop;
  end if;
end $$;

-- ---------------------------------------------------------------------------------------------
-- 7. State snapshot returned to the app
-- ---------------------------------------------------------------------------------------------
create or replace function private.state_json(uid uuid) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare ps public.player_state; cfg jsonb := private.cfg(); iv numeric := (cfg->'hearts'->>'regen_minutes')::numeric * 60;
        mx int := (cfg->'hearts'->>'max')::int; d date := private.local_day(uid); alive boolean; vip boolean := private.is_vip(uid);
        unl boolean; lv jsonb; dl jsonb := cfg->'gems'->'daily'; claim boolean; nexti int; ach jsonb; comp jsonb;
begin
  select * into ps from public.player_state where user_id = uid;
  alive := ps.last_day is not null and ps.last_day >= d - 1 - ps.freezes;
  unl := vip or (ps.unlimited_until is not null and ps.unlimited_until > now());
  lv := private.xp_to_next(ps.xp);
  claim := ps.login_day is distinct from d;
  nexti := case when ps.login_day = d then ps.login_streak
                when ps.login_day = d - 1 then ps.login_streak else 0 end;
  select coalesce(jsonb_object_agg(achievement_id, extract(epoch from earned_at) * 1000), '{}'::jsonb) into ach from public.user_achievements where user_id = uid;
  select coalesce(jsonb_object_agg(lesson_id, best_stars), '{}'::jsonb) into comp from public.lesson_completions where user_id = uid;
  return jsonb_build_object(
    'xp', ps.xp, 'gems', ps.gems, 'level', lv,
    'hearts', case when unl then mx else ps.hearts end, 'hearts_max', mx, 'unlimited', unl,
    'unlimited_until', ps.unlimited_until, 'vip', vip,
    'next_heart_at', case when not unl and ps.hearts < mx then ps.hearts_at + make_interval(secs => iv) end,
    'regen_minutes', (cfg->'hearts'->>'regen_minutes')::int, 'refill_gems', (cfg->'hearts'->>'refill_gems')::int,
    'streak', case when alive then ps.streak else 0 end, 'best_streak', ps.best_streak, 'streak_today', ps.last_day = d,
    'freezes', ps.freezes, 'boost_until', case when ps.boost_until > now() then ps.boost_until end, 'boost_mult', ps.boost_mult,
    'goal', ps.goal, 'day', d, 'day_xp', case when ps.day = d then ps.day_xp else 0 end,
    'daily', jsonb_build_object('can_claim', claim, 'day_index', case when claim then (nexti % jsonb_array_length(dl)) else ((nexti - 1) % jsonb_array_length(dl)) end,
                                'rewards', dl, 'streak', case when claim and ps.login_day < d - 1 then 0 else ps.login_streak end),
    'achievements', ach, 'done', comp, 'server_time', now());
end $$;

create or replace function public.get_my_state(p_tz int default null) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'denied'; end if;
  if p_tz is not null and p_tz between -840 and 840 then
    update public.profiles set tz_offset_min = p_tz where id = uid and tz_offset_min <> p_tz;
  end if;
  perform private.ps_get(uid);
  return private.state_json(uid);
end $$;

create or replace function public.set_my_goal(p_goal int) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'denied'; end if;
  if p_goal is null or p_goal < 5 or p_goal > 500 then raise exception 'invalid'; end if;
  perform private.ps_get(uid);
  update public.player_state set goal = p_goal where user_id = uid;
  return private.state_json(uid);
end $$;

-- ---------------------------------------------------------------------------------------------
-- 8. Lessons: start -> (misses) -> complete
-- ---------------------------------------------------------------------------------------------
create or replace function public.start_lesson(p_lesson text, p_kind text default 'lesson', p_questions int default null) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); ps public.player_state; l public.lessons; u public.units; c public.courses; n int; w int; sp int; att_id uuid;
        unl boolean; vip boolean;
begin
  if uid is null then raise exception 'denied'; end if;
  if exists (select 1 from public.profiles where id = uid and suspended) then raise exception 'denied'; end if;
  perform private.rl('start', 240, 3600);
  ps := private.ps_get(uid);
  vip := private.is_vip(uid);
  unl := vip or (ps.unlimited_until is not null and ps.unlimited_until > now());
  if p_kind = 'practice' then
    n := least(greatest(coalesce(p_questions, 8), 3), 40); w := 0; sp := 0;
  elsif p_kind = 'lesson' then
    select * into l from public.lessons where id = p_lesson;
    if not found then raise exception 'not_found'; end if;
    select * into u from public.units where id = l.unit_id;
    select * into c from public.courses where id = u.course_id;
    if not (public.is_editor() or (l.published and u.published and c.published and not c.archived and (not u.vip or vip))) then
      raise exception 'denied';
    end if;
    select count(*), count(*) filter (where type = 'intro'), count(*) filter (where type in ('speak','listen')) into n, w, sp
      from public.questions where lesson_id = l.id;
    if n = 0 then raise exception 'empty_lesson'; end if;
    if ps.hearts <= 0 and not unl then raise exception 'no_hearts'; end if;
  else
    raise exception 'invalid';
  end if;
  insert into public.lesson_attempts (user_id, lesson_id, kind, questions, words, speaking)
  values (uid, case when p_kind = 'lesson' then p_lesson end, p_kind, n, w, sp) returning lesson_attempts.id into att_id;
  return jsonb_build_object('attempt_id', att_id, 'questions', n, 'state', private.state_json(uid));
end $$;

create or replace function public.lesson_miss(p_attempt uuid) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); a public.lesson_attempts; ps public.player_state; unl boolean; mx int := (private.cfg()->'hearts'->>'max')::int;
begin
  if uid is null then raise exception 'denied'; end if;
  select * into a from public.lesson_attempts where id = p_attempt and user_id = uid for update;
  if not found or a.status <> 'open' then raise exception 'not_found'; end if;
  if a.misses >= a.questions * 3 + 5 then raise exception 'rate_limited'; end if;
  ps := private.ps_get(uid);
  unl := private.is_vip(uid) or (ps.unlimited_until is not null and ps.unlimited_until > now());
  update public.lesson_attempts set misses = misses + 1 where id = a.id;
  if a.kind = 'lesson' and not unl then
    if ps.hearts <= 0 then raise exception 'no_hearts'; end if;
    update public.player_state set hearts = hearts - 1,
      hearts_at = case when ps.hearts >= mx then now() else ps.hearts_at end where user_id = uid;
  end if;
  return private.state_json(uid);
end $$;

create or replace function public.complete_lesson(p_attempt uuid, p_mistakes int) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare
  uid uuid := auth.uid(); a public.lesson_attempts; cfg jsonb := private.cfg(); ps public.player_state; l public.lessons;
  mis int := least(greatest(coalesce(p_mistakes, 0), 0), 60); stars int; first_time boolean; raw int; mult numeric := 1; xp int; g int := 0;
  lv0 int; lv1 int; unit_done boolean := false; today_xp int; cap int; d date := private.local_day(uid);
  ev jsonb; ach jsonb; goal_hit boolean := false; res jsonb; gmult jsonb; star_xp int := (cfg->'xp'->>'star')::int;
  done_today int;
begin
  if uid is null then raise exception 'denied'; end if;
  select * into a from public.lesson_attempts where id = p_attempt and user_id = uid for update;
  if not found then raise exception 'not_found'; end if;
  if a.status = 'done' then return a.result; end if;        -- repeated call: same answer, no second reward
  if a.kind <> 'lesson' then raise exception 'invalid'; end if;
  if extract(epoch from (now() - a.started_at)) < a.questions * (cfg->'xp'->>'sec_per_question')::numeric then raise exception 'too_fast'; end if;
  select count(*) into done_today from public.lesson_attempts where user_id = uid and kind = 'lesson' and status = 'done' and finished_day = d;
  if done_today >= (cfg->'xp'->>'completions_per_day')::int then raise exception 'rate_limited'; end if;

  ps := private.ps_get(uid);
  select * into l from public.lessons where id = a.lesson_id;
  lv0 := private.level_of(ps.xp);
  select exists (select 1 from public.lesson_completions where user_id = uid and lesson_id = a.lesson_id) into first_time; first_time := not first_time;
  stars := case when mis = 0 then 3 when mis <= 2 then 2 else 1 end;

  if first_time then
    raw := coalesce(l.xp, 8) + stars * star_xp;
  else
    raw := (cfg->'xp'->>'repeat')::int;
  end if;

  insert into public.lesson_completions (user_id, lesson_id, best_stars) values (uid, a.lesson_id, stars)
  on conflict (user_id, lesson_id) do update set best_stars = greatest(lesson_completions.best_stars, excluded.best_stars),
        times = lesson_completions.times + 1, last_at = now();

  if first_time then
    unit_done := exists (select 1 from public.lessons x where x.unit_id = l.unit_id and x.published)
      and not exists (select 1 from public.lessons x where x.unit_id = l.unit_id and x.published
                      and not exists (select 1 from public.lesson_completions c where c.user_id = uid and c.lesson_id = x.id));
    if unit_done then raw := raw + (cfg->'xp'->>'unit')::int; end if;
  end if;
  raw := least(raw, (cfg->'xp'->>'max_lesson_xp')::int);

  -- XP multipliers: admin event and personal boost, never stacked
  gmult := cfg->'multiplier';
  if coalesce((gmult->>'value')::numeric, 1) > 1 and (coalesce(gmult->>'until', '') = '' or (gmult->>'until')::timestamptz > now()) then mult := (gmult->>'value')::numeric; end if;
  if ps.boost_until is not null and ps.boost_until > now() then mult := greatest(mult, ps.boost_mult); end if;
  xp := round(raw * mult)::int;
  cap := (cfg->'xp'->>'daily_cap')::int;
  select coalesce(sum(amount), 0) into today_xp from public.xp_events where user_id = uid and day = d and kind in ('lesson','practice');
  xp := greatest(0, least(xp, cap - today_xp));

  ev := private.touch_streak(uid);
  perform private.xp_add(uid, xp, 'lesson', a.lesson_id, jsonb_build_object('stars', stars, 'mistakes', mis, 'words', a.words, 'speaking', a.speaking));

  if first_time then
    g := (cfg->'gems'->>'lesson')::int + case when stars = 3 then (cfg->'gems'->>'perfect')::int else 0 end + case when unit_done then (cfg->'gems'->>'unit')::int else 0 end;
  else
    g := (cfg->'gems'->>'repeat')::int;
  end if;
  update public.lesson_attempts set status = 'done', finished_at = now(), finished_day = d, mistakes = mis where id = a.id;
  perform private.gem_add(uid, g, 'lesson', a.id::text, jsonb_build_object('lesson', a.lesson_id));

  -- daily goal reward, once per local day
  select * into ps from public.player_state where user_id = uid;
  if ps.day = d and ps.day_xp >= ps.goal then
    goal_hit := private.gem_add(uid, (cfg->'gems'->>'goal')::int, 'goal', d::text, '{}'::jsonb);
    if goal_hit then g := g + (cfg->'gems'->>'goal')::int; end if;
  end if;

  ach := private.check_achievements(uid);
  select * into ps from public.player_state where user_id = uid;
  lv1 := private.level_of(ps.xp);

  res := jsonb_build_object('xp', xp, 'raw', raw, 'mult', mult, 'stars', stars, 'gems', g, 'first', first_time, 'unit_done', unit_done,
    'goal_hit', goal_hit, 'level_up', case when lv1 > lv0 then lv1 end, 'streak_event', ev, 'achievements', ach, 'accuracy_mistakes', mis,
    'state', private.state_json(uid));
  update public.lesson_attempts set result = res where id = a.id;
  return res;
end $$;

create or replace function public.complete_practice(p_attempt uuid, p_correct int) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare
  uid uuid := auth.uid(); a public.lesson_attempts; cfg jsonb := private.cfg(); ps public.player_state; cor int; xp int; mult numeric := 1; g int;
  d date := private.local_day(uid); heart boolean := false; mx int := (cfg->'hearts'->>'max')::int; cap int; today_xp int; res jsonb; gmult jsonb; ach jsonb;
  ev jsonb;
begin
  if uid is null then raise exception 'denied'; end if;
  select * into a from public.lesson_attempts where id = p_attempt and user_id = uid for update;
  if not found then raise exception 'not_found'; end if;
  if a.status = 'done' then return a.result; end if;
  if a.kind <> 'practice' then raise exception 'invalid'; end if;
  if extract(epoch from (now() - a.started_at)) < a.questions * (cfg->'xp'->>'sec_per_question')::numeric then raise exception 'too_fast'; end if;
  cor := least(greatest(coalesce(p_correct, 0), 0), a.questions);
  ps := private.ps_get(uid);
  gmult := cfg->'multiplier';
  if coalesce((gmult->>'value')::numeric, 1) > 1 and (coalesce(gmult->>'until', '') = '' or (gmult->>'until')::timestamptz > now()) then mult := (gmult->>'value')::numeric; end if;
  if ps.boost_until is not null and ps.boost_until > now() then mult := greatest(mult, ps.boost_mult); end if;
  xp := round(((cfg->'xp'->>'practice')::int + cor) * mult)::int;
  cap := (cfg->'xp'->>'daily_cap')::int;
  select coalesce(sum(amount), 0) into today_xp from public.xp_events where user_id = uid and day = d and kind in ('lesson','practice');
  xp := greatest(0, least(xp, cap - today_xp));
  ev := private.touch_streak(uid);
  perform private.xp_add(uid, xp, 'practice', a.id::text, jsonb_build_object('correct', cor));
  update public.lesson_attempts set status = 'done', finished_at = now(), finished_day = d, mistakes = a.questions - cor where id = a.id;
  g := (cfg->'gems'->>'practice')::int;
  perform private.gem_add(uid, g, 'practice', a.id::text, '{}'::jsonb);
  -- rewarded bonus: a good practice session earns one heart back (a few times per day)
  select * into ps from public.player_state where user_id = uid;
  if cor * 10 >= a.questions * 7 and ps.hearts < mx then
    if ps.practice_heart_day is distinct from d then update public.player_state set practice_heart_day = d, practice_hearts = 0 where user_id = uid; ps.practice_hearts := 0; end if;
    if ps.practice_hearts < (cfg->'hearts'->>'practice_reward_per_day')::int then
      update public.player_state set hearts = hearts + 1, practice_hearts = ps.practice_hearts + 1, practice_heart_day = d where user_id = uid;
      heart := true;
    end if;
  end if;
  ach := private.check_achievements(uid);
  res := jsonb_build_object('xp', xp, 'gems', g, 'heart', heart, 'achievements', ach, 'streak_event', ev, 'state', private.state_json(uid));
  update public.lesson_attempts set result = res where id = a.id;
  return res;
end $$;

-- ---------------------------------------------------------------------------------------------
-- 9. Daily login reward, quests, shop
-- ---------------------------------------------------------------------------------------------
create or replace function public.claim_daily_reward() returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); ps public.player_state; d date := private.local_day(uid); cfg jsonb := private.cfg(); arr jsonb := cfg->'gems'->'daily';
        n int; amt int; ok boolean;
begin
  if uid is null then raise exception 'denied'; end if;
  ps := private.ps_get(uid);
  if ps.login_day = d then raise exception 'already_claimed'; end if;
  n := case when ps.login_day = d - 1 then ps.login_streak + 1 else 1 end;
  amt := (arr->>(((n - 1) % jsonb_array_length(arr))::int))::int;
  ok := private.gem_add(uid, amt, 'daily', d::text, jsonb_build_object('day', n));
  if not ok then raise exception 'already_claimed'; end if;
  update public.player_state set login_day = d, login_streak = n where user_id = uid;
  return jsonb_build_object('gems', amt, 'day', n, 'state', private.state_json(uid));
end $$;

create or replace function private.period_start(p_period text, d date) returns date
language sql immutable as $$
  select case p_period when 'daily' then d when 'weekly' then date_trunc('week', d)::date else date_trunc('month', d)::date end
$$;
create or replace function private.period_end(p_period text, d date) returns date
language sql immutable as $$
  select case p_period when 'daily' then d when 'weekly' then (date_trunc('week', d) + interval '6 days')::date
         else (date_trunc('month', d) + interval '1 month - 1 day')::date end
$$;

create or replace function private.quest_progress(uid uuid, q public.quest_defs, d date) returns int
language plpgsql stable security definer set search_path = public, private as $$
declare s date := private.period_start(q.period, d); e date := private.period_end(q.period, d); v numeric;
begin
  v := case q.metric
    when 'xp' then (select coalesce(sum(amount), 0) from public.xp_events where user_id = uid and day between s and e and kind in ('lesson','practice'))
    when 'lessons' then (select count(*) from public.lesson_attempts where user_id = uid and kind = 'lesson' and status = 'done' and finished_day between s and e)
    when 'perfect' then (select count(*) from public.lesson_attempts where user_id = uid and kind = 'lesson' and status = 'done' and mistakes = 0 and finished_day between s and e)
    when 'practice' then (select count(*) from public.lesson_attempts where user_id = uid and kind = 'practice' and status = 'done' and finished_day between s and e)
    when 'words' then (select coalesce(sum(words), 0) from public.lesson_attempts where user_id = uid and kind = 'lesson' and status = 'done' and finished_day between s and e)
    when 'speaking' then (select coalesce(sum(speaking), 0) from public.lesson_attempts where user_id = uid and kind = 'lesson' and status = 'done' and finished_day between s and e)
    when 'days' then (select count(distinct day) from public.xp_events where user_id = uid and day between s and e and kind in ('lesson','practice'))
    else 0 end;
  return least(v, q.target)::int;
end $$;

create or replace function public.get_quests() returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); d date; q public.quest_defs; out jsonb := '[]'::jsonb; pr int; cl boolean;
begin
  if uid is null then raise exception 'denied'; end if;
  perform private.ps_get(uid);
  d := private.local_day(uid);
  for q in select * from public.quest_defs where active and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now()) order by position, id loop
    pr := private.quest_progress(uid, q, d);
    cl := exists (select 1 from public.quest_claims where user_id = uid and quest_id = q.id and period_key = private.period_start(q.period, d));
    out := out || jsonb_build_array(jsonb_build_object('id', q.id, 'period', q.period, 'metric', q.metric, 'target', q.target, 'progress', pr,
      'gems', q.reward_gems, 'xp', q.reward_xp, 'title', q.title, 'claimed', cl, 'claimable', pr >= q.target and not cl,
      'ends', private.period_end(q.period, d)));
  end loop;
  return out;
end $$;

create or replace function public.claim_quest(p_quest text) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); q public.quest_defs; d date; ok int; ach jsonb;
begin
  if uid is null then raise exception 'denied'; end if;
  perform private.ps_get(uid);
  d := private.local_day(uid);
  select * into q from public.quest_defs where id = p_quest and active and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now());
  if not found then raise exception 'not_found'; end if;
  if private.quest_progress(uid, q, d) < q.target then raise exception 'not_ready'; end if;
  insert into public.quest_claims (user_id, quest_id, period_key) values (uid, q.id, private.period_start(q.period, d)) on conflict do nothing;
  get diagnostics ok = row_count;
  if ok = 0 then raise exception 'already_claimed'; end if;
  perform private.gem_add(uid, q.reward_gems, 'quest', q.id || ':' || private.period_start(q.period, d)::text, '{}'::jsonb);
  if q.reward_xp > 0 then perform private.xp_add(uid, q.reward_xp, 'quest', q.id, '{}'::jsonb); end if;
  ach := private.check_achievements(uid);
  return jsonb_build_object('gems', q.reward_gems, 'xp', q.reward_xp, 'achievements', ach, 'state', private.state_json(uid));
end $$;

create or replace function public.buy_item(p_item text, p_idem text) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); it public.shop_items; ps public.player_state; cfg jsonb := private.cfg(); mx int := (cfg->'hearts'->>'max')::int;
        mf int := coalesce((cfg->'streak'->>'max_freeze')::int, 2); prev jsonb; ok boolean; mins int;
begin
  if uid is null then raise exception 'denied'; end if;
  if p_idem is null or length(p_idem) < 8 or length(p_idem) > 80 then raise exception 'invalid'; end if;
  perform private.rl('buy', 60, 3600);
  -- the same purchase key twice returns the first result instead of charging twice
  if exists (select 1 from public.purchases where user_id = uid and idem_key = p_idem) then
    return jsonb_build_object('duplicate', true, 'state', private.state_json(uid));
  end if;
  select * into it from public.shop_items where id = p_item and active;
  if not found then raise exception 'not_found'; end if;
  ps := private.ps_get(uid);
  if ps.gems < it.price_gems then raise exception 'not_enough_gems'; end if;
  if it.kind = 'heart_refill' and ps.hearts >= mx then raise exception 'already_full'; end if;
  if it.kind = 'streak_freeze' and ps.freezes >= mf then raise exception 'already_full'; end if;
  insert into public.purchases (user_id, item_id, price_gems, idem_key) values (uid, it.id, it.price_gems, p_idem);
  ok := private.gem_add(uid, -it.price_gems, 'purchase', p_idem, jsonb_build_object('item', it.id));
  if it.price_gems > 0 and not ok then raise exception 'duplicate'; end if;
  mins := coalesce((it.payload->>'minutes')::int, 15);
  if it.kind = 'heart_refill' then update public.player_state set hearts = mx, hearts_at = now() where user_id = uid;
  elsif it.kind = 'streak_freeze' then update public.player_state set freezes = least(mf, freezes + 1) where user_id = uid;
  elsif it.kind = 'xp_boost' then
    update public.player_state set boost_until = greatest(coalesce(boost_until, now()), now()) + make_interval(mins => mins),
      boost_mult = coalesce((it.payload->>'mult')::numeric, 2) where user_id = uid;
  elsif it.kind = 'unlimited_hearts' then
    update public.player_state set unlimited_until = greatest(coalesce(unlimited_until, now()), now()) + make_interval(mins => mins) where user_id = uid;
  end if;
  return jsonb_build_object('item', it.id, 'state', private.state_json(uid));
end $$;

-- Hearts can also be refilled directly from the lesson-failed screen (same price as the shop item, set in rules).
create or replace function public.refill_hearts(p_idem text) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); cfg jsonb := private.cfg(); price int := (cfg->'hearts'->>'refill_gems')::int; mx int := (cfg->'hearts'->>'max')::int; ps public.player_state;
begin
  if uid is null then raise exception 'denied'; end if;
  if p_idem is null or length(p_idem) < 8 or length(p_idem) > 80 then raise exception 'invalid'; end if;
  perform private.rl('buy', 60, 3600);
  if exists (select 1 from public.purchases where user_id = uid and idem_key = p_idem) then
    return jsonb_build_object('duplicate', true, 'state', private.state_json(uid));
  end if;
  ps := private.ps_get(uid);
  if ps.hearts >= mx then raise exception 'already_full'; end if;
  if ps.gems < price then raise exception 'not_enough_gems'; end if;
  insert into public.purchases (user_id, item_id, price_gems, idem_key) values (uid, 'heart_refill', price, p_idem);
  perform private.gem_add(uid, -price, 'purchase', p_idem, jsonb_build_object('item', 'heart_refill'));
  update public.player_state set hearts = mx, hearts_at = now() where user_id = uid;
  return jsonb_build_object('state', private.state_json(uid));
end $$;

-- ---------------------------------------------------------------------------------------------
-- 10. Seed data (only inserted when missing, so admin edits survive re-running)
-- ---------------------------------------------------------------------------------------------
insert into public.achievement_defs (id, metric, threshold, icon, title, descr, reward_gems, position) values
 ('first','lessons',1,'star','{"hy":"Առաջին քայլը","en":"First step"}','{"hy":"Ավարտիր առաջին դասը","en":"Finish your first lesson"}',10,1),
 ('five','lessons',5,'book','{"hy":"Հինգ դաս","en":"Five lessons"}','{"hy":"Ավարտիր 5 դաս","en":"Finish 5 lessons"}',15,2),
 ('ten','lessons',10,'book','{"hy":"Տասը դաս","en":"Ten lessons"}','{"hy":"Ավարտիր 10 դաս","en":"Finish 10 lessons"}',25,3),
 ('lessons25','lessons',25,'book','{"hy":"25 դաս","en":"25 lessons"}','{"hy":"Ավարտիր 25 դաս","en":"Finish 25 lessons"}',50,4),
 ('streak3','best_streak',3,'flame','{"hy":"Երեք օր անընդմեջ","en":"Three-day streak"}','{"hy":"Սովորիր 3 օր անընդմեջ","en":"Learn 3 days in a row"}',10,5),
 ('streak7','best_streak',7,'flame','{"hy":"Մեկ շաբաթ","en":"One full week"}','{"hy":"Սովորիր 7 օր անընդմեջ","en":"Learn 7 days in a row"}',30,6),
 ('streak30','best_streak',30,'flame','{"hy":"Մեկ ամիս","en":"One full month"}','{"hy":"Սովորիր 30 օր անընդմեջ","en":"Learn 30 days in a row"}',150,7),
 ('xp100','xp',100,'bolt','{"hy":"100 XP","en":"100 XP"}','{"hy":"Հավաքիր 100 XP","en":"Earn 100 XP"}',10,8),
 ('xp500','xp',500,'bolt','{"hy":"500 XP","en":"500 XP"}','{"hy":"Հավաքիր 500 XP","en":"Earn 500 XP"}',30,9),
 ('xp2000','xp',2000,'bolt','{"hy":"2000 XP","en":"2000 XP"}','{"hy":"Հավաքիր 2000 XP","en":"Earn 2000 XP"}',80,10),
 ('perfect','perfect',1,'check','{"hy":"Անթերի դաս","en":"Flawless lesson"}','{"hy":"Ստացիր 3 աստղ դասում","en":"Get 3 stars in a lesson"}',10,11),
 ('unit','units',1,'shield','{"hy":"Թեման ավարտված է","en":"Topic complete"}','{"hy":"Ավարտիր մի ամբողջ թեմա","en":"Finish a whole topic"}',30,12),
 ('level3','level',3,'crown','{"hy":"3-րդ մակարդակ","en":"Level 3"}','{"hy":"Հասիր 3-րդ մակարդակին","en":"Reach level 3"}',15,13),
 ('practice','practice',3,'heart','{"hy":"Կրկնող","en":"Reviewer"}','{"hy":"Ավարտիր 3 կրկնություն","en":"Finish 3 practice sessions"}',15,14)
on conflict (id) do nothing;

insert into public.quest_defs (id, period, metric, target, reward_gems, reward_xp, title, position) values
 ('d_xp','daily','xp',30,10,0,'{"hy":"Վաստակիր 30 XP","en":"Earn 30 XP"}',1),
 ('d_lessons','daily','lessons',2,15,0,'{"hy":"Ավարտիր 2 դաս","en":"Finish 2 lessons"}',2),
 ('d_perfect','daily','perfect',1,20,0,'{"hy":"Անթերի դաս","en":"A flawless lesson"}',3),
 ('d_words','daily','words',8,10,0,'{"hy":"Սովորիր 8 նոր բառ","en":"Learn 8 new words"}',4),
 ('d_speak','daily','speaking',1,10,0,'{"hy":"Խոսելու կամ լսելու մարտահրավեր","en":"Speaking or listening challenge"}',5),
 ('w_xp','weekly','xp',300,60,20,'{"hy":"Շաբաթվա մարտահրավեր՝ 300 XP","en":"Weekly challenge: 300 XP"}',10),
 ('w_days','weekly','days',5,40,0,'{"hy":"Սովորիր 5 օր այս շաբաթ","en":"Learn on 5 days this week"}',11),
 ('w_lessons','weekly','lessons',10,50,0,'{"hy":"Ավարտիր 10 դաս այս շաբաթ","en":"Finish 10 lessons this week"}',12),
 ('m_xp','monthly','xp',1500,150,50,'{"hy":"Ամսվա իրադարձություն՝ 1500 XP","en":"Monthly event: 1500 XP"}',20)
on conflict (id) do nothing;

insert into public.shop_items (id, kind, price_gems, payload, icon, title, descr, position) values
 ('heart_refill','heart_refill',50,'{}','heart','{"hy":"Սրտերի լրացում","en":"Heart refill"}','{"hy":"Վերականգնիր բոլոր սրտերը","en":"Refill all your hearts"}',1),
 ('streak_freeze','streak_freeze',100,'{}','shield','{"hy":"Շարքի սառեցում","en":"Streak freeze"}','{"hy":"Պահպանում է շարքդ մեկ բաց թողնված օրվա համար","en":"Protects your streak for one missed day"}',2),
 ('xp_boost_15','xp_boost',60,'{"minutes":15,"mult":2}','bolt','{"hy":"XP ուժեղացուցիչ՝ 15 րոպե","en":"XP boost: 15 minutes"}','{"hy":"Կրկնակի XP 15 րոպե","en":"Double XP for 15 minutes"}',3),
 ('xp_boost_60','xp_boost',180,'{"minutes":60,"mult":2}','bolt','{"hy":"XP ուժեղացուցիչ՝ 1 ժամ","en":"XP boost: 1 hour"}','{"hy":"Կրկնակի XP 1 ժամ","en":"Double XP for 1 hour"}',4),
 ('unlimited_30','unlimited_hearts',150,'{"minutes":30}','heart','{"hy":"Անսահմանափակ սրտեր՝ 30 րոպե","en":"Unlimited hearts: 30 minutes"}','{"hy":"Սխալները սրտ չեն արժենում 30 րոպե","en":"Mistakes cost no hearts for 30 minutes"}',5)
on conflict (id) do nothing;

-- ===== supabase/migrations/003_course_draft.sql =====
-- 003: mark courses whose content is not yet reviewed by a native speaker.
-- Safe to re-run; adds a column only.
alter table public.courses add column if not exists draft boolean not null default false;

-- ===== supabase/migrations/004_settings.sql =====
-- Settings: privacy option (hide from the weekly leaderboard) and self-service account deletion.
-- Safe to run more than once. Nothing is dropped except the old leaderboard() signature, which is re-created below.

alter table public.profiles add column if not exists hide_lb boolean not null default false;

-- A signed-in user changes only their own privacy flag (they still cannot touch role / VIP / ban columns).
create or replace function public.set_privacy(p_hide boolean) returns void
language sql security definer set search_path = public as $$
  update public.profiles set hide_lb = coalesce(p_hide, false) where id = auth.uid()
$$;
revoke all on function public.set_privacy(boolean) from public;
grant execute on function public.set_privacy(boolean) to authenticated;

-- Weekly leaderboard: hidden learners are left out for everyone except themselves.
drop function if exists public.leaderboard();
create or replace function public.leaderboard() returns table(name text, xp bigint, me boolean, league int)
language sql stable security definer set search_path = public as $$
  select coalesce(nullif(p.name, ''), 'Learner') as name,
         coalesce(sum((e->>'xp')::int), 0)::bigint as xp,
         (p.id = auth.uid()) as me,
         coalesce(nullif(g.data->'league'->>'tier', '')::int, 0) as league
  from public.progress g
  join public.profiles p on p.id = g.user_id and not p.suspended and (not p.hide_lb or p.id = auth.uid())
  cross join lateral jsonb_array_elements(coalesce(g.data->'log', '[]'::jsonb)) e
  where (e->>'t')::bigint >= (extract(epoch from now()) * 1000)::bigint - 7 * 86400000
  group by p.id, p.name, g.data
  order by xp desc
  limit 50
$$;
grant execute on function public.leaderboard() to authenticated;

-- Deletes the caller's own account and, through ON DELETE CASCADE, their profile, progress, XP and economy rows.
-- Administrators cannot delete themselves this way (so the last admin cannot lock everyone out).
create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  if exists (select 1 from public.profiles where id = uid and is_admin) then raise exception 'admin_cannot_delete'; end if;
  delete from auth.users where id = uid;
end $$;
revoke all on function public.delete_my_account() from public;
grant execute on function public.delete_my_account() to authenticated;

-- ===== supabase/migrations/005_gem_policy.sql =====
-- Gems policy: gems are NOT free for everyone.
--   * anyone can get gems by paying (the owner grants a pack after payment: admin_grant_gems)
--   * VIP members additionally earn gems from lessons/streaks/goals and can claim a daily VIP bonus
-- (Admin > Settings can set economy.gems.free_earn = true to let everybody earn gems again.)
-- Spending gems (negative amounts) is never blocked.
create or replace function private.gem_add(uid uuid, delta int, p_reason text, p_ref text, p_meta jsonb) returns boolean
language plpgsql security definer set search_path = public, private as $$
declare bal int; ins bigint;
begin
  if delta = 0 then return false; end if;
  if delta > 0 and p_reason not in ('admin','purchase','vip_daily') and not private.is_vip(uid)
     and not coalesce((private.cfg()->'gems'->>'free_earn')::boolean, false) then
    return false;   -- free accounts do not earn gems
  end if;
  insert into public.gem_transactions (user_id, delta, reason, ref, balance_after, meta)
  values (uid, delta, p_reason, coalesce(p_ref, ''), 0, coalesce(p_meta, '{}'::jsonb))
  on conflict (user_id, reason, ref) do nothing returning id into ins;
  if ins is null then return false; end if;
  update public.player_state set gems = gems + delta, updated_at = now() where user_id = uid returning gems into bal;
  if bal is null then raise exception 'no_state'; end if;
  update public.gem_transactions set balance_after = bal where id = ins;
  return true;
exception when check_violation then
  raise exception 'not_enough_gems';
end $$;

create or replace function public.claim_vip_gems() returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); amt int; d date; ok boolean;
begin
  if uid is null then raise exception 'denied'; end if;
  if not private.is_vip(uid) then raise exception 'vip_only'; end if;
  perform private.ps_get(uid);
  amt := coalesce((private.cfg()->'gems'->>'vip_daily')::int, 10);
  d := private.local_day(uid);
  ok := private.gem_add(uid, amt, 'vip_daily', d::text, '{}'::jsonb);
  return jsonb_build_object('claimed', ok, 'amount', amt, 'state', private.state_json(uid));
end $$;
grant execute on function public.claim_vip_gems() to authenticated;

create or replace function public.admin_grant_gems(p_user uuid, p_amount int, p_note text default '') returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare ok boolean;
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  if p_amount is null or p_amount < 1 or p_amount > 100000 then raise exception 'invalid'; end if;
  if not exists (select 1 from public.profiles where id = p_user) then raise exception 'other'; end if;
  perform private.ps_get(p_user);
  ok := private.gem_add(p_user, p_amount, 'purchase', gen_random_uuid()::text, jsonb_build_object('note', left(coalesce(p_note,''), 200), 'by', auth.uid()));
  return jsonb_build_object('granted', ok, 'amount', p_amount);
end $$;
grant execute on function public.admin_grant_gems(uuid, int, text) to authenticated;

-- ===== supabase/migrations/006_pics_type.sql =====
-- New exercise type 'pics': hear/see a word and tap the right picture (emoji or uploaded image).
alter table public.questions drop constraint if exists questions_type_check;
alter table public.questions add constraint questions_type_check
  check (type in ('intro','mc','image','listen','read','type','match','order','fill','speak','tf','fix','pics'));

-- ===== supabase/migrations/007_roles_profile_friends.sql =====
-- Lingora migration 007 (Part 1): roles, profile fields, VIP subscription ledger, friends.
-- Safe to run more than once. Requires 001-006.
--
-- Role model
--   super_admin : owner. The ONLY role that can grant or remove admin/editor. Can only be assigned from the SQL editor.
--   admin       : manages users (VIP, suspension, gems), content and settings. Cannot create other admins.
--   editor      : manages courses and lessons only.
--   user        : learner. "VIP" is not a role: it is derived from profiles.vip_until (written only by admin_grant_vip).
--                 A learner without an active VIP period is a Free user.
--
-- Make yourself the owner (run in the SQL editor, which is not subject to the guard below):
--   update public.profiles set role = 'super_admin' where email = 'you@example.com';

-- ---------------------------------------------------------------------------------------------
-- 1. Roles
-- ---------------------------------------------------------------------------------------------
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check check (role in ('user','editor','admin','super_admin'));

-- is_admin stays the single flag every existing policy uses. It is now derived from role by a trigger (below).
update public.profiles set role = 'admin' where is_admin and role in ('user','editor');
update public.profiles set is_admin = true where role in ('admin','super_admin') and not is_admin;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select (is_admin or role in ('admin','super_admin')) from public.profiles where id = auth.uid()), false)
$$;

create or replace function public.is_editor() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select (is_admin or role in ('editor','admin','super_admin')) and not suspended
                   from public.profiles where id = auth.uid()), false)
$$;

create or replace function public.is_super_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select role = 'super_admin' and not suspended from public.profiles where id = auth.uid()), false)
$$;
revoke all on function public.is_super_admin() from public;
grant execute on function public.is_super_admin() to authenticated;

-- ---------------------------------------------------------------------------------------------
-- 2. Profile fields: username and avatar
-- ---------------------------------------------------------------------------------------------
alter table public.profiles add column if not exists username text;
alter table public.profiles add column if not exists avatar text not null default '';
alter table public.profiles drop constraint if exists profiles_username_check;
alter table public.profiles add constraint profiles_username_check check (username is null or username ~ '^[a-z0-9_]{3,20}$');
alter table public.profiles drop constraint if exists profiles_avatar_check;
alter table public.profiles add constraint profiles_avatar_check check (avatar ~ '^[a-z0-9_-]{0,24}$');
create unique index if not exists profiles_username_key on public.profiles (lower(username)) where username is not null;

-- ---------------------------------------------------------------------------------------------
-- 3. Guard: nobody can raise their own privileges, and only the owner can change admin roles.
--    Runs for every UPDATE that comes through the API. The SQL editor / service role (auth.uid() is null)
--    and the SECURITY DEFINER functions below (they set lingora.priv) are trusted.
-- ---------------------------------------------------------------------------------------------
create or replace function private.guard_profile_update() returns trigger
language plpgsql security definer set search_path = public, private as $$
declare caller uuid := auth.uid(); sup boolean; adm boolean;
begin
  -- keep role and is_admin consistent whichever one was edited
  if new.role is distinct from old.role then
    new.is_admin := new.role in ('admin','super_admin');
  elsif new.is_admin is distinct from old.is_admin then
    new.role := case when new.is_admin then 'admin' when old.role in ('admin','super_admin') then 'user' else old.role end;
  end if;

  if caller is null or coalesce(current_setting('lingora.priv', true), '') = '1' then return new; end if;

  select (role = 'super_admin' and not suspended), (is_admin and not suspended) into sup, adm
    from public.profiles where id = caller;
  sup := coalesce(sup, false); adm := coalesce(adm, false);

  if new.id is distinct from old.id or new.created_at is distinct from old.created_at
     or new.friend_code is distinct from old.friend_code then
    raise exception 'denied';
  end if;

  -- role / admin flag: owner only, never on yourself, never to super_admin through the API
  if new.role is distinct from old.role or new.is_admin is distinct from old.is_admin then
    if not sup then raise exception 'denied'; end if;
    if caller = old.id then raise exception 'denied_self'; end if;
    if new.role = 'super_admin' or old.role = 'super_admin' then raise exception 'denied'; end if;
  end if;

  -- VIP period and suspension: admins only. Staff accounts can only be suspended by the owner.
  if new.vip_until is distinct from old.vip_until or new.suspended is distinct from old.suspended then
    if not adm then raise exception 'denied'; end if;
    if new.suspended is distinct from old.suspended and (old.is_admin or old.role = 'super_admin') and not sup then
      raise exception 'denied';
    end if;
    if new.suspended and caller = old.id then raise exception 'denied_self'; end if;
  end if;

  -- a non-admin can never change anything else about a row that is not their own
  if caller <> old.id and not adm then raise exception 'denied'; end if;
  return new;
end $$;

drop trigger if exists guard_profile_update on public.profiles;
create trigger guard_profile_update before update on public.profiles
  for each row execute function private.guard_profile_update();

-- Owner-only role change (clear errors instead of a generic trigger failure).
create or replace function public.admin_set_role(p_user uuid, p_role text) returns jsonb
language plpgsql security definer set search_path = public, private as $$
begin
  if auth.uid() is null or not public.is_super_admin() then raise exception 'denied'; end if;
  if p_role not in ('user','editor','admin') then raise exception 'invalid'; end if;
  if p_user = auth.uid() then raise exception 'denied_self'; end if;
  if not exists (select 1 from public.profiles where id = p_user) then raise exception 'other'; end if;
  if exists (select 1 from public.profiles where id = p_user and role = 'super_admin') then raise exception 'denied'; end if;
  perform set_config('lingora.priv', '1', true);
  update public.profiles set role = p_role where id = p_user;
  return jsonb_build_object('user', p_user, 'role', p_role);
end $$;
revoke all on function public.admin_set_role(uuid, text) from public;
grant execute on function public.admin_set_role(uuid, text) to authenticated;

-- ---------------------------------------------------------------------------------------------
-- 4. VIP subscriptions: an append-only ledger. profiles.vip_until stays the fast check used by policies.
-- ---------------------------------------------------------------------------------------------
create table if not exists public.vip_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan text not null default 'custom' check (plan in ('month','quarter','year','custom','revoked')),
  days int not null default 0,
  starts_at timestamptz not null default now(),
  ends_at timestamptz,
  source text not null default 'admin' check (source in ('admin','payment','promo')),
  granted_by uuid references auth.users(id) on delete set null,
  note text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists vip_sub_user_idx on public.vip_subscriptions (user_id, created_at desc);
alter table public.vip_subscriptions enable row level security;
drop policy if exists "vipsub own" on public.vip_subscriptions;
create policy "vipsub own" on public.vip_subscriptions for select using (user_id = auth.uid() or public.is_admin());
-- no insert/update/delete policies: only the functions below write to it.

create or replace function public.admin_grant_vip(p_user uuid, p_days int, p_note text default '') returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare base timestamptz; ends timestamptz;
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  if p_days is null or p_days < 1 or p_days > 3660 then raise exception 'invalid'; end if;
  if not exists (select 1 from public.profiles where id = p_user) then raise exception 'other'; end if;
  select greatest(now(), coalesce(vip_until, now())) into base from public.profiles where id = p_user for update;
  ends := base + make_interval(days => p_days);
  insert into public.vip_subscriptions (user_id, plan, days, starts_at, ends_at, source, granted_by, note)
  values (p_user, case p_days when 30 then 'month' when 90 then 'quarter' when 365 then 'year' else 'custom' end,
          p_days, base, ends, 'admin', auth.uid(), left(coalesce(p_note, ''), 200));
  perform set_config('lingora.priv', '1', true);
  update public.profiles set vip_until = ends where id = p_user;
  return jsonb_build_object('user', p_user, 'vip_until', ends);
end $$;
revoke all on function public.admin_grant_vip(uuid, int, text) from public;
grant execute on function public.admin_grant_vip(uuid, int, text) to authenticated;

create or replace function public.admin_revoke_vip(p_user uuid, p_note text default '') returns jsonb
language plpgsql security definer set search_path = public, private as $$
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  if not exists (select 1 from public.profiles where id = p_user) then raise exception 'other'; end if;
  insert into public.vip_subscriptions (user_id, plan, days, starts_at, ends_at, source, granted_by, note)
  values (p_user, 'revoked', 0, now(), now(), 'admin', auth.uid(), left(coalesce(p_note, ''), 200));
  perform set_config('lingora.priv', '1', true);
  update public.profiles set vip_until = null where id = p_user;
  return jsonb_build_object('user', p_user, 'vip_until', null);
end $$;
revoke all on function public.admin_revoke_vip(uuid, text) from public;
grant execute on function public.admin_revoke_vip(uuid, text) to authenticated;

-- ---------------------------------------------------------------------------------------------
-- 5. Profile editing (the only way a learner changes name / username / avatar)
-- ---------------------------------------------------------------------------------------------
create or replace function public.update_my_profile(p_name text, p_username text, p_avatar text) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); nm text := btrim(coalesce(p_name, '')); un text := nullif(lower(btrim(coalesce(p_username, ''))), '');
        av text := coalesce(p_avatar, '');
begin
  if uid is null then raise exception 'denied'; end if;
  if public.is_suspended() then raise exception 'denied'; end if;
  perform private.rl('profile_edit', 30, 3600);
  if char_length(nm) < 1 or char_length(nm) > 24 then raise exception 'invalid_name'; end if;
  if un is not null and un !~ '^[a-z0-9_]{3,20}$' then raise exception 'invalid_username'; end if;
  if av !~ '^[a-z0-9_-]{0,24}$' then raise exception 'invalid'; end if;
  begin
    perform set_config('lingora.priv', '1', true);
    update public.profiles set name = nm, username = un, avatar = av where id = uid;
  exception when unique_violation then
    raise exception 'username_taken';
  end;
  return jsonb_build_object('name', nm, 'username', un, 'avatar', av);
end $$;
revoke all on function public.update_my_profile(text, text, text) from public;
grant execute on function public.update_my_profile(text, text, text) to authenticated;

-- ---------------------------------------------------------------------------------------------
-- 6. Friends: a real friendship graph. Browsers never read other people's rows directly.
-- ---------------------------------------------------------------------------------------------
create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  requester uuid not null references auth.users(id) on delete cascade,
  addressee uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted')),
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  check (requester <> addressee)
);
create unique index if not exists friendships_pair_key on public.friendships (least(requester, addressee), greatest(requester, addressee));
create index if not exists friendships_addr_idx on public.friendships (addressee, status);
create index if not exists friendships_req_idx on public.friendships (requester, status);
alter table public.friendships enable row level security;
drop policy if exists "friendships own read" on public.friendships;
create policy "friendships own read" on public.friendships for select using (requester = auth.uid() or addressee = auth.uid() or public.is_admin());
-- no write policies: friend_request / friend_respond / friend_remove below are the only writers.

-- Sends a request by friend code (always allowed) or by username (only when that person is searchable).
-- If the other person already asked you, the request is accepted instead.
create or replace function public.friend_request(p_who text) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); q text := lower(btrim(coalesce(p_who, ''))); tgt public.profiles; ex public.friendships;
        cfg jsonb := private.cfg()->'friends'; nfr int; npend int;
begin
  if uid is null or public.is_suspended() then raise exception 'denied'; end if;
  perform private.rl('friend_req', 20, 3600);
  if q = '' or char_length(q) > 40 then raise exception 'invalid'; end if;
  select * into tgt from public.profiles
   where not suspended and (lower(friend_code) = q or (lower(username) = q and coalesce((privacy->>'searchable')::boolean, true)))
   limit 1;
  if tgt.id is null then raise exception 'not_found'; end if;
  if tgt.id = uid then raise exception 'self'; end if;
  select * into ex from public.friendships
   where least(requester, addressee) = least(uid, tgt.id) and greatest(requester, addressee) = greatest(uid, tgt.id);
  if ex.id is not null then
    if ex.status = 'accepted' then raise exception 'already_friends'; end if;
    if ex.requester = uid then raise exception 'already_sent'; end if;
    update public.friendships set status = 'accepted', responded_at = now() where id = ex.id;
    return jsonb_build_object('status', 'accepted');
  end if;
  select count(*) into nfr from public.friendships where status = 'accepted' and (requester = uid or addressee = uid);
  if nfr >= coalesce((cfg->>'max')::int, 200) then raise exception 'friend_limit'; end if;
  select count(*) into npend from public.friendships where status = 'pending' and requester = uid;
  if npend >= coalesce((cfg->>'pending_max')::int, 50) then raise exception 'pending_limit'; end if;
  insert into public.friendships (requester, addressee) values (uid, tgt.id);
  return jsonb_build_object('status', 'pending');
end $$;
revoke all on function public.friend_request(text) from public;
grant execute on function public.friend_request(text) to authenticated;

create or replace function public.friend_respond(p_id uuid, p_accept boolean) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); f public.friendships;
begin
  if uid is null or public.is_suspended() then raise exception 'denied'; end if;
  perform private.rl('friend_resp', 60, 3600);
  select * into f from public.friendships where id = p_id and addressee = uid and status = 'pending' for update;
  if f.id is null then raise exception 'not_found'; end if;
  if coalesce(p_accept, false) then
    update public.friendships set status = 'accepted', responded_at = now() where id = f.id;
    return jsonb_build_object('status', 'accepted');
  end if;
  delete from public.friendships where id = f.id;
  return jsonb_build_object('status', 'declined');
end $$;
revoke all on function public.friend_respond(uuid, boolean) from public;
grant execute on function public.friend_respond(uuid, boolean) to authenticated;

-- Removes a friend, cancels a request you sent, or (for the addressee) is the same as declining.
create or replace function public.friend_remove(p_id uuid) returns void
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'denied'; end if;
  perform private.rl('friend_rm', 60, 3600);
  delete from public.friendships where id = p_id and (requester = uid or addressee = uid);
end $$;
revoke all on function public.friend_remove(uuid) from public;
grant execute on function public.friend_remove(uuid) to authenticated;

-- Everything the Friends tab and the dashboard preview need, in one call.
-- Other people's data is limited to: display name, username, avatar, level, streak and 7-day XP,
-- and activity is hidden when that person turned "show activity" off. No emails, no ids of strangers.
create or replace function public.friends_overview() returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); me public.profiles; fr jsonb; inc jsonb; outc int;
begin
  if uid is null then raise exception 'denied'; end if;
  select * into me from public.profiles where id = uid;
  select coalesce(jsonb_agg(x order by (x->>'week_xp')::int desc nulls last, x->>'name'), '[]'::jsonb) into fr from (
    select jsonb_build_object(
      'id', f.id,
      'name', coalesce(nullif(p.name, ''), 'Learner'),
      'username', p.username,
      'avatar', p.avatar,
      'show', coalesce((p.privacy->>'show_activity')::boolean, true),
      'level', case when coalesce((p.privacy->>'show_activity')::boolean, true) then private.level_of(coalesce(ps.xp, 0)) end,
      'streak', case when coalesce((p.privacy->>'show_activity')::boolean, true)
                     and ps.last_day is not null and ps.last_day >= private.local_day(p.id) - 1 then ps.streak end,
      'week_xp', case when coalesce((p.privacy->>'show_activity')::boolean, true) then
                   (select coalesce(sum(e.amount), 0) from public.xp_events e where e.user_id = p.id and e.created_at > now() - interval '7 days') end
    ) as x
    from public.friendships f
    join public.profiles p on p.id = case when f.requester = uid then f.addressee else f.requester end and not p.suspended
    left join public.player_state ps on ps.user_id = p.id
    where f.status = 'accepted' and (f.requester = uid or f.addressee = uid)
  ) s;
  select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'name', coalesce(nullif(p.name, ''), 'Learner'),
                                               'username', p.username, 'avatar', p.avatar, 'at', f.created_at) order by f.created_at desc), '[]'::jsonb)
    into inc
    from public.friendships f join public.profiles p on p.id = f.requester and not p.suspended
    where f.status = 'pending' and f.addressee = uid;
  select count(*) into outc from public.friendships where status = 'pending' and requester = uid;
  return jsonb_build_object('code', me.friend_code, 'username', me.username, 'friends', fr, 'incoming', inc, 'outgoing', outc);
end $$;
revoke all on function public.friends_overview() from public;
grant execute on function public.friends_overview() to authenticated;

-- The 'friends' achievement metric was a placeholder; count real accepted friendships.
create or replace function private.metric(uid uuid, p_metric text) returns numeric
language plpgsql stable security definer set search_path = public, private as $$
begin
  return case p_metric
    when 'lessons' then (select count(*) from public.lesson_completions where user_id = uid)
    when 'perfect' then (select count(*) from public.lesson_completions where user_id = uid and best_stars >= 3)
    when 'xp' then (select xp from public.player_state where user_id = uid)
    when 'level' then (select private.level_of(xp) from public.player_state where user_id = uid)
    when 'best_streak' then (select best_streak from public.player_state where user_id = uid)
    when 'practice' then (select count(*) from public.lesson_attempts where user_id = uid and kind = 'practice' and status = 'done')
    when 'units' then (
      select count(*) from public.units u
      where u.published
        and exists (select 1 from public.lessons l where l.unit_id = u.id and l.published)
        and not exists (select 1 from public.lessons l where l.unit_id = u.id and l.published
                        and not exists (select 1 from public.lesson_completions c where c.user_id = uid and c.lesson_id = l.id)))
    when 'friends' then (select count(*) from public.friendships where status = 'accepted' and (requester = uid or addressee = uid))
    else 0 end;
end $$;

-- ---------------------------------------------------------------------------------------------
-- 7. The caller's own access summary (role, VIP state) so the browser never has to guess.
-- ---------------------------------------------------------------------------------------------
create or replace function public.my_access() returns jsonb
language sql stable security definer set search_path = public as $$
  select case when p.id is null then null else jsonb_build_object(
    'role', p.role, 'is_admin', p.is_admin or p.role in ('admin','super_admin'),
    'is_super', p.role = 'super_admin', 'suspended', p.suspended,
    'vip', coalesce(p.is_admin, false) or (p.vip_until is not null and p.vip_until > now()),
    'vip_until', p.vip_until) end
  from (select 1) d left join public.profiles p on p.id = auth.uid()
$$;
revoke all on function public.my_access() from public;
grant execute on function public.my_access() to authenticated;

-- ===== supabase/migrations/008_learning_engine.sql =====
-- PART 2: learning engine. Server-side answer validation, exercise attempts, mistake book (spaced repetition),
-- two more exercise types, five course levels, categories. Safe to run on top of 001-007.

-- ===== courses: levels + categories =====
update public.courses set difficulty = case difficulty when 'easy' then 'beginner' when 'medium' then 'intermediate' when 'hard' then 'advanced' else difficulty end
  where difficulty in ('easy','medium','hard');
alter table public.courses alter column difficulty set default 'beginner';
alter table public.courses drop constraint if exists courses_difficulty_check;
alter table public.courses add constraint courses_difficulty_check
  check (difficulty in ('beginner','elementary','intermediate','upper_intermediate','advanced','easy','medium','hard'));
alter table public.courses add column if not exists categories text[] not null default '{}';

-- ===== questions: new types, publish flag (admin: publish/unpublish single exercises) =====
alter table public.questions add column if not exists published boolean not null default true;
alter table public.questions drop constraint if exists questions_type_check;
alter table public.questions add constraint questions_type_check
  check (type in ('intro','mc','image','listen','read','type','match','order','fill','speak','tf','fix','pics','listen_type','write'));

-- ===== helpers =====
create or replace function private.fold(x text) returns text language sql immutable as $$
  select btrim(regexp_replace(regexp_replace(lower(translate(coalesce(x,''),
    'ÁÀÂÄÃÅÇÉÈÊËÍÌÎÏÑÓÒÔÖÕÚÙÛÜÝáàâäãåçéèêëíìîïñóòôöõúùûüýÿšžčğışœŠŽČĞİŞ',
    'AAAAAACEEEEIIIINOOOOOUUUUYaaaaaaceeeeiiiinooooouuuuyyszcgisoSZCGIS')),
    '[.,!?։՞՜]', '', 'g'), '\s+', ' ', 'g'))
$$;
create or replace function private.norm(x text) returns text language sql immutable as $$
  select btrim(regexp_replace(regexp_replace(lower(coalesce(x,'')), '[.,!?։՞՜]', '', 'g'), '\s+', ' ', 'g'))
$$;
-- true when a and b differ by at most one edit (insert, delete, replace, or swap of neighbours)
create or replace function private.lev1(a text, b text) returns boolean language plpgsql immutable as $$
declare i int := 1; la int := length(a); lb int := length(b);
begin
  if abs(la - lb) > 1 then return false; end if;
  while i <= least(la, lb) and substr(a,i,1) = substr(b,i,1) loop i := i + 1; end loop;
  if i > least(la, lb) then return true; end if;
  if la = lb then
    return substr(a,i+1) = substr(b,i+1) or (substr(a,i,1) = substr(b,i+1,1) and substr(a,i+1,1) = substr(b,i,1) and substr(a,i+2) = substr(b,i+2));
  end if;
  if la > lb then return substr(a,i+1) = substr(b,i); end if;
  return substr(b,i+1) = substr(a,i);
end $$;

-- a question is playable only if it has what the player needs (mirrors the app's toStep)
create or replace function private.q_valid(t text, d jsonb) returns boolean language sql immutable as $$
  select case t
    when 'intro' then coalesce(d->>'en','') <> '' and coalesce(d->>'hy','') <> ''
    when 'mc' then coalesce(d->>'prompt','') <> '' and coalesce(d->>'answer','') <> ''
    when 'image' then d->'vis' is not null and coalesce(d->>'answer','') <> ''
    when 'listen' then coalesce(d->>'text','') <> '' and coalesce(d->>'answer','') <> ''
    when 'read' then coalesce(d->>'passage','') <> '' and coalesce(d->>'prompt','') <> '' and coalesce(d->>'answer','') <> ''
    when 'type' then coalesce(d->>'prompt','') <> '' and coalesce(d->>'answer','') <> ''
    when 'match' then jsonb_typeof(d->'pairs') = 'array' and jsonb_array_length(d->'pairs') >= 2
    when 'speak' then coalesce(d->>'text','') <> ''
    when 'tf' then d->>'answer' in ('true','false') and coalesce(d->>'statement','') <> ''
    when 'fix' then coalesce(d->>'wrong','') <> '' and coalesce(d->>'answer','') <> ''
    when 'order' then coalesce(d->>'sentence','') <> ''
    when 'fill' then position('___' in coalesce(d->>'sentence','')) > 0 and coalesce(d->>'answer','') <> ''
    when 'pics' then jsonb_typeof(d->'items') = 'array' and jsonb_array_length(d->'items') >= 3 and coalesce(d->>'answer','') <> ''
    when 'listen_type' then coalesce(d->>'text','') <> ''
    when 'write' then coalesce(d->>'prompt','') <> '' and (coalesce(d->>'answer','') <> '' or jsonb_typeof(d->'keywords') = 'array')
    else false end
$$;

-- server-side verdict. true / false, or null when the server cannot judge it (speaking).
create or replace function private.check_answer(t text, d jsonb, a jsonb, lenient boolean) returns boolean
language plpgsql immutable as $$
declare txt text; acc jsonb; x jsonb; ok boolean; words text[]; given text[]; n int; kw jsonb; k text;
begin
  case t
    when 'mc','image','listen','read','fill','pics','tf' then
      return coalesce(a->>'choice','') <> '' and (a->>'choice') = (d->>'answer');
    when 'type','fix','listen_type','write' then
      txt := coalesce(a->>'text','');
      if btrim(txt) = '' then return false; end if;
      acc := coalesce(d->'accept', '[]'::jsonb);
      if coalesce(d->>'answer','') <> '' then acc := acc || to_jsonb(d->>'answer'); end if;
      if t = 'listen_type' then acc := acc || to_jsonb(d->>'text'); end if;
      for x in select * from jsonb_array_elements(acc) loop
        if private.fold(x #>> '{}') = private.fold(txt) and private.fold(txt) <> '' then return true; end if;
        if lenient and length(private.fold(txt)) >= 5 and length(private.fold(x #>> '{}')) >= 5
           and private.lev1(private.fold(x #>> '{}'), private.fold(txt)) then return true; end if;
      end loop;
      if t = 'write' and jsonb_typeof(d->'keywords') = 'array' and jsonb_array_length(d->'keywords') > 0 then
        ok := true;
        for k in select jsonb_array_elements_text(d->'keywords') loop
          if position(private.fold(k) in private.fold(txt)) = 0 then ok := false; end if;
        end loop;
        return ok;
      end if;
      return false;
    when 'order' then
      words := string_to_array(btrim(regexp_replace(d->>'sentence', '[?.!,։]', '', 'g')), ' ');
      select array_agg(w) into given from jsonb_array_elements_text(coalesce(a->'tokens','[]'::jsonb)) w;
      return lower(array_to_string(words, ' ')) = lower(coalesce(array_to_string(given, ' '), '~'));
    when 'match' then
      n := jsonb_array_length(d->'pairs');
      if jsonb_typeof(a->'pairs') <> 'array' or jsonb_array_length(a->'pairs') <> n then return false; end if;
      for x in select * from jsonb_array_elements(a->'pairs') loop
        if not exists (select 1 from jsonb_array_elements(d->'pairs') p where p->>0 = x->>0 and p->>1 = x->>1) then return false; end if;
      end loop;
      return (select count(distinct (e->>0)) from jsonb_array_elements(a->'pairs') e) = n;
    else return null;
  end case;
end $$;

-- ===== tables =====
create table if not exists public.exercise_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  attempt_id uuid not null references public.lesson_attempts(id) on delete cascade,
  lesson_id text,
  question_id text not null,
  qtype text not null,
  seq int not null,
  correct boolean not null,
  verified boolean not null default true,
  answer jsonb,
  ms int,
  created_at timestamptz not null default now(),
  unique (attempt_id, seq)
);
create index if not exists exercise_attempts_user_idx on public.exercise_attempts(user_id, created_at desc);
create index if not exists exercise_attempts_q_idx on public.exercise_attempts(question_id);
alter table public.exercise_attempts enable row level security;
drop policy if exists "own exercise attempts" on public.exercise_attempts;
create policy "own exercise attempts" on public.exercise_attempts for select using (user_id = auth.uid() or public.is_editor());

create table if not exists public.mistake_book (
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id text not null,
  lesson_id text,
  qtype text not null,
  wrong_count int not null default 0,
  right_streak int not null default 0,
  box int not null default 1 check (box between 1 and 5),
  last_wrong_at timestamptz,
  next_review date not null default current_date,
  mastered_at timestamptz,
  primary key (user_id, question_id)
);
alter table public.mistake_book enable row level security;
drop policy if exists "own mistakes" on public.mistake_book;
create policy "own mistakes" on public.mistake_book for select using (user_id = auth.uid());

-- ===== submit_answer =====
create or replace function public.submit_answer(p_attempt uuid, p_question text, p_seq int, p_answer jsonb,
  p_client_ok boolean default null, p_lenient boolean default false, p_ms int default null) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); a public.lesson_attempts; q public.questions; ex public.exercise_attempts;
        v boolean; ok boolean; ver boolean; mb public.mistake_book; nb int;
begin
  if uid is null then raise exception 'denied'; end if;
  if p_seq is null or p_seq < 0 or p_seq > 5000 then raise exception 'invalid'; end if;
  select * into a from public.lesson_attempts where id = p_attempt and user_id = uid for update;
  if not found or a.status <> 'open' then raise exception 'not_found'; end if;
  select * into ex from public.exercise_attempts where attempt_id = a.id and seq = p_seq;
  if found then                                           -- a repeated submit returns the stored verdict, nothing changes
    if ex.question_id <> p_question then raise exception 'invalid'; end if;
    return jsonb_build_object('correct', ex.correct, 'verified', ex.verified, 'duplicate', true);
  end if;
  if (select count(*) from public.exercise_attempts where attempt_id = a.id) >= a.questions * 6 + 20 then raise exception 'rate_limited'; end if;
  select * into q from public.questions where id = p_question;
  if not found or q.type = 'intro' then raise exception 'not_found'; end if;
  if a.kind = 'lesson' and q.lesson_id is distinct from a.lesson_id then raise exception 'invalid'; end if;
  v := private.check_answer(q.type, q.data, p_answer, coalesce(p_lenient, false));
  ver := v is not null;
  ok := coalesce(v, coalesce(p_client_ok, false));
  insert into public.exercise_attempts (user_id, attempt_id, lesson_id, question_id, qtype, seq, correct, verified, answer, ms)
  values (uid, a.id, q.lesson_id, q.id, q.type, p_seq, ok, ver, left(p_answer::text, 2000)::jsonb, p_ms);
  -- mistake book + spaced repetition (boxes 1..5 -> 1, 2, 4, 8, 16 days)
  if not ok then
    insert into public.mistake_book (user_id, question_id, lesson_id, qtype, wrong_count, right_streak, box, last_wrong_at, next_review)
    values (uid, q.id, q.lesson_id, q.type, 1, 0, 1, now(), current_date + 1)
    on conflict (user_id, question_id) do update set wrong_count = mistake_book.wrong_count + 1, right_streak = 0, box = 1,
      last_wrong_at = now(), next_review = current_date + 1, mastered_at = null;
  else
    select * into mb from public.mistake_book where user_id = uid and question_id = q.id;
    if found then
      nb := least(mb.box + 1, 5);
      update public.mistake_book set right_streak = right_streak + 1, box = nb,
        next_review = current_date + (case nb when 2 then 2 when 3 then 4 when 4 then 8 else 16 end),
        mastered_at = case when right_streak + 1 >= 3 then coalesce(mastered_at, now()) else null end
      where user_id = uid and question_id = q.id;
    end if;
  end if;
  return jsonb_build_object('correct', ok, 'verified', ver, 'duplicate', false);
end $$;
grant execute on function public.submit_answer(uuid, text, int, jsonb, boolean, boolean, int) to authenticated;

-- the learner's own mistake book: hardest first, with the question so it can be practised again
create or replace function public.my_mistakes(p_limit int default 60) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'denied'; end if;
  return coalesce((select jsonb_agg(r order by r.wrong_count desc, r.last_wrong_at desc) from (
    select m.question_id, m.lesson_id, m.qtype, m.wrong_count, m.right_streak, m.box, m.last_wrong_at, m.next_review,
           (m.next_review <= current_date) as due, (m.mastered_at is not null) as mastered, q.data
    from public.mistake_book m join public.questions q on q.id = m.question_id
    where m.user_id = uid and q.published
    order by m.mastered_at is not null, m.wrong_count desc limit least(greatest(p_limit,1),200)) r), '[]'::jsonb);
end $$;
grant execute on function public.my_mistakes(int) to authenticated;

-- complete_lesson now derives mistakes from the answers the server recorded and refuses lessons with unanswered exercises
create or replace function public.complete_lesson(p_attempt uuid, p_mistakes int) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare
  uid uuid := auth.uid(); a public.lesson_attempts; cfg jsonb := private.cfg(); ps public.player_state; l public.lessons;
  mis int := least(greatest(coalesce(p_mistakes, 0), 0), 60); stars int; first_time boolean; raw int; mult numeric := 1; xp int; g int := 0;
  lv0 int; lv1 int; unit_done boolean := false; today_xp int; cap int; d date := private.local_day(uid);
  ev jsonb; ach jsonb; goal_hit boolean := false; res jsonb; gmult jsonb; star_xp int := (cfg->'xp'->>'star')::int;
  done_today int; wrong_rows int; has_rows boolean; need_answers boolean := coalesce((cfg->'answers'->>'required')::boolean, true);
begin
  if uid is null then raise exception 'denied'; end if;
  select * into a from public.lesson_attempts where id = p_attempt and user_id = uid for update;
  if not found then raise exception 'not_found'; end if;
  if a.status = 'done' then return a.result; end if;        -- repeated call: same answer, no second reward
  if a.kind <> 'lesson' then raise exception 'invalid'; end if;
  if extract(epoch from (now() - a.started_at)) < a.questions * (cfg->'xp'->>'sec_per_question')::numeric then raise exception 'too_fast'; end if;
  select count(*) into done_today from public.lesson_attempts where user_id = uid and kind = 'lesson' and status = 'done' and finished_day = d;
  if done_today >= (cfg->'xp'->>'completions_per_day')::int then raise exception 'rate_limited'; end if;

  select count(*) filter (where not correct), count(*) > 0 into wrong_rows, has_rows from public.exercise_attempts where attempt_id = a.id;
  if need_answers and exists (
       select 1 from public.questions q
       where q.lesson_id = a.lesson_id and q.type <> 'intro' and q.published and private.q_valid(q.type, q.data)
         and not exists (select 1 from public.exercise_attempts e where e.attempt_id = a.id and e.question_id = q.id and e.correct)) then
    raise exception 'incomplete';          -- every exercise must have a correct, server-recorded answer
  end if;
  if has_rows then mis := least(greatest(wrong_rows, a.misses), 60); end if;
  ps := private.ps_get(uid);
  select * into l from public.lessons where id = a.lesson_id;
  lv0 := private.level_of(ps.xp);
  select exists (select 1 from public.lesson_completions where user_id = uid and lesson_id = a.lesson_id) into first_time; first_time := not first_time;
  stars := case when mis = 0 then 3 when mis <= 2 then 2 else 1 end;

  if first_time then
    raw := coalesce(l.xp, 8) + stars * star_xp;
  else
    raw := (cfg->'xp'->>'repeat')::int;
  end if;

  insert into public.lesson_completions (user_id, lesson_id, best_stars) values (uid, a.lesson_id, stars)
  on conflict (user_id, lesson_id) do update set best_stars = greatest(lesson_completions.best_stars, excluded.best_stars),
        times = lesson_completions.times + 1, last_at = now();

  if first_time then
    unit_done := exists (select 1 from public.lessons x where x.unit_id = l.unit_id and x.published)
      and not exists (select 1 from public.lessons x where x.unit_id = l.unit_id and x.published
                      and not exists (select 1 from public.lesson_completions c where c.user_id = uid and c.lesson_id = x.id));
    if unit_done then raw := raw + (cfg->'xp'->>'unit')::int; end if;
  end if;
  raw := least(raw, (cfg->'xp'->>'max_lesson_xp')::int);

  -- XP multipliers: admin event and personal boost, never stacked
  gmult := cfg->'multiplier';
  if coalesce((gmult->>'value')::numeric, 1) > 1 and (coalesce(gmult->>'until', '') = '' or (gmult->>'until')::timestamptz > now()) then mult := (gmult->>'value')::numeric; end if;
  if ps.boost_until is not null and ps.boost_until > now() then mult := greatest(mult, ps.boost_mult); end if;
  xp := round(raw * mult)::int;
  cap := (cfg->'xp'->>'daily_cap')::int;
  select coalesce(sum(amount), 0) into today_xp from public.xp_events where user_id = uid and day = d and kind in ('lesson','practice');
  xp := greatest(0, least(xp, cap - today_xp));

  ev := private.touch_streak(uid);
  perform private.xp_add(uid, xp, 'lesson', a.lesson_id, jsonb_build_object('stars', stars, 'mistakes', mis, 'words', a.words, 'speaking', a.speaking));

  if first_time then
    g := (cfg->'gems'->>'lesson')::int + case when stars = 3 then (cfg->'gems'->>'perfect')::int else 0 end + case when unit_done then (cfg->'gems'->>'unit')::int else 0 end;
  else
    g := (cfg->'gems'->>'repeat')::int;
  end if;
  update public.lesson_attempts set status = 'done', finished_at = now(), finished_day = d, mistakes = mis where id = a.id;
  perform private.gem_add(uid, g, 'lesson', a.id::text, jsonb_build_object('lesson', a.lesson_id));

  -- daily goal reward, once per local day
  select * into ps from public.player_state where user_id = uid;
  if ps.day = d and ps.day_xp >= ps.goal then
    goal_hit := private.gem_add(uid, (cfg->'gems'->>'goal')::int, 'goal', d::text, '{}'::jsonb);
    if goal_hit then g := g + (cfg->'gems'->>'goal')::int; end if;
  end if;

  ach := private.check_achievements(uid);
  select * into ps from public.player_state where user_id = uid;
  lv1 := private.level_of(ps.xp);

  res := jsonb_build_object('xp', xp, 'raw', raw, 'mult', mult, 'stars', stars, 'gems', g, 'first', first_time, 'unit_done', unit_done,
    'goal_hit', goal_hit, 'level_up', case when lv1 > lv0 then lv1 end, 'streak_event', ev, 'achievements', ach, 'accuracy_mistakes', mis,
    'state', private.state_json(uid));
  update public.lesson_attempts set result = res where id = a.id;
  return res;
end $$;



-- ===== supabase/migrations/009_admin_vip_audit.sql =====
-- Lingora migration 009 (Part 3): audit log, VIP plans + dates + history, FREE/VIP content protection on the backend,
-- server-side user/VIP/stat queries, payments ledger (webhook-only writes), media registry, UI text overrides.
-- Safe to run more than once. Requires 001-008.

-- ---------------------------------------------------------------------------------------------
-- 1. Audit log (append-only; written only by triggers/functions, readable by admins)
-- ---------------------------------------------------------------------------------------------
create table if not exists public.audit_log (
  id bigint generated always as identity primary key,
  actor uuid references auth.users(id) on delete set null,
  actor_role text not null default '',
  action text not null,
  entity text not null,
  entity_id text not null default '',
  detail jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_log_time_idx on public.audit_log (created_at desc);
create index if not exists audit_log_entity_idx on public.audit_log (entity, entity_id);
alter table public.audit_log enable row level security;
drop policy if exists "audit admin read" on public.audit_log;
create policy "audit admin read" on public.audit_log for select using (public.is_admin());
revoke insert, update, delete on public.audit_log from anon, authenticated;

create or replace function private.like_pat(p text) returns text language sql immutable as $$
  select '%' || regexp_replace(lower(btrim(coalesce(p, ''))), '([\\%_])', E'\\\\\\1', 'g') || '%'
$$;

create or replace function private.audit(p_action text, p_entity text, p_id text, p_detail jsonb default '{}'::jsonb) returns void
language plpgsql security definer set search_path = public, private as $$
begin
  if auth.uid() is null then return; end if;          -- SQL editor / service role: not an API actor
  insert into public.audit_log (actor, actor_role, action, entity, entity_id, detail)
  values (auth.uid(), coalesce((select role from public.profiles where id = auth.uid()), ''), p_action, p_entity, coalesce(p_id, ''), coalesce(p_detail, '{}'::jsonb));
end $$;
revoke all on function private.audit(text, text, text, jsonb) from public;

-- one trigger for every content / config table: who inserted, changed or deleted which row (changed column names, not values)
create or replace function private.audit_row() returns trigger
language plpgsql security definer set search_path = public, private as $$
declare r jsonb := to_jsonb(coalesce(new, old)); o jsonb; keys text[]; idv text;
begin
  if auth.uid() is null then return coalesce(new, old); end if;
  idv := coalesce(r->>'id', r->>'key', (r->>'lang') || '.' || (r->>'key'), '');
  if tg_op = 'UPDATE' then
    o := to_jsonb(old);
    select array_agg(k) into keys from jsonb_object_keys(r) k where r->k is distinct from o->k;
    if keys is null then return new; end if;
    perform private.audit('update', tg_table_name, idv, jsonb_build_object('changed', to_jsonb(keys), 'title', coalesce(r->'title', r->'name')));
  elsif tg_op = 'INSERT' then
    perform private.audit('create', tg_table_name, idv, jsonb_build_object('title', coalesce(r->'title', r->'name')));
  else
    perform private.audit('delete', tg_table_name, idv, jsonb_build_object('title', coalesce(r->'title', r->'name')));
  end if;
  return coalesce(new, old);
end $$;

-- account-level changes (role, suspension, VIP period) are logged from profiles
create or replace function private.audit_profile() returns trigger
language plpgsql security definer set search_path = public, private as $$
declare ch jsonb := '{}'::jsonb;
begin
  if new.role is distinct from old.role then ch := ch || jsonb_build_object('role', jsonb_build_array(old.role, new.role)); end if;
  if new.suspended is distinct from old.suspended then ch := ch || jsonb_build_object('suspended', jsonb_build_array(old.suspended, new.suspended)); end if;
  if new.vip_until is distinct from old.vip_until then ch := ch || jsonb_build_object('vip_until', jsonb_build_array(old.vip_until, new.vip_until)); end if;
  if ch <> '{}'::jsonb then perform private.audit('update', 'profiles', new.id::text, ch); end if;
  return new;
end $$;
drop trigger if exists audit_profile on public.profiles;
create trigger audit_profile after update on public.profiles for each row execute function private.audit_profile();

-- ---------------------------------------------------------------------------------------------
-- 2. VIP: plans, start date, richer ledger
-- ---------------------------------------------------------------------------------------------
create table if not exists public.vip_plans (
  id text primary key check (id ~ '^[a-z0-9_-]{2,24}$'),
  title jsonb not null,
  descr jsonb not null default '{}'::jsonb,
  days int not null check (days between 1 and 3660),
  price_cents int check (price_cents is null or price_cents >= 0),     -- null = no online price (manual plans only)
  currency text not null default 'usd' check (currency ~ '^[a-z]{3}$'),
  provider_price text,                                                  -- e.g. Stripe price id; never a secret
  active boolean not null default true,
  position int not null default 0
);
alter table public.vip_plans enable row level security;
drop policy if exists "plans read" on public.vip_plans;
create policy "plans read" on public.vip_plans for select using (active or public.is_admin());
drop policy if exists "plans admin write" on public.vip_plans;
create policy "plans admin write" on public.vip_plans for all using (public.is_admin()) with check (public.is_admin());
insert into public.vip_plans (id, title, descr, days, position) values
  ('month', '{"hy":"Ամսական","en":"Monthly"}', '{}', 30, 1),
  ('year',  '{"hy":"Տարեկան","en":"Yearly"}',  '{}', 365, 2)
on conflict (id) do nothing;

alter table public.profiles add column if not exists vip_from timestamptz;       -- null = active as soon as vip_until is in the future
alter table public.vip_subscriptions drop constraint if exists vip_subscriptions_plan_check;
alter table public.vip_subscriptions add column if not exists plan_id text;
alter table public.vip_subscriptions add column if not exists action text not null default 'grant';
alter table public.vip_subscriptions add column if not exists payment_id uuid;
alter table public.vip_subscriptions drop constraint if exists vip_subscriptions_action_check;
alter table public.vip_subscriptions add constraint vip_subscriptions_action_check check (action in ('grant','extend','set','revoke','payment','refund'));

create or replace function public.is_vip() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin or (vip_until is not null and vip_until > now() and (vip_from is null or vip_from <= now()))
                   from public.profiles where id = auth.uid()), false)
$$;
create or replace function private.is_vip(uid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin or (vip_until is not null and vip_until > now() and (vip_from is null or vip_from <= now()))
                   from public.profiles where id = uid), false)
$$;

-- vip_from may only be written by admins / the functions below
create or replace function private.guard_vip_from() returns trigger
language plpgsql security definer set search_path = public, private as $$
begin
  if new.vip_from is distinct from old.vip_from and auth.uid() is not null
     and coalesce(current_setting('lingora.priv', true), '') <> '1' and not public.is_admin() then
    raise exception 'denied';
  end if;
  return new;
end $$;
drop trigger if exists guard_vip_from on public.profiles;
create trigger guard_vip_from before update on public.profiles for each row execute function private.guard_vip_from();

-- grant / extend: the period always continues from the current end (or from now); plan optional
drop function if exists public.admin_grant_vip(uuid, int, text);
create or replace function public.admin_grant_vip(p_user uuid, p_days int, p_note text default '', p_plan text default null) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare base timestamptz; ends timestamptz; pr public.profiles; act text; pid text := nullif(p_plan, ''); d int := p_days;
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  if pid is not null then
    select days into d from public.vip_plans where id = pid;
    if not found then raise exception 'not_found'; end if;
  end if;
  if d is null or d < 1 or d > 3660 then raise exception 'invalid'; end if;
  select * into pr from public.profiles where id = p_user for update;
  if not found then raise exception 'other'; end if;
  act := case when pr.vip_until is not null and pr.vip_until > now() then 'extend' else 'grant' end;
  base := greatest(now(), coalesce(pr.vip_until, now()));
  ends := base + make_interval(days => d);
  insert into public.vip_subscriptions (user_id, plan, plan_id, days, starts_at, ends_at, source, granted_by, note, action)
  values (p_user, coalesce(pid, case d when 30 then 'month' when 90 then 'quarter' when 365 then 'year' else 'custom' end), pid, d, base, ends, 'admin', auth.uid(), left(coalesce(p_note, ''), 200), act);
  perform set_config('lingora.priv', '1', true);
  update public.profiles set vip_until = ends, vip_from = case when pr.vip_until is not null and pr.vip_until > now() then pr.vip_from else null end where id = p_user;
  return jsonb_build_object('user', p_user, 'vip_until', ends, 'action', act);
end $$;
revoke all on function public.admin_grant_vip(uuid, int, text, text) from public;
grant execute on function public.admin_grant_vip(uuid, int, text, text) to authenticated;

-- explicit dates (start in the future, a fixed end, or a correction)
create or replace function public.admin_set_vip(p_user uuid, p_plan text, p_starts timestamptz, p_ends timestamptz, p_note text default '') returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare st timestamptz := coalesce(p_starts, now()); pid text := case when coalesce(p_plan, '') in ('', 'custom') then null else p_plan end;
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  if p_ends is null or p_ends <= st or p_ends > now() + interval '20 years' or st < now() - interval '20 years' then raise exception 'invalid'; end if;
  if pid is not null and not exists (select 1 from public.vip_plans where id = pid) then raise exception 'not_found'; end if;
  if not exists (select 1 from public.profiles where id = p_user) then raise exception 'other'; end if;
  insert into public.vip_subscriptions (user_id, plan, plan_id, days, starts_at, ends_at, source, granted_by, note, action)
  values (p_user, coalesce(pid, 'custom'), pid, greatest(1, ceil(extract(epoch from (p_ends - st)) / 86400)::int), st, p_ends, 'admin', auth.uid(), left(coalesce(p_note, ''), 200), 'set');
  perform set_config('lingora.priv', '1', true);
  update public.profiles set vip_until = p_ends, vip_from = case when st > now() then st end where id = p_user;
  return jsonb_build_object('user', p_user, 'vip_from', st, 'vip_until', p_ends);
end $$;
revoke all on function public.admin_set_vip(uuid, text, timestamptz, timestamptz, text) from public;
grant execute on function public.admin_set_vip(uuid, text, timestamptz, timestamptz, text) to authenticated;

create or replace function public.admin_revoke_vip(p_user uuid, p_note text default '') returns jsonb
language plpgsql security definer set search_path = public, private as $$
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  if not exists (select 1 from public.profiles where id = p_user) then raise exception 'other'; end if;
  insert into public.vip_subscriptions (user_id, plan, days, starts_at, ends_at, source, granted_by, note, action)
  values (p_user, 'revoked', 0, now(), now(), 'admin', auth.uid(), left(coalesce(p_note, ''), 200), 'revoke');
  perform set_config('lingora.priv', '1', true);
  update public.profiles set vip_until = null, vip_from = null where id = p_user;
  return jsonb_build_object('user', p_user, 'vip_until', null);
end $$;

-- suspend / restore an account (with a reason in the audit log)
create or replace function public.admin_set_suspended(p_user uuid, p_on boolean, p_note text default '') returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare tgt public.profiles;
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  if p_user = auth.uid() then raise exception 'denied_self'; end if;
  select * into tgt from public.profiles where id = p_user;
  if not found then raise exception 'other'; end if;
  if tgt.role in ('admin','super_admin','editor') and not public.is_super_admin() then raise exception 'denied'; end if;
  if tgt.role = 'super_admin' then raise exception 'denied'; end if;
  perform set_config('lingora.priv', '1', true);
  update public.profiles set suspended = coalesce(p_on, false) where id = p_user;
  perform private.audit(case when p_on then 'suspend' else 'restore' end, 'profiles', p_user::text, jsonb_build_object('note', left(coalesce(p_note, ''), 200)));
  return jsonb_build_object('user', p_user, 'suspended', coalesce(p_on, false));
end $$;
revoke all on function public.admin_set_suspended(uuid, boolean, text) from public;
grant execute on function public.admin_set_suspended(uuid, boolean, text) to authenticated;

-- ---------------------------------------------------------------------------------------------
-- 3. FREE / VIP on courses, units and lessons — enforced in the database
-- ---------------------------------------------------------------------------------------------
alter table public.courses add column if not exists vip boolean not null default false;
alter table public.lessons add column if not exists vip boolean not null default false;

drop policy if exists "lessons read" on public.lessons;
create policy "lessons read" on public.lessons for select using (
  public.is_editor()
  or (published and exists (select 1 from public.units u join public.courses c on c.id = u.course_id
        where u.id = lessons.unit_id and u.published and c.published and not c.archived
          and (not (u.vip or c.vip or lessons.vip) or public.is_vip())))
);
drop policy if exists "questions read" on public.questions;
create policy "questions read" on public.questions for select using (
  public.is_editor()
  or (published and exists (select 1 from public.lessons l join public.units u on u.id = l.unit_id join public.courses c on c.id = u.course_id
        where l.id = questions.lesson_id and l.published and u.published and c.published and not c.archived
          and (not (u.vip or c.vip or l.vip) or public.is_vip())))
);

-- locked lessons (title only, no content) so the learning path can still show them with a lock
create or replace function public.locked_lessons() returns jsonb
language sql stable security definer set search_path = public as $$
  select case when public.is_vip() then '[]'::jsonb else coalesce((
    select jsonb_agg(jsonb_build_object('id', l.id, 'unit_id', l.unit_id, 'title', l.title, 'position', l.position) order by l.position)
    from public.lessons l join public.units u on u.id = l.unit_id join public.courses c on c.id = u.course_id
    where l.published and u.published and c.published and not c.archived and (u.vip or c.vip or l.vip)), '[]'::jsonb) end
$$;
grant execute on function public.locked_lessons() to authenticated;

create or replace function public.start_lesson(p_lesson text, p_kind text default 'lesson', p_questions int default null) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); ps public.player_state; l public.lessons; u public.units; c public.courses; n int; w int; sp int; att_id uuid;
        unl boolean; isvip boolean;
begin
  if uid is null then raise exception 'denied'; end if;
  if exists (select 1 from public.profiles where id = uid and suspended) then raise exception 'denied'; end if;
  perform private.rl('start', 240, 3600);
  ps := private.ps_get(uid);
  isvip := private.is_vip(uid);
  unl := isvip or (ps.unlimited_until is not null and ps.unlimited_until > now());
  if p_kind = 'practice' then
    n := least(greatest(coalesce(p_questions, 8), 3), 40); w := 0; sp := 0;
  elsif p_kind = 'lesson' then
    select * into l from public.lessons where id = p_lesson;
    if not found then raise exception 'not_found'; end if;
    select * into u from public.units where id = l.unit_id;
    select * into c from public.courses where id = u.course_id;
    if not (public.is_editor() or (l.published and u.published and c.published and not c.archived and (not (u.vip or c.vip or l.vip) or isvip))) then
      raise exception 'denied';
    end if;
    select count(*), count(*) filter (where type = 'intro'), count(*) filter (where type in ('speak','listen')) into n, w, sp
      from public.questions where lesson_id = l.id;
    if n = 0 then raise exception 'empty_lesson'; end if;
    if ps.hearts <= 0 and not unl then raise exception 'no_hearts'; end if;
  else
    raise exception 'invalid';
  end if;
  insert into public.lesson_attempts (user_id, lesson_id, kind, questions, words, speaking)
  values (uid, case when p_kind = 'lesson' then p_lesson end, p_kind, n, w, sp) returning lesson_attempts.id into att_id;
  return jsonb_build_object('attempt_id', att_id, 'questions', n, 'state', private.state_json(uid));
end $$;

-- ---------------------------------------------------------------------------------------------
-- 4. Server-side admin queries: users (search / filter / sort / page), user detail, VIP list, history, stats, audit
-- ---------------------------------------------------------------------------------------------
create or replace function public.admin_list_users(p_q text default '', p_filter text default 'all', p_sort text default 'created',
  p_dir text default 'desc', p_limit int default 25, p_offset int default 0) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare q text := private.like_pat(p_q); tot int; rows jsonb; lim int := least(greatest(coalesce(p_limit, 25), 1), 100);
        asc_ boolean := lower(coalesce(p_dir, 'desc')) = 'asc';
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  with base as (
    select p.id, p.email, p.name, p.username, p.role, p.suspended, p.created_at, p.vip_until, p.vip_from,
           (p.vip_until is not null and p.vip_until > now() and (p.vip_from is null or p.vip_from <= now())) as vip_active,
           coalesce(s.xp, 0) as xp, coalesce(s.streak, 0) as streak, s.last_day,
           (select count(*) from public.lesson_completions lc where lc.user_id = p.id) as lessons_done
    from public.profiles p left join public.player_state s on s.user_id = p.id
    where (btrim(coalesce(p_q, '')) = '' or lower(p.email) like q escape E'\\' or lower(p.name) like q escape E'\\' or lower(coalesce(p.username, '')) like q escape E'\\' or p.id::text = btrim(p_q))
      and case coalesce(p_filter, 'all')
        when 'vip' then p.vip_until is not null and p.vip_until > now() and (p.vip_from is null or p.vip_from <= now())
        when 'expired' then p.vip_until is not null and p.vip_until <= now()
        when 'free' then not (p.vip_until is not null and p.vip_until > now())
        when 'staff' then p.role <> 'user'
        when 'suspended' then p.suspended
        else true end
  )
  , numbered as (
    select b.*, count(*) over () as tot, row_number() over (order by
        case when p_sort = 'xp' and not asc_ then b.xp end desc nulls last, case when p_sort = 'xp' and asc_ then b.xp end asc nulls last,
        case when p_sort = 'name' and not asc_ then lower(b.name) end desc nulls last, case when p_sort = 'name' and asc_ then lower(b.name) end asc nulls last,
        case when p_sort = 'vip_until' and not asc_ then b.vip_until end desc nulls last, case when p_sort = 'vip_until' and asc_ then b.vip_until end asc nulls last,
        case when p_sort not in ('xp','name','vip_until') and asc_ then b.created_at end asc, case when p_sort not in ('xp','name','vip_until') and not asc_ then b.created_at end desc,
        b.id) as rn
    from base b)
  select coalesce(max(n.tot), 0), coalesce(jsonb_agg((to_jsonb(n) - 'tot' - 'rn') order by n.rn) filter (where n.rn > greatest(coalesce(p_offset, 0), 0) and n.rn <= greatest(coalesce(p_offset, 0), 0) + lim), '[]'::jsonb)
    into tot, rows from numbered n;
  return jsonb_build_object('total', tot, 'rows', rows);
end $$;
revoke all on function public.admin_list_users(text, text, text, text, int, int) from public;
grant execute on function public.admin_list_users(text, text, text, text, int, int) to authenticated;

create or replace function public.admin_user_detail(p_user uuid) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare r jsonb;
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  select jsonb_build_object(
    'profile', (select to_jsonb(p) - 'friend_code' from public.profiles p where p.id = p_user),
    'state', (select jsonb_build_object('xp', s.xp, 'gems', s.gems, 'hearts', s.hearts, 'streak', s.streak, 'best_streak', s.best_streak, 'last_day', s.last_day) from public.player_state s where s.user_id = p_user),
    'lessons_done', (select count(*) from public.lesson_completions where user_id = p_user),
    'answers', (select jsonb_build_object('total', count(*), 'correct', count(*) filter (where correct)) from public.exercise_attempts where user_id = p_user),
    'vip_history', coalesce((select jsonb_agg(jsonb_build_object('id', v.id, 'action', v.action, 'plan', v.plan, 'plan_id', v.plan_id, 'days', v.days, 'starts_at', v.starts_at, 'ends_at', v.ends_at,
        'source', v.source, 'granted_by', v.granted_by, 'granted_by_email', (select email from public.profiles g where g.id = v.granted_by), 'note', v.note, 'created_at', v.created_at) order by v.created_at desc)
        from (select * from public.vip_subscriptions where user_id = p_user order by created_at desc limit 50) v), '[]'::jsonb),
    'xp_events', coalesce((select jsonb_agg(e order by e.created_at desc) from (select amount, kind, ref, created_at from public.xp_events where user_id = p_user order by created_at desc limit 10) e), '[]'::jsonb),
    'audit', coalesce((select jsonb_agg(a order by a.created_at desc) from (select action, entity, detail, created_at, (select email from public.profiles g where g.id = l.actor) as actor_email from public.audit_log l where entity = 'profiles' and entity_id = p_user::text order by created_at desc limit 20) a), '[]'::jsonb)
  ) into r;
  if r->'profile' is null or r->'profile' = 'null'::jsonb then raise exception 'other'; end if;
  return r;
end $$;
revoke all on function public.admin_user_detail(uuid) from public;
grant execute on function public.admin_user_detail(uuid) to authenticated;

create or replace function public.admin_list_vip(p_q text default '', p_status text default 'active', p_limit int default 25, p_offset int default 0) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare q text := private.like_pat(p_q); tot int; rows jsonb; lim int := least(greatest(coalesce(p_limit, 25), 1), 100);
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  select count(*) into tot from public.profiles p
   where (btrim(coalesce(p_q, '')) = '' or lower(p.email) like q escape E'\\' or lower(p.name) like q escape E'\\')
     and case p_status when 'active' then p.vip_until > now() and (p.vip_from is null or p.vip_from <= now())
                       when 'scheduled' then p.vip_until > now() and p.vip_from > now()
                       when 'expired' then p.vip_until <= now()
                       else p.vip_until is not null end;
  select coalesce(jsonb_agg(to_jsonb(x)), '[]'::jsonb) into rows from (
    select p.id, p.email, p.name, p.vip_from, p.vip_until,
           (select v.plan_id from public.vip_subscriptions v where v.user_id = p.id and v.action <> 'revoke' order by v.created_at desc limit 1) as plan_id,
           (select v.source from public.vip_subscriptions v where v.user_id = p.id and v.action <> 'revoke' order by v.created_at desc limit 1) as source,
           (select g.email from public.vip_subscriptions v join public.profiles g on g.id = v.granted_by where v.user_id = p.id and v.action <> 'revoke' order by v.created_at desc limit 1) as granted_by_email
    from public.profiles p
    where (btrim(coalesce(p_q, '')) = '' or lower(p.email) like q escape E'\\' or lower(p.name) like q escape E'\\')
      and case p_status when 'active' then p.vip_until > now() and (p.vip_from is null or p.vip_from <= now())
                        when 'scheduled' then p.vip_until > now() and p.vip_from > now()
                        when 'expired' then p.vip_until <= now()
                        else p.vip_until is not null end
    order by p.vip_until desc offset greatest(coalesce(p_offset, 0), 0) limit lim) x;
  return jsonb_build_object('total', tot, 'rows', rows);
end $$;
revoke all on function public.admin_list_vip(text, text, int, int) from public;
grant execute on function public.admin_list_vip(text, text, int, int) to authenticated;

create or replace function public.admin_stats() returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  return jsonb_build_object(
    'users', (select count(*) from public.profiles),
    'new7', (select count(*) from public.profiles where created_at > now() - interval '7 days'),
    'active7', (select count(*) from public.player_state where last_day >= current_date - 7),
    'vip_active', (select count(*) from public.profiles where vip_until > now() and (vip_from is null or vip_from <= now())),
    'vip_expired', (select count(*) from public.profiles where vip_until <= now()),
    'suspended', (select count(*) from public.profiles where suspended),
    'completions', (select count(*) from public.lesson_completions),
    'answers', (select count(*) from public.exercise_attempts),
    'xp_total', (select coalesce(sum(xp), 0) from public.player_state),
    'payments_ok', (select count(*) from public.payments where status = 'succeeded'),
    'signups', coalesce((select jsonb_agg(jsonb_build_object('d', d::date, 'n', (select count(*) from public.profiles where created_at::date = d::date)) order by d)
                         from generate_series(current_date - 13, current_date, interval '1 day') d), '[]'::jsonb),
    'recent', coalesce((select jsonb_agg(a order by a.created_at desc) from (
        select l.action, l.entity, l.entity_id, l.detail, l.created_at, (select email from public.profiles g where g.id = l.actor) as actor_email
        from public.audit_log l order by l.created_at desc limit 12) a), '[]'::jsonb));
end $$;
revoke all on function public.admin_stats() from public;
grant execute on function public.admin_stats() to authenticated;

create or replace function public.admin_audit(p_q text default '', p_entity text default '', p_limit int default 30, p_offset int default 0) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare q text := private.like_pat(p_q); tot int; rows jsonb; lim int := least(greatest(coalesce(p_limit, 30), 1), 100);
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  select count(*) into tot from public.audit_log l left join public.profiles g on g.id = l.actor
   where (p_entity = '' or l.entity = p_entity) and (btrim(coalesce(p_q, '')) = '' or lower(l.action) like q escape E'\\' or lower(l.entity_id) like q escape E'\\' or lower(coalesce(g.email, '')) like q escape E'\\');
  select coalesce(jsonb_agg(to_jsonb(x)), '[]'::jsonb) into rows from (
    select l.id, l.action, l.entity, l.entity_id, l.detail, l.created_at, l.actor_role, g.email as actor_email
    from public.audit_log l left join public.profiles g on g.id = l.actor
    where (p_entity = '' or l.entity = p_entity) and (btrim(coalesce(p_q, '')) = '' or lower(l.action) like q escape E'\\' or lower(l.entity_id) like q escape E'\\' or lower(coalesce(g.email, '')) like q escape E'\\')
    order by l.created_at desc, l.id desc offset greatest(coalesce(p_offset, 0), 0) limit lim) x;
  return jsonb_build_object('total', tot, 'rows', rows);
end $$;
revoke all on function public.admin_audit(text, text, int, int) from public;
grant execute on function public.admin_audit(text, text, int, int) to authenticated;

-- ---------------------------------------------------------------------------------------------
-- 5. Payments: written ONLY by a trusted server (webhook) through apply_payment; never by the browser
-- ---------------------------------------------------------------------------------------------
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_id text references public.vip_plans(id) on delete set null,
  provider text not null check (provider ~ '^[a-z0-9_-]{2,24}$'),
  provider_ref text not null,
  amount_cents int not null check (amount_cents >= 0),
  currency text not null check (currency ~ '^[a-z]{3}$'),
  status text not null check (status in ('succeeded','failed','refunded')),
  days_granted int not null default 0,
  raw jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique (provider, provider_ref)
);
create index if not exists payments_user_idx on public.payments (user_id, created_at desc);
alter table public.payments enable row level security;
drop policy if exists "payments read" on public.payments;
create policy "payments read" on public.payments for select using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.payments from anon, authenticated;

create or replace function public.apply_payment(p_user uuid, p_plan text, p_provider text, p_ref text, p_amount int, p_currency text, p_status text, p_raw jsonb default '{}'::jsonb) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare pay public.payments; pl public.vip_plans; pr public.profiles; base timestamptz; ends timestamptz;
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then raise exception 'denied'; end if;
  if p_status not in ('succeeded','failed','refunded') then raise exception 'invalid'; end if;
  select * into pl from public.vip_plans where id = p_plan;
  if not found then raise exception 'not_found'; end if;
  select * into pay from public.payments where provider = p_provider and provider_ref = p_ref for update;
  if found then
    if pay.status = p_status then return jsonb_build_object('payment', pay.id, 'status', pay.status, 'duplicate', true); end if;
    if p_status = 'refunded' and pay.status = 'succeeded' then
      update public.payments set status = 'refunded' where id = pay.id;
      select * into pr from public.profiles where id = pay.user_id for update;
      ends := case when pr.vip_until is null then null else pr.vip_until - make_interval(days => pay.days_granted) end;
      insert into public.vip_subscriptions (user_id, plan, plan_id, days, starts_at, ends_at, source, note, action, payment_id)
      values (pay.user_id, 'revoked', pay.plan_id, 0, now(), now(), 'payment', 'refund ' || p_ref, 'refund', pay.id);
      perform set_config('lingora.priv', '1', true);
      update public.profiles set vip_until = case when ends is null or ends <= now() then null else ends end,
                                 vip_from = case when ends is null or ends <= now() then null else vip_from end where id = pay.user_id;
      return jsonb_build_object('payment', pay.id, 'status', 'refunded', 'duplicate', false);
    end if;
    raise exception 'invalid';                          -- no other transition is accepted
  end if;
  if not exists (select 1 from auth.users where id = p_user) then raise exception 'other'; end if;
  insert into public.payments (user_id, plan_id, provider, provider_ref, amount_cents, currency, status, days_granted, raw)
  values (p_user, p_plan, p_provider, p_ref, greatest(coalesce(p_amount, 0), 0), lower(p_currency), p_status, case when p_status = 'succeeded' then pl.days else 0 end, coalesce(p_raw, '{}'::jsonb))
  returning * into pay;
  if p_status = 'succeeded' then
    select * into pr from public.profiles where id = p_user for update;
    base := greatest(now(), coalesce(pr.vip_until, now()));
    ends := base + make_interval(days => pl.days);
    insert into public.vip_subscriptions (user_id, plan, plan_id, days, starts_at, ends_at, source, note, action, payment_id)
    values (p_user, p_plan, p_plan, pl.days, base, ends, 'payment', left(p_provider || ' ' || p_ref, 200), 'payment', pay.id);
    perform set_config('lingora.priv', '1', true);
    update public.profiles set vip_until = ends, vip_from = case when pr.vip_until is not null and pr.vip_until > now() then pr.vip_from end where id = p_user;
  end if;
  return jsonb_build_object('payment', pay.id, 'status', pay.status, 'duplicate', false);
end $$;
revoke all on function public.apply_payment(uuid, text, text, text, int, text, text, jsonb) from public, anon, authenticated;
grant execute on function public.apply_payment(uuid, text, text, text, int, text, text, jsonb) to service_role;

create or replace function public.admin_payments(p_limit int default 25, p_offset int default 0) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare lim int := least(greatest(coalesce(p_limit, 25), 1), 100);
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  return jsonb_build_object('total', (select count(*) from public.payments), 'rows', coalesce((select jsonb_agg(to_jsonb(x)) from (
    select p.id, p.plan_id, p.provider, p.provider_ref, p.amount_cents, p.currency, p.status, p.days_granted, p.created_at, u.email
    from public.payments p left join public.profiles u on u.id = p.user_id order by p.created_at desc offset greatest(coalesce(p_offset, 0), 0) limit lim) x), '[]'::jsonb));
end $$;
revoke all on function public.admin_payments(int, int) from public;
grant execute on function public.admin_payments(int, int) to authenticated;

-- ---------------------------------------------------------------------------------------------
-- 6. Media registry (the files live in the 'media' bucket; this records what, who and how big)
-- ---------------------------------------------------------------------------------------------
create table if not exists public.media_assets (
  id uuid primary key default gen_random_uuid(),
  path text not null unique check (path ~ '^[A-Za-z0-9/_.-]{3,200}$' and path !~ '\.\.'),
  kind text not null check (kind in ('image','audio')),
  mime text not null check (mime in ('image/jpeg','image/png','image/webp','image/gif','audio/mpeg','audio/mp3','audio/ogg','audio/wav','audio/webm','audio/mp4')),
  bytes int not null check (bytes > 0 and bytes <= 5242880),
  url text not null check (url ~ '^https://'),
  alt text not null default '',
  uploaded_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  check ((kind = 'image' and mime like 'image/%') or (kind = 'audio' and mime like 'audio/%'))
);
alter table public.media_assets enable row level security;
drop policy if exists "media_assets read" on public.media_assets;
create policy "media_assets read" on public.media_assets for select using (public.is_editor());
drop policy if exists "media_assets insert" on public.media_assets;
create policy "media_assets insert" on public.media_assets for insert with check (public.is_editor() and uploaded_by = auth.uid());
drop policy if exists "media_assets delete" on public.media_assets;
create policy "media_assets delete" on public.media_assets for delete using (public.is_editor());
drop policy if exists "media_assets update" on public.media_assets;
create policy "media_assets update" on public.media_assets for update using (public.is_editor()) with check (public.is_editor());

-- ---------------------------------------------------------------------------------------------
-- 6b. Storage bucket: only these file types, max 5 MB (checked again by the browser and by media_assets)
update storage.buckets set file_size_limit = 5242880,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','image/gif','audio/mpeg','audio/mp3','audio/ogg','audio/wav','audio/webm','audio/mp4'] where id = 'media';

-- ---------------------------------------------------------------------------------------------
-- 7. UI text overrides (translations editable without a deploy)
-- ---------------------------------------------------------------------------------------------
create table if not exists public.ui_overrides (
  lang text not null check (lang in ('hy','en','ru')),
  key text not null check (key ~ '^[A-Za-z0-9_]{1,40}$'),
  value text not null check (char_length(value) <= 400),
  updated_at timestamptz not null default now(),
  primary key (lang, key)
);
alter table public.ui_overrides enable row level security;
drop policy if exists "ui read" on public.ui_overrides;
create policy "ui read" on public.ui_overrides for select using (true);
drop policy if exists "ui admin write" on public.ui_overrides;
create policy "ui admin write" on public.ui_overrides for all using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------------------------
-- 8. Audit triggers on every admin-managed table
-- ---------------------------------------------------------------------------------------------
do $$ declare t text; begin
  foreach t in array array['languages','courses','units','lessons','questions','settings','site_content','shop_items','achievement_defs','quest_defs','vip_plans','ui_overrides','media_assets'] loop
    if to_regclass('public.' || t) is not null then
      execute format('drop trigger if exists audit_row on public.%I', t);
      execute format('create trigger audit_row after insert or update or delete on public.%I for each row execute function private.audit_row()', t);
    end if;
  end loop;
end $$;

-- ===== supabase/migrations/010_gamification_world_ai.sql =====
-- Lingora migration 010 (Part 4): server-side leagues + trusted leaderboard, notifications, challenges, shop categories + inventory,
-- Lingora World (avatar costumes, rooms, decorations), AI usage limits/cost tracking, weak-topic analysis and recommendations.
-- Safe to run more than once. Requires 001-009.

-- ---------------------------------------------------------------------------------------------
-- 1. Shop: categories (item / room / costume), VIP-only items, inventory
-- ---------------------------------------------------------------------------------------------
alter table public.shop_items drop constraint if exists shop_items_kind_check;
alter table public.shop_items add constraint shop_items_kind_check check (kind in ('heart_refill','streak_freeze','xp_boost','unlimited_hearts','cosmetic'));
alter table public.shop_items add column if not exists category text not null default 'item';
alter table public.shop_items drop constraint if exists shop_items_category_check;
alter table public.shop_items add constraint shop_items_category_check check (category in ('item','room','costume'));
alter table public.shop_items add column if not exists slot text not null default '';
alter table public.shop_items add column if not exists vip_only boolean not null default false;
alter table public.shop_items drop constraint if exists shop_items_price_max;
alter table public.shop_items add constraint shop_items_price_max check (price_gems <= 100000);
alter table public.shop_items drop constraint if exists shop_items_cosmetic_slot;
alter table public.shop_items add constraint shop_items_cosmetic_slot check (kind <> 'cosmetic' or slot in ('head','eyes','neck','room','decor'));

create table if not exists public.inventory (
  user_id uuid not null references auth.users(id) on delete cascade,
  item_id text not null references public.shop_items(id) on delete restrict,   -- an item people own can be hidden (active=false) but not deleted
  acquired_at timestamptz not null default now(),
  primary key (user_id, item_id)
);
alter table public.inventory enable row level security;
drop policy if exists "own inventory" on public.inventory;
create policy "own inventory" on public.inventory for select using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.inventory from anon, authenticated;

-- buy_item: consumables as before; cosmetics are one-per-account, VIP-only items need VIP, price re-read from the table
create or replace function public.buy_item(p_item text, p_idem text) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); it public.shop_items; ps public.player_state; cfg jsonb := private.cfg(); mx int := (cfg->'hearts'->>'max')::int;
        mf int := coalesce((cfg->'streak'->>'max_freeze')::int, 2); ok boolean; mins int;
begin
  if uid is null then raise exception 'denied'; end if;
  if exists (select 1 from public.profiles where id = uid and suspended) then raise exception 'denied'; end if;
  if p_idem is null or length(p_idem) < 8 or length(p_idem) > 80 then raise exception 'invalid'; end if;
  perform private.rl('buy', 60, 3600);
  if exists (select 1 from public.purchases where user_id = uid and idem_key = p_idem) then
    return jsonb_build_object('duplicate', true, 'state', private.state_json(uid));
  end if;
  select * into it from public.shop_items where id = p_item and active;
  if not found then raise exception 'not_found'; end if;
  if it.price_gems < 0 then raise exception 'invalid'; end if;
  if it.vip_only and not private.is_vip(uid) then raise exception 'vip_only'; end if;
  ps := private.ps_get(uid);
  if it.kind = 'cosmetic' and exists (select 1 from public.inventory where user_id = uid and item_id = it.id) then raise exception 'already_owned'; end if;
  if ps.gems < it.price_gems then raise exception 'not_enough_gems'; end if;
  if it.kind = 'heart_refill' and ps.hearts >= mx then raise exception 'already_full'; end if;
  if it.kind = 'streak_freeze' and ps.freezes >= mf then raise exception 'already_full'; end if;
  insert into public.purchases (user_id, item_id, price_gems, idem_key) values (uid, it.id, it.price_gems, p_idem);
  ok := private.gem_add(uid, -it.price_gems, 'purchase', p_idem, jsonb_build_object('item', it.id));
  if it.price_gems > 0 and not ok then raise exception 'duplicate'; end if;
  mins := coalesce((it.payload->>'minutes')::int, 15);
  if it.kind = 'heart_refill' then update public.player_state set hearts = mx, hearts_at = now() where user_id = uid;
  elsif it.kind = 'streak_freeze' then update public.player_state set freezes = least(mf, freezes + 1) where user_id = uid;
  elsif it.kind = 'xp_boost' then
    update public.player_state set boost_until = greatest(coalesce(boost_until, now()), now()) + make_interval(mins => mins),
      boost_mult = coalesce((it.payload->>'mult')::numeric, 2) where user_id = uid;
  elsif it.kind = 'unlimited_hearts' then
    update public.player_state set unlimited_until = greatest(coalesce(unlimited_until, now()), now()) + make_interval(mins => mins) where user_id = uid;
  elsif it.kind = 'cosmetic' then
    insert into public.inventory (user_id, item_id) values (uid, it.id) on conflict do nothing;
  end if;
  return jsonb_build_object('item', it.id, 'state', private.state_json(uid));
end $$;

insert into public.shop_items (id, kind, category, slot, price_gems, payload, icon, title, descr, vip_only, position) values
 ('c_headphones','cosmetic','costume','head',60,'{"emoji":"🎧"}','headphones','{"hy":"Ականջակալներ","en":"Headphones"}','{"hy":"Երաժշտությամբ սովորելու համար","en":"For learning with music"}',false,20),
 ('c_party','cosmetic','costume','head',70,'{"emoji":"🥳"}','party','{"hy":"Տոնական գլխարկ","en":"Party hat"}','{}',false,21),
 ('c_crown','cosmetic','costume','head',200,'{"emoji":"👑"}','crown','{"hy":"Թագ","en":"Crown"}','{"hy":"Միայն VIP-ի համար","en":"VIP members only"}',true,22),
 ('c_glasses','cosmetic','costume','eyes',80,'{"emoji":"🕶️"}','glasses','{"hy":"Արևային ակնոց","en":"Sunglasses"}','{}',false,23),
 ('c_monocle','cosmetic','costume','eyes',90,'{"emoji":"🧐"}','monocle','{"hy":"Մոնոկլ","en":"Monocle"}','{}',false,24),
 ('c_scarf','cosmetic','costume','neck',60,'{"emoji":"🧣"}','scarf','{"hy":"Շարֆ","en":"Scarf"}','{}',false,25),
 ('c_bow','cosmetic','costume','neck',50,'{"emoji":"🎀"}','bow','{"hy":"Թիթեռնիկ","en":"Bow"}','{}',false,26),
 ('c_medal','cosmetic','costume','neck',120,'{"emoji":"🏅"}','medal','{"hy":"Մեդալ","en":"Medal"}','{}',false,27),
 ('r_cozy','cosmetic','room','room',0,'{"sky":["#efe7ff","#d9c9ff"],"floor":"#c9b2f5"}','room','{"hy":"Հարմարավետ սենյակ","en":"Cozy room"}','{"hy":"Սկզբնական սենյակ","en":"Your starting room"}',false,30),
 ('r_garden','cosmetic','room','room',150,'{"sky":["#d7f5dd","#a9e5b8"],"floor":"#7ccf8e"}','room','{"hy":"Պարտեզ","en":"Garden"}','{}',false,31),
 ('r_library','cosmetic','room','room',200,'{"sky":["#ffe9cf","#f6c98f"],"floor":"#b9824a"}','room','{"hy":"Գրադարան","en":"Library"}','{}',false,32),
 ('r_space','cosmetic','room','room',250,'{"sky":["#2b2358","#4b3a9a"],"floor":"#3a2f7a"}','room','{"hy":"Տիեզերք","en":"Space"}','{}',false,33),
 ('d_plant','cosmetic','item','decor',40,'{"emoji":"🪴"}','plant','{"hy":"Սենյակային բույս","en":"House plant"}','{}',false,40),
 ('d_books','cosmetic','item','decor',50,'{"emoji":"📚"}','books','{"hy":"Գրքեր","en":"Books"}','{}',false,41),
 ('d_frame','cosmetic','item','decor',70,'{"emoji":"🖼️"}','frame','{"hy":"Նկար պատին","en":"Wall picture"}','{}',false,42),
 ('d_globe','cosmetic','item','decor',90,'{"emoji":"🌍"}','globe','{"hy":"Գլոբուս","en":"Globe"}','{}',false,43),
 ('d_cat','cosmetic','item','decor',120,'{"emoji":"🐈"}','cat','{"hy":"Կատու","en":"Cat"}','{}',false,44),
 ('d_telescope','cosmetic','item','decor',160,'{"emoji":"🔭"}','telescope','{"hy":"Աստղադիտակ","en":"Telescope"}','{}',false,45),
 ('d_piano','cosmetic','item','decor',180,'{"emoji":"🎹"}','piano','{"hy":"Դաշնամուր","en":"Piano"}','{}',false,46),
 ('d_trophy','cosmetic','item','decor',220,'{"emoji":"🏆"}','trophy','{"hy":"Գավաթ","en":"Trophy"}','{}',true,47)
on conflict (id) do nothing;

-- ---------------------------------------------------------------------------------------------
-- 2. Lingora World: what is worn / which room / where decorations stand (ownership checked on the server)
-- ---------------------------------------------------------------------------------------------
create table if not exists public.world_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  room text not null default 'r_cozy',
  equipped jsonb not null default '{}'::jsonb,
  decor jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.world_state enable row level security;
drop policy if exists "own world" on public.world_state;
create policy "own world" on public.world_state for select using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.world_state from anon, authenticated;

create or replace function public.my_world() returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); w public.world_state;
begin
  if uid is null then raise exception 'denied'; end if;
  select * into w from public.world_state where user_id = uid;
  return jsonb_build_object(
    'inventory', coalesce((select jsonb_agg(item_id order by acquired_at) from public.inventory where user_id = uid), '[]'::jsonb),
    'world', jsonb_build_object('room', coalesce(w.room, 'r_cozy'), 'equipped', coalesce(w.equipped, '{}'::jsonb), 'decor', coalesce(w.decor, '[]'::jsonb)));
end $$;
grant execute on function public.my_world() to authenticated;

create or replace function public.set_world(p_room text, p_equipped jsonb, p_decor jsonb) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); room text := coalesce(nullif(p_room, ''), 'r_cozy'); eq jsonb := '{}'::jsonb; dc jsonb := '[]'::jsonb; k text; v text; el jsonb; it public.shop_items; x numeric; y numeric; cnt int := 0;
begin
  if uid is null then raise exception 'denied'; end if;
  perform private.rl('world', 120, 3600);
  if p_equipped is not null and jsonb_typeof(p_equipped) <> 'object' then raise exception 'invalid'; end if;
  if p_decor is not null and jsonb_typeof(p_decor) <> 'array' then raise exception 'invalid'; end if;
  if jsonb_array_length(coalesce(p_decor, '[]'::jsonb)) > 24 then raise exception 'invalid'; end if;
  -- room: must be a room item that is free (price 0) or owned
  select * into it from public.shop_items where id = room and category = 'room' and kind = 'cosmetic';
  if not found then raise exception 'invalid'; end if;
  if it.price_gems > 0 and not exists (select 1 from public.inventory where user_id = uid and item_id = room) then raise exception 'not_owned'; end if;
  -- worn costumes: slot must match the item and the item must be owned
  for k, v in select key, value #>> '{}' from jsonb_each(coalesce(p_equipped, '{}'::jsonb)) loop
    if v is null or v = '' then continue; end if;
    select * into it from public.shop_items where id = v and category = 'costume' and kind = 'cosmetic';
    if not found or it.slot <> k then raise exception 'invalid'; end if;
    if not exists (select 1 from public.inventory where user_id = uid and item_id = v) then raise exception 'not_owned'; end if;
    eq := eq || jsonb_build_object(k, v);
  end loop;
  -- decorations: owned decor items, coordinates clamped to the room
  for el in select * from jsonb_array_elements(coalesce(p_decor, '[]'::jsonb)) loop
    if jsonb_typeof(el) <> 'object' or jsonb_typeof(el->'x') <> 'number' or jsonb_typeof(el->'y') <> 'number' then raise exception 'invalid'; end if;
    select * into it from public.shop_items where id = el->>'item' and category = 'item' and slot = 'decor' and kind = 'cosmetic';
    if not found then raise exception 'invalid'; end if;
    if not exists (select 1 from public.inventory where user_id = uid and item_id = it.id) then raise exception 'not_owned'; end if;
    x := least(greatest((el->>'x')::numeric, 0), 100); y := least(greatest((el->>'y')::numeric, 0), 100);
    dc := dc || jsonb_build_array(jsonb_build_object('item', it.id, 'x', round(x, 1), 'y', round(y, 1)));
    cnt := cnt + 1;
  end loop;
  insert into public.world_state (user_id, room, equipped, decor, updated_at) values (uid, room, eq, dc, now())
  on conflict (user_id) do update set room = excluded.room, equipped = excluded.equipped, decor = excluded.decor, updated_at = now();
  return jsonb_build_object('room', room, 'equipped', eq, 'decor', dc);
end $$;
grant execute on function public.set_world(text, jsonb, jsonb) to authenticated;

-- ---------------------------------------------------------------------------------------------
-- 3. Notifications (in-app, read/unread, per-kind preferences)
-- ---------------------------------------------------------------------------------------------
alter table public.profiles add column if not exists notif_prefs jsonb not null default '{}'::jsonb;
create table if not exists public.notifications (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('achievement','streak','friend_request','friend_accepted','mission','league','vip','challenge','system')),
  data jsonb not null default '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on public.notifications (user_id, created_at desc);
alter table public.notifications enable row level security;
drop policy if exists "own notifications" on public.notifications;
create policy "own notifications" on public.notifications for select using (user_id = auth.uid());
revoke insert, update, delete on public.notifications from anon, authenticated;

create or replace function private.notify(uid uuid, p_kind text, p_data jsonb default '{}'::jsonb) returns void
language plpgsql security definer set search_path = public, private as $$
declare pr jsonb;
begin
  select notif_prefs into pr from public.profiles where id = uid;
  if not found then return; end if;
  if coalesce((pr->>p_kind)::boolean, true) is false then return; end if;
  insert into public.notifications (user_id, kind, data) values (uid, p_kind, coalesce(p_data, '{}'::jsonb));
  delete from public.notifications where user_id = uid and id <= (select id from public.notifications where user_id = uid order by id desc offset 200 limit 1);
end $$;
revoke all on function private.notify(uuid, text, jsonb) from public;

create or replace function private.trg_notify_friend() returns trigger
language plpgsql security definer set search_path = public, private as $$
begin
  if tg_op = 'INSERT' and new.status = 'pending' then
    perform private.notify(new.addressee, 'friend_request', jsonb_build_object('from', coalesce(nullif((select name from public.profiles where id = new.requester), ''), 'Learner')));
  elsif tg_op = 'UPDATE' and old.status = 'pending' and new.status = 'accepted' then
    perform private.notify(new.requester, 'friend_accepted', jsonb_build_object('from', coalesce(nullif((select name from public.profiles where id = new.addressee), ''), 'Learner')));
  end if;
  return new;
end $$;
drop trigger if exists notify_friend on public.friendships;
create trigger notify_friend after insert or update on public.friendships for each row execute function private.trg_notify_friend();

create or replace function private.trg_notify_ach() returns trigger
language plpgsql security definer set search_path = public, private as $$
begin
  perform private.notify(new.user_id, 'achievement', jsonb_build_object('id', new.achievement_id, 'title', (select title from public.achievement_defs where id = new.achievement_id)));
  return new;
end $$;
drop trigger if exists notify_ach on public.user_achievements;
create trigger notify_ach after insert on public.user_achievements for each row execute function private.trg_notify_ach();

create or replace function private.trg_notify_quest() returns trigger
language plpgsql security definer set search_path = public, private as $$
begin
  perform private.notify(new.user_id, 'mission', jsonb_build_object('id', new.quest_id));
  return new;
end $$;
drop trigger if exists notify_quest on public.quest_claims;
create trigger notify_quest after insert on public.quest_claims for each row execute function private.trg_notify_quest();

create or replace function private.trg_notify_vip() returns trigger
language plpgsql security definer set search_path = public, private as $$
begin
  perform private.notify(new.user_id, 'vip', jsonb_build_object('action', new.action, 'ends', new.ends_at));
  return new;
end $$;
drop trigger if exists notify_vip on public.vip_subscriptions;
create trigger notify_vip after insert on public.vip_subscriptions for each row execute function private.trg_notify_vip();

create or replace function private.trg_notify_streak() returns trigger
language plpgsql security definer set search_path = public, private as $$
begin
  if new.streak > old.streak and new.streak in (3, 7, 14, 30, 50, 100, 200, 365) then
    perform private.notify(new.user_id, 'streak', jsonb_build_object('days', new.streak));
  end if;
  return new;
end $$;
drop trigger if exists notify_streak on public.player_state;
create trigger notify_streak after update of streak on public.player_state for each row execute function private.trg_notify_streak();

create or replace function public.my_notifications(p_limit int default 40) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'denied'; end if;
  return jsonb_build_object(
    'unread', (select count(*) from public.notifications where user_id = uid and read_at is null),
    'prefs', (select notif_prefs from public.profiles where id = uid),
    'rows', coalesce((select jsonb_agg(to_jsonb(n) - 'user_id' order by n.id desc) from (select * from public.notifications where user_id = uid order by id desc limit least(greatest(coalesce(p_limit, 40), 1), 100)) n), '[]'::jsonb));
end $$;
grant execute on function public.my_notifications(int) to authenticated;

create or replace function public.notifications_read(p_ids bigint[] default null) returns int
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); n int;
begin
  if uid is null then raise exception 'denied'; end if;
  update public.notifications set read_at = now() where user_id = uid and read_at is null and (p_ids is null or id = any(p_ids));
  get diagnostics n = row_count;
  return n;
end $$;
grant execute on function public.notifications_read(bigint[]) to authenticated;

create or replace function public.set_notify_prefs(p_prefs jsonb) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); k text; out jsonb := '{}'::jsonb;
begin
  if uid is null then raise exception 'denied'; end if;
  if p_prefs is null or jsonb_typeof(p_prefs) <> 'object' then raise exception 'invalid'; end if;
  for k in select jsonb_object_keys(p_prefs) loop
    if k not in ('achievement','streak','friend_request','friend_accepted','mission','league','vip','challenge','system') or jsonb_typeof(p_prefs->k) <> 'boolean' then raise exception 'invalid'; end if;
    out := out || jsonb_build_object(k, p_prefs->k);
  end loop;
  perform set_config('lingora.priv', '1', true);
  update public.profiles set notif_prefs = out where id = uid;
  return out;
end $$;
grant execute on function public.set_notify_prefs(jsonb) to authenticated;

-- ---------------------------------------------------------------------------------------------
-- 4. Weekly leagues and a leaderboard computed from SERVER xp events (the old one read client-written progress)
-- ---------------------------------------------------------------------------------------------
create table if not exists public.league_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  tier int not null default 0 check (tier between 0 and 9),
  week date not null,
  updated_at timestamptz not null default now()
);
create table if not exists public.league_results (
  user_id uuid not null references auth.users(id) on delete cascade,
  week date not null,
  tier_before int not null,
  tier_after int not null,
  xp int not null,
  reward int not null default 0,
  primary key (user_id, week)
);
alter table public.league_state enable row level security;
alter table public.league_results enable row level security;
drop policy if exists "own league" on public.league_state;
create policy "own league" on public.league_state for select using (user_id = auth.uid() or public.is_admin());
drop policy if exists "own league results" on public.league_results;
create policy "own league results" on public.league_results for select using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.league_state, public.league_results from anon, authenticated;

create or replace function private.week_start(uid uuid) returns date
language sql stable security definer set search_path = public as $$
  select date_trunc('week', private.local_day(uid)::timestamp)::date
$$;

create or replace function public.league_tick() returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); cfg jsonb := private.cfg(); cur date; st public.league_state; xp int; pro int; dem int; mx int; ntier int; rew int := 0; changed boolean := false; names jsonb;
begin
  if uid is null then raise exception 'denied'; end if;
  perform private.ps_get(uid);
  cur := private.week_start(uid);
  pro := coalesce((cfg->'league'->>'promote_xp')::int, 100);
  dem := coalesce((cfg->'league'->>'demote_xp')::int, 20);
  mx := coalesce((cfg->'league'->>'tiers')::int, 5) - 1;
  insert into public.league_state (user_id, tier, week) values (uid, 0, cur) on conflict (user_id) do nothing;
  select * into st from public.league_state where user_id = uid for update;
  if st.week < cur then
    select coalesce(sum(amount), 0) into xp from public.xp_events where user_id = uid and day >= cur - 7 and day < cur;
    ntier := st.tier;
    if xp >= pro and ntier < mx then ntier := ntier + 1; rew := coalesce((cfg->'league'->>'reward_gems')::int, 20);
    elsif xp < dem and ntier > 0 then ntier := ntier - 1; end if;
    insert into public.league_results (user_id, week, tier_before, tier_after, xp, reward) values (uid, cur - 7, st.tier, ntier, xp, rew) on conflict do nothing;
    if rew > 0 then perform private.gem_add(uid, rew, 'league', (cur - 7)::text, jsonb_build_object('tier', ntier)); end if;
    update public.league_state set tier = ntier, week = cur, updated_at = now() where user_id = uid;
    if ntier <> st.tier then perform private.notify(uid, 'league', jsonb_build_object('tier', ntier, 'up', ntier > st.tier)); end if;
    changed := true; st.tier := ntier;
  end if;
  return jsonb_build_object('tier', st.tier, 'week', cur, 'changed', changed, 'week_xp',
    (select coalesce(sum(amount), 0) from public.xp_events where user_id = uid and day >= cur),
    'promote_xp', pro, 'demote_xp', dem, 'tiers', mx + 1);
end $$;
grant execute on function public.league_tick() to authenticated;

drop function if exists public.leaderboard();
create or replace function public.leaderboard() returns table(name text, xp bigint, me boolean, league int)
language sql stable security definer set search_path = public, private as $$
  select coalesce(nullif(p.name, ''), 'Learner') as name,
         coalesce(sum(e.amount), 0)::bigint as xp,
         (p.id = auth.uid()) as me,
         coalesce(l.tier, 0) as league
  from public.profiles p
  left join public.xp_events e on e.user_id = p.id and e.day >= private.week_start(p.id)
  left join public.league_state l on l.user_id = p.id
  where not p.suspended and (p.id = auth.uid() or (not p.hide_lb and coalesce((p.privacy->>'show_activity')::boolean, true)))
  group by p.id, p.name, l.tier
  having p.id = auth.uid() or coalesce(sum(e.amount), 0) > 0
  order by xp desc, name
  limit 50
$$;
grant execute on function public.leaderboard() to authenticated;

-- ---------------------------------------------------------------------------------------------
-- 5. Learning challenges between friends (scored from server xp events)
-- ---------------------------------------------------------------------------------------------
create table if not exists public.challenges (
  id uuid primary key default gen_random_uuid(),
  creator uuid not null references auth.users(id) on delete cascade,
  opponent uuid not null references auth.users(id) on delete cascade,
  days int not null check (days between 1 and 14),
  status text not null default 'pending' check (status in ('pending','active','declined','finished')),
  starts_at timestamptz,
  ends_at timestamptz,
  winner uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  check (creator <> opponent)
);
create unique index if not exists challenges_open_pair on public.challenges (least(creator, opponent), greatest(creator, opponent)) where status in ('pending','active');
alter table public.challenges enable row level security;
drop policy if exists "own challenges" on public.challenges;
create policy "own challenges" on public.challenges for select using (creator = auth.uid() or opponent = auth.uid() or public.is_admin());
revoke insert, update, delete on public.challenges from anon, authenticated;

drop function if exists public.challenge_create(uuid, int);
create or replace function public.challenge_create(p_friendship uuid, p_days int default 7) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); cid uuid; f public.friendships; fr uuid;
begin
  if uid is null then raise exception 'denied'; end if;
  perform private.rl('challenge', 20, 3600);
  if p_days is null or p_days < 1 or p_days > 14 then raise exception 'invalid'; end if;
  if exists (select 1 from public.profiles where id = uid and suspended) then raise exception 'denied'; end if;
  select * into f from public.friendships where id = p_friendship and status = 'accepted' and (requester = uid or addressee = uid);
  if not found then raise exception 'denied'; end if;
  fr := case when f.requester = uid then f.addressee else f.requester end;
  if exists (select 1 from public.profiles where id = fr and suspended) then raise exception 'denied'; end if;
  begin
    insert into public.challenges (creator, opponent, days) values (uid, fr, p_days) returning id into cid;
  exception when unique_violation then raise exception 'exists';
  end;
  perform private.notify(fr, 'challenge', jsonb_build_object('state', 'invite', 'from', coalesce(nullif((select name from public.profiles where id = uid), ''), 'Learner'), 'days', p_days));
  return jsonb_build_object('id', cid);
end $$;
grant execute on function public.challenge_create(uuid, int) to authenticated;

create or replace function public.challenge_respond(p_id uuid, p_accept boolean) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); c public.challenges;
begin
  if uid is null then raise exception 'denied'; end if;
  select * into c from public.challenges where id = p_id for update;
  if not found or c.opponent <> uid or c.status <> 'pending' then raise exception 'denied'; end if;
  if coalesce(p_accept, false) then
    update public.challenges set status = 'active', starts_at = now(), ends_at = now() + make_interval(days => c.days) where id = p_id;
    perform private.notify(c.creator, 'challenge', jsonb_build_object('state', 'accepted', 'from', coalesce(nullif((select name from public.profiles where id = uid), ''), 'Learner')));
  else
    update public.challenges set status = 'declined' where id = p_id;
  end if;
  return jsonb_build_object('status', case when coalesce(p_accept, false) then 'active' else 'declined' end);
end $$;
grant execute on function public.challenge_respond(uuid, boolean) to authenticated;

create or replace function public.my_challenges() returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); ch public.challenges; a int; b int; w uuid; prize int := coalesce((private.cfg()->'league'->>'challenge_gems')::int, 20);
begin
  if uid is null then raise exception 'denied'; end if;
  -- settle finished challenges (idempotent; the prize is paid once through the gem ledger)
  for ch in select * from public.challenges where status = 'active' and ends_at <= now() and (creator = uid or opponent = uid) for update loop
    select coalesce(sum(amount), 0) into a from public.xp_events where user_id = ch.creator and created_at >= ch.starts_at and created_at < ch.ends_at;
    select coalesce(sum(amount), 0) into b from public.xp_events where user_id = ch.opponent and created_at >= ch.starts_at and created_at < ch.ends_at;
    w := case when a > b then ch.creator when b > a then ch.opponent end;
    update public.challenges set status = 'finished', winner = w where id = ch.id;
    if w is not null then perform private.gem_add(w, prize, 'challenge', ch.id::text, '{}'::jsonb); end if;
    perform private.notify(ch.creator, 'challenge', jsonb_build_object('state', 'finished', 'won', w = ch.creator, 'tie', w is null));
    perform private.notify(ch.opponent, 'challenge', jsonb_build_object('state', 'finished', 'won', w = ch.opponent, 'tie', w is null));
  end loop;
  return coalesce((select jsonb_agg(x order by x->>'created_at' desc) from (
    select jsonb_build_object('id', c.id, 'status', c.status, 'days', c.days, 'starts_at', c.starts_at, 'ends_at', c.ends_at, 'created_at', c.created_at,
      'mine', c.creator = uid, 'friendship', (select f.id from public.friendships f where f.status = 'accepted' and ((f.requester = c.creator and f.addressee = c.opponent) or (f.requester = c.opponent and f.addressee = c.creator)) limit 1), 'other', coalesce(nullif(o.name, ''), 'Learner'), 'other_id', o.id,
      'my_xp', case when c.starts_at is null then 0 else (select coalesce(sum(amount), 0) from public.xp_events where user_id = uid and created_at >= c.starts_at and created_at < c.ends_at) end,
      'their_xp', case when c.starts_at is null or not coalesce((o.privacy->>'show_activity')::boolean, true) then null else (select coalesce(sum(amount), 0) from public.xp_events where user_id = o.id and created_at >= c.starts_at and created_at < c.ends_at) end,
      'won', c.winner = uid) as x
    from public.challenges c join public.profiles o on o.id = case when c.creator = uid then c.opponent else c.creator end
    where c.creator = uid or c.opponent = uid order by c.created_at desc limit 30) s), '[]'::jsonb);
end $$;
grant execute on function public.my_challenges() to authenticated;

-- ---------------------------------------------------------------------------------------------
-- 6. AI coach: usage limits + cost tracking (the model is called only from a server function; keys never reach the browser)
-- ---------------------------------------------------------------------------------------------
create table if not exists public.ai_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  day date not null,
  calls int not null default 0,
  tokens_in bigint not null default 0,
  tokens_out bigint not null default 0,
  cost_micro bigint not null default 0,            -- millionths of a US dollar
  primary key (user_id, day)
);
alter table public.ai_usage enable row level security;
drop policy if exists "own ai usage" on public.ai_usage;
create policy "own ai usage" on public.ai_usage for select using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.ai_usage from anon, authenticated;

create or replace function private.ai_cfg() returns jsonb
language sql stable security definer set search_path = public as $$
  select '{"enabled":true,"daily_free":3,"daily_vip":25,"monthly_budget_micro":20000000}'::jsonb || coalesce((select value from public.settings where key = 'ai'), '{}'::jsonb)
$$;

-- called by the Edge Function with the learner's own JWT BEFORE any model call: checks and counts the request
create or replace function public.ai_reserve() returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); cfg jsonb := private.ai_cfg(); lim int; used int; d date := current_date; spent bigint;
begin
  if uid is null then raise exception 'denied'; end if;
  if exists (select 1 from public.profiles where id = uid and suspended) then raise exception 'denied'; end if;
  if not coalesce((cfg->>'enabled')::boolean, true) then raise exception 'ai_disabled'; end if;
  perform private.rl('ai', 30, 3600);
  select coalesce(sum(cost_micro), 0) into spent from public.ai_usage where day >= date_trunc('month', current_date)::date;
  if spent >= coalesce((cfg->>'monthly_budget_micro')::bigint, 20000000) then raise exception 'ai_budget'; end if;
  lim := case when private.is_vip(uid) then (cfg->>'daily_vip')::int else (cfg->>'daily_free')::int end;
  insert into public.ai_usage (user_id, day, calls) values (uid, d, 0) on conflict do nothing;
  select calls into used from public.ai_usage where user_id = uid and day = d for update;
  if used >= lim then raise exception 'ai_limit'; end if;
  update public.ai_usage set calls = calls + 1 where user_id = uid and day = d;
  return jsonb_build_object('used', used + 1, 'limit', lim, 'vip', private.is_vip(uid));
end $$;
grant execute on function public.ai_reserve() to authenticated;

-- records tokens + cost after the model answered (server only: browsers cannot call it)
create or replace function public.ai_record(p_user uuid, p_in int, p_out int, p_cost_micro bigint) returns void
language plpgsql security definer set search_path = public, private as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then raise exception 'denied'; end if;
  insert into public.ai_usage (user_id, day, calls, tokens_in, tokens_out, cost_micro) values (p_user, current_date, 0, greatest(p_in, 0), greatest(p_out, 0), greatest(p_cost_micro, 0))
  on conflict (user_id, day) do update set tokens_in = public.ai_usage.tokens_in + excluded.tokens_in, tokens_out = public.ai_usage.tokens_out + excluded.tokens_out, cost_micro = public.ai_usage.cost_micro + excluded.cost_micro;
end $$;
revoke all on function public.ai_record(uuid, int, int, bigint) from public, anon, authenticated;
grant execute on function public.ai_record(uuid, int, int, bigint) to service_role;

create or replace function public.my_ai_usage() returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); cfg jsonb := private.ai_cfg();
begin
  if uid is null then raise exception 'denied'; end if;
  return jsonb_build_object('enabled', coalesce((cfg->>'enabled')::boolean, true), 'used', coalesce((select calls from public.ai_usage where user_id = uid and day = current_date), 0),
    'limit', case when private.is_vip(uid) then (cfg->>'daily_vip')::int else (cfg->>'daily_free')::int end);
end $$;
grant execute on function public.my_ai_usage() to authenticated;

create or replace function public.admin_ai_stats() returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  return jsonb_build_object('today_calls', (select coalesce(sum(calls), 0) from public.ai_usage where day = current_date),
    'month_calls', (select coalesce(sum(calls), 0) from public.ai_usage where day >= date_trunc('month', current_date)::date),
    'month_cost_micro', (select coalesce(sum(cost_micro), 0) from public.ai_usage where day >= date_trunc('month', current_date)::date),
    'month_tokens', (select coalesce(sum(tokens_in + tokens_out), 0) from public.ai_usage where day >= date_trunc('month', current_date)::date),
    'budget_micro', (private.ai_cfg()->>'monthly_budget_micro')::bigint, 'config', private.ai_cfg());
end $$;
revoke all on function public.admin_ai_stats() from public;
grant execute on function public.admin_ai_stats() to authenticated;

-- the coach reads the learner's own data through this function (service role passes the learner id; the model only ever sees this summary)
create or replace function public.coach_context(p_user uuid) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then raise exception 'denied'; end if;
  return jsonb_build_object(
    'level', private.level_of(coalesce((select xp from public.player_state where user_id = p_user), 0)),
    'streak', coalesce((select streak from public.player_state where user_id = p_user), 0),
    'lessons_done', (select count(*) from public.lesson_completions where user_id = p_user),
    'accuracy', (select case when count(*) = 0 then null else round(100.0 * count(*) filter (where correct) / count(*)) end from (select correct from public.exercise_attempts where user_id = p_user order by created_at desc limit 200) a),
    'weak', coalesce((select jsonb_agg(w) from (
        select q.type, q.data, m.wrong_count, l.title as lesson_title, l.grammar
        from public.mistake_book m join public.questions q on q.id = m.question_id join public.lessons l on l.id = m.lesson_id
        where m.user_id = p_user and m.mastered_at is null order by m.wrong_count desc, m.last_wrong_at desc limit 12) w), '[]'::jsonb));
end $$;
revoke all on function public.coach_context(uuid) from public, anon, authenticated;
grant execute on function public.coach_context(uuid) to service_role;

-- ---------------------------------------------------------------------------------------------
-- 7. Weak topics, lesson recommendations, revision history (all computed from server records)
-- ---------------------------------------------------------------------------------------------
create or replace function public.my_weak_topics() returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'denied'; end if;
  return jsonb_build_object(
    'lessons', coalesce((select jsonb_agg(x order by (x->>'wrong')::int desc) from (
        select jsonb_build_object('lesson_id', l.id, 'title', l.title, 'grammar', l.grammar, 'wrong', sum(m.wrong_count), 'items', count(*), 'open', count(*) filter (where m.mastered_at is null)) as x
        from public.mistake_book m join public.lessons l on l.id = m.lesson_id join public.questions q on q.id = m.question_id and q.published
        where m.user_id = uid group by l.id, l.title, l.grammar order by sum(m.wrong_count) desc limit 8) s), '[]'::jsonb),
    'types', coalesce((select jsonb_agg(jsonb_build_object('qtype', t.qtype, 'wrong', t.w, 'open', t.o) order by t.w desc) from (
        select qtype, sum(wrong_count)::int as w, count(*) filter (where mastered_at is null)::int as o from public.mistake_book where user_id = uid group by qtype) t), '[]'::jsonb),
    'repeated', (select count(*) from public.mistake_book where user_id = uid and wrong_count >= 3 and mastered_at is null));
end $$;
grant execute on function public.my_weak_topics() to authenticated;

create or replace function public.my_recommendations(p_limit int default 5) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); is_v boolean; lim int := least(greatest(coalesce(p_limit, 5), 1), 10);
begin
  if uid is null then raise exception 'denied'; end if;
  is_v := private.is_vip(uid);
  return coalesce((select jsonb_agg(r) from (
    -- 1) lessons with the most open mistakes, 2) the next lesson never completed (in course order); only lessons this learner may open
    select * from (
      select l.id as lesson_id, l.title, 'review'::text as reason, sum(m.wrong_count)::int as score
      from public.mistake_book m join public.lessons l on l.id = m.lesson_id join public.units u on u.id = l.unit_id join public.courses c on c.id = u.course_id
      where m.user_id = uid and m.mastered_at is null and l.published and u.published and c.published and not c.archived and (not (u.vip or c.vip or l.vip) or is_v)
      group by l.id, l.title order by score desc limit lim
    ) a
    union all
    select * from (
      select l.id, l.title, 'next'::text, 0
      from public.lessons l join public.units u on u.id = l.unit_id join public.courses c on c.id = u.course_id
      where l.published and u.published and c.published and not c.archived and (not (u.vip or c.vip or l.vip) or is_v)
        and not exists (select 1 from public.lesson_completions lc where lc.user_id = uid and lc.lesson_id = l.id)
      order by c.position, u.position, l.position limit 2
    ) b) r), '[]'::jsonb);
end $$;
grant execute on function public.my_recommendations(int) to authenticated;

create or replace function public.my_revision_history(p_limit int default 30) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'denied'; end if;
  return coalesce((select jsonb_agg(x order by x->>'at' desc) from (
    select jsonb_build_object('question_id', e.question_id, 'qtype', e.qtype, 'correct', e.correct, 'at', e.created_at, 'practice', a.kind = 'practice') as x
    from public.exercise_attempts e join public.lesson_attempts a on a.id = e.attempt_id
    where e.user_id = uid and exists (select 1 from public.mistake_book m where m.user_id = uid and m.question_id = e.question_id)
    order by e.created_at desc limit least(greatest(coalesce(p_limit, 30), 1), 100)) s), '[]'::jsonb);
end $$;
grant execute on function public.my_revision_history(int) to authenticated;

-- audit the new admin-managed tables
do $$ begin
  execute 'drop trigger if exists audit_row on public.shop_items';
  execute 'create trigger audit_row after insert or update or delete on public.shop_items for each row execute function private.audit_row()';
end $$;

-- ---------------------------------------------------------------------------------------------
-- 8. Hardening (security audit): signed-out visitors may not execute any RPC except the tiny predicates that RLS policies call.
--    Every RPC already refuses auth.uid() = null; this removes the surface entirely. Future functions are private by default.
-- ---------------------------------------------------------------------------------------------
do $$ declare f record; had_auth boolean; had_svc boolean;
begin
  for f in select p.oid, p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'public' and p.prokind = 'f' loop
    had_auth := has_function_privilege('authenticated', f.oid, 'execute');   -- keep exactly what signed-in users could already call
    had_svc := has_function_privilege('service_role', f.oid, 'execute');
    execute format('revoke execute on function %s from public, anon', f.sig);
    if had_auth then execute format('grant execute on function %s to authenticated', f.sig); end if;
    if had_svc then execute format('grant execute on function %s to service_role', f.sig); end if;
  end loop;
end $$;
grant execute on function public.is_admin(), public.is_super_admin(), public.is_editor(), public.is_suspended() to anon;
do $$ begin
  if to_regprocedure('public.is_vip()') is not null then execute 'grant execute on function public.is_vip() to anon'; end if;
  if to_regprocedure('public.is_vip(uuid)') is not null then execute 'grant execute on function public.is_vip(uuid) to anon'; end if;
end $$;
alter default privileges in schema public revoke execute on functions from public, anon;
-- Lingora 2.1 migration 011: stories, story progress, placement results.
-- Additive and idempotent: safe to run more than once, touches no existing table or row.
-- Requires the helpers already created by SETUP.sql: public.is_editor() (admins and editors).

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  language text not null check (language ~ '^[a-z]{2,3}$'),          -- course language code, for example 'en', 'fr'
  level text not null check (level in ('A1','A2','B1','B2','C1','C2')),
  title jsonb not null,                                              -- {"hy":"...","en":"..."}
  emoji text not null default '📖' check (char_length(emoji) <= 8),
  paragraphs jsonb not null default '[]'::jsonb,                     -- [{"t":"text","tr":"translation","audio":"https://..."}]
  vocab jsonb not null default '[]'::jsonb,                          -- [{"w":"word","tr":"translation"}]
  questions jsonb not null default '[]'::jsonb,                      -- [{"p":0,"q":"?","a":"answer","o":["wrong","wrong"],"x":"explanation"}]
  published boolean not null default false,
  position int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint stories_arrays check (jsonb_typeof(paragraphs)='array' and jsonb_typeof(vocab)='array' and jsonb_typeof(questions)='array'),
  -- a story can only be published when it has text and at least one question (no empty or broken stories)
  constraint stories_publish_ready check (not published or (jsonb_array_length(paragraphs) > 0 and jsonb_array_length(questions) > 0))
);
create index if not exists stories_lang_idx on public.stories (language, published, position);
alter table public.stories enable row level security;
drop policy if exists "stories read" on public.stories;
create policy "stories read" on public.stories for select using (published or public.is_editor());
drop policy if exists "stories staff write" on public.stories;
create policy "stories staff write" on public.stories for all using (public.is_editor()) with check (public.is_editor());

create table if not exists public.story_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  story_id uuid not null references public.stories(id) on delete cascade,
  stars int not null check (stars between 1 and 3),
  completed_at timestamptz not null default now(),
  primary key (user_id, story_id)
);
alter table public.story_progress enable row level security;
drop policy if exists "story progress own read" on public.story_progress;
create policy "story progress own read" on public.story_progress for select using (user_id = auth.uid());
-- no direct insert/update policy: rows are written only through record_story_progress()

create or replace function public.record_story_progress(p_story uuid, p_stars int)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if p_stars is null or p_stars < 1 or p_stars > 3 then raise exception 'invalid'; end if;
  if not exists (select 1 from public.stories s where s.id = p_story and s.published) then raise exception 'not_found'; end if;
  insert into public.story_progress (user_id, story_id, stars) values (auth.uid(), p_story, p_stars)
  on conflict (user_id, story_id) do update set stars = greatest(public.story_progress.stars, excluded.stars), completed_at = now();
end $$;
revoke all on function public.record_story_progress(uuid, int) from public;
grant execute on function public.record_story_progress(uuid, int) to authenticated;

create table if not exists public.placement_results (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  language text not null check (language ~ '^[a-z]{2,3}$'),
  cefr text not null check (cefr in ('A1','A2','B1','B2','C1','C2')),
  score int not null check (score >= 0),
  total int not null check (total > 0 and score <= total),
  created_at timestamptz not null default now()
);
create index if not exists placement_user_idx on public.placement_results (user_id, language, created_at desc);
alter table public.placement_results enable row level security;
drop policy if exists "placement own read" on public.placement_results;
create policy "placement own read" on public.placement_results for select using (user_id = auth.uid() or public.is_editor());

create or replace function public.record_placement(p_language text, p_cefr text, p_score int, p_total int)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if p_cefr not in ('A1','A2','B1','B2','C1','C2') or p_total is null or p_total < 1 or p_total > 60 or p_score < 0 or p_score > p_total or p_language !~ '^[a-z]{2,3}$' then raise exception 'invalid'; end if;
  -- at most 10 saved results per learner per hour (stops table spam)
  if (select count(*) from public.placement_results where user_id = auth.uid() and created_at > now() - interval '1 hour') >= 10 then raise exception 'limit'; end if;
  insert into public.placement_results (user_id, language, cefr, score, total) values (auth.uid(), p_language, p_cefr, p_score, p_total);
end $$;
revoke all on function public.record_placement(text, text, int, int) from public;
grant execute on function public.record_placement(text, text, int, int) to authenticated;

-- ===== supabase/migrations/012_ai_coach_release.sql (Lingora 4.0) =====
-- ai_release(): give back an AI coach call when the model did not answer (see migrations/012_ai_coach_release.sql).
-- The service-role check in ai_record / coach_context / apply_payment above already uses auth.role() (works with current PostgREST).
create or replace function public.ai_release(p_user uuid) returns void
language plpgsql security definer set search_path = public, private as $$
begin
  if coalesce(auth.role(), '') <> 'service_role' and session_user not in ('postgres', 'supabase_admin') then raise exception 'denied'; end if;
  update public.ai_usage set calls = greatest(calls - 1, 0) where user_id = p_user and day = current_date;
end $$;
revoke all on function public.ai_release(uuid) from public, anon, authenticated;
grant execute on function public.ai_release(uuid) to service_role;

-- ===== supabase/migrations/013_reset_progress.sql (Lingora 4.0) =====
--
-- (a) reset_my_progress(): a REAL server-side "reset my progress". Before this, "Reset progress" in cloud mode cleared only the
--     browser copy; player_state / lesson_completions are authoritative on the server and were simply re-applied on the next sync
--     (B-006: "old progress comes back"). The function clears XP, streak, finished lessons, the mistake book, story stars and this
--     week's XP events for the CALLER only (auth.uid(); no user id is accepted).
--     It deliberately KEEPS everything that is money-like or a one-time reward, so a reset can never be used to farm them:
--     gems, hearts, freezes, boosts, VIP, streak milestones (player_state.milestones), achievements, quest claims, gem ledger,
--     lesson attempts (daily completion limits keep counting).
-- (b) complete_lesson(): the first-completion gem reward is now keyed by LESSON (reason 'lesson_first'), not by attempt id, so it
--     is paid once per lesson per account even if the lesson is completed again after a reset. The result now reports the gems
--     that were really paid (0 when none), instead of the configured amount.
-- Rollback: drop function public.reset_my_progress(); and re-run the previous complete_lesson from SETUP.sql (migration 010/008 block).

create or replace function public.reset_my_progress() returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); wk date;
begin
  if uid is null then raise exception 'denied'; end if;
  if public.is_suspended() then raise exception 'suspended'; end if;
  perform private.ps_get(uid);                      -- make sure the state row exists
  wk := private.week_start(uid);
  delete from public.lesson_completions where user_id = uid;
  delete from public.mistake_book where user_id = uid;
  delete from public.story_progress where user_id = uid;
  delete from public.xp_events where user_id = uid and day >= wk;   -- this week only: the weekly leaderboard sums these
  update public.player_state set xp = 0, streak = 0, best_streak = 0, last_day = null, day = null, day_xp = 0, updated_at = now()
   where user_id = uid;
  insert into public.progress (user_id, data, updated_at) values (uid, '{}'::jsonb, now())
  on conflict (user_id) do update set data = '{}'::jsonb, updated_at = now();
  insert into public.audit_log (actor, actor_role, action, entity, entity_id, detail)
  values (uid, 'user', 'progress_reset', 'user', uid::text, '{}'::jsonb);
  return private.state_json(uid);
end $$;
revoke all on function public.reset_my_progress() from public, anon;
grant execute on function public.reset_my_progress() to authenticated;

-- complete_lesson (the hardened 008 version: answers must be recorded by the server) with the per-lesson first-completion reward
create or replace function public.complete_lesson(p_attempt uuid, p_mistakes int) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare
  uid uuid := auth.uid(); a public.lesson_attempts; cfg jsonb := private.cfg(); ps public.player_state; l public.lessons;
  mis int := least(greatest(coalesce(p_mistakes, 0), 0), 60); stars int; first_time boolean; raw int; mult numeric := 1; xp int; g int := 0;
  lv0 int; lv1 int; unit_done boolean := false; today_xp int; cap int; d date := private.local_day(uid);
  ev jsonb; ach jsonb; goal_hit boolean := false; res jsonb; gmult jsonb; star_xp int := (cfg->'xp'->>'star')::int;
  done_today int; wrong_rows int; has_rows boolean; need_answers boolean := coalesce((cfg->'answers'->>'required')::boolean, true);
begin
  if uid is null then raise exception 'denied'; end if;
  select * into a from public.lesson_attempts where id = p_attempt and user_id = uid for update;
  if not found then raise exception 'not_found'; end if;
  if a.status = 'done' then return a.result; end if;        -- repeated call: same answer, no second reward
  if a.kind <> 'lesson' then raise exception 'invalid'; end if;
  if extract(epoch from (now() - a.started_at)) < a.questions * (cfg->'xp'->>'sec_per_question')::numeric then raise exception 'too_fast'; end if;
  select count(*) into done_today from public.lesson_attempts where user_id = uid and kind = 'lesson' and status = 'done' and finished_day = d;
  if done_today >= (cfg->'xp'->>'completions_per_day')::int then raise exception 'rate_limited'; end if;

  select count(*) filter (where not correct), count(*) > 0 into wrong_rows, has_rows from public.exercise_attempts where attempt_id = a.id;
  if need_answers and exists (
       select 1 from public.questions q
       where q.lesson_id = a.lesson_id and q.type <> 'intro' and q.published and private.q_valid(q.type, q.data)
         and not exists (select 1 from public.exercise_attempts e where e.attempt_id = a.id and e.question_id = q.id and e.correct)) then
    raise exception 'incomplete';          -- every exercise must have a correct, server-recorded answer
  end if;
  if has_rows then mis := least(greatest(wrong_rows, a.misses), 60); end if;
  ps := private.ps_get(uid);
  select * into l from public.lessons where id = a.lesson_id;
  lv0 := private.level_of(ps.xp);
  select exists (select 1 from public.lesson_completions where user_id = uid and lesson_id = a.lesson_id) into first_time; first_time := not first_time;
  stars := case when mis = 0 then 3 when mis <= 2 then 2 else 1 end;

  if first_time then
    raw := coalesce(l.xp, 8) + stars * star_xp;
  else
    raw := (cfg->'xp'->>'repeat')::int;
  end if;

  insert into public.lesson_completions (user_id, lesson_id, best_stars) values (uid, a.lesson_id, stars)
  on conflict (user_id, lesson_id) do update set best_stars = greatest(lesson_completions.best_stars, excluded.best_stars),
        times = lesson_completions.times + 1, last_at = now();

  if first_time then
    unit_done := exists (select 1 from public.lessons x where x.unit_id = l.unit_id and x.published)
      and not exists (select 1 from public.lessons x where x.unit_id = l.unit_id and x.published
                      and not exists (select 1 from public.lesson_completions c where c.user_id = uid and c.lesson_id = x.id));
    if unit_done then raw := raw + (cfg->'xp'->>'unit')::int; end if;
  end if;
  raw := least(raw, (cfg->'xp'->>'max_lesson_xp')::int);

  -- XP multipliers: admin event and personal boost, never stacked
  gmult := cfg->'multiplier';
  if coalesce((gmult->>'value')::numeric, 1) > 1 and (coalesce(gmult->>'until', '') = '' or (gmult->>'until')::timestamptz > now()) then mult := (gmult->>'value')::numeric; end if;
  if ps.boost_until is not null and ps.boost_until > now() then mult := greatest(mult, ps.boost_mult); end if;
  xp := round(raw * mult)::int;
  cap := (cfg->'xp'->>'daily_cap')::int;
  select coalesce(sum(amount), 0) into today_xp from public.xp_events where user_id = uid and day = d and kind in ('lesson','practice');
  xp := greatest(0, least(xp, cap - today_xp));

  ev := private.touch_streak(uid);
  perform private.xp_add(uid, xp, 'lesson', a.lesson_id, jsonb_build_object('stars', stars, 'mistakes', mis, 'words', a.words, 'speaking', a.speaking));

  update public.lesson_attempts set status = 'done', finished_at = now(), finished_day = d, mistakes = mis where id = a.id;
  if first_time then
    g := (cfg->'gems'->>'lesson')::int + case when stars = 3 then (cfg->'gems'->>'perfect')::int else 0 end + case when unit_done then (cfg->'gems'->>'unit')::int else 0 end;
    -- ONE first-completion reward per lesson per account: the key is the lesson, not the attempt, so it survives
    -- reset_my_progress() and a reset + replay can no longer farm gems. g reports what was really paid (0 if nothing was paid).
    if not private.gem_add(uid, g, 'lesson_first', a.lesson_id, jsonb_build_object('lesson', a.lesson_id, 'attempt', a.id)) then g := 0; end if;
  else
    g := (cfg->'gems'->>'repeat')::int;
    perform private.gem_add(uid, g, 'lesson', a.id::text, jsonb_build_object('lesson', a.lesson_id));
  end if;

  -- daily goal reward, once per local day
  select * into ps from public.player_state where user_id = uid;
  if ps.day = d and ps.day_xp >= ps.goal then
    goal_hit := private.gem_add(uid, (cfg->'gems'->>'goal')::int, 'goal', d::text, '{}'::jsonb);
    if goal_hit then g := g + (cfg->'gems'->>'goal')::int; end if;
  end if;

  ach := private.check_achievements(uid);
  select * into ps from public.player_state where user_id = uid;
  lv1 := private.level_of(ps.xp);

  res := jsonb_build_object('xp', xp, 'raw', raw, 'mult', mult, 'stars', stars, 'gems', g, 'first', first_time, 'unit_done', unit_done,
    'goal_hit', goal_hit, 'level_up', case when lv1 > lv0 then lv1 end, 'streak_event', ev, 'achievements', ach, 'accuracy_mistakes', mis,
    'state', private.state_json(uid));
  update public.lesson_attempts set result = res where id = a.id;
  return res;
end $$;

-- ===== migrations/014_phase1_stability.sql (Lingora Phase 1) =====
-- Lingora Phase 1 migration 014 (stability). Additive and idempotent: three function bodies are replaced in place; no table, column or row changes.
--  P1-02 private.touch_streak / public.claim_daily_reward: a client-reported time zone that moves the local date BACKWARDS no longer counts as a new day.
--        Before: flipping the reported zone (get_my_state(p_tz) accepts any value in -840..840) pushed the streak forward several times per real day
--        and collected streak-milestone gems / XP / freezes. Same flip allowed several daily-reward claims.
--  P1-05 public.admin_list_users: the 'free' filter now means "no ACTIVE VIP" (matches the 'vip' filter). A VIP that is scheduled for the future
--        was in neither list.
-- Rollback: re-run the three definitions from the previous SETUP.sql section.
create or replace function private.touch_streak(uid uuid) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare ps public.player_state; d date := private.local_day(uid); miss int; ev jsonb := '{}'::jsonb; cfg jsonb := private.cfg();
        m jsonb; mx int := coalesce((cfg->'streak'->>'max_freeze')::int, 2);
begin
  select * into ps from public.player_state where user_id = uid for update;
  -- P1-02: `>=`, not `=`. A client that reports an earlier time zone makes today's local date older than last_day; that used to count
  -- as a new day (streak +1, milestone gems) and let the streak be pushed forward several times per real day.
  if ps.last_day is not null and ps.last_day >= d then return ev; end if;
  if ps.last_day is null then ps.streak := 1;
  else
    miss := (d - ps.last_day) - 1;
    if miss <= 0 then ps.streak := ps.streak + 1;
    elsif miss <= ps.freezes then ps.freezes := ps.freezes - miss; ps.streak := ps.streak + 1; ev := jsonb_build_object('froze', miss);
    else ps.streak := 1;
    end if;
  end if;
  ps.last_day := d; ps.best_streak := greatest(ps.best_streak, ps.streak);
  update public.player_state set streak = ps.streak, best_streak = ps.best_streak, last_day = d, freezes = ps.freezes where user_id = uid;
  -- streak milestones, once each
  select x into m from jsonb_array_elements(coalesce(cfg->'streak'->'milestones', '[]'::jsonb)) x where (x->>'d')::int = ps.streak limit 1;
  if m is not null and (ps.milestones->>(ps.streak::text)) is null then
    update public.player_state set milestones = milestones || jsonb_build_object(ps.streak::text, extract(epoch from now())::bigint) where user_id = uid;
    if coalesce((m->>'xp')::int, 0) > 0 then perform private.xp_add(uid, (m->>'xp')::int, 'streak', ps.streak::text, '{}'::jsonb); end if;
    if coalesce((m->>'freeze')::int, 0) > 0 then
      update public.player_state set freezes = least(mx, freezes + (m->>'freeze')::int) where user_id = uid;
    end if;
    if coalesce((m->>'boost')::int, 0) > 0 then
      update public.player_state set boost_until = now() + make_interval(mins => (m->>'boost')::int), boost_mult = 2 where user_id = uid;
    end if;
    if coalesce((m->>'gems')::int, 0) > 0 then perform private.gem_add(uid, (m->>'gems')::int, 'streak', ps.streak::text, '{}'::jsonb); end if;
    ev := ev || jsonb_build_object('milestone', m);
  end if;
  return ev;
end $$;

create or replace function public.claim_daily_reward() returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); ps public.player_state; d date := private.local_day(uid); cfg jsonb := private.cfg(); arr jsonb := cfg->'gems'->'daily';
        n int; amt int; ok boolean;
begin
  if uid is null then raise exception 'denied'; end if;
  ps := private.ps_get(uid);
  if ps.login_day is not null and ps.login_day >= d then raise exception 'already_claimed'; end if;   -- P1-02: `>=` (time-zone flip guard)
  n := case when ps.login_day = d - 1 then ps.login_streak + 1 else 1 end;
  amt := (arr->>(((n - 1) % jsonb_array_length(arr))::int))::int;
  ok := private.gem_add(uid, amt, 'daily', d::text, jsonb_build_object('day', n));
  if not ok then raise exception 'already_claimed'; end if;
  update public.player_state set login_day = d, login_streak = n where user_id = uid;
  return jsonb_build_object('gems', amt, 'day', n, 'state', private.state_json(uid));
end $$;

create or replace function public.admin_list_users(p_q text default '', p_filter text default 'all', p_sort text default 'created',
  p_dir text default 'desc', p_limit int default 25, p_offset int default 0) returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare q text := private.like_pat(p_q); tot int; rows jsonb; lim int := least(greatest(coalesce(p_limit, 25), 1), 100);
        asc_ boolean := lower(coalesce(p_dir, 'desc')) = 'asc';
begin
  if auth.uid() is null or not public.is_admin() then raise exception 'denied'; end if;
  with base as (
    select p.id, p.email, p.name, p.username, p.role, p.suspended, p.created_at, p.vip_until, p.vip_from,
           (p.vip_until is not null and p.vip_until > now() and (p.vip_from is null or p.vip_from <= now())) as vip_active,
           coalesce(s.xp, 0) as xp, coalesce(s.streak, 0) as streak, s.last_day,
           (select count(*) from public.lesson_completions lc where lc.user_id = p.id) as lessons_done
    from public.profiles p left join public.player_state s on s.user_id = p.id
    where (btrim(coalesce(p_q, '')) = '' or lower(p.email) like q escape E'\\' or lower(p.name) like q escape E'\\' or lower(coalesce(p.username, '')) like q escape E'\\' or p.id::text = btrim(p_q))
      and case coalesce(p_filter, 'all')
        when 'vip' then p.vip_until is not null and p.vip_until > now() and (p.vip_from is null or p.vip_from <= now())
        when 'expired' then p.vip_until is not null and p.vip_until <= now()
        when 'free' then not (p.vip_until is not null and p.vip_until > now() and (p.vip_from is null or p.vip_from <= now()))
        when 'staff' then p.role <> 'user'
        when 'suspended' then p.suspended
        else true end
  )
  , numbered as (
    select b.*, count(*) over () as tot, row_number() over (order by
        case when p_sort = 'xp' and not asc_ then b.xp end desc nulls last, case when p_sort = 'xp' and asc_ then b.xp end asc nulls last,
        case when p_sort = 'name' and not asc_ then lower(b.name) end desc nulls last, case when p_sort = 'name' and asc_ then lower(b.name) end asc nulls last,
        case when p_sort = 'vip_until' and not asc_ then b.vip_until end desc nulls last, case when p_sort = 'vip_until' and asc_ then b.vip_until end asc nulls last,
        case when p_sort not in ('xp','name','vip_until') and asc_ then b.created_at end asc, case when p_sort not in ('xp','name','vip_until') and not asc_ then b.created_at end desc,
        b.id) as rn
    from base b)
  select coalesce(max(n.tot), 0), coalesce(jsonb_agg((to_jsonb(n) - 'tot' - 'rn') order by n.rn) filter (where n.rn > greatest(coalesce(p_offset, 0), 0) and n.rn <= greatest(coalesce(p_offset, 0), 0) + lim), '[]'::jsonb)
    into tot, rows from numbered n;
  return jsonb_build_object('total', tot, 'rows', rows);
end $$;

-- ===== migrations/015_phase2_economy.sql (Lingora Phase 2) =====
-- Lingora Phase 2 migration 015: the coin economy and individual VIP-lesson unlocks.
-- Additive and idempotent (safe to run twice). No existing balance, purchase or progress row is changed.
--  1. Every learner earns Lingora Coins (gems) from learning. Before, only VIP members did (005_gem_policy). The owner can still switch
--     it off again with Admin > Settings economy.gems.free_earn = false. Earning stays bounded: first completion of each lesson only (key = lesson),
--     the daily goal once a day, streak milestones once each, quests once per period, and now practice sessions at most gems.practice_daily_cap (default 5) per rolling 24 h.
--  2. lessons.vip lessons (in a free unit / free course) can be unlocked one by one for coins: table lesson_unlocks (own rows readable, writes only through
--     public.unlock_lesson), public.shop_lessons() for the Shop, owned lessons are readable through the same RLS as VIP and startable through start_lesson.
--  3. state_json carries "unlocked" (the lesson ids the account owns) so the client never has to guess.
-- Price: lessons.unlock_price, else economy.shop.lesson_unlock, else 80 coins.

alter table public.lessons add column if not exists unlock_price int check (unlock_price is null or (unlock_price between 1 and 100000));

create table if not exists public.lesson_unlocks (
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id text not null references public.lessons(id) on delete cascade,
  price int not null check (price >= 0),
  created_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);
alter table public.lesson_unlocks enable row level security;
drop policy if exists "own unlocks" on public.lesson_unlocks;
create policy "own unlocks" on public.lesson_unlocks for select using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.lesson_unlocks from anon, authenticated;

create or replace function public.owns_lesson(p_lesson text) returns boolean
language sql stable security definer set search_path = public as $$
  select auth.uid() is not null and exists (select 1 from public.lesson_unlocks where user_id = auth.uid() and lesson_id = p_lesson)
$$;
grant execute on function public.owns_lesson(text) to anon, authenticated;

-- gem_add: free accounts earn (unless the owner switched it off); practice coins are capped per rolling 24 h
create or replace function private.gem_add(uid uuid, delta int, p_reason text, p_ref text, p_meta jsonb) returns boolean
language plpgsql security definer set search_path = public, private as $$
declare bal int; ins bigint; cap int; got int;
begin
  if delta = 0 then return false; end if;
  if delta > 0 and p_reason not in ('admin','purchase','vip_daily') and not private.is_vip(uid)
     and not coalesce((private.cfg()->'gems'->>'free_earn')::boolean, true) then
    return false;   -- the owner turned free earning off
  end if;
  if delta > 0 and p_reason = 'practice' then
    cap := coalesce((private.cfg()->'gems'->>'practice_daily_cap')::int, 5);
    select coalesce(sum(g.delta), 0) into got from public.gem_transactions g
      where g.user_id = uid and g.reason = 'practice' and g.created_at > now() - interval '24 hours';
    delta := least(delta, greatest(cap - got, 0));
    if delta <= 0 then return false; end if;
  end if;
  insert into public.gem_transactions (user_id, delta, reason, ref, balance_after, meta)
  values (uid, delta, p_reason, coalesce(p_ref, ''), 0, coalesce(p_meta, '{}'::jsonb))
  on conflict (user_id, reason, ref) do nothing returning id into ins;
  if ins is null then return false; end if;
  update public.player_state set gems = gems + delta, updated_at = now() where user_id = uid returning gems into bal;
  if bal is null then raise exception 'no_state'; end if;
  update public.gem_transactions set balance_after = bal where id = ins;
  return true;
exception when check_violation then
  raise exception 'not_enough_gems';
end $$;

-- who can read a lesson / its questions: staff, VIP, or (for a lesson-level VIP flag only) the account that unlocked it
drop policy if exists "lessons read" on public.lessons;
create policy "lessons read" on public.lessons for select using (
  public.is_editor()
  or (published and exists (select 1 from public.units u join public.courses c on c.id = u.course_id
        where u.id = lessons.unit_id and u.published and c.published and not c.archived
          and (not (u.vip or c.vip or lessons.vip) or public.is_vip() or (not (u.vip or c.vip) and public.owns_lesson(lessons.id)))))
);
drop policy if exists "questions read" on public.questions;
create policy "questions read" on public.questions for select using (
  public.is_editor()
  or (published and exists (select 1 from public.lessons l join public.units u on u.id = l.unit_id join public.courses c on c.id = u.course_id
        where l.id = questions.lesson_id and l.published and u.published and c.published and not c.archived
          and (not (u.vip or c.vip or l.vip) or public.is_vip() or (not (u.vip or c.vip) and public.owns_lesson(l.id)))))
);

create or replace function public.locked_lessons() returns jsonb
language sql stable security definer set search_path = public as $$
  select case when public.is_vip() then '[]'::jsonb else coalesce((
    select jsonb_agg(jsonb_build_object('id', l.id, 'unit_id', l.unit_id, 'title', l.title, 'position', l.position) order by l.position)
    from public.lessons l join public.units u on u.id = l.unit_id join public.courses c on c.id = u.course_id
    where l.published and u.published and c.published and not c.archived and (u.vip or c.vip or l.vip)
      and not (not (u.vip or c.vip) and public.owns_lesson(l.id))), '[]'::jsonb) end
$$;
grant execute on function public.locked_lessons() to authenticated;

create or replace function public.start_lesson(p_lesson text, p_kind text default 'lesson', p_questions int default null) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); ps public.player_state; l public.lessons; u public.units; c public.courses; n int; w int; sp int; att_id uuid;
        unl boolean; isvip boolean;
begin
  if uid is null then raise exception 'denied'; end if;
  if exists (select 1 from public.profiles where id = uid and suspended) then raise exception 'denied'; end if;
  perform private.rl('start', 240, 3600);
  ps := private.ps_get(uid);
  isvip := private.is_vip(uid);
  unl := isvip or (ps.unlimited_until is not null and ps.unlimited_until > now());
  if p_kind = 'practice' then
    n := least(greatest(coalesce(p_questions, 8), 3), 40); w := 0; sp := 0;
  elsif p_kind = 'lesson' then
    select * into l from public.lessons where id = p_lesson;
    if not found then raise exception 'not_found'; end if;
    select * into u from public.units where id = l.unit_id;
    select * into c from public.courses where id = u.course_id;
    if not (public.is_editor() or (l.published and u.published and c.published and not c.archived and (not (u.vip or c.vip or l.vip) or isvip or (not (u.vip or c.vip) and public.owns_lesson(l.id))))) then
      raise exception 'denied';
    end if;
    select count(*), count(*) filter (where type = 'intro'), count(*) filter (where type in ('speak','listen')) into n, w, sp
      from public.questions where lesson_id = l.id;
    if n = 0 then raise exception 'empty_lesson'; end if;
    if ps.hearts <= 0 and not unl then raise exception 'no_hearts'; end if;
  else
    raise exception 'invalid';
  end if;
  insert into public.lesson_attempts (user_id, lesson_id, kind, questions, words, speaking)
  values (uid, case when p_kind = 'lesson' then p_lesson end, p_kind, n, w, sp) returning lesson_attempts.id into att_id;
  return jsonb_build_object('attempt_id', att_id, 'questions', n, 'state', private.state_json(uid));
end $$;

create or replace function private.state_json(uid uuid) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare ps public.player_state; cfg jsonb := private.cfg(); iv numeric := (cfg->'hearts'->>'regen_minutes')::numeric * 60;
        mx int := (cfg->'hearts'->>'max')::int; d date := private.local_day(uid); alive boolean; vip boolean := private.is_vip(uid);
        unl boolean; unl_l jsonb; lv jsonb; dl jsonb := cfg->'gems'->'daily'; claim boolean; nexti int; ach jsonb; comp jsonb;
begin
  select * into ps from public.player_state where user_id = uid;
  alive := ps.last_day is not null and ps.last_day >= d - 1 - ps.freezes;
  unl := vip or (ps.unlimited_until is not null and ps.unlimited_until > now());
  lv := private.xp_to_next(ps.xp);
  claim := ps.login_day is distinct from d;
  nexti := case when ps.login_day = d then ps.login_streak
                when ps.login_day = d - 1 then ps.login_streak else 0 end;
  select coalesce(jsonb_object_agg(achievement_id, extract(epoch from earned_at) * 1000), '{}'::jsonb) into ach from public.user_achievements where user_id = uid;
  select coalesce(jsonb_agg(lesson_id order by lesson_id), '[]'::jsonb) into unl_l from public.lesson_unlocks where user_id = uid;
  select coalesce(jsonb_object_agg(lesson_id, best_stars), '{}'::jsonb) into comp from public.lesson_completions where user_id = uid;
  return jsonb_build_object(
    'xp', ps.xp, 'gems', ps.gems, 'level', lv,
    'hearts', case when unl then mx else ps.hearts end, 'hearts_max', mx, 'unlimited', unl,
    'unlimited_until', ps.unlimited_until, 'vip', vip,
    'next_heart_at', case when not unl and ps.hearts < mx then ps.hearts_at + make_interval(secs => iv) end,
    'regen_minutes', (cfg->'hearts'->>'regen_minutes')::int, 'refill_gems', (cfg->'hearts'->>'refill_gems')::int,
    'streak', case when alive then ps.streak else 0 end, 'best_streak', ps.best_streak, 'streak_today', ps.last_day = d,
    'freezes', ps.freezes, 'boost_until', case when ps.boost_until > now() then ps.boost_until end, 'boost_mult', ps.boost_mult,
    'goal', ps.goal, 'day', d, 'day_xp', case when ps.day = d then ps.day_xp else 0 end,
    'daily', jsonb_build_object('can_claim', claim, 'day_index', case when claim then (nexti % jsonb_array_length(dl)) else ((nexti - 1) % jsonb_array_length(dl)) end,
                                'rewards', dl, 'streak', case when claim and ps.login_day < d - 1 then 0 else ps.login_streak end),
    'achievements', ach, 'done', comp, 'unlocked', unl_l, 'server_time', now());
end $$;



-- the lessons a learner can buy with coins: VIP-flagged lessons inside a free unit of a free course
create or replace function public.shop_lessons() returns jsonb
language plpgsql stable security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); dflt int;
begin
  if uid is null then raise exception 'denied'; end if;
  dflt := coalesce((private.cfg()->'shop'->>'lesson_unlock')::int, 80);
  return coalesce((select jsonb_agg(jsonb_build_object('id', l.id, 'title', l.title, 'unit', u.title, 'course_id', c.id, 'xp', l.xp,
            'price', coalesce(l.unlock_price, dflt), 'owned', exists (select 1 from public.lesson_unlocks k where k.user_id = uid and k.lesson_id = l.id),
            'questions', (select count(*) from public.questions q where q.lesson_id = l.id))
          order by c.position, u.position, l.position)
     from public.lessons l join public.units u on u.id = l.unit_id join public.courses c on c.id = u.course_id
     where l.vip and l.published and u.published and c.published and not c.archived and not u.vip and not c.vip), '[]'::jsonb);
end $$;
grant execute on function public.shop_lessons() to authenticated;

-- unlock_lesson: the only way a lesson unlock is created. Price is read from the database, never from the browser; the player row is locked
-- first, so two parallel taps cannot both pay; a second call for a lesson already owned changes nothing; the balance can never go below zero.
create or replace function public.unlock_lesson(p_lesson text, p_idem text) returns jsonb
language plpgsql security definer set search_path = public, private as $$
declare uid uuid := auth.uid(); l public.lessons; u public.units; c public.courses; ps public.player_state; price int; ok boolean;
begin
  if uid is null then raise exception 'denied'; end if;
  if exists (select 1 from public.profiles where id = uid and suspended) then raise exception 'denied'; end if;
  if p_idem is null or length(p_idem) < 8 or length(p_idem) > 80 or p_lesson is null then raise exception 'invalid'; end if;
  perform private.rl('unlock', 60, 3600);
  perform private.ps_get(uid);
  select * into ps from public.player_state where user_id = uid for update;
  if exists (select 1 from public.lesson_unlocks where user_id = uid and lesson_id = p_lesson) then
    return jsonb_build_object('duplicate', true, 'lesson', p_lesson, 'state', private.state_json(uid));
  end if;
  select * into l from public.lessons where id = p_lesson;
  if not found then raise exception 'not_found'; end if;
  select * into u from public.units where id = l.unit_id;
  select * into c from public.courses where id = u.course_id;
  if not (l.published and u.published and c.published and not c.archived) then raise exception 'not_found'; end if;
  if not l.vip or u.vip or c.vip then raise exception 'not_unlockable'; end if;
  if private.is_vip(uid) then raise exception 'already_vip'; end if;
  price := coalesce(l.unlock_price, coalesce((private.cfg()->'shop'->>'lesson_unlock')::int, 80));
  if ps.gems < price then raise exception 'not_enough_gems'; end if;
  insert into public.lesson_unlocks (user_id, lesson_id, price) values (uid, l.id, price);
  ok := private.gem_add(uid, -price, 'unlock', l.id, jsonb_build_object('lesson', l.id, 'idem', p_idem));
  if price > 0 and not ok then raise exception 'duplicate'; end if;
  return jsonb_build_object('lesson', l.id, 'price', price, 'state', private.state_json(uid));
end $$;
grant execute on function public.unlock_lesson(text, text) to authenticated;
