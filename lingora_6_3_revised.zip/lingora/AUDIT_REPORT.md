# Lingora 4.0 audit report (session 4)

Environment: PostgreSQL 16 and Chromium were available, so the SQL, AI, payment, end-to-end and browser suites were really executed.
No Supabase project, Stripe account, AI provider key or TTS key was available: nothing below was verified against those live services.

## Test results (all executed in this session, final run)
| Suite | Result |
|---|---|
| `tests/sql/run.sh` (RLS, economy, anti-cheat, VIP, admin, reset) | 86 / 86 (67 existing + 19 new) |
| `tests/ai/coach.test.mjs` (mock provider) | 26 / 26 |
| `tests/stripe/stripe.test.mjs` (real handlers + real PostgreSQL, mocked api.stripe.com) | 19 / 19, run twice |
| `tests/e2e/e2e.mjs` (Chromium + PostgreSQL stand-in) | 43 / 43 |
| `tests/ui/sync.mjs` | 21 / 21 |
| `tests/ui/mediacopy.mjs` (previously crashed) | 26 / 26 |
| `tests/ui/reset.mjs` (new) | 17 / 17; mutation-checked: with the fix disabled 4 checks fail (old XP returns) |
| `tests/ui/pay.mjs` (new) | 7 / 7 |
| `tests/ui/admin.mjs` (new, B-004 regression) | 8 / 8 |
| `tests/ui/contrast.mjs` | 32 screens, 0 low-contrast text |

## Bugs found and fixed
See BUG_TRACKER.md (B-001, B-004, B-006 to B-011). Two of the earlier "fixes" were wrong: B-001 was marked fixed but the handler was unreachable, and B-004 was assumed to be a stub artifact; it is a genuine request/render loop that would also hit real users whenever `admin_stats` fails.

## Database changes
`migrations/013_reset_progress.sql` (also appended to `SETUP.sql`; idempotent):
- `public.reset_my_progress()`: caller-only, security definer, fixed search_path, granted to `authenticated` only. Clears XP, streak, finished lessons, mistake book, story stars, this week's XP events and the progress blob. Keeps gems, hearts, VIP, milestones, achievements, quest claims and ledgers, so a reset cannot be used to farm anything. Writes an audit-log row.
- `complete_lesson`: first-completion gems keyed by lesson (`lesson_first`); reports the gems really paid. Based on the hardened 008 version (a first draft copied the older one; the test suite caught it before delivery).
Rollback: `drop function public.reset_my_progress();` and re-run the previous `complete_lesson` from SETUP.sql.

## Security review
Checked: RLS enabled on every public table, no write policy that lets a learner change money/VIP/role/attempt data, all SECURITY DEFINER functions have a fixed search_path, anon cannot execute privileged functions, storage bucket mime allowlist (no SVG), leaderboard is server-derived (xp_events), VIP/gems/hearts only change through server functions, front-end template scan for unescaped user data (one admin-controlled field fixed), no `eval`/`document.write`. Payments: signature (HMAC-SHA256, constant-time, 5-minute replay window), amount/currency cross-check, idempotency on (provider, ref), refunds, failed-then-retried invoices, checkout bound to the verified user, Stripe price cross-checked with the database, redirect only to checkout.stripe.com, suspended users blocked, functions answer 503 when secrets are absent.

## Remaining known issues / not done
1. Stripe and the Edge Functions are NOT verified against real Stripe or a deployed Supabase. Needs: Stripe account, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `SITE_URL`, a `vip_plans` row with `price_cents` + `provider_price`, deploy `stripe-webhook` with `--no-verify-jwt`, then set `ONLINE_PAYMENTS: true` in config.js and do a Stripe test-mode purchase.
2. `supabase-js` is loaded from jsDelivr (version pinned) without a Subresource Integrity hash: no network here to compute it. Self-host it or add the hash.
3. No rate limit on `create-checkout` beyond Stripe/auth; `settings` rows are world-readable by design (never store secrets there); `ALLOWED_ORIGIN` defaults to `*` if unset: set it.
4. Admin dashboard still has a legacy path that loads all profiles/progress (now paginated, bounded and error-safe, but not server-side aggregated).
5. AI coach quality, TTS and real Supabase behaviour were tested only against mock providers/stand-ins. Not changed beyond what its existing tests cover; no new coach features were added this session.
6. Content: unchanged. English A1 is the only full course; 6 languages are drafts awaiting native review; 7 are samples; A2 to C2 do not exist (COURSE_COMPLETENESS.md was not regenerated; its numbers were not re-derived this session). No content was invented.
7. UI/UX redesign, performance work (bundle is ~561 KB unminified) and offline-storage tuning were not done: prioritised correctness, security and data integrity.

## Production readiness
Not yet. Core economy, RLS and sync are well tested; the payment path and live-service integrations are unverified, and the items above need an owner. Suitable for a closed beta with manual VIP payments (the existing flow) today.
