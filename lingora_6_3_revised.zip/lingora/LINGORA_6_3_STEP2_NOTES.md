# Lingora 6.3 — Step 2 changes

## Included changes

- Removed the learner-facing Stories and AI Coach items from the bottom navigation.
- Old `stories` and `ai` routes now redirect to Learn.
- Removed the standalone AI Coach learner page module; shared AI backend code and admin AI tools were left intact.
- Stories now appear inside the matching lesson intro, not as a separate learner page.
- A story must be explicitly linked to a lesson in the Stories admin panel.
- A linked story stays locked until the learner has met every vocabulary item listed for that story. Only learned story vocabulary is highlighted and listed.
- Flashcards continue to use the learner's met vocabulary and due SRS schedule; the arbitrary first-12-word fallback is not present.
- Added migration `migrations/016_stories_lesson_link.sql` to add the optional `lesson_id` column without deleting existing story data.

## Required Supabase step

Run `migrations/016_stories_lesson_link.sql` in the Supabase SQL Editor. The original stories migration `011_stories_placement.sql` must already have been applied. This migration is additive and safe to run more than once.

Then open Admin → Stories, edit each existing story, choose its lesson, and save it. Make sure the story's vocabulary list contains only words taught in that lesson or earlier lessons. Publish only after selecting a lesson.

## Checks performed

- `node build.mjs` — passed.
- `node build.mjs --check` — passed.
- `node --check site/app.js` — passed.
- `node tests/static/actions.mjs` — passed (194 distinct actions, all have handlers).
- Browser/UI tests could not run because Playwright is not installed in this environment.
- AI and Stripe integration tests could not run because the local Supabase test service at `127.0.0.1:54321` was not running.
