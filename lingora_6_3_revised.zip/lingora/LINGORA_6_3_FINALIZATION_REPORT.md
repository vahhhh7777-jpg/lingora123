# Lingora 6.3 — Finalization build

This package is a finalization pass on the supplied **Lingora 6.3 — Step 2** source. It keeps the existing app architecture and builds on features already present instead of replacing working systems.

## Changes made in this pass

### Lesson-linked stories
- Fixed cloud-story normalization so `stories.lesson_id` is retained as `lessonId`. Without this, the lesson page could not match a published database story to its lesson.
- Stories now become readable only after the learner has met every target vocabulary item in that story.
- Added seven built-in A1 stories, each linked to an actual seed-course lesson and using that lesson’s target vocabulary.
- The story card shows learned vocabulary count and saved quiz stars.
- Locked stories are visibly disabled and explain how many more words are needed.
- The story view and quiz start both enforce the same unlock rule, so bypassing the card does not bypass the rule.
- Unknown story vocabulary is not automatically marked as learned or inserted into the learner's SRS data.
- Story authoring now requires at least one vocabulary item.
- Lessons with an attached story now show the intro panel even when the lesson has no other intro text; lessons without stories do not show an empty story panel.
- Cloud stories are loaded while the learner is in Learn, and cloud stories take priority over a built-in story assigned to the same lesson.
- Added Armenian and English labels that were previously missing.
- Added responsive styles for lesson story cards and their locked/completed states.

### Existing systems retained
- Learn already has a lesson path and lesson intro content.
- Flashcards already draw from words the learner has met and the due SRS schedule; the arbitrary first-12-word fallback remains absent.
- Daily flashcard goals and example sentences remain intact.
- Listening and speaking practice already use encountered vocabulary/sentences and the normal lesson runner.
- The report already includes average accuracy, active days, streak, unit progress, and weak words.
- Learner-facing AI Coach navigation/page removal from Step 2 is retained. Shared voice/TTS and backend code are not removed.
- Existing Supabase progress and story quiz progress are preserved.

## Files changed
- `src/js/31-lesson-runner.js`
- `src/js/37-views.js`
- `src/js/41-actions.js`
- `src/js/38-stories-english-course.js`
- `src/js/42-stories-admin.js`
- `src/js/35-events.js`
- `site/styles.css`
- `site/index.html` (asset cache-busting)
- `index.html` (root redirect to the actual site entry point)
- `site/app.js` (rebuilt from source)
- `tests/static/stories.mjs` (new static regression test)
- `package.json` (static test script now runs both static test files)

## Supabase action still required
Run `migrations/016_stories_lesson_link.sql` in the Supabase SQL Editor if it has not already been applied. Then open **Admin → Stories**, edit each story, assign its lesson, ensure its vocabulary list contains words taught in that lesson or earlier, and publish it. Existing story rows are not deleted by this migration.

## Checks
- `node build.mjs --check` — PASS
- `node --check site/app.js` — PASS
- `npm run test:static` — PASS (action-handler guard and lesson-story regression checks)
- `npm run test:ui` — NOT RUN successfully: Playwright is not installed in this build environment.
- `npm run test:ai` — BLOCKED: local Supabase test endpoint `127.0.0.1:54321` is not running.
- `npm run test:stripe` — BLOCKED: local Supabase test endpoint `127.0.0.1:54321` is not running.

## Local opening
- Open the project root `index.html`; it redirects to `site/index.html`.
- The site entry point references versioned `app.js` and `styles.css` URLs to avoid stale browser cache.

## Release status
This is a source/build package with passing syntax and static checks. It is **not certified as production-ready** until the migration is applied to the intended Supabase project and browser/UI plus cloud integration tests pass in an environment with Playwright and Supabase services available.
