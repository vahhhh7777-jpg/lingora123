# FINALIZATION_STATUS: Lingora 4.0 technical foundation

Date: 2026-11-14. Scope of this round: AI coach, Supabase/SQL audit, integration testing. **No lessons were generated.**

## What "tested" means here (read this first)
- **Tested for real:** PostgreSQL 16 running SETUP.sql and the migrations; the real browser app (`site/app.js`, headless Chromium) driven through the UI; the real `ai-coach` handler code.
- **Stand-ins (not Supabase):** there are no Supabase credentials, no Supabase CLI/Deno and no outbound access to the CDN or a model provider in this environment. So the tests use
  1. a local server (`tests/bridge/server.mjs`) that speaks the Supabase HTTP protocol subset the app uses (auth, REST, RPC, functions) on top of the real PostgreSQL, running every query under the caller's role so RLS and GRANTs are enforced by PostgreSQL itself;
  2. a small stand-in for `@supabase/supabase-js` in the browser (`tests/bridge/supabase-standin.js`);
  3. a **rule-based mock** of the Anthropic API (not a language model).
- **NOT tested:** a real Supabase project (real GoTrue e-mail confirmation, real PostgREST, real supabase-js, Storage, deployed Edge runtime on Deno), a real model's answer quality, real e-mail, payments, TTS, real phones. **Do not read this report as "integration with Supabase is verified".** The same checks can be run against your project with `tests/live/smoke.mjs` (see Blockers).

## Completed
1. **AI coach implemented** (Edge Function `ai-coach`, tutor mode: multilingual (14 languages), CEFR A1-C2, corrections of grammar / vocabulary / spelling / word order / register with explanations in Armenian or English, conversation history, role-play scenarios, secure server-side key, error handling) and wired into the app with a real conversation UI. Details in `AI_COACH_SETUP.md`.
2. **Why it was missing:** the 4.0 ZIP never contained `supabase/functions/ai-coach` or `_shared/coach.js` (only `tts`), although the README and the SQL/client code expect them. Not recoverable from the ZIP, so re-implemented against the existing database contract (`ai_reserve`, `ai_record`, `coach_context`, `my_ai_usage`) and the existing client error codes.
3. **Supabase audit:** SETUP.sql and migration 011 run cleanly on a fresh PostgreSQL 16 and again on top of themselves (idempotent); all 40 public tables have RLS enabled; 57 policies; all 2142 questions of the built-in course are accepted by the server-side validator after an admin import.
4. **Two real problems found and fixed** (migration 012, also folded into SETUP.sql):
   - `ai_record`, `coach_context` and `apply_payment` decided "is this the server?" with the legacy setting `request.jwt.claim.role`. Reproduced on the original SETUP.sql (connecting as `authenticator` like Supabase does, JSON claims only): `ai_record` fails with `denied`. Fixed with `auth.role()` (accepts both forms). If your project's PostgREST still sets the legacy setting nothing changes for you; on a current one this fix is required for AI cost accounting, the coach context and verified-payment application.
   - A failed model call used up the learner's daily call. New `ai_release()` (service role only) gives it back.
5. App fixes: the old one-shot "ask" box became a real chat; 404 from a missing function is shown as "not configured"; network failure shows "no connection"; sign-out wipes the stored conversation; service worker cache bumped to `ee-v20`.

## Files changed / added
- New: `supabase/functions/ai-coach/index.ts`, `supabase/functions/_shared/coach.js`, `migrations/012_ai_coach_release.sql`, `AI_COACH_SETUP.md`, `tests/` (sql, ai, bridge, live, e2e).
- Changed: `SETUP.sql` (service-role check via `auth.role()` in 3 functions; `ai_release` appended), `src/js/33-part-4-...js` (tutor chat, error map), `src/js/12-backends.js` (`askCoach` error mapping), `src/js/34-auth-actions.js` (sign-out wipe), `src/js/40-ai-role-play-...js` (scenario sent as a structured field instead of prompt wrapping), `site/styles.css`, `site/sw.js`, `site/app.js` (rebuilt; `node build.mjs --check` OK).

## Functions implemented
- Edge Function `ai-coach` (modes `tutor`, `plan`, `explain`, `exercises`, legacy `chat`). Flow: validate -> verify caller with the auth server -> check configuration (before counting a call) -> `ai_reserve` (daily limit, monthly budget, switch, rate limit) -> `coach_context` -> model call (25 s timeout) -> validate model output -> `ai_record` (tokens, cost) -> answer. On failure: `ai_release`.
- SQL: `ai_release(uuid)`; patched `ai_record`, `coach_context`, `apply_payment`.

## Database changes
- Migration 012 only: one new function + three function bodies patched in place. No table, column or row is created, altered or deleted. Safe to run on a live project; safe to run twice (tested on a database built from the original SETUP.sql, run twice). Existing user data is never reset.

## Actual test results (all run in this session)
| Suite | Command | Result |
|---|---|---|
| SQL on real PostgreSQL 16 | `tests/sql/run.sh` | **67 / 67 checks passed** (SETUP.sql twice, 011, 012; sign-up trigger, progress RLS, lesson start/answer/complete, XP + events + completions persisted, anti-cheat `too_fast`, repeat completion gives no second XP, admin RPCs denied to learners, privilege-escalation attempts blocked, audit log, VIP grant, AI quota/limit/budget/switch, privileges of the service-role functions as `authenticator`) |
| AI coach handler through HTTP | `node --test tests/ai/coach.test.mjs` | **26 / 26 passed** (mock provider). Includes all 14 languages x CEFR levels reaching the prompt, history order, injection attempts, invented corrections dropped, refunds on provider error / timeout / bad output, missing key not charged, limit, budget, disabled, suspended, oversize, CORS. A mutation check (refund disabled) made the refund tests fail, so they do test something. |
| Protocol smoke test | `node tests/live/smoke.mjs` against the stand-in | **24 passed, 0 failed, 0 blocked**: register, login, wrong password, profile, start/answer/complete a lesson, XP, second login sees XP, progress row, RLS, AI coach, anonymous refused, bad request, admin denied for learner, learner cannot self-promote, admin can list users and read stats, account cleanup |
| Browser end-to-end (Chromium, 390 px, 1200 px, 320 px) | `tests/e2e/run.sh` | **43 / 43 passed**: UI registration, login (also from a fresh browser), wrong password, admin tab hidden for learners and shown for the promoted admin, admin import of the built-in course (14 courses, 63 units, 182 lessons, 2142 questions), a real lesson played to the end (server judged answers, XP 20 saved, completion saved), page refresh keeps session and progress, AI chat with correction + explanation, history sent (3 messages), level B1 and language reach the model, conversation and level survive refresh, errors (key missing, function not deployed, provider failure, offline, daily limit), no secret in the page, no horizontal scroll at 320 px, sign-out wipes the conversation, no JavaScript errors |
| Build | `node build.mjs --check` | OK |

Notes on the browser run: the server refuses lessons finished faster than 1.5 s per exercise, so the test waits 22 s before playing (a human pace); the admin account was promoted with a SQL statement (the documented first-admin step), not through the UI.

## Remaining blockers / not verified
1. **Real Supabase run.** Needs from you: project URL, anon key, the function deployed (`supabase functions deploy ai-coach`), secret `ANTHROPIC_API_KEY`, at least one published lesson (import the built-in course in Admin), e-mail confirmation off for the test run (or a confirmed test learner via `SMOKE_EMAIL`/`SMOKE_PASSWORD`), an admin account (`ADMIN_EMAIL`/`ADMIN_PASSWORD`). Then `SUPABASE_URL=... SUPABASE_ANON_KEY=... EXPECT_AI=1 node tests/live/smoke.mjs`. Until then these are **unverified**: real e-mail confirmation flow, password reset, real supabase-js behaviour, Storage uploads, the Deno runtime of the function, a real model's correction quality (the tutor prompt is untested against a real model; expect to tune wording after the first real conversations), the default model name `claude-haiku-4-5` (override with `AI_MODEL`).
2. If your project already has `ai_record` etc. from the original SETUP.sql, run migration 012 (otherwise cost accounting may fail with `denied` on current PostgREST).
3. Known, not changed: in the dark theme the shared `.chip` style was light-on-light (scenario chips); the new chat chips are fixed, the rest of the app was not audited for this.
4. Tutor chat history is kept only in the browser tab (`sessionStorage`); there is no cross-device conversation history by design (privacy, free-plan database size).
5. Still open from before and untouched: A2-C2 and the other language content (`COURSE_COMPLETENESS.md`), neural TTS deployment, native-speaker review.

## Next
1. Provide Supabase credentials or run `tests/live/smoke.mjs` yourself, then fix whatever it reports.
2. After that, the curriculum.

## Round 4.0-final (quick pass, 2026-11-14)
- Re-ran everything: build OK, `--check` OK, SQL 67/67, AI handler 26/26, browser e2e 43/43 on most runs.
- Found one flaky e2e failure (~1 run in 3: 36/43, lesson completion not stored). Cause: the test solver could not map the "image" exercise (shown as emoji + Armenian options while the stored answer is English), picked a wrong option, ran out of hearts. The app behaved correctly. Solver patched in tests/e2e/e2e.mjs (maps via the intro question); the patched version was NOT re-run repeatedly because this pass was stopped early.
- No application source changes were made in this pass. Content (A2–C2, other languages), neural TTS deployment and a real Supabase run remain unverified/open as listed above.

## Round 4.0-final-2 (quick pass, 2026-11-14)
- Fixed B-001 (dead admin "copy media URL" button). Build and `--check` OK. Test suites could not run here (no PostgreSQL/Chromium). See BUG_TRACKER.md.
- Exact next steps: (1) run tests/sql, tests/ai, tests/e2e on a machine with PostgreSQL + Chromium; (2) review swallowed errors in 13-cache-offline-and-sync.js:41 and 27-admin...:365; (3) dark-theme `.chip` audit; (4) real Supabase smoke run.

## Round 3 checkpoint (INTERMEDIATE, 2026-11-14)
- Build, `--check`, `node --check site/app.js`: OK at packaging time.
- `tests/ui/sync.mjs` 21/21 (stub, before last change; not re-run). `tests/ui/contrast.mjs` 0 failures on 32 screens (admin/AI chat/modals uncovered). `tests/ui/mediacopy.mjs` NOT RUN (Chromium crash on Admin, B-004).
- NOT RUN: tests/sql, tests/ai, tests/e2e, tests/live (no PostgreSQL here). No real Supabase, AI Coach or TTS verification.
- Not production-ready. Next: B-004, re-run all UI tests, B-006, then real Supabase smoke (`SUPABASE_URL=... SUPABASE_ANON_KEY=... EXPECT_AI=1 node tests/live/smoke.mjs`).
