/* ---------- admin v2: sections, course organizer, lesson wizard, flat lists ---------- */
Object.assign(UI.hy,{
 s_dash:'Ակնարկ',s_courses:'Դասընթացներ',s_lessons:'Դասեր',s_vocab:'Բառեր',s_exercises:'Վարժություններ',s_content:'Լեզուներ',s_categories:'Կատեգորիաներ',s_users:'Օգտատերեր',s_media:'Մեդիա',s_settings:'Կարգավորումներ',
 oSearch:'Որոնել…',oNewCourse:'+ Դասընթաց',oNewUnit:'+ Թեմա',oNewLesson:'+ Դաս',oEmpty:'Դեռ դասընթաց չկա։ Ընտրիր լեզուն և սեղմիր «+ Դասընթաց»։',oLang:'Լեզու',oPrevC:'Դասընթացի նախադիտում',oPub:'Հրապարակել',oUnpub:'Հանել հրապարակումից',
 wTitle:'Նոր դաս',wEdit:'Դասի խմբագրում',w1:'Հիմնական',w2:'Բառեր',w3:'Բացատրություն',w4:'Վարժություններ',w5:'Հրապարակում',wNext:'Հաջորդը',wBack:'Հետ',wExit:'Փակել',
 wLang:'Սովորվող լեզու',wCourse:'Դասընթաց',wUnit:'Թեմա',wExpl:'Բացատրության լեզու',wPick:'— ընտրիր —',wNoUnit:'Այս դասընթացում թեմա չկա։ Նախ ավելացրու թեմա (Դասընթացներ բաժնում)։',wReq:'Լրացրու վերնագիրը, դասընթացը և թեման։',
 wAutoOk:'Պահված է',wAutoErr:'Չպահվեց',wSaving:'Պահվում է…',
 wAddWord:'+ Ավելացնել բառ',wWord:'Բառ',wTr:'Թարգմանություն',wPron:'Արտասանություն',wEx:'Օրինակ',wExTr:'Օրինակի թարգմանություն',wCsv:'Տեղադրիր աղյուսակից (բառ ⇥ թարգմանություն ⇥ արտասանություն ⇥ օրինակ ⇥ թարգմանություն)։ Բաժանիչ՝ tab, «;» կամ ստորակետ։',wCsvB:'Ներմուծել',wCsvN:'Ավելացվեց {n} բառ։',wMedia:'Նկար / աուդիո',wBlankNote:'Բառը պահվում է, երբ բառն ու թարգմանությունը լրացված են։',wNoWords:'Բառեր դեռ չկան։',
 wGoals:'Դասի նպատակներ (մեկը տողում)',wSummary:'Ամփոփում',wBlocks:'Բացատրության բլոկներ',wAddBlock:'Ավելացնել բլոկ',wPreviewB:'Այսպես կերևա սովորողին',
 bk_text:'Տեքստ',bk_grammar:'Քերականական կանոն',bk_example:'Օրինակ',bk_note:'Նշում',bk_tip:'Կարևոր հուշում',bk_table:'Աղյուսակ',bk_image:'Նկար',bk_audio:'Աուդիո',
 bkTable:'Մեկ տողը՝ մեկ շարք, վանդակները բաժանիր «|»-ով (առաջին տողը՝ վերնագիր)',bkCap:'Ստորագրություն',bkUrl:'Հղում https://… կամ վերբեռնիր',bkTr:'Թարգմանություն',
 wAddEx:'Ընտրիր վարժության տեսակը',wExList:'Դասի վարժությունները',wNoEx:'Վարժություններ դեռ չկան։',
 wSumT:'Դասի ամփոփումը',wWords:'բառ',wExs:'վարժություն',wBlk:'բլոկ',wDraft:'Պահել սևագիր',wPublish:'Հրապարակել',wSched:'Ժամանակացույցով հրապարակումը այս տարբերակում չկա։',wPubOk:'Դասը հրապարակվեց։',wDraftOk:'Դասը պահվեց որպես սևագիր։',
 lAll:'Բոլոր դասերը',lAllC:'Բոլոր դասընթացները',vAdd:'Ավելացնել բառեր դասին',eAdd:'Ավելացնել վարժություն դասին',pickLesson:'Ընտրիր դաս',
 catT:'Կատեգորիաներ',catNone:'Դասընթացներին կատեգորիա դեռ չի տրված։ Կատեգորիան նշվում է դասընթացի խմբագրման ձևում։',catRename:'Վերանվանել',catCount:'դասընթաց',
 mediaT:'Մեդիա գրադարան',mediaNone:'Դեռ ոչ մի նկար կամ աուդիո չի օգտագործվում դասերում։',mediaUp:'Վերբեռնել և պատճենել հղումը',mediaCopy:'Պատճենել հղումը',mediaUsed:'Օգտագործվում է՝',mediaNote:'Ցուցակը ցույց է տալիս դասերում օգտագործվող ֆայլերը։ Ֆայլերի ջնջումը կատարվում է Supabase Storage-ում։',
 setT:'Կարգավորումներ',setMode:'Աշխատանքի ռեժիմ',setCloud:'Supabase (իրական բազա)',setDemo:'Demo (տվյալները միայն այս բրաուզերում)',setCounts:'Բովանդակություն',setReload:'Թարմացնել բովանդակությունը',setAdmins:'Ադմիններ',
 nowSaved:'Պահված է։'
});
Object.assign(UI.en,{
 s_dash:'Overview',s_courses:'Courses',s_lessons:'Lessons',s_vocab:'Vocabulary',s_exercises:'Exercises',s_content:'Languages',s_categories:'Categories',s_users:'Users',s_media:'Media',s_settings:'Settings',
 oSearch:'Search…',oNewCourse:'+ Course',oNewUnit:'+ Unit',oNewLesson:'+ Lesson',oEmpty:'No courses yet. Pick a language and tap “+ Course”.',oLang:'Language',oPrevC:'Preview course',oPub:'Publish',oUnpub:'Unpublish',
 wTitle:'New lesson',wEdit:'Edit lesson',w1:'Basics',w2:'Vocabulary',w3:'Explanation',w4:'Exercises',w5:'Publish',wNext:'Next',wBack:'Back',wExit:'Close',
 wLang:'Language being learned',wCourse:'Course',wUnit:'Unit',wExpl:'Explanation language',wPick:'— choose —',wNoUnit:'This course has no units yet. Add a unit first (in Courses).',wReq:'Fill in the title, course and unit.',
 wAutoOk:'Saved',wAutoErr:'Not saved',wSaving:'Saving…',
 wAddWord:'+ Add word',wWord:'Word',wTr:'Translation',wPron:'Pronunciation',wEx:'Example',wExTr:'Example translation',wCsv:'Paste from a spreadsheet (word ⇥ translation ⇥ pronunciation ⇥ example ⇥ translation). Separator: tab, “;” or comma.',wCsvB:'Import',wCsvN:'Added {n} words.',wMedia:'Image / audio',wBlankNote:'A word is saved once the word and translation are filled in.',wNoWords:'No words yet.',
 wGoals:'Lesson goals (one per line)',wSummary:'Summary',wBlocks:'Explanation blocks',wAddBlock:'Add a block',wPreviewB:'How learners will see it',
 bk_text:'Text',bk_grammar:'Grammar rule',bk_example:'Example',bk_note:'Note',bk_tip:'Important tip',bk_table:'Table',bk_image:'Image',bk_audio:'Audio',
 bkTable:'One row per line, separate cells with “|” (first line is the header)',bkCap:'Caption',bkUrl:'Link https://… or upload',bkTr:'Translation',
 wAddEx:'Choose an exercise type',wExList:'Exercises in this lesson',wNoEx:'No exercises yet.',
 wSumT:'Lesson summary',wWords:'words',wExs:'exercises',wBlk:'blocks',wDraft:'Save as draft',wPublish:'Publish',wSched:'Scheduled publishing is not available in this version.',wPubOk:'Lesson published.',wDraftOk:'Lesson saved as a draft.',
 lAll:'All lessons',lAllC:'All courses',vAdd:'Add words to a lesson',eAdd:'Add an exercise to a lesson',pickLesson:'Choose a lesson',
 catT:'Categories',catNone:'No course has a category yet. Set one in the course edit form.',catRename:'Rename',catCount:'courses',
 mediaT:'Media library',mediaNone:'No images or audio are used in lessons yet.',mediaUp:'Upload and copy the link',mediaCopy:'Copy link',mediaUsed:'Used in:',mediaNote:'This list shows files used in lessons. Deleting files is done in Supabase Storage.',
 setT:'Settings',setMode:'Running mode',setCloud:'Supabase (real database)',setDemo:'Demo (data stays in this browser)',setCounts:'Content',setReload:'Reload content',setAdmins:'Admins',
 nowSaved:'Saved.'
});

const SECS=['dash','courses','lessons','vocab','stories','exercises','content','categories','users','media','settings'];
const WTYPES=['pics','mc','type','fill','order','match','listen','read','tf','image','fix','speak','listen_type','write'];
const BKINDS=['text','grammar','example','note','tip','table','image','audio'];
const PAGE=25;
const ago=()=>new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
const langName=id=>{const l=langOf(id);return l?tx(l.name):(id==='hy'?'Հայերեն':id==='en'?'English':id||'');};
const lessonPath=l=>{const c=rawC(),u=c.units.find(x=>x.id===l.unit_id),co=u&&c.courses.find(x=>x.id===u.course_id);return {u,co};};

/* ----- layout ----- */
function adminShell(body){
  const cur=adm.sub||'dash';
  const AIC={stories:'book',dash:'chart',courses:'cap',lessons:'tasks',vocab:'pencil',exercises:'target',content:'bell',categories:'palette',users:'user',vip:'crown',media:'camera',modules:'zap',audit:'clock',settings:'sliders'};
  const nav=SECS.map(k=>`<button data-a="asub" data-v="${k}" title="${esc(t('s_'+k))}" aria-label="${esc(t('s_'+k))}" ${cur===k?'aria-current="page"':''}>${LI(AIC[k]||'info')}<span>${t('s_'+k)}</span></button>`).join('');
  return `<h1 class="ph">${t('admin')}</h1>${MODE==='demo'?`<div class="banner">${t('demo')}</div>`:''}
  <div class="admwrap"><aside class="admside"><button class="admtoggle" data-a="admmenu" aria-expanded="${!!adm.menu}"><span class="admcur">${LI(AIC[cur]||'info')}${t('s_'+cur)}</span>${IC.chev}</button><nav class="admnav ${adm.menu?'open':''}" aria-label="${esc(t('admin'))}">${nav}</nav></aside>
  <section class="admmain" id="admmain">${body}</section></div>${p3cfHtml()}`;
}
function adminBody(){
  if(adm.edit)return formView();
  if(adm.wiz)return wizView();
  switch(adm.sub||'dash'){
    case 'dash':return p3statsHtml()+dashView();
    case 'users':return p3usersView()||usersView();
    case 'vip':return p3vipView();
    case 'audit':return p3auditView();
    case 'modules':return p3modulesView();
    case 'courses':return organizerView();
    case 'lessons':return lessonsListView();
    case 'vocab':return vocabView();
    case 'stories':return pxAdminStories();
    case 'exercises':return exercisesView();
    case 'categories':return categoriesView();
    case 'media':return mediaView()+p3mediaHtml();
    case 'settings':return settingsView();
    default:return contentView();
  }
}
const pagerHtml=(key,total)=>{
  const pages=Math.ceil(total/PAGE);if(pages<2)return '';
  const p=adm.pg[key]||0;
  return `<div class="acts pager"><button class="btn btn-ghost" data-a="pg" data-k="${key}" data-v="-1" ${p===0?'disabled':''}>${t('prevP')}</button><span class="note">${p+1} / ${pages} · ${total}</span><button class="btn btn-ghost" data-a="pg" data-k="${key}" data-v="1" ${p>=pages-1?'disabled':''}>${t('nextP')}</button></div>`;
};
const pageOf=(key,list)=>{const pages=Math.max(1,Math.ceil(list.length/PAGE));adm.pg[key]=Math.min(adm.pg[key]||0,pages-1);return list.slice(adm.pg[key]*PAGE,adm.pg[key]*PAGE+PAGE);};
const tagSt=s=>`<span class="tag st-${s}">${t('st_'+s)}</span>`;
const lessonStat=l=>l.published===false?'draft':'published';

/* ----- course organizer ----- */
function lessonNode(l,i,arr){
  const qs=qsOf(l.id),words=qs.filter(q=>q.type==='intro').length,ex=qs.length-words,armed=adm.delArm===delKey('lessons',l.id),pub=l.published!==false;
  return `<div class="orow olesson dnd" draggable="true" data-dnd="lessons" data-id="${esc(l.id)}"><div class="o-t"><b>${esc(tx(l.title)||t('l0'))}</b><span class="o-m">${tagSt(lessonStat(l))}<span class="tag rv-${l.review||'draft'}">${t('rv_'+(l.review||'draft'))}</span> ${words} ${t('wWords')} · ${ex} ${t('wExs')}</span></div>
   <div class="o-a"><button class="sbtn" data-a="wopen" data-id="${esc(l.id)}">${t('edit')}</button><button class="sbtn" data-a="eprev" data-id="${esc(l.id)}">${t('preview')}</button><button class="sbtn" data-a="ldup" data-id="${esc(l.id)}">${t('dup')}</button>
   <button class="sbtn" data-a="epub" data-t="lessons" data-id="${esc(l.id)}">${t(pub?'oUnpub':'oPub')}</button>
   <button class="sbtn pom ${armed?'armed':''}" data-a="edel" data-t="lessons" data-id="${esc(l.id)}">${armed?t('delSure'):t('del')}</button></div></div>`;
}
function unitNode(u){
  const c=rawC(),ls=c.lessons.filter(l=>l.unit_id===u.id).sort(byPos),open=adm.open['u:'+u.id],armed=adm.delArm===delKey('units',u.id),pubn=ls.filter(l=>l.published!==false).length;
  return `<div class="onode ounit"><div class="orow dnd" draggable="true" data-dnd="units" data-id="${esc(u.id)}"><button class="chev ${open?'on':''}" data-a="otoggle" data-k="u:${esc(u.id)}" aria-expanded="${!!open}" aria-label="${esc(tx(u.title))}">${IC.chev}</button>
   <div class="o-t"><b>${esc(tx(u.title))}${u.vip?vipBadge():''}</b><span class="o-m">${tagSt(u.published===false?'draft':'published')} ${pubn}/${ls.length} ${t('x_lessons')}</span></div>
   <div class="o-a"><button class="sbtn" data-a="wnew" data-unit="${esc(u.id)}">${t('oNewLesson')}</button><button class="sbtn" data-a="eedit" data-t="units" data-id="${esc(u.id)}">${t('edit')}</button><button class="sbtn" data-a="udup" data-id="${esc(u.id)}">${t('dup')}</button>
   <button class="sbtn" data-a="epub" data-t="units" data-id="${esc(u.id)}">${t(u.published===false?'oPub':'oUnpub')}</button><button class="sbtn pom ${armed?'armed':''}" data-a="edel" data-t="units" data-id="${esc(u.id)}">${armed?t('delSure'):t('del')}</button></div></div>
   ${open?`<div class="okids">${ls.length?ls.map(lessonNode).join(''):`<p class="note">${t('nothing')}</p>`}</div>`:''}</div>`;
}
function courseNode(co){
  const c=rawC(),h=courseHealth(c,co.id),st=courseStatus(c,co),us=c.units.filter(u=>u.course_id===co.id).sort(byPos),open=adm.open['c:'+co.id],armed=adm.delArm===delKey('courses',co.id);
  const pct=h.lessons?Math.round(h.published/h.lessons*100):0;
  return `<div class="onode ocourse"><div class="orow dnd" draggable="true" data-dnd="courses" data-id="${esc(co.id)}"><button class="chev ${open?'on':''}" data-a="otoggle" data-k="c:${esc(co.id)}" aria-expanded="${!!open}" aria-label="${esc(tx(co.title))}">${IC.chev}</button>
   <div class="o-t"><b>${esc(tx(co.title))}${co.vip?vipBadge():''}</b><span class="o-m">${tagSt(st)}<span class="tag">${esc(langName(co.language_id))} ← ${esc(langName(co.source))}</span><span class="tag">${esc(co.level||'A1')}</span> ${us.length} ${t('x_units')} · ${h.published}/${h.lessons} ${t('x_lessons')} · ${pct}%</span><span class="bar mini"><i style="width:${pct}%"></i></span></div>
   <div class="o-a"><button class="sbtn" data-a="onewunit" data-course="${esc(co.id)}">${t('oNewUnit')}</button><button class="sbtn" data-a="eedit" data-t="courses" data-id="${esc(co.id)}">${t('edit')}</button><button class="sbtn" data-a="cprev" data-id="${esc(co.id)}">${t('preview')}</button><button class="sbtn" data-a="cdup" data-id="${esc(co.id)}">${t('dup')}</button>
   <button class="sbtn" data-a="epub" data-t="courses" data-id="${esc(co.id)}">${t(co.published===false?'oPub':'oUnpub')}</button><button class="sbtn" data-a="carch" data-id="${esc(co.id)}">${t(co.archived?'restoreB':'archiveB')}</button>
   <button class="sbtn pom ${armed?'armed':''}" data-a="edel" data-t="courses" data-id="${esc(co.id)}">${armed?t('delSure'):t('del')}</button></div></div>
   ${open?`<div class="okids">${us.length?us.map(unitNode).join(''):`<p class="note">${t('nothing')}</p>`}</div>`:''}</div>`;
}
function organizerList(){
  const q=norm(adm.oq||''),c=rawC();
  const cos=c.courses.slice().sort((a,b)=>byPos(a,b)).filter(x=>!q||norm(tx(x.title,'hy')+' '+tx(x.title,'en')).includes(q));
  return cos.length?cos.map(courseNode).join(''):`<div class="empty">${t('oEmpty')}</div>`;
}
function organizerView(){
  const c=rawC();
  if(!A.dbCount)return contentView();
  const langs=c.languages.slice().sort(byPos);
  return `<div class="acts tb"><input id="oq" class="search" type="search" value="${esc(adm.oq||'')}" placeholder="${esc(t('oSearch'))}" aria-label="${esc(t('oSearch'))}">
   <select id="nclang" class="search s2" aria-label="${esc(t('oLang'))}">${langs.map(l=>`<option value="${esc(l.id)}" ${adm.nclang===l.id?'selected':''}>${esc(tx(l.name))}</option>`).join('')}</select>
   <button class="btn btn-orange" data-a="onewcourse">${t('oNewCourse')}</button></div><div id="olist">${organizerList()}</div>`;
}

/* ----- flat lists: lessons, vocabulary, exercises ----- */
function lessonsListView(){
  if(!A.dbCount)return contentView();
  const c=rawC(),q=norm(adm.lq||''),cf=adm.lcourse||'';
  let list=c.lessons.map(l=>({l,p:lessonPath(l)})).filter(x=>x.p.co&&(!cf||x.p.co.id===cf)&&(!q||norm(tx(x.l.title,'hy')+' '+tx(x.l.title,'en')).includes(q)));
  const rows=pageOf('lessons',list).map(x=>{const l=x.l,qs=qsOf(l.id),armed=adm.delArm===delKey('lessons',l.id);
    return `<div class="urow"><div class="acc"><b>${esc(tx(l.title)||t('l0'))} ${tagSt(lessonStat(l))}</b><span>${esc(tx(x.p.co.title))} › ${esc(x.p.u?tx(x.p.u.title):'')} · ${qs.length} ${t('x_questions')}</span></div>
     <div class="acts"><button class="sbtn" data-a="wopen" data-id="${esc(l.id)}">${t('edit')}</button><button class="sbtn" data-a="eprev" data-id="${esc(l.id)}">${t('preview')}</button><button class="sbtn" data-a="ldup" data-id="${esc(l.id)}">${t('dup')}</button>
     <button class="sbtn" data-a="epub" data-t="lessons" data-id="${esc(l.id)}">${t(l.published===false?'oPub':'oUnpub')}</button><button class="sbtn pom ${armed?'armed':''}" data-a="edel" data-t="lessons" data-id="${esc(l.id)}">${armed?t('delSure'):t('del')}</button></div></div>`;}).join('');
  return `<div class="acts tb"><input id="lq" class="search" type="search" value="${esc(adm.lq||'')}" placeholder="${esc(t('oSearch'))}" aria-label="${esc(t('oSearch'))}">
   <select id="lcourse" class="search s2" aria-label="${esc(t('wCourse'))}"><option value="">${t('lAllC')}</option>${c.courses.map(co=>`<option value="${esc(co.id)}" ${cf===co.id?'selected':''}>${esc(tx(co.title))}</option>`).join('')}</select>
   <button class="btn btn-orange" data-a="wnew">${t('oNewLesson')}</button></div>${rows||`<div class="empty">${t('nothing')}</div>`}${pagerHtml('lessons',list.length)}`;
}
function lessonPicker(id){
  const c=rawC();
  return `<select id="${id}" class="search s2" aria-label="${esc(t('pickLesson'))}">${c.lessons.map(l=>{const p=lessonPath(l);return p.co?`<option value="${esc(l.id)}">${esc(tx(p.co.title))} › ${esc(tx(l.title)||t('l0'))}</option>`:'';}).join('')}</select>`;
}
function qFlatRows(list,key){
  return pageOf(key,list).map(q=>{const l=rawC().lessons.find(x=>x.id===q.lesson_id),armed=adm.delArm===delKey('questions',q.id);
    return `<div class="urow"><div class="acc"><b><span class="tag">${esc(t('qt_'+q.type))}</span> ${esc(qSummary(q))}</b><span>${esc(l?tx(l.title):'')}</span></div>
     <div class="acts"><button class="sbtn" data-a="qedit2" data-id="${esc(q.id)}">${t('edit')}</button><button class="sbtn pom ${armed?'armed':''}" data-a="edel" data-t="questions" data-id="${esc(q.id)}">${armed?t('delSure'):t('del')}</button></div></div>`;}).join('');
}
function vocabView(){
  if(!A.dbCount)return contentView();
  const q=norm(adm.vq||''),list=rawC().questions.filter(x=>x.type==='intro'&&(!q||norm((x.data.en||'')+' '+(x.data.hy||'')).includes(q)));
  return `<div class="acts tb"><input id="vq" class="search" type="search" value="${esc(adm.vq||'')}" placeholder="${esc(t('oSearch'))}" aria-label="${esc(t('oSearch'))}">${lessonPicker('vlesson')}<button class="btn btn-orange" data-a="wvocab">${t('vAdd')}</button></div>
   ${qFlatRows(list,'vocab')||`<div class="empty">${t('nothing')}</div>`}${pagerHtml('vocab',list.length)}`;
}
function exercisesView(){
  if(!A.dbCount)return contentView();
  const q=norm(adm.eq||''),tf=adm.etype||'';
  const list=rawC().questions.filter(x=>x.type!=='intro'&&(!tf||x.type===tf)&&(!q||norm(qSummary(x)).includes(q)));
  return `<div class="acts tb"><input id="eq" class="search" type="search" value="${esc(adm.eq||'')}" placeholder="${esc(t('oSearch'))}" aria-label="${esc(t('oSearch'))}">
   <select id="etype" class="search s2" aria-label="${esc(t('wAddEx'))}"><option value="">—</option>${WTYPES.map(x=>`<option value="${x}" ${tf===x?'selected':''}>${esc(t('qt_'+x))}</option>`).join('')}</select>${lessonPicker('elesson')}<button class="btn btn-orange" data-a="wex">${t('eAdd')}</button></div>
   ${qFlatRows(list,'ex')||`<div class="empty">${t('nothing')}</div>`}${pagerHtml('ex',list.length)}`;
}

/* ----- categories, media, settings ----- */
function categoriesView(){
  const c=rawC(),m={};
  c.courses.forEach(co=>{const k=(co.category||'').trim();if(k)m[k]=(m[k]||0)+1;});
  const ks=Object.keys(m).sort();
  return `<section class="card"><h2>${t('catT')}</h2>${ks.length?ks.map((k,i)=>`<div class="catrow"><input class="search" data-cat="${esc(k)}" value="${esc(k)}" aria-label="${esc(k)}" maxlength="40"><span class="note">${m[k]} ${t('catCount')}</span><button class="sbtn" data-a="catren" data-k="${esc(k)}">${t('catRename')}</button></div>`).join(''):`<p class="note">${t('catNone')}</p>`}</section>`;
}
function mediaItems(){
  const c=rawC(),out=[];
  const add=(u,kind,where)=>{if(u&&safeUrl(u,kind))out.push({u,kind,where});};
  c.courses.forEach(x=>add(x.cover,'image',tx(x.title)));
  c.lessons.forEach(x=>{add(x.cover,'image',tx(x.title));(x.blocks||[]).forEach(b=>{if(b.k==='image')add(b.url,'image',tx(x.title));if(b.k==='audio')add(b.url,'audio',tx(x.title));});});
  c.questions.forEach(q=>{const l=c.lessons.find(x=>x.id===q.lesson_id);add(q.data&&q.data.image,'image',l?tx(l.title):'');add(q.data&&q.data.audio,'audio',l?tx(l.title):'');});
  return out;
}
function mediaView(){
  const items=mediaItems(),list=pageOf('media',items);
  return `<section class="card"><h2>${t('mediaT')}</h2><div class="acts"><label class="btn btn-orange upl">${t('mediaUp')}<input type="file" accept="image/*,audio/*" id="mup" hidden></label></div>${adm.mediaUrl?`<div class="fld"><input class="search" readonly value="${esc(adm.mediaUrl.length>300?adm.mediaUrl.slice(0,60)+'…':adm.mediaUrl)}" aria-label="URL"><button class="sbtn" data-a="mcopy">${t('mediaCopy')}</button></div>`:''}<p class="note">${t('mediaNote')}</p></section>
   ${list.length?`<div class="mgrid">${list.map(m=>`<div class="mitem">${m.kind==='image'?`<img src="${esc(m.u)}" loading="lazy" alt="">`:`<audio controls preload="none" src="${esc(m.u)}"></audio>`}<small>${t('mediaUsed')} ${esc(m.where)}</small></div>`).join('')}</div>${pagerHtml('media',items.length)}`:`<div class="empty">${t('mediaNone')}</div>`}`;
}
function settingsView(){
  const c=rawC(),admins=(adm.users||[]).filter(u=>u.is_admin);
  return `<section class="card"><h2>${t('setT')}</h2><p><b>${t('setMode')}:</b> ${t(MODE==='cloud'?'setCloud':'setDemo')}</p>
   <p><b>${t('setCounts')}:</b> ${c.languages.length} ${t('x_languages')} · ${c.courses.length} ${t('x_courses')} · ${c.units.length} ${t('x_units')} · ${c.lessons.length} ${t('x_lessons')} · ${c.questions.length} ${t('x_questions')}</p>
   <div class="acts"><button class="btn btn-ghost" data-a="reload">${t('setReload')}</button><button class="btn btn-ghost" data-a="cexport">${t('expB')}</button><label class="btn btn-ghost upl">${t('impB')}<input type="file" accept="application/json,.json" id="cimport" hidden></label></div><p class="note">${t('impNote')}</p>
   ${admins.length?`<h2 style="margin-top:10px">${t('setAdmins')}</h2>${admins.map(u=>`<div class="note">${esc(u.name||u.email)} · ${esc(u.email)}</div>`).join('')}`:''}</section>`;
}

/* ----- lesson wizard ----- */
function wizInit(lessonId,unitId,step){
  const c=rawC();let l=lessonId&&c.lessons.find(x=>x.id===lessonId),u=unitId&&c.units.find(x=>x.id===unitId);
  if(l)u=c.units.find(x=>x.id===l.unit_id);
  const co=u&&c.courses.find(x=>x.id===u.course_id);
  adm.wiz={id:l?l.id:'',step:step||1,err:'',saved:'',saving:false,blanks:1,
    d:{lang:co?co.language_id:'',course:co?co.id:'',unit:u?u.id:'',title:l?Object.assign({},l.title):{hy:'',en:''},descr:l?Object.assign({},l.descr||{}):{hy:'',en:''},difficulty:l?l.difficulty||'easy':'easy',minutes:l?l.minutes||5:5}};
  adm.edit=null;adm.nav.lesson=l?l.id:'';adm.nav.unit=u?u.id:'';adm.nav.course=co?co.id:'';
}
const wizLesson=()=>adm.wiz&&adm.wiz.id?rawC().lessons.find(x=>x.id===adm.wiz.id):null;
/* Copies a media URL. Uses the Clipboard API, then execCommand; if both are refused (permissions, insecure origin, some mobile browsers)
   the URL field is selected and the user is told to copy it by hand. Never reports success unless the copy happened. */
async function copyMediaUrl(url,el){
  if(!url){toast(t('mediaCopyNone'),'confused');return true;}
  const ok=await copyText(url);
  if(ok){toast(t('mediaCopied'),'happy');return true;}
  const inp=(el&&el.closest&&el.closest('.fld,.mitem,.card')&&el.closest('.fld,.mitem,.card').querySelector('input[readonly],input[aria-label="URL"]'))||document.querySelector('input[aria-label="URL"]');
  if(inp){try{inp.focus();inp.select();inp.setSelectionRange(0,url.length);}catch(e){}}
  toast(t('mediaCopyFail'),'confused');return true;
}
async function wizSaveBasics(create){
  const w=adm.wiz,d=w.d;
  if(!tx(d.title)||!d.course||!d.unit){w.err=t('wReq');return false;}
  const T=o=>({hy:o.hy||o.en||'',en:o.en||o.hy||''});
  let row=wizLesson();
  if(!row){
    if(!create)return false;
    const pos=Math.max(0,...sib('lessons',{unit:d.unit}).map(x=>x.pos||0))+1;
    row={id:mkId('lesson'),unit_id:d.unit,pos,xp:8,review:'draft',objectives:'',grammar:'',summary:'',cover:'',blocks:[],published:false};
  }
  row=Object.assign({},row,{unit_id:d.unit,title:T(d.title),descr:T(d.descr),difficulty:d.difficulty,minutes:Math.max(1,+d.minutes||5)});
  return await wizPersist('lessons',row,r=>{w.id=r.id;adm.nav.lesson=r.id;});
}
async function wizPersist(table,row,after){
  const w=adm.wiz;w.saving=true;w.err='';wizStatus();
  try{await persist(table,row);if(after)after(row);w.saved=ago();w.saving=false;wizStatus();return true;}
  catch(x){w.saving=false;w.err=t('e_'+mapErr(x));wizStatus();return false;}
}
function wizStatus(){
  const el=document.getElementById('wstat');if(!el||!adm.wiz)return;const w=adm.wiz;
  el.className='wstat '+(w.err?'err':w.saving?'':'ok');el.textContent=w.err?(t('wAutoErr')+': '+w.err):w.saving?t('wSaving'):w.saved?(t('wAutoOk')+' · '+w.saved):'';
}
function wizView(){
  const w=adm.wiz,l=wizLesson(),c=rawC(),step=w.step,steps=[1,2,3,4,5];
  const head=`<div class="wiz-h"><div class="wiz-t"><b>${esc(l?(tx(l.title)||t('wEdit')):t('wTitle'))}</b><span id="wstat" class="wstat ${w.err?'err':'ok'}" role="status">${w.err?esc(t('wAutoErr')+': '+w.err):w.saved?esc(t('wAutoOk')+' · '+w.saved):''}</span></div><button class="sbtn" data-a="wexit">${t('wExit')}</button></div>
   <ol class="steps" aria-label="steps">${steps.map(i=>`<li><button data-a="wstep" data-v="${i}" ${i===step?'aria-current="step"':''} class="${i<step?'done':''}" ${(!l&&i>1)?'disabled':''}><i>${i}</i><span>${t('w'+i)}</span></button></li>`).join('')}</ol>`;
  let body='';
  if(step===1)body=wizStep1();else if(step===2)body=wizStep2(l);else if(step===3)body=wizStep3(l);else if(step===4)body=wizStep4(l);else body=wizStep5(l);
  const foot=`<div class="wiz-f"><button class="btn btn-ghost" data-a="wback" ${step===1?'disabled':''}>${t('wBack')}</button>${step<5?`<button class="btn btn-purple" data-a="wnext">${t('wNext')}</button>`:''}</div>`;
  return `<section class="card wiz">${head}${body}${w.err&&step===1?`<div class="msg err">${esc(w.err)}</div>`:''}${foot}</section>`;
}
function wizStep1(){
  const w=adm.wiz,d=w.d,c=rawC();
  const langs=c.languages.slice().sort(byPos),cos=c.courses.filter(x=>!d.lang||x.language_id===d.lang),co=c.courses.find(x=>x.id===d.course),us=c.units.filter(u=>u.course_id===d.course).sort(byPos);
  const opt=(items,cur)=>`<option value="">${t('wPick')}</option>`+items.map(x=>`<option value="${esc(x[0])}" ${cur===x[0]?'selected':''}>${esc(x[1])}</option>`).join('');
  return `<div class="wgrid"><label class="fld">${t('wLang')}<select class="search s2" data-w="lang">${opt(langs.map(l=>[l.id,tx(l.name)]),d.lang)}</select></label>
   <label class="fld">${t('wCourse')}<select class="search s2" data-w="course">${opt(cos.map(x=>[x.id,tx(x.title)]),d.course)}</select></label>
   <label class="fld">${t('wUnit')}<select class="search s2" data-w="unit">${opt(us.map(u=>[u.id,tx(u.title)]),d.unit)}</select></label>
   <div class="fld">${t('wExpl')}<div class="chipro">${co?esc(langName(co.source)):'—'}</div></div></div>
   ${d.course&&!us.length?`<div class="msg err">${t('wNoUnit')}</div>`:''}
   ${['hy','en'].map(l=>`<label class="fld">${t('fTitle')} (${l==='hy'?'Հայ':'EN'})<input data-w="title" data-l="${l}" value="${esc(d.title[l]||'')}" autocomplete="off"></label>`).join('')}
   ${['hy','en'].map(l=>`<label class="fld">${t('fDescr')} (${l==='hy'?'Հայ':'EN'})<input data-w="descr" data-l="${l}" value="${esc(d.descr[l]||'')}" autocomplete="off"></label>`).join('')}
   <div class="wgrid"><label class="fld">${t('fDiff')}<select class="search s2" data-w="difficulty">${DIFFS.map(x=>`<option value="${x}" ${d.difficulty===x?'selected':''}>${t('diff_'+x)}</option>`).join('')}</select></label>
   <label class="fld">${t('fMinutes')}<input data-w="minutes" type="number" min="1" max="120" value="${esc(d.minutes)}"></label></div>`;
}
function wordRow(q,i){
  const d=q.data||{},id=q?q.id:'';
  const f=(k,lab)=>`<input data-wq="${esc(id)}" data-k="${k}" value="${esc(d[k]||'')}" placeholder="${esc(t(lab))}" aria-label="${esc(t(lab))}" autocomplete="off">`;
  return `<div class="wword" data-id="${esc(id)}"><div class="wcells">${f('en','wWord')}${f('hy','wTr')}${f('pron','wPron')}${f('example','wEx')}${f('exampleTr','wExTr')}</div>
   <details class="wmore"><summary>${t('wMedia')}</summary><div class="fld"><input data-wq="${esc(id)}" data-k="image" value="${esc(d.image||'')}" placeholder="${esc(t('fImage'))}" data-f="image"><label class="btn btn-ghost upl">${t('upl')}<input type="file" accept="image/*" data-up="image" hidden></label></div>
   <div class="fld"><input data-wq="${esc(id)}" data-k="audio" value="${esc(d.audio||'')}" placeholder="${esc(t('fAudio'))}" data-f="audio"><label class="btn btn-ghost upl">${t('upl')}<input type="file" accept="audio/*" data-up="audio" hidden></label></div></details>
   <button class="sbtn pom" data-a="wdelq" data-id="${esc(id)}" aria-label="${esc(t('del'))}">✕</button></div>`;
}
function blankRow(j){
  const f=(k,lab)=>`<input data-wb="${j}" data-k="${k}" placeholder="${esc(t(lab))}" aria-label="${esc(t(lab))}" autocomplete="off">`;
  return `<div class="wword blank"><div class="wcells">${f('en','wWord')}${f('hy','wTr')}${f('pron','wPron')}${f('example','wEx')}${f('exampleTr','wExTr')}</div></div>`;
}
function wizStep2(l){
  const w=adm.wiz,words=l?qsOf(l.id).filter(q=>q.type==='intro'):[];
  let h=`<div class="wlist">${words.length?words.map(wordRow).join(''):`<p class="note">${t('wNoWords')}</p>`}`;
  for(let j=0;j<w.blanks;j++)h+=blankRow(j);
  h+=`</div><div class="acts"><button class="btn btn-orange" data-a="waddword">${t('wAddWord')}</button></div><p class="note">${t('wBlankNote')}</p>
   <details class="wmore"><summary>CSV / ${t('wCsvB')}</summary><label class="fld">${t('wCsv')}<textarea id="w-csv" rows="5"></textarea></label><button class="btn btn-purple" data-a="wcsv">${t('wCsvB')}</button></details>`;
  return h;
}
function blocksHtml(blocks){
  return (blocks||[]).map(b=>{
    const v=esc(b.v||'').replace(/\n/g,'<br>');
    switch(b.k){
      case 'text':return `<p class="bk bk-text">${v}</p>`;
      case 'grammar':return `<div class="bk bk-grammar"><b>${t('bk_grammar')}</b><div>${v}</div></div>`;
      case 'example':return `<div class="bk bk-example"><div>${v}</div>${b.tr?`<small>${esc(b.tr)}</small>`:''}</div>`;
      case 'note':return `<div class="bk bk-note"><b>${t('bk_note')}</b> ${v}</div>`;
      case 'tip':return `<div class="bk bk-tip"><b>★ ${t('bk_tip')}</b> ${v}</div>`;
      case 'table':{const rows=String(b.v||'').split('\n').map(r=>r.split('|').map(x=>x.trim())).filter(r=>r.some(Boolean));if(!rows.length)return '';return `<div class="bk-tw"><table class="bk-table"><thead><tr>${rows[0].map(x=>`<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${rows.slice(1).map(r=>`<tr>${r.map(x=>`<td>${esc(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;}
      case 'image':return safeUrl(b.url,'image')?`<figure class="bk"><img class="qimg" src="${esc(b.url)}" loading="lazy" alt="${esc(b.v||'')}">${b.v?`<figcaption>${esc(b.v)}</figcaption>`:''}</figure>`:'';
      case 'audio':return safeUrl(b.url,'audio')?`<div class="bk"><audio controls preload="none" src="${esc(b.url)}"></audio>${b.v?`<small>${esc(b.v)}</small>`:''}</div>`:'';
    }
    return '';
  }).join('');
}
function blockEditor(b,i,n){
  const fld=(k,lab,tag,ph)=>tag==='ta'?`<textarea data-wbk="${i}" data-k="${k}" rows="3" placeholder="${esc(ph||'')}" aria-label="${esc(lab)}">${esc(b[k]||'')}</textarea>`:`<input data-wbk="${i}" data-k="${k}" value="${esc(b[k]||'')}" placeholder="${esc(ph||lab)}" aria-label="${esc(lab)}">`;
  let inner='';
  if(b.k==='image'||b.k==='audio')inner=`<div class="fld"><input data-wbk="${i}" data-k="url" data-f="${b.k}" value="${esc(b.url||'')}" placeholder="${esc(t('bkUrl'))}"><label class="btn btn-ghost upl">${t('upl')}<input type="file" accept="${b.k}/*" data-up="${b.k}" hidden></label></div>${fld('v',t('bkCap'),'in')}`;
  else if(b.k==='table')inner=`<p class="note">${t('bkTable')}</p>${fld('v',t('bk_table'),'ta','Word | Meaning\nHello | Բարև')}`;
  else if(b.k==='example')inner=fld('v',t('bk_example'),'ta')+fld('tr',t('bkTr'),'in');
  else inner=fld('v',t('bk_'+b.k),'ta');
  return `<div class="wblock"><div class="wb-h"><b>${t('bk_'+b.k)}</b><span><button class="sbtn" data-a="wbmove" data-i="${i}" data-d="-1" ${i===0?'disabled':''} aria-label="${t('up')}">↑</button><button class="sbtn" data-a="wbmove" data-i="${i}" data-d="1" ${i===n-1?'disabled':''} aria-label="${t('down')}">↓</button><button class="sbtn pom" data-a="wbdel" data-i="${i}" aria-label="${t('del')}">✕</button></span></div>${inner}</div>`;
}
function wizStep3(l){
  const bl=l.blocks||[];
  return `<label class="fld">${t('wGoals')}<textarea data-wl="objectives" rows="3">${esc(l.objectives||'')}</textarea></label>
   <label class="fld">${t('fGrammar')}<textarea data-wl="grammar" rows="3">${esc(l.grammar||'')}</textarea></label>
   <h3 class="wh">${t('wBlocks')}</h3>${bl.map((b,i)=>blockEditor(b,i,bl.length)).join('')}
   <p class="note">${t('wAddBlock')}</p><div class="bkcards">${BKINDS.map(k=>`<button class="bkcard" data-a="wbadd" data-k="${k}">+ ${t('bk_'+k)}</button>`).join('')}</div>
   <label class="fld">${t('wSummary')}<textarea data-wl="summary" rows="3">${esc(l.summary||'')}</textarea></label>
   ${bl.length?`<h3 class="wh">${t('wPreviewB')}</h3><div class="wprev">${blocksHtml(bl)}</div>`:''}`;
}
function wizStep4(l){
  const ex=qsOf(l.id).filter(q=>q.type!=='intro');
  return `<div class="acts"><button class="btn btn-orange" data-a="wpicsgen">${t('picGen')}</button></div><p class="note">${t('picGenNote')}</p><h3 class="wh">${t('wAddEx')}</h3><div class="excards">${WTYPES.map(k=>`<button class="excard" data-a="wexnew" data-ty="${k}"><b>${t('qt_'+k)}</b><small>${esc(t('qHint_'+k))}</small></button>`).join('')}</div>
   <h3 class="wh">${t('wExList')} · ${ex.length}</h3>${ex.length?ex.map((q,i,arr)=>qRow(q,i,arr)).join(''):`<p class="note">${t('wNoEx')}</p>`}
   ${ex.length?`<div class="acts"><button class="btn btn-ghost" data-a="eprev" data-id="${esc(l.id)}">${t('previewL')}</button></div>`:''}`;
}
function wizStep5(l){
  const qs=qsOf(l.id),words=qs.filter(q=>q.type==='intro').length,ex=qs.length-words,is=lessonIssues(l,qs),errs=is.some(x=>x[0]==='err'),pub=l.published!==false;
  return `<h3 class="wh">${t('wSumT')}</h3><div class="stats"><div class="stat"><b>${words}</b><span>${t('wWords')}</span></div><div class="stat"><b>${ex}</b><span>${t('wExs')}</span></div><div class="stat"><b>${(l.blocks||[]).length}</b><span>${t('wBlk')}</span></div></div>
   <div style="margin-top:12px">${is.length?is.map(x=>`<div class="iss ${x[0]}"><b>${x[0]==='err'?'✕':x[0]==='warn'?'!':'i'}</b><span>${t(x[1])}</span></div>`).join(''):`<div class="iss ok"><b>✓</b><span>${t('iss_ok')}</span></div>`}</div>
   <div class="acts" style="margin-top:12px"><button class="btn btn-ghost" data-a="eprev" data-id="${esc(l.id)}">${t('previewL')}</button><button class="btn btn-ghost" data-a="wdraft">${t('wDraft')}</button><button class="btn btn-orange" data-a="wpub" ${errs?'disabled':''}>${t(pub?'wPublish':'wPublish')}</button></div>
   ${errs?`<p class="note">${t('errPublish')}</p>`:''}<p class="note">${t('wSched')}</p>`;
}

/* ----- wizard + section events ----- */
let wTimer=0;
function wizDebounce(fn){clearTimeout(wTimer);wTimer=setTimeout(fn,600);}
async function act2(a,d,el){
  if(await act3(a,d,el))return true;
  switch(a){
    case 'admmenu':adm.menu=!adm.menu;render();return true;
    case 'otoggle':adm.open[d.k]=!adm.open[d.k];render();return true;
    case 'pg':adm.pg[d.k]=Math.max(0,(adm.pg[d.k]||0)+(+d.v));render();return true;
    case 'onewcourse':{const s=$('nclang');adm.nav.lang=s?s.value:'';if(!adm.nav.lang){return true;}adm.nclang=adm.nav.lang;adm.err='';adm.edit={table:'courses',isNew:true,row:newRow('courses')};render();return true;}
    case 'onewunit':adm.nav.course=d.course;adm.err='';adm.edit={table:'units',isNew:true,row:newRow('units')};adm.open['c:'+d.course]=true;render();return true;
    case 'cprev':{
      const c=rawC(),us=c.units.filter(u=>u.course_id===d.id).sort(byPos);let qs=[];
      us.forEach(u=>c.lessons.filter(l=>l.unit_id===u.id).sort(byPos).forEach(l=>{qs=qs.concat(qsOf(l.id));}));
      startPreview(qs.slice(0,40),null);return true;
    }
    case 'wnew':wizInit('',d.unit||'',1);render();window.scrollTo(0,0);return true;
    case 'wopen':wizInit(d.id,'',1);render();window.scrollTo(0,0);return true;
    case 'wvocab':{const s=$('vlesson');if(s&&s.value){wizInit(s.value,'',2);render();window.scrollTo(0,0);}return true;}
    case 'wex':{const s=$('elesson');if(s&&s.value){wizInit(s.value,'',4);render();window.scrollTo(0,0);}return true;}
    case 'qedit2':{const q=rawC().questions.find(x=>x.id===d.id);if(!q)return true;adm.nav.lesson=q.lesson_id;adm.err='';adm.edit={table:'questions',isNew:false,row:JSON.parse(JSON.stringify(q))};render();return true;}
    case 'wexit':adm.wiz=null;adm.edit=null;adm.nav.lesson='';render();return true;
    case 'wstep':{const w=adm.wiz;if(!w)return true;if(!wizLesson()&&+d.v>1)return true;if(w.step===1){const ok=await wizSaveBasics(false);if(!ok&&w.err){render();return true;}}w.step=+d.v;w.err='';render();return true;}
    case 'wnext':{const w=adm.wiz;if(w.step===1){if(!await wizSaveBasics(true)){render();return true;}}w.step=Math.min(5,w.step+1);w.err='';render();window.scrollTo(0,0);return true;}
    case 'wback':{const w=adm.wiz;w.step=Math.max(1,w.step-1);render();return true;}
    case 'waddword':adm.wiz.blanks++;render();return true;
    case 'wpicsgen':{
      const l=wizLesson();if(!l)return true;
      const words=qsOf(l.id).filter(q=>q.type==='intro'&&q.data&&q.data.en&&((q.data.vis&&q.data.vis[0]==='e'&&q.data.vis[1])||safeUrl(q.data.image,'image')));
      if(words.length<3){toast(t('picGenNeed'));return true;}
      const card=q=>{const d=q.data,r={w:d.en,l:d.hy};if(d.vis&&d.vis[0]==='e'&&d.vis[1])r.e=d.vis[1];if(safeUrl(d.image,'image'))r.img=d.image;return r;};
      const pos0=Math.max(0,...qsOf(l.id).map(q=>q.pos||0));
      const qs=words.map((q,i)=>{
        const others=[];for(let k=1;k<words.length&&others.length<3;k++)others.push(words[(i+k)%words.length]);
        const items=[card(q)].concat(others.map(card));
        return {id:'pa-'+q.id,lesson_id:l.id,type:'pics',data:{items,answer:q.data.en},pos:pos0+i+1};
      });
      try{await B.upsertMany('questions',qs);qs.forEach(q=>localPut('questions',q));reapply();adm.wiz.saved=ago();toast(t('picGenOk').replace('{n}',qs.length));}catch(e){adm.wiz.err=t('e_'+mapErr(e));}
      render();return true;
    }
    case 'wdelq':{try{await B.remove('questions',d.id);rmRow(rawC(),'questions',d.id);reapply();}catch(e){toast(t('e_'+mapErr(e)));}render();return true;}
    case 'wcsv':{
      const l=wizLesson(),ta=$('w-csv');if(!l||!ta)return true;
      const pos0=Math.max(0,...qsOf(l.id).map(q=>q.pos||0));
      const rows=ta.value.split('\n').map(x=>x.replace(/\r$/,'')).filter(x=>x.trim()).map(x=>(x.indexOf('\t')>=0?x.split('\t'):x.indexOf(';')>=0?x.split(';'):x.split(',')).map(s=>s.trim()));
      const qs=rows.filter(r=>r[0]&&r[1]).map((r,i)=>{const o={en:r[0],hy:r[1]};if(r[2])o.pron=r[2];if(r[3])o.example=r[3];if(r[4])o.exampleTr=r[4];return {id:mkId('q'),lesson_id:l.id,type:'intro',data:o,pos:pos0+i+1};});
      if(!qs.length){toast(t('errQ'));return true;}
      try{await B.upsertMany('questions',qs);qs.forEach(q=>localPut('questions',q));reapply();adm.wiz.saved=ago();toast(t('wCsvN').replace('{n}',qs.length));}catch(e){adm.wiz.err=t('e_'+mapErr(e));}
      render();return true;
    }
    case 'wbadd':{const l=wizLesson();if(!l)return true;const bl=(l.blocks||[]).concat([{k:d.k,v:''}]);await wizPersist('lessons',Object.assign({},l,{blocks:bl}));render();return true;}
    case 'wbdel':{const l=wizLesson();const bl=(l.blocks||[]).slice();bl.splice(+d.i,1);await wizPersist('lessons',Object.assign({},l,{blocks:bl}));render();return true;}
    case 'wbmove':{const l=wizLesson();const bl=(l.blocks||[]).slice(),i=+d.i,j=i+(+d.d);if(j<0||j>=bl.length)return true;[bl[i],bl[j]]=[bl[j],bl[i]];await wizPersist('lessons',Object.assign({},l,{blocks:bl}));render();return true;}
    case 'wexnew':{const l=wizLesson();if(!l)return true;adm.nav.lesson=l.id;adm.err='';adm.edit={table:'questions',isNew:true,row:{id:'',lesson_id:l.id,type:d.ty,data:{},pos:Math.max(0,...qsOf(l.id).map(q=>q.pos||0))+1}};render();window.scrollTo(0,0);return true;}
    case 'wdraft':{const l=wizLesson();if(await wizPersist('lessons',Object.assign({},l,{published:false})))toast(t('wDraftOk'));adm.wiz=null;render();return true;}
    case 'wpub':{
      const l=wizLesson();if(lessonIssues(l,qsOf(l.id)).some(x=>x[0]==='err')){toast(t('errPublish'));return true;}
      if(await wizPersist('lessons',Object.assign({},l,{published:true}))){toast(t('wPubOk'));adm.wiz=null;}
      render();return true;
    }
    case 'catren':{
      const inp=document.querySelector('input[data-cat="'+CSS.escape(d.k)+'"]'),nv=inp?inp.value.trim():'';if(!nv||nv===d.k)return true;
      try{for(const co of rawC().courses.filter(x=>(x.category||'').trim()===d.k))await persist('courses',Object.assign({},co,{category:nv}));toast(t('nowSaved'));}catch(e){toast(t('e_'+mapErr(e)));}
      render();return true;
    }
    case 'mcopy':return await copyMediaUrl(adm.mediaUrl||'',el);
  }
  return false;
}
/* inline edits: wizard fields, word rows, blocks, lesson texts, list filters */
document.addEventListener('input',e=>{
  const el=e.target;if(!el.matches)return;
  if(el.id==='oq'){adm.oq=el.value;$('olist').innerHTML=organizerList();return;}
  if(el.id==='lq'||el.id==='vq'||el.id==='eq'){const k={lq:'lq',vq:'vq',eq:'eq'}[el.id];adm[k]=el.value;const pos=el.selectionStart;adm.pg={};render();const n=$(el.id);if(n){n.focus();try{n.setSelectionRange(pos,pos);}catch(x){}}return;}
  const w=adm.wiz;if(!w)return;
  if(el.dataset.w&&el.tagName==='INPUT'){
    const k=el.dataset.w;if(el.dataset.l){w.d[k][el.dataset.l]=el.value;}else w.d[k]=el.value;
    if(wizLesson())wizDebounce(()=>wizSaveBasics(false));
  }
});
document.addEventListener('change',async e=>{
  const el=e.target;if(!el.matches)return;
  if(el.id==='nclang'){adm.nclang=el.value;return;}
  if(el.id==='lcourse'){adm.lcourse=el.value;adm.pg={};render();return;}
  if(el.id==='etype'){adm.etype=el.value;adm.pg={};render();return;}
  if(el.id==='mup'&&el.files&&el.files[0]){
    const f=el.files[0],kind=f.type.indexOf('audio/')===0?'audio':'image';
    if(f.type.indexOf(kind+'/')!==0||f.size>(kind==='audio'?5e6:3e6)||/svg/i.test(f.type)){toast(t('uplBad'));el.value='';return;}
    try{adm.mediaUrl=await B.upload(kind==='image'?await shrinkImage(f):f,kind);toast(t('uplOk'));}catch(x){const c=mapErr(x);toast(t(c==='uplType'||c==='uplSize'?c:'uplBad'));}
    el.value='';render();return;
  }
  const w=adm.wiz;if(!w)return;
  if(el.dataset.w&&el.tagName==='SELECT'){
    const k=el.dataset.w,d=w.d;d[k]=el.value;
    if(k==='lang'){d.course='';d.unit='';}if(k==='course')d.unit='';
    if(wizLesson()&&(k==='unit'))await wizSaveBasics(false);
    render();return;
  }
  if(el.dataset.w){if(wizLesson())await wizSaveBasics(false);return;}
  const l=wizLesson();
  if(el.dataset.wq){
    const q=rawC().questions.find(x=>x.id===el.dataset.wq);if(!q)return;
    const row=el.closest('.wword'),d=Object.assign({},q.data);
    row.querySelectorAll('[data-wq]').forEach(i=>{const v=i.value.trim();if(v)d[i.dataset.k]=v;else delete d[i.dataset.k];});
    if(!d.en||!d.hy){w.err=t('errQ');wizStatus();return;}
    await wizPersist('questions',Object.assign({},q,{data:d}));return;
  }
  if(el.dataset.wb!==undefined){
    const row=el.closest('.wword'),d={};
    row.querySelectorAll('[data-wb]').forEach(i=>{const v=i.value.trim();if(v)d[i.dataset.k]=v;});
    if(!d.en||!d.hy||!l)return;
    const q={id:mkId('q'),lesson_id:l.id,type:'intro',data:d,pos:Math.max(0,...qsOf(l.id).map(x=>x.pos||0))+1};
    if(await wizPersist('questions',q)){
      w.blanks=Math.max(0,w.blanks-1);
      row.classList.remove('blank');row.dataset.id=q.id;
      row.querySelectorAll('[data-wb]').forEach(i=>{i.removeAttribute('data-wb');i.dataset.wq=q.id;});
      const x=document.createElement('button');x.className='sbtn pom';x.dataset.a='wdelq';x.dataset.id=q.id;x.textContent='✕';x.setAttribute('aria-label',t('del'));row.appendChild(x);
    }
    return;
  }
  if(el.dataset.wbk!==undefined&&l){
    const bl=(l.blocks||[]).map(b=>Object.assign({},b)),i=+el.dataset.wbk;if(!bl[i])return;
    bl[i][el.dataset.k]=el.value;await wizPersist('lessons',Object.assign({},l,{blocks:bl}));
    return;
  }
  if(el.dataset.wl&&l){await wizPersist('lessons',Object.assign({},l,{[el.dataset.wl]:el.value}));return;}
});
