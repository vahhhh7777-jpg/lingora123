/* ---------- admin: dashboard, content builder, users ---------- */
const addDays=(cur,n)=>{const base=Math.max(Date.now(),cur?new Date(cur).getTime():0);return new Date(base+n*864e5).toISOString();};
const rawC=()=>A.rawCat||EMPTY_CAT();
const sib=(table,nav)=>{
  const c=rawC(),P={courses:['language_id','lang'],units:['course_id','course'],lessons:['unit_id','unit'],questions:['lesson_id','lesson']}[table];
  return (P?c[table].filter(r=>r[P[0]]===nav[P[1]]):c[table]).slice().sort(byPos);
};
const PARENT={courses:['language_id','lang'],units:['course_id','course'],lessons:['unit_id','unit'],questions:['lesson_id','lesson']};
const CHILD={languages:['courses','lang'],courses:['units','course'],units:['lessons','unit'],lessons:['questions','lesson']};
const mkId=p=>p+'-'+Date.now().toString(36).slice(-5)+Math.random().toString(36).slice(2,5);
const slugOf=s=>String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,18);
const LEVELS=['A1','A2','B1','B2','C1','C2'],DIFFS=['beginner','elementary','intermediate','upper_intermediate','advanced','easy','medium','hard'],TINTS=['blue','apricot','rose','mint'],QTYPES=['intro','mc','image','listen','read','type','match','order','fill','speak','tf','fix','pics','listen_type','write'];

/* ----- stored question forms: [key, label, kind] ----- */
const QT={
 intro:[['en','fWord','text'],['hy','fTrans','text'],['pron','fPron','text'],['pos','fPos','text'],['definition','fDef','text'],['example','fExample','text'],['exampleTr','fExampleTr','text'],['vis','fVis','vis']],
 mc:[['prompt','fPrompt','text'],['speak','fSpeak','text'],['answer','fAnswer','text'],['options','fWrong','wrong'],['explanation','fExpl','text']],
 pics:[['items','fPicItems','picitems'],['explanation','fExpl','text']],
 image:[['vis','fVis','vis'],['answer','fAnswer','text'],['options','fWrong','wrong'],['explanation','fExpl','text']],
 listen:[['text','fSpoken','text'],['answer','fAnswer','text'],['options','fWrong','wrong'],['explanation','fExpl','text']],
 listen_type:[['text','fSpoken','text'],['answer','fAnswer','text'],['accept','fAccept','csv'],['explanation','fExpl','text']],
 write:[['prompt','fPrompt','text'],['answer','fAnswer','text'],['accept','fAccept','csv'],['keywords','fKeywords','csv'],['explanation','fExpl','text']],
 read:[['passage','fPassage','area'],['prompt','fPrompt','text'],['answer','fAnswer','text'],['options','fWrong','wrong'],['explanation','fExpl','text']],
 type:[['prompt','fPrompt','text'],['answer','fAnswer','text'],['accept','fAccept','csv'],['explanation','fExpl','text']],
 match:[['pairs','fPairs','pairs']],
 order:[['prompt','fPromptH','text'],['sentence','fSentence','text'],['extra','fExtra','csv'],['explanation','fExpl','text']],
 tf:[['statement','fStatement','text'],['answer','fTfAnswer','tf'],['explanation','fExpl','text']],
 fix:[['wrong','fWrongS','text'],['answer','fFixed','text'],['accept','fAccept','csv'],['explanation','fExpl','text']],
 speak:[['text','fSpeakT','text'],['translation','fTrans','text'],['explanation','fExpl','text']],
 fill:[['prompt','fPromptH','text'],['sentence','fFillS','text'],['answer','fAnswer','text'],['distractors','fDistr','csv'],['explanation','fExpl','text']]
};
const QX=[['instruction','fInstruction','text'],['wrongMsg','fWrongMsg','text'],['hint','fHint','text'],['image','fImage','media'],['audio','fAudio','media']];
const ENT={
 languages:{f:[['code','fCode','id'],['name','fName','l2'],['flag','fFlag','text'],['tts','fTts','text'],['difficulty','fDiff','diff'],['active','fActive','chk']]},
 courses:{f:[['title','fTitle','l2'],['descr','fDescr','l2'],['category','fCategory','text'],['categories','fCategories','csv'],['cover','fCover','text'],['source','fSource','src'],['level','fLevel','level'],['difficulty','fDiff','diff'],['months','fMonths','num'],['tint','fColor','tint'],['sample','fSample','chk'],['vip','fVip','chk'],['published','fPublished','chk']]},
 units:{f:[['title','fTitle','l2'],['descr','fDescr','l2'],['tint','fColor','tint'],['vip','fVip','chk'],['published','fPublished','chk']]},
 lessons:{f:[['title','fTitle','l2'],['descr','fDescr','l2'],['objectives','fObjectives','area'],['grammar','fGrammar','area'],['summary','fSummary','area'],['cover','fCover','text'],['difficulty','fDiff','diff'],['minutes','fMinutes','num'],['xp','fXp','num'],['review','fReview','review'],['vip','fVip','chk'],['published','fPublished','chk']]}
};
const rowTitle=(table,r)=>table==='languages'?tx(r.name):tx(r.title);

function qSummary(q){
  const d=q.data||{};
  switch(q.type){
    case 'intro':return (d.en||'')+' — '+(d.hy||'');
    case 'mc':return (d.prompt||'')+' → '+(d.answer||'');
    case 'pics':return '🖼 '+(d.answer||'')+' ('+((d.items||[]).length)+')';
    case 'image':return (d.vis?d.vis[0]+':'+(d.vis[1]||''):'')+' → '+(d.answer||'');
    case 'listen':return '🔊 '+(d.text||'')+' → '+(d.answer||'');
    case 'read':return (d.prompt||'')+' → '+(d.answer||'');
    case 'type':return (d.prompt||'')+' → '+(d.answer||'');
    case 'listen_type':return '🔊✍ '+(d.text||'');
    case 'write':return '✍ '+(d.prompt||'')+' → '+(d.answer||(d.keywords||[]).join(', '));
    case 'match':return (d.pairs||[]).map(p=>p[0]+' = '+p[1]).join(' · ');
    case 'order':return (d.prompt||'')+' → '+(d.sentence||'');
    case 'fill':return (d.sentence||'')+' → '+(d.answer||'');
    case 'tf':return (d.statement||'')+' → '+(d.answer==='true'?t('tTrue'):t('tFalse'));
    case 'fix':return (d.wrong||'')+' → '+(d.answer||'');
    case 'speak':return '🎤 '+(d.text||'')+' — '+(d.translation||'');
  }
  return '';
}
const delKey=(table,id)=>table+':'+id;
function crumbs(){
  const n=adm.nav,c=rawC(),out=[[t('x_languages'),'root']];
  const l=c.languages.find(x=>x.id===n.lang),co=c.courses.find(x=>x.id===n.course),u=c.units.find(x=>x.id===n.unit),le=c.lessons.find(x=>x.id===n.lesson);
  if(l)out.push([tx(l.name),'lang']);
  if(co)out.push([tx(co.title),'course']);
  if(u)out.push([tx(u.title),'unit']);
  if(le)out.push([tx(le.title)||t('l0'),'lesson']);
  return `<nav class="crumbs" aria-label="path">${out.map((x,i)=>i===out.length-1?`<b>${esc(x[0])}</b>`:`<button class="link" data-a="anav" data-v="${x[1]}">${esc(x[0])}</button>`).join('<span aria-hidden="true">›</span>')}</nav>`;
}
function adminLevel(){const n=adm.nav;return n.lesson?'questions':n.unit?'lessons':n.course?'units':n.lang?'courses':'languages';}
function entRow(table,r,i,arr){
  const c=rawC(),kid=CHILD[table],cnt=kid?c[kid[0]].filter(x=>x[PARENT[kid[0]][0]]===r.id).length:0;
  const on=table==='languages'?r.active!==false:r.published!==false;
  const st=table==='courses'?courseStatus(rawC(),r):'',h=table==='courses'?courseHealth(rawC(),r.id):null;
  const badges=(r.vip?vipBadge():'')+(r.sample?`<span class="tag sample">${t('sampleCourse')}</span>`:'')+(st?`<span class="tag st-${st}">${t('st_'+st)}</span>`:'')+(table==='lessons'?`<span class="tag rv-${r.review||'draft'}">${t('rv_'+(r.review||'draft'))}</span>`:'');
  const meta=[table==='lessons'?(cnt+' '+t('x_questions')+' · '+(r.xp||8)+' XP'):(kid?cnt+' '+t('x_'+kid[0]):''),
              table==='languages'?(r.code||r.id):table==='courses'?(r.level||'A1')+' · '+t('diff_'+(r.difficulty||'easy'))+' · '+h.published+'/'+h.lessons+' '+t('x_lessons')+' · '+h.questions+' '+t('x_questions'):table==='lessons'?t('diff_'+(r.difficulty||'easy')):''].filter(Boolean).join(' · ');
  const key=delKey(table,r.id),armed=adm.delArm===key;
  return `<div class="urow dnd" draggable="true" data-dnd="${table}" data-id="${esc(r.id)}" title="${esc(t('dragHint'))}"><div class="acc"><b>${i+1}. ${esc(r.flag?r.flag+' · ':'')}${esc(rowTitle(table,r))} ${badges}</b><span>${esc(meta)}</span></div>
   <div class="acts"><button class="sbtn" data-a="eopen" data-t="${table}" data-id="${esc(r.id)}">${t('open')}</button>
   <button class="sbtn" data-a="eedit" data-t="${table}" data-id="${esc(r.id)}">${t('edit')}</button>
   ${table==='lessons'?`<button class="sbtn" data-a="eprev" data-id="${esc(r.id)}">${t('preview')}</button><button class="sbtn" data-a="ldup" data-id="${esc(r.id)}">${t('dup')}</button>`:''}
   <button class="sbtn ${on?'':'off'}" data-a="epub" data-t="${table}" data-id="${esc(r.id)}" aria-pressed="${String(on)}">${t(table==='languages'?(on?'actOn':'actOff'):(on?'pubOn':'pubOff'))}</button>
   ${table==='courses'?`<button class="sbtn" data-a="carch" data-id="${esc(r.id)}">${t(r.archived?'restoreB':'archiveB')}</button>`:''}
   <button class="sbtn" data-a="emove" data-t="${table}" data-id="${esc(r.id)}" data-d="-1" ${i===0?'disabled':''} aria-label="${t('up')}">↑</button>
   <button class="sbtn" data-a="emove" data-t="${table}" data-id="${esc(r.id)}" data-d="1" ${i===arr.length-1?'disabled':''} aria-label="${t('down')}">↓</button>
   <button class="sbtn pom ${armed?'armed':''}" data-a="edel" data-t="${table}" data-id="${esc(r.id)}">${armed?t('delSure'):t('del')}</button></div></div>`;
}
function qRow(q,i,arr){
  const key=delKey('questions',q.id),armed=adm.delArm===key;
  return `<div class="urow dnd" draggable="true" data-dnd="questions" data-id="${esc(q.id)}" title="${esc(t('dragHint'))}"><div class="acc"><b>${i+1}. <span class="tag">${esc(t('qt_'+q.type))}</span></b><span>${esc(qSummary(q))}</span></div>
   <div class="acts"><button class="sbtn" data-a="qedit" data-id="${esc(q.id)}">${t('edit')}</button>
   <button class="sbtn" data-a="qdup" data-id="${esc(q.id)}">${t('dup')}</button>
   <button class="sbtn" data-a="emove" data-t="questions" data-id="${esc(q.id)}" data-d="-1" ${i===0?'disabled':''} aria-label="${t('up')}">↑</button>
   <button class="sbtn" data-a="emove" data-t="questions" data-id="${esc(q.id)}" data-d="1" ${i===arr.length-1?'disabled':''} aria-label="${t('down')}">↓</button>
   <button class="sbtn pom ${armed?'armed':''}" data-a="edel" data-t="questions" data-id="${esc(q.id)}">${armed?t('delSure'):t('del')}</button></div></div>`;
}
function issuesBox(){
  const l=rawC().lessons.find(x=>x.id===adm.nav.lesson);if(!l)return '';
  const is=lessonIssues(l,qsOf(l.id));
  return `<section class="card"><h2>${t('issuesT')}</h2>${is.length?is.map(x=>`<div class="iss ${x[0]}"><b>${x[0]==='err'?'✕':x[0]==='warn'?'!':'i'}</b><span>${t(x[1])}</span></div>`).join(''):`<div class="iss ok"><b>✓</b><span>${t('iss_ok')}</span></div>`}</section>`;
}
const bulkBox=()=>`<section class="card"><h2>${t('bulkT')}</h2><p class="note">${t('bulkS')}</p><textarea id="bulkw" rows="5" placeholder="Hello = Բարև ; Hello, how are you?"></textarea>
  <label class="chk"><input id="bulkmc" type="checkbox" checked>${t('bulkMc')}</label><div class="acts"><button class="btn btn-purple" data-a="bulkw" ${adm.busy?'disabled':''}>${t('bulkB')}</button></div></section>`;
function contentView(){
  if(!A.dbCount){
    return `<section class="card"><p class="note">${t('importNote')}</p><button class="btn btn-orange" data-a="unitimport" ${adm.busy?'disabled':''}>${t('importB')}</button></section>`;
  }
  const lv=adminLevel(),list=sib(lv,adm.nav);
  let head='';
  if(lv==='questions'){
    head=`<div class="acts"><select id="qtype" class="search s2" aria-label="${esc(t('newQ'))}">${QTYPES.map(x=>`<option value="${x}">${esc(t('qt_'+x))}</option>`).join('')}</select>
      <button class="btn btn-orange" data-a="qnew">${t('newQ')}</button><button class="btn btn-ghost" data-a="eprev" data-id="${esc(adm.nav.lesson)}">${t('previewL')}</button></div>`;
  }else{
    head=`<div class="acts"><button class="btn btn-orange" data-a="enew" data-t="${lv}">${t('new_'+lv)}</button></div>`;
  }
  const PAGE=25;let pager='';
  if(!adm.qp||adm.qp.k!==adm.nav.lesson)adm.qp={k:adm.nav.lesson,p:0};
  const pages=Math.ceil(list.length/PAGE);adm.qp.p=Math.min(adm.qp.p,Math.max(0,pages-1));
  const shown=lv==='questions'?list.slice(adm.qp.p*PAGE,adm.qp.p*PAGE+PAGE):list;
  if(lv==='questions'&&pages>1)pager=`<div class="acts pager"><button class="btn btn-ghost" data-a="qpage" data-v="-1" ${adm.qp.p===0?'disabled':''}>${t('prevP')}</button><span class="note">${adm.qp.p+1} / ${pages} · ${list.length}</span><button class="btn btn-ghost" data-a="qpage" data-v="1" ${adm.qp.p>=pages-1?'disabled':''}>${t('nextP')}</button></div>`;
  const rows=list.length?(lv==='questions'?shown.map(qRow):list.map((r,i,arr)=>entRow(lv,r,i,arr))).join('')+pager:`<div class="empty">${t('nothing')}</div>`;
  return crumbs()+head+(lv==='questions'?issuesBox():'')+(lv==='questions'?bulkBox():'')+rows+(lv==='languages'||lv==='courses'||lv==='units'?`<p class="note" style="margin-top:12px">${t('cascadeNote')}</p>`:'');
}

/* ----- forms ----- */
function visSel(v){const ty=v&&v[0]||'';return {ty,val:v&&v[1]||''};}
function ctl(f,v,isNew){
  const k=f[0],L=esc(t(f[1])),kind=f[2],a=`data-f="${k}"`;
  const sel=(items,cur)=>items.map(x=>`<option value="${esc(x[0])}" ${String(cur)===String(x[0])?'selected':''}>${esc(x[1])}</option>`).join('');
  switch(kind){
    case 'id':return `<label class="fld">${L}<input ${a} data-k="text" value="${esc(v||'')}" ${isNew?'':'readonly'} autocapitalize="none" autocomplete="off" maxlength="8"></label>`;
    case 'l2':{v=v||{};return ['hy','en'].map(l=>`<label class="fld">${L} (${l==='hy'?'Հայ':'EN'})<input ${a} data-k="l2" data-l="${l}" value="${esc(v[l]||'')}"></label>`).join('');}
    case 'text':return `<label class="fld">${L}<input ${a} data-k="text" value="${esc(v==null?'':v)}" autocomplete="off"></label>`;
    case 'media':{const ac=k==='audio'?'audio/*':'image/*';return `<div class="fld">${L}<input ${a} data-k="text" value="${esc(v==null?'':v)}" autocomplete="off" placeholder="https://…"><label class="btn btn-ghost upl">${t('upl')}<input type="file" accept="${ac}" data-up="${k}" hidden></label></div>`;}
    case 'num':return `<label class="fld">${L}<input ${a} data-k="num" type="number" min="0" max="999" value="${esc(v==null?'':v)}"></label>`;
    case 'area':return `<label class="fld">${L}<textarea ${a} data-k="text" rows="4">${esc(v||'')}</textarea></label>`;
    case 'chk':return `<label class="chk"><input ${a} data-k="chk" type="checkbox" ${v?'checked':''}>${L}</label>`;
    case 'diff':return `<label class="fld">${L}<select ${a} data-k="text" class="search s2">${sel(DIFFS.map(x=>[x,t('diff_'+x)]),v||'easy')}</select></label>`;
    case 'src':{const ls=rawC().languages.map(l=>[l.id,tx(l.name)]);if(!ls.some(x=>x[0]==='hy'))ls.push(['hy','Հայերեն']);if(!ls.some(x=>x[0]==='en'))ls.push(['en','English']);return `<label class="fld">${L}<select ${a} data-k="text" class="search s2">${sel(ls,v||'hy')}</select></label>`;}
    case 'review':return `<label class="fld">${L}<select ${a} data-k="text" class="search s2">${sel(['draft','review','verified'].map(x=>[x,t('rv_'+x)]),v||'draft')}</select></label>`;
    case 'tf':return `<label class="fld">${L}<select ${a} data-k="text" class="search s2"><option value="true" ${v!=='false'?'selected':''}>${t('tTrue')}</option><option value="false" ${v==='false'?'selected':''}>${t('tFalse')}</option></select></label>`;
    case 'level':return `<label class="fld">${L}<select ${a} data-k="text" class="search s2">${sel(LEVELS.map(x=>[x,x]),v||'A1')}</select></label>`;
    case 'tint':return `<label class="fld">${L}<select ${a} data-k="text" class="search s2">${sel(TINTS.map(x=>[x,x]),v||'blue')}</select></label>`;
    case 'wrong':return `<label class="fld">${L}<textarea ${a} data-k="lines" rows="3">${esc((v||[]).join('\n'))}</textarea></label>`;
    case 'csv':return `<label class="fld">${L}<input ${a} data-k="csv" value="${esc((v||[]).join(', '))}" autocomplete="off"></label>`;
    case 'pairs':return `<label class="fld">${L}<textarea ${a} data-k="pairs" rows="5" placeholder="Hello = Բարև">${esc((v||[]).map(p=>p[0]+' = '+p[1]).join('\n'))}</textarea></label>`;
    case 'picitems':{
      const rows=Array.isArray(v)?v.slice():[];while(rows.length<4)rows.push({});
      const inp=(i,p,lab,val,ph)=>`<label class="fld">${esc(t(lab))}<input data-f="${k}" data-k="pic" data-i="${i}" data-p="${p}" value="${esc(val||'')}" placeholder="${esc(ph||'')}" autocomplete="off"></label>`;
      return `<div class="fld">${L}<p class="note">${t('picItemsNote')}</p>${rows.slice(0,6).map((r,i)=>`<div class="picrow ${i===0?'ans':''}"><b>${i===0?t('picCorrect'):'#'+(i+1)}</b>${inp(i,'w','picW',r.w)}${inp(i,'l','picL',r.l)}${inp(i,'e','picE',r.e,'☕')}
        <div class="fld">${esc(t('picImg'))}<input data-f="${k}" data-k="pic" data-i="${i}" data-p="img" value="${esc(r.img||'')}" placeholder="https://…" autocomplete="off"><label class="btn btn-ghost upl">${t('upl')}<input type="file" accept="image/*" data-up="image" hidden></label></div></div>`).join('')}</div>`;
    }
    case 'vis':{
      const {ty,val}=visSel(v);
      return `<div class="fld">${L}<div class="acts"><select ${a} data-k="vist" class="search s2" aria-label="${esc(t('fVis'))}"><option value="" ${ty===''?'selected':''}>${t('visNone')}</option><option value="e" ${ty==='e'?'selected':''}>${t('visEmoji')}</option><option value="n" ${ty==='n'?'selected':''}>${t('visNum')}</option><option value="c" ${ty==='c'?'selected':''}>${t('visCol')}</option></select>
       <input ${a} data-k="visv" value="${esc(val)}" placeholder="${esc(t('visVal'))}" aria-label="${esc(t('visVal'))}"></div></div>`;
    }
  }
  return '';
}
function formView(){
  const e=adm.edit,isQ=e.table==='questions';
  const fields=isQ?QT[e.row.type].concat(QX):ENT[e.table].f;
  const val=k=>{
    if(!isQ)return e.row[k];
    const d=e.row.data||{};
    return k==='options'?(d.options||[]).filter(o=>o!==d.answer):d[k];
  };
  const title=isQ?t('qt_'+e.row.type):t('new_'+e.table);
  return `<form id="eform" class="card" novalidate><h2>${esc(isQ?title:(e.isNew?t('new_'+e.table):t('edit')))}</h2>
   ${fields.map(f=>ctl(f,val(f[0]),e.isNew)).join('')}
   ${isQ?`<p class="note">${t('qHint_'+e.row.type)}</p>`:''}
   ${adm.err?`<div class="msg err">${esc(adm.err)}</div>`:''}
   <div class="acts"><button class="btn btn-purple" type="submit" ${adm.busy?'disabled':''}>${t('save')}</button>
   ${isQ?`<button type="button" class="btn btn-ghost" data-a="qprev">${t('preview')}</button>`:''}
   <button type="button" class="btn btn-ghost" data-a="ucancel">${t('cancel')}</button></div></form>`;
}
function readForm(){
  const o={},T={};
  document.querySelectorAll('#eform [data-f]').forEach(el=>{
    const k=el.dataset.f,kd=el.dataset.k,v=el.value==null?'':String(el.value);
    if(kd==='l2'){(o[k]=o[k]||{})[el.dataset.l]=v.trim();}
    else if(kd==='chk')o[k]=!!el.checked;
    else if(kd==='num')o[k]=Math.max(0,Math.round(Number(v))||0);
    else if(kd==='lines')o[k]=v.split('\n').map(x=>x.trim()).filter(Boolean);
    else if(kd==='csv')o[k]=v.split(',').map(x=>x.trim()).filter(Boolean);
    else if(kd==='pairs')o[k]=v.split('\n').map(x=>x.split('=')).filter(p=>p.length>=2).map(p=>[p[0].trim(),p.slice(1).join('=').trim()]).filter(p=>p[0]&&p[1]);
    else if(kd==='pic'){const A2=(o[k]=o[k]||[]);(A2[+el.dataset.i]=A2[+el.dataset.i]||{})[el.dataset.p]=v.trim();}
    else if(kd==='vist'){(T[k]=T[k]||{}).t=v;}
    else if(kd==='visv'){(T[k]=T[k]||{}).v=v.trim();}
    else o[k]=v.trim();
  });
  Object.keys(T).forEach(k=>{
    const x=T[k];
    o[k]=x.t==='e'&&x.v?['e',x.v]:x.t==='n'&&x.v?['n',x.v]:x.t==='c'&&/^#[0-9a-f]{3,8}$/i.test(x.v||'')?['c',x.v]:null;
  });
  return o;
}
/* Builds the stored data of a question from the form, or null when it is not valid. */
function questionData(type,o){
  const d={};
  QT[type].concat(QX).forEach(f=>{d[f[0]]=o[f[0]];});
  if((o.image&&!safeUrl(o.image,'image'))||(o.audio&&!safeUrl(o.audio,'audio')))return null;
  if(type==='pics'){
    const items=(o.items||[]).filter(x=>x&&x.w&&(x.e||x.img)).map(x=>{const r={w:x.w};if(x.l)r.l=x.l;if(x.e)r.e=x.e;if(x.img)r.img=x.img;return r;});
    if(items.length<3||new Set(items.map(x=>x.w)).size!==items.length||items.some(x=>x.img&&!safeUrl(x.img,'image')))return null;
    if(!(o.items||[])[0]||!o.items[0].w||!(o.items[0].e||o.items[0].img))return null;
    return Object.assign({items,answer:items[0].w},o.explanation?{explanation:o.explanation}:{},(o.hint?{hint:o.hint}:{}));
  }
  const wrong=Array.isArray(o.options)?o.options.filter(x=>x!==o.answer):[];
  if('options' in d)d.options=[o.answer].concat(wrong);
  if(type==='fill'){d.distractors=(o.distractors||[]).filter(x=>x!==o.answer);}
  Object.keys(d).forEach(k=>{if(d[k]==null||d[k]===''||(Array.isArray(d[k])&&!d[k].length&&k!=='options'&&k!=='pairs'&&k!=='distractors'))delete d[k];});
  if(type==='order'||type==='type'||type==='fill'){}
  const q={id:'x',type,data:d};
  if(!toStep(q))return null;
  if(d.options&&d.options.length<2)return null;
  if(type==='fill'&&((d.sentence.split('___').length!==2)||!(d.distractors||[]).length))return null;
  if(type==='order'&&d.sentence.split(' ').filter(Boolean).length<2)return null;
  if(type==='match'&&(d.pairs.length<2||d.pairs.length>6))return null;
  if(type==='image'&&!d.vis)return null;
  if(type==='fix'&&norm(d.wrong)===norm(d.answer))return null;
  if(type==='fill'&&!d.distractors)d.distractors=[];
  return d;
}
function newRow(table){
  const n=adm.nav,pos=Math.max(0,...sib(table,n).map(r=>r.pos||0))+1,P=PARENT[table];
  const base={pos};
  if(P)base[P[0]]=n[P[1]];
  if(table==='languages')return Object.assign(base,{id:'',code:'',name:{hy:'',en:''},flag:'',tts:'',difficulty:'easy',active:true});
  if(table==='courses')return Object.assign(base,{id:'',title:{hy:'',en:''},descr:{hy:'',en:''},source:'hy',level:'A1',difficulty:'easy',category:'',cover:'',archived:false,months:3,tint:'blue',sample:false,published:false});
  if(table==='units')return Object.assign(base,{id:'',title:{hy:'',en:''},descr:{hy:'',en:''},tint:'blue',vip:false,published:false});
  return Object.assign(base,{id:'',title:{hy:'',en:''},descr:{hy:'',en:''},xp:8,difficulty:'easy',minutes:5,review:'draft',objectives:'',grammar:'',summary:'',cover:'',published:false});
}
/* local copy of what the server now holds, so the screen updates without refetching everything */
function localPut(table,row){
  const c=rawC(),i=c[table].findIndex(x=>x.id===row.id);
  if(i<0)c[table].push(row);else c[table][i]=row;
  A.rawCat=c;A.dbCount=c.courses.length||c.languages.length||A.dbCount;
}
function reapply(){setCatalog(A.rawCat);saveCache();}
async function persist(table,row){
  await B.upsert(table,row);
  localPut(table,row);reapply();
}
async function saveForm(){
  const e=adm.edit,o=readForm();adm.err='';
  let row;
  if(e.table==='questions'){
    const d=questionData(e.row.type,o);
    if(!d){adm.err=t('errQ');render();return;}
    row=Object.assign({},e.row,{data:d});
  }else{
    row=Object.assign({},e.row);
    const f=ENT[e.table].f;
    f.forEach(x=>{if(x[0] in o)row[x[0]]=o[x[0]];});
    ['name','title','descr'].forEach(k=>{
      if(row[k]&&typeof row[k]==='object'){
        if(!row[k].hy)row[k].hy=row[k].en||'';
        if(!row[k].en)row[k].en=row[k].hy||'';
      }
    });
    if(e.table==='languages'){
      row.code=String(row.code||'').toLowerCase();
      if(e.isNew){row.id=row.code;}
      row.flag=(row.flag||row.code||'').toUpperCase().slice(0,3);
      if(!/^[a-z][a-z0-9-]{1,7}$/.test(row.code)||!tx(row.name)||!row.tts||(e.isNew&&rawC().languages.some(x=>x.id===row.id))){adm.err=t('errEnt');render();return;}
    }else{
      if(!tx(row.title)){adm.err=t('errEnt');render();return;}
      if(e.isNew)row.id=mkId(slugOf(row.title.en)||e.table.slice(0,3));
    }
    if(e.table==='lessons'){row.xp=row.xp||8;row.minutes=row.minutes||5;}
  }
  if(e.isNew&&!row.id)row.id=mkId('q');
  adm.busy=true;render();
  try{await persist(e.table,row);adm.edit=null;adm.busy=false;toast(t('saved'));render();}
  catch(x){adm.busy=false;adm.err=t('e_'+mapErr(x));render();}
}
const qsOf=lid=>sib('questions',{lesson:lid});

/* ----- dashboard ----- */
function dashData(){
  const users=adm.users||[],P=adm.prog||{},c=rawC(),now=Date.now(),cut7=dstr(new Date(now-7*864e5));
  const progs=Object.keys(P).map(k=>P[k]).filter(Boolean);
  const uMap={};c.units.forEach(u=>{uMap[u.id]=u.course_id;});
  const l2c={};c.lessons.forEach(l=>{l2c[l.id]=uMap[l.unit_id];});
  const pop={};
  Object.keys(P).forEach(uid=>{
    const done=(P[uid]&&P[uid].done)||{};
    Object.keys(done).forEach(lid=>{const co=l2c[lid];if(!co)return;const o=pop[co]=pop[co]||{learners:{},n:0};o.learners[uid]=1;o.n++;});
  });
  const miss={};progs.forEach(p=>Object.keys(p.miss||{}).forEach(k=>{miss[k]=(miss[k]||0)+p.miss[k];}));
  const days=[];for(let i=13;i>=0;i--){const d=new Date(now-i*864e5);days.push({k:dstr(d),n:0,w:d.getDay()});}
  users.forEach(u=>{if(!u.created_at)return;const d=days.find(x=>x.k===dstr(new Date(u.created_at)));if(d)d.n++;});
  return {
    users:users.length,vip:users.filter(profVip).length,new7:users.filter(u=>u.created_at&&new Date(u.created_at).getTime()>=now-7*864e5).length,
    active7:progs.filter(p=>(p.last||'')>=cut7).length,done:progs.reduce((n,p)=>n+Object.keys(p.done||{}).length,0),xp:progs.reduce((n,p)=>n+(p.xp||0),0),
    pop:c.courses.map(co=>({co,learners:Object.keys((pop[co.id]||{learners:{}}).learners).length,n:(pop[co.id]||{n:0}).n})).sort((a,b)=>b.n-a.n),
    hard:Object.keys(miss).sort((a,b)=>miss[b]-miss[a]).slice(0,5).map(k=>[k,miss[k]]),days
  };
}
function admProgBanner(){return adm.perr?`<div class="msg err" role="alert">${esc(t('admProgErr'))} (${esc(t('e_'+adm.perr))}) <button class="btn sm" data-a="admretry">${esc(t('syncRetry'))}</button></div>`:'';}
function dashView(){
  if(adm.loading)return `<div role="status" aria-busy="true" aria-label="${esc(t('loadingT'))}">${skel(3)}</div>`;
  if(adm.uerr)return `<div class="msg err">${t('e_'+adm.uerr)}</div>`;
  const D=dashData(),c=rawC(),st=n=>`<div class="stat"><b>${n[0]}</b><span>${esc(n[1])}</span></div>`;
  const mx=Math.max(1,...D.days.map(d=>d.n)),mp=Math.max(1,...D.pop.map(p=>p.n));
  const bars=D.days.map((d,i)=>`<div class="bcol ${i===13?'now':''}"><span class="bv">${d.n}</span><i style="height:${Math.round(d.n/mx*100)}%"></i><span class="bd">${esc(t('wd')[d.w])}</span></div>`).join('');
  const pop=D.pop.slice(0,8).map(p=>`<div class="urep"><div><span>${esc(tx(p.co.title))}</span><span>${p.learners} · ${p.n}</span></div><div class="bar"><i style="width:${Math.round(p.n/mp*100)}%"></i></div></div>`).join('');
  const hard=D.hard.map(h=>`<div class="weak"><b>${esc(h[0])}</b><span>×${h[1]}</span></div>`).join('');
  const drafts=c.courses.concat(c.units,c.lessons).filter(r=>r.published===false).length;
  const cst={published:0,draft:0,incomplete:0,archived:0};c.courses.forEach(co=>{cst[courseStatus(c,co)]++;});
  const words=c.questions.filter(q=>q.type==='intro').length;
  const comp=c.courses.map(co=>{const h=courseHealth(c,co.id);return {co,h,s:courseStatus(c,co),pct:h.lessons?Math.round(h.published/h.lessons*100):0};});
  const compRows=comp.map(x=>`<div class="urep"><div><span>${esc(tx(x.co.title))} <span class="tag st-${x.s}">${t('st_'+x.s)}</span></span><span>${x.h.published}/${x.h.lessons} · ${x.h.questions}</span></div><div class="bar"><i style="width:${x.pct}%"></i></div></div>`).join('');
  const short=`<section class="card"><div class="acts"><button class="btn btn-orange" data-a="dgo" data-v="content">${t('dgoContent')}</button><button class="btn btn-ghost" data-a="dgo" data-v="users">${t('users')}</button><button class="btn btn-ghost" data-a="dgo" data-v="learner">${t('dgoPrev')}</button><button class="btn btn-ghost" data-a="cexport">${t('expB')}</button><label class="btn btn-ghost upl">${t('impB')}<input type="file" accept="application/json,.json" id="cimport" hidden></label></div><p class="note">${t('impNote')}</p></section>`;
  return admProgBanner()+short+`<section class="card"><h2>${t('dContent')}</h2><div class="stats">${[[cst.published,t('st_published')],[cst.draft,t('st_draft')],[cst.incomplete,t('st_incomplete')],[words,t('dWords')]].map(st).join('')}</div></section><div class="stats">${[[D.users,t('total')],[D.vip,t('vipCount')],[D.new7,t('dNew7')],[D.active7,t('dActive7')],[D.done,t('dLessons')],[D.xp,t('dXp')]].map(st).join('')}</div>
   <section class="card"><h2>${t('dContent')}</h2><div class="stats">${[[c.languages.length,t('x_languages')],[c.courses.length,t('x_courses')],[c.units.length,t('x_units')],[c.lessons.length,t('x_lessons')],[c.questions.length,t('x_questions')],[drafts,t('pubOff')]].map(st).join('')}</div></section>
   <section class="card"><h2>${t('dCompl')}</h2>${compRows||`<p class="note">${t('noData')}</p>`}<p class="note">${t('dComplNote')}</p></section>
   <section class="card"><h2>${t('dSignups')}</h2><div class="bars">${bars}</div></section>
   <section class="card"><h2>${t('dPopular')}</h2>${pop||`<p class="note">${t('noData')}</p>`}<p class="note">${t('dPopNote')}</p></section>
   <section class="card"><h2>${t('dHard')}</h2>${hard||`<p class="note">${t('noData')}</p>`}</section>`;
}

/* ----- users ----- */
function userRows(){
  const q=norm(adm.uq),P=adm.prog||{};
  const list=adm.users.filter(u=>!q||norm(u.email).includes(q)||norm(u.name||'').includes(q));
  if(!list.length)return `<div class="empty">${t('noUsers')}</div>`;
  return list.map(u=>{
    const on=profVip(u),p=P[u.id];
    const st=u.role==='super_admin'?t('role_super'):u.is_admin?t('adminRole'):on?(t('vipUntil')+' '+new Date(u.vip_until).toLocaleDateString()):t('free');
    const pr=p?`${p.xp||0} XP · ${Object.keys(p.done||{}).length} ${t('x_lessons')}${p.last?' · '+esc(p.last):''}`:'';
    return `<div class="urow"><div class="urow-h"><div class="acc"><b>${esc(u.name||u.email)}</b><span>${esc(u.email)}</span><span>${on?vipBadge()+' ':''}${esc(st)}</span>${pr?`<span>${pr}</span>`:''}</div></div>
      <div class="acts">${[30,90,365].map(n=>`<button class="sbtn" data-a="vipadd" data-id="${esc(u.id)}" data-n="${n}">+${n} ${t('plusDays')}</button>`).join('')}
      ${ECON()?((CFG.GEM_PACKS||[]).map(pk=>`<button class="sbtn" data-a="gemadd" data-id="${esc(u.id)}" data-n="${esc(pk.gems)}">+${esc(pk.gems)} ${t('gGrant')}</button>`).join('')):''}
      ${u.vip_until?`<button class="sbtn pom" data-a="vipdel" data-id="${esc(u.id)}">${t('removeVip')}</button>`:''}
      ${isSuper()&&A.user&&u.id!==A.user.id&&u.role!=='super_admin'?`<button class="sbtn ${u.is_admin?'pom':''}" data-a="roleset" data-id="${esc(u.id)}" data-v="${u.is_admin?'0':'1'}">${t(u.is_admin?'removeAdmin':'makeAdmin')}</button>`:''}</div></div>`;
  }).join('');
}
function usersView(){
  if(adm.loading)return `<div role="status" aria-busy="true" aria-label="${esc(t('loadingT'))}">${skel(3)}</div>`;
  if(adm.uerr)return `<div class="msg err">${t('e_'+adm.uerr)}</div>`;
  const vc=adm.users.filter(profVip).length;
  return `${admProgBanner()}<div class="stats"><div class="stat"><b>${adm.users.length}</b><span>${t('total')}</span></div><div class="stat"><b>${vc}</b><span>${t('vipCount')}</span></div></div>
   <div style="margin-top:14px"><input id="uq" class="search" type="search" value="${esc(adm.uq)}" placeholder="${esc(t('searchUsers'))}" autocomplete="off"></div><div id="ulist">${userRows()}</div>`;
}
function adminView(){
  if(!isStaff())return '';
  const ek=adm.edit?adm.edit.table+'|'+adm.edit.row.id+'|'+adm.edit.isNew:'';
  if(ek!==adm._ek){adm._ek=ek;adm.dirty=false;adm.discardArm=false;}
  return adminShell(adminBody());
  const seg=`<div class="seg" role="tablist">${[['dash',t('dash')],['content',t('contentTab')],['stories',pt('sAdmin')],['users',t('users')]].map(x=>`<button role="tab" aria-checked="${String(adm.sub===x[0])}" data-a="asub" data-v="${x[0]}">${esc(x[1])}</button>`).join('')}</div>`;
  const body=adm.sub==='dash'?dashView():adm.sub==='users'?usersView():adm.sub==='stories'?pxAdminStories():(adm.edit?formView():contentView());
  return `<h1 class="ph">${t('admin')}</h1>${MODE==='demo'?`<div class="banner">${t('demo')}</div>`:''}${seg}<div style="margin-top:14px">${body}</div>`;
}
async function loadUsers(){
  if(!B||!isAdmin())return;
  adm.loading=true;adm.uerr='';adm.perr='';render();
  try{
    adm.users=await B.listUsers();
    adm.prog={};
    try{(await B.allProgress()).forEach(r=>{adm.prog[r.user_id]=r.data;});}catch(e){adm.prog={};adm.perr=mapErr(e);console.warn('admin: could not load learner progress',e);}
  }catch(e){adm.uerr=mapErr(e);}
  adm.loading=false;if(tab==='admin')render();
}

/* Imports a curriculum exported by Lingora (or written by hand in the same shape). Nothing is overwritten: every id is renamed,
   everything arrives unpublished and marked "unverified", so a person must review it before learners see it. */
async function importCurriculum(j){
  if(!j||typeof j!=='object')throw new Error('shape');
  const arr=k=>Array.isArray(j[k])?j[k]:[];
  if(arr('questions').length>5000||arr('lessons').length>2000)throw new Error('big');
  const cur=rawC(),sfx='-i'+Date.now().toString(36).slice(-4),map={};
  const rid=(tb,id)=>{const k=tb+':'+id;return map[k]||(map[k]=String(id)+sfx);};
  const langOk=id=>cur.languages.some(l=>l.id===id);
  let skip=0;
  const courses=arr('courses').filter(c=>c&&c.id&&c.language_id&&(langOk(c.language_id)||arr('languages').some(l=>l.id===c.language_id))).map(c=>Object.assign({},c,{id:rid('c',c.id),published:false,archived:false}));
  const cid=new Set(courses.map(c=>c.id));
  const units=arr('units').filter(u=>u&&u.id&&cid.has(rid('c',u.course_id))).map(u=>Object.assign({},u,{id:rid('u',u.id),course_id:rid('c',u.course_id),published:false}));
  const uid=new Set(units.map(u=>u.id));
  const lessons=arr('lessons').filter(l=>l&&l.id&&uid.has(rid('u',l.unit_id))).map(l=>Object.assign({},l,{id:rid('l',l.id),unit_id:rid('u',l.unit_id),published:false,review:'draft'}));
  const lid=new Set(lessons.map(l=>l.id));
  const questions=arr('questions').filter(q=>{const ok=q&&q.id&&QTYPES.indexOf(q.type)>=0&&lid.has(rid('l',q.lesson_id))&&toStep(q);if(!ok)skip++;return ok;})
    .map(q=>({id:rid('q',q.id),lesson_id:rid('l',q.lesson_id),type:q.type,data:q.data,pos:q.pos||0}));
  const newLangs=arr('languages').filter(l=>l&&l.id&&/^[a-z]{2,8}$/.test(l.id)&&!langOk(l.id)&&courses.some(c=>c.language_id===l.id)).map(l=>Object.assign({},l,{active:true}));
  if(!courses.length)throw new Error('empty');
  if(newLangs.length)await B.upsertMany('languages',newLangs);
  await B.upsertMany('courses',courses);await B.upsertMany('units',units);await B.upsertMany('lessons',lessons);await B.upsertMany('questions',questions);
  return {q:questions.length,l:lessons.length,skip};
}
