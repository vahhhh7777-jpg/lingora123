/* ---------- views: learning path, words, report, profile ---------- */
let notifOpen=false;
let langOpen=false,ptab='over',pgAnim=true,tab='home',flow='landing',dictQ='',dictF='',resetArm=false,wantScroll=false,themeSet=false;
const ob={step:0,anim:true};
const WHYS=['travel','work','study','family','fun'];
const adm={sub:'dash',open:{},pg:{},wiz:null,menu:false,users:[],prog:{},uq:'',loading:false,uerr:'',edit:null,delArm:'',busy:false,err:'',nav:{lang:'',course:'',unit:'',lesson:''}};
const vipBadge=()=>`<span class="vipbadge">${IC.crown}VIP</span>`;
const claimable=()=>QUESTS.filter(q=>questProg(q)>=q.n&&!qClaimed(q.id));
function ring(pct,size,label){
  const r=(size-12)/2,c=+(2*Math.PI*r).toFixed(1),off=+(c*(1-pct/100)).toFixed(1);
  return `<div class="ring" style="width:${size}px;height:${size}px" role="img" aria-label="${esc(label||pct+'%')}"><svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}"><circle cx="${size/2}" cy="${size/2}" r="${r}" class="rt"/><circle cx="${size/2}" cy="${size/2}" r="${r}" class="rv" style="--c:${c};--o:${off}" transform="rotate(-90 ${size/2} ${size/2})"/></svg><b>${pct}%</b></div>`;
}
const confetti=n=>'<div class="confetti" aria-hidden="true">'+Array.from({length:n||24},(_,i)=>`<i style="--x:${Math.round(Math.random()*100)}%;--c:${['#1677FF','#FF922B','#FFB15C','#3295FF','#35D07F'][i%5]};--d:${(Math.random()*.7).toFixed(2)}s;--r:${Math.round(Math.random()*90)}deg"></i>`).join('')+'</div>';
const TROPHY='<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M18 8h28v14a14 14 0 0 1-28 0z" fill="currentColor"/><path d="M18 12H8c0 10 4 16 12 18M46 12h10c0 10-4 16-12 18" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><rect x="28" y="34" width="8" height="10" fill="currentColor"/><rect x="20" y="46" width="24" height="8" rx="3" fill="currentColor"/></svg>';
const ago2=ts=>{const m=Math.round((Date.now()-ts)/60000);if(m<1)return t('justNow');if(m<60)return m+' '+t('minShort');const h=Math.round(m/60);if(h<24)return h+' '+t('hShort');return Math.round(h/24)+' '+t('dShort');};
function notifPanel(){
  const list=(S.notifs||[]);
  const rows=list.map(n=>`<div class="nrow ${n.read?'':'new'}">${gloro(n.mood||'happy',40)}<div><b>${esc(n.title)}</b>${n.body?`<span>${esc(n.body)}</span>`:''}<small>${esc(ago2(n.t))}</small></div></div>`).join('');
  return `<div class="pop-bg" data-a="popclose"><div class="pop-card" role="dialog" aria-modal="true" aria-label="${esc(t('notifT'))}" data-a="noop"><div class="pop-h"><h2>${t('notifT')}</h2><button class="iconb" data-a="popclose" aria-label="${esc(t('close'))}">${IC.x}</button></div>${rows||`<div class="empty">${gloro('sleep',84)}<span>${t('notifNone')}</span></div>`}</div></div>`;
}
function markAllRead(){if((S.notifs||[]).some(n=>!n.read)){ntMarkServer();S.notifs.forEach(n=>{n.read=true;});save();pushProgress();}}
function popups(){
  if(DLG)return dlgHtml();
  if(notifOpen)return notifPanel();
  if(!langOpen)return '';
  const cur=curCourse();
  const rows=courseCards().map(c=>{const st=courseStats(c.id);return `<button class="lopt ${cur&&cur.id===c.id?'on':''}" data-a="course" data-id="${esc(c.id)}"><span class="code">${c.flag}</span><span class="lr-t"><b>${esc(c.name[S.lang])}</b><small>${esc(c.note[S.lang])}${c.level?' · '+esc(c.level):''}</small><span class="bar mini"><i style="width:${st.pct}%"></i></span></span><span class="pc">${st.pct}%</span></button>`;}).join('');
  return `<div class="pop-bg" data-a="popclose"><div class="pop-card" role="dialog" aria-modal="true" aria-label="${esc(t('chooseLang'))}" data-a="noop"><div class="pop-h"><h2>${t('chooseLang')}</h2><button class="iconb" data-a="popclose" aria-label="${esc(t('close'))}">${IC.x}</button></div><div class="lopts">${rows||`<div class="empty">${gloro('curious',96)}<span>${t('noCourse')}</span></div>`}</div><button class="btn btn-ghost popfoot" data-a="tab" data-v="courses">${t('courses')}</button></div></div>`;
}
function starRow(n,cls){let h='';for(let i=0;i<3;i++)h+=IC.star.replace('<svg','<svg class="'+(i<n?'on':'')+'"');return `<div class="${cls}" aria-label="${n}/3">${h}</div>`;}
function lessonLabel(f){return tx(f.lesson.title)||t('l0')+' '+(f.j+1);}
function sampleBanner(){const c=curCourse();return c&&c.draft?`<div class="banner">${t('draftBanner')}</div>`:c&&!c.real?`<div class="banner">${t('sampleBanner')}</div>`:'';}
const loading=()=>`<div class="gl-load" role="status">${gloro('sleep',84)}<span>${esc(t('loadingT'))}</span></div>`;
const skel=n=>Array.from({length:n},()=>'<div class="skel" aria-hidden="true"></div>').join('');
const netBanner=()=>MODE==='cloud'&&!A.net&&!A.booting?`<div class="banner err">${t('netErr')} <button class="link" data-a="reload">${t('retry')}</button></div>`:'';
function learnView(){
  if(A.booting)return `<div role="status" aria-label="${esc(t('loadingT'))}">${loading()}${skel(3)}</div>`;
  let h=netBanner()+sampleBanner();
  if(!UNITS.length)return h+`<div class="empty">${gloro('curious',96)}<span>${t('noCourse')}</span></div>`;
  h+=learnTools();
  const XS=[0,-44,-64,-40,0,44,64,40];
  const POSES=[['wave','pathHi'],['explaining','pathRev'],['thinking','pathThink'],['proud','pathGo'],['excited','pathYou']];
  UNITS.forEach(u=>{
    const title=esc(u.t[S.lang]||u.t.hy||u.t.en),desc=esc(u.d[S.lang]||u.d.hy||u.d.en||'');
    if(u.locked){
      h+=`<section class="unit"><div class="uhead"><div><h2>${title}${vipBadge()}</h2><p>${desc}</p></div></div><div class="lockedu">${IC.lock}<span>${t('vipLocked')}</span><button class="sbtn" data-a="vipinfo">${t('vipHow')}</button></div></section>`;
      return;
    }
    const dn=FLAT.filter(f=>f.u===u&&S.done[f.id]).length;
    const ui=UNITS.indexOf(u),pose=POSES[ui%POSES.length],side=ui%2?'l':'r';
    h+=`<section class="unit"><div class="uhead"><div><small class="useg">${t('unitWord')} ${ui+1}</small><h2>${title}${u.vip?vipBadge():''}</h2><p>${desc}</p></div><span class="ucount">${dn}/${u._n||0}</span></div><div class="path">`;
    const ul=FLAT.filter(f=>f.u===u);
    ul.forEach((f,k)=>{
      const i=u._fi+k,st=stateOf(i),stars=S.done[f.id]||0,x=XS[k%4];
      const ch=ul.length>=3&&k===ul.length-1,aud=(QBY[f.id]||[]).some(q=>q.type==='listen'||q.type==='speak');
      const icon=st==='lock'?IC.lock:st==='done'?IC.check:ch?IC.bolt:IC.star;
      if(k===2&&ul.length>=3)h+=`<div class="mrow ${side}" aria-hidden="true">${gloro(pose[0],104)}<div class="mbub">${t(pose[1])}</div></div>`;
      h+=`<div class="nodewrap" style="--x:${x}px">${st==='open'?`<div class="bubble">${t('start')}</div><span class="buddy ${x>0?'l':'r'}" aria-hidden="true">${gloro('encouraging',60)}</span>`:''}
        <button class="node st-${st} ${ch?'chal':''}" data-a="node" data-i="${i}" aria-label="${esc(lessonLabel(f))}${ch?' · '+esc(t('unitNode')):''}">${icon}${aud&&st!=='lock'?`<span class="nbadge">${IC.speaker}</span>`:''}</button>
        <div class="nlabel">${esc(lessonLabel(f))}${ch?`<small class="chtag">${esc(t('unitNode'))}</small>`:''}</div>${st==='done'?starRow(stars,'stars'):''}</div>`;
    });
    h+=`<div class="nodewrap trophy ${u._n&&dn===u._n?'on':''}"><span class="troph" aria-label="${esc(t('unitDone'))}">${TROPHY}<b>${UNITS.indexOf(u)+1}</b></span></div></div></section>`;
  });
  return h;
}
let dictU='',dictMax=60,dictSort='az';
/* A word enters the learner's own list only once it was met: its lesson is finished, or it was practised, missed, saved or marked. */
const wordKey=w=>w.en;
function wordState(w){
  const k=wordKey(w),e=S.srs&&S.srs[k];
  if(S.lw&&S.lw[k]||(e&&e.b>=4))return 'learned';
  if(S.miss&&(S.miss[k]||S.miss[w.hy])||(e&&e.b>0&&e.d<=today()))return 'review';
  if(e&&e.b>0)return 'learning';
  return 'new';
}
const wordMet=w=>!!(S.done[w.lid]||(S.srs&&S.srs[wordKey(w)])||(S.miss&&(S.miss[w.en]||S.miss[w.hy]))||S.fav[w.en]||(S.lw&&S.lw[w.en]));
const WORD_ORDER={review:0,new:1,learning:2,learned:3};
const DICT_FILTERS=[['','dAll'],['new','dNew'],['learning','dLearning'],['review','dReview'],['learned','dLearned'],['fav','favOnly']];
function dictData(){
  const q=norm(dictQ),all=[];
  UNITS.forEach(u=>{
    if(u.locked||(dictU&&u.id!==dictU))return;
    u.words.concat(u.sents).forEach(w=>{if(wordMet(w))all.push(Object.assign({u,sent:u.sents.indexOf(w)>=0,st:wordState(w)},w));});
  });
  const counts={'':all.length,fav:0};
  all.forEach(w=>{counts[w.st]=(counts[w.st]||0)+1;if(S.fav[w.en])counts.fav++;});
  const rows=all.filter(w=>(!q||norm(w.en).includes(q)||norm(w.hy).includes(q))&&(!dictF||(dictF==='fav'?S.fav[w.en]:w.st===dictF)));
  rows.sort(dictSort==='prog'?(x,y)=>WORD_ORDER[x.st]-WORD_ORDER[y.st]||x.en.localeCompare(y.en):(x,y)=>x.en.localeCompare(y.en));
  return {rows,counts};
}
function dictList(){
  const {rows}=dictData();
  const row=w=>`<div class="row st-${w.st}"><button class="spk fav ${S.fav[w.en]?'on':''}" data-a="fav" data-t="${esc(w.en)}" aria-pressed="${!!S.fav[w.en]}" aria-label="${esc(t('favB'))}">${S.fav[w.en]?'★':'☆'}</button><button class="spk" data-a="say" data-t="${esc(w.en)}" aria-label="Listen">${IC.speaker}</button><div class="row-t"><b lang="${tl()}">${esc(w.en)}</b><span>${esc(w.hy)}</span>${w.pron||w.pos?`<small>${w.pron?'/'+esc(w.pron)+'/':''}${w.pron&&w.pos?' · ':''}${esc(w.pos||'')}</small>`:''}${w.ex?`<small lang="${tl()}">${esc(w.ex)}</small>`:''}<small class="wst">${esc(t('d'+w.st.charAt(0).toUpperCase()+w.st.slice(1)))} · ${esc(tx(w.u.t))}</small></div><button class="wl ${w.st==='learned'?'on':''}" data-a="wlearn" data-t="${esc(w.en)}" aria-pressed="${w.st==='learned'}" aria-label="${esc(t('markLearned'))}" title="${esc(t('markLearned'))}">${IC.check}</button></div>`;
  if(!rows.length){
    const none=!dictData().counts[''];
    return `<div class="empty">${gloro(none?'curious':'confused',96)}<span>${esc(t(none?'dEmpty':'none'))}</span>${none?`<button type="button" class="btn btn-purple" data-a="tab" data-v="learn">${esc(t('startLearn'))}</button>`:''}</div>`;
  }
  const shown=rows.slice(0,dictMax);
  return `<p class="note dcount">${shown.length}/${rows.length}</p>`+shown.map(row).join('')+(rows.length>shown.length?`<button class="btn btn-ghost dmore" data-a="dmore">+60</button>`:'');
}
function wordsView(){
  const us=UNITS.filter(u=>!u.locked),{counts}=dictData();
  const rev=counts.review||0;
  return `<div class="seg dseg dseg-w">${DICT_FILTERS.map(x=>`<button class="${dictF===x[0]?'on':''}" data-a="dfilter" data-v="${x[0]}">${t(x[1])}<small>${counts[x[0]||'']||0}</small></button>`).join('')}</div><div class="dtools"><input id="dq" class="search" type="search" value="${esc(dictQ)}" placeholder="${esc(t('search'))}" autocomplete="off" aria-label="${esc(t('search'))}"><button class="btn btn-ghost dsort" data-a="dsort" aria-label="${esc(t('dSort'))}">${esc(t(dictSort==='az'?'dSortAz':'dSortProg'))}</button></div>${rev&&canPractice()?`<button class="rec" data-px="cards"><span class="ri">${IC.bolt}</span><span><b>${esc(t('dReviewCta').replace('{n}',rev))}</b></span></button>`:''}<div class="chiprow">${us.length>1?`<button class="fchip ${dictU?'':'on'}" data-a="dunit" data-v="">${esc(t('allW'))}</button>`+us.map(u=>`<button class="fchip ${dictU===u.id?'on':''}" data-a="dunit" data-v="${esc(u.id)}">${esc(tx(u.t))}</button>`).join(''):''}</div><div id="dlist">${dictList()}</div>`;
}
function vipHowHtml(){
  const price=(CFG.PRICE_TEXT&&(CFG.PRICE_TEXT[S.lang]||CFG.PRICE_TEXT.hy))||t('vipHowDefault');
  const link=CFG.CONTACT_URL?`<a class="btn btn-purple" href="${esc(CFG.CONTACT_URL)}" target="_blank" rel="noopener">${esc(CFG.CONTACT_LABEL||'Contact')}</a>`:'';
  return `<p class="note">${esc(price)}</p>${payPlansHtml()}${link}`;
}
/* Online payment buttons: only when config.js has ONLINE_PAYMENTS:true, the person is signed in, and a plan has a Stripe price.
   The server (create-checkout) re-checks everything; the browser only says WHICH plan. Plans are loaded once (never from inside a render loop). */
const PAYX={plans:null,busy:'',err:''};
function payOnline(){return CFG.ONLINE_PAYMENTS===true&&MODE==='cloud'&&!!A.user&&!!B&&typeof B.vipPlans==='function';}
function payPlansHtml(){
  if(!payOnline())return '';
  if(PAYX.plans===null){PAYX.plans=[];B.vipPlans().then(r=>{PAYX.plans=r||[];render();}).catch(()=>{PAYX.plans=[];});return '';}
  if(!PAYX.plans.length)return '';
  const btn=p=>`<button type="button" class="btn btn-purple" data-a="buyvip" data-v="${esc(p.id)}"${PAYX.busy?' disabled':''}>${esc(p.title&&(p.title[S.lang]||p.title.en)||p.id)} · ${(p.price_cents/100).toFixed(2)} ${esc(String(p.currency||'').toUpperCase())}${PAYX.busy===p.id?' …':''}</button>`;
  return `<div class="paybtns" style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">${PAYX.plans.map(btn).join('')}</div>${PAYX.err?`<p class="note" role="alert">${esc(PAYX.err)}</p>`:''}`;
}
function report(){
  const log=S.log||[];
  if(!log.length)return `<div class="empty">${gloro('thinking',96)}<span>${t('noData')}</span></div>`;
  const rec=log.slice(-20),avg=Math.round(rec.reduce((n,e)=>n+(e.acc||0),0)/rec.length);
  const cut=Date.now()-30*864e5,active=new Set(log.filter(e=>e.t>=cut).map(e=>dstr(new Date(e.t)))).size;
  const units=UNITS.filter(u=>!u.locked&&u._n).map(u=>{
    const dn=FLAT.filter(f=>f.u===u&&S.done[f.id]).length,p=Math.round(dn/u._n*100);
    return `<div class="urep"><div><span>${esc(u.t[S.lang]||u.t.hy)}</span><span>${dn}/${u._n}</span></div><div class="bar"><i style="width:${p}%"></i></div></div>`;
  }).join('');
  const all={};UNITS.forEach(u=>{if(!u.locked){u.words.concat(u.sents).forEach(w=>{all[w.en]=w.hy;if(!all[w.hy])all[w.hy]=w.en;});}});
  const weak=Object.keys(S.miss||{}).filter(k=>all[k]).sort((a,b)=>S.miss[b]-S.miss[a]).slice(0,5)
    .map(k=>`<div class="weak"><b lang="en">${esc(k)}</b><span>${esc(all[k])} · ×${S.miss[k]}</span></div>`).join('');
  return `<div class="tile-row"><div class="stat"><b>${avg}%</b><span>${t('avgAcc')}</span></div><div class="stat"><b>${active}</b><span>${t('activeDays')}</span></div><div class="stat"><b>${S.best||0}</b><span>${t('bestStreak')}</span></div></div>
   <section class="card"><h2>${t('byUnit')}</h2>${units}</section>
   <section class="card"><h2>${t('weak')}</h2>${weak||`<p class="note">${t('noWeak')}</p>`}</section>`;
}
function reportBlock(){
  if(!isVip())return `<section class="card"><h2>${IC.crown}${t('repLocked')}</h2><ul>${t('vipList').map(x=>`<li>${esc(x)}</li>`).join('')}</ul>${vipHowHtml()}</section>`;
  return `<div class="sec-h"><h2>${t('repTitle')}</h2></div>${report()}`;
}

const pwBox=(id,ac)=>`<span class="pwbox"><input id="${id}" type="password" autocomplete="${ac}"><button type="button" class="pweye" data-a="pwtoggle" aria-pressed="false" aria-label="${esc(t('showPw'))}">${IC.eye}</button></span>`;
function termsLabel(){
  const c=CFG||{},lnk=(u,k)=>/^https:\/\//i.test(u||'')?`<a href="${esc(u)}" target="_blank" rel="noopener noreferrer">${t(k)}</a>`:t(k);
  return t('agreePre')+' '+lnk(c.TERMS_URL,'termsL')+(c.PRIVACY_URL?' '+t('andW')+' '+lnk(c.PRIVACY_URL,'privacyL'):'');
}
function authCard(bare){
  const box=inner=>bare?`<div class="form">${inner}</div>`:`<section class="card">${inner}</section>`;
  if(A.recovery){
    return box(`<h2>${t('newPw')}</h2>${A.err?`<div class="msg err">${t('e_'+A.err)}</div>`:''}<form id="pwform" class="form"><label class="fld">${t('password')}<input id="np" type="password" autocomplete="new-password"></label><button class="btn btn-purple" type="submit">${t('setPw')}</button></form>`);
  }
  if(A.user){
    const p=A.profile||{};
    const st=p.is_admin?t('adminRole'):profVip(p)?(t('vipUntil')+' '+new Date(p.vip_until).toLocaleDateString()):t('free');
    return box(`<h2>${t('account')}</h2><div class="acc"><b>${esc(p.name||A.user.email)}</b><span>${esc(A.user.email)}</span><span>${profVip(p)?vipBadge()+' ':''}${esc(st)}</span></div><div class="acts"><button class="sbtn" data-a="signout">${t('signout')}</button></div>`);
  }
  const su=A.form==='signup';
  return box(`${bare?'':`<h2>${t('account')}</h2>`}<p class="note">${t('authWhy')}</p>
   ${A.err?`<div class="msg err">${t('e_'+A.err)}</div>`:''}${A.msg?`<div class="msg">${t('m_'+A.msg)}</div>`:''}
   <form id="authform" class="form" novalidate>
    ${su?`<label class="fld">${t('name')}<input id="nm" value="${esc(A.nm)}" autocomplete="name"></label>`:''}
    <label class="fld">${t('email')}<input id="em" type="email" value="${esc(A.em)}" autocomplete="email" inputmode="email" autocapitalize="none"></label>
    <label class="fld">${t('password')}${pwBox('pw',su?'new-password':'current-password')}</label>
    ${su?`<p class="note pwrule">${t('pwRule')}</p><label class="fld">${t('confirmPw')}${pwBox('pw2','new-password')}</label>
    <label class="chk"><input id="tm" type="checkbox" ${A.tm?'checked':''}><span>${termsLabel()}</span></label>`:''}
    <button class="btn btn-purple" type="submit" ${A.busy?'disabled':''}>${su?t('signup'):t('signin')}</button>
   </form>
   <button class="link" data-a="authmode">${su?t('haveAcc'):t('noAcc')}</button>${su?'':`<button class="link" data-a="forgot">${t('forgot')}</button>`}`);
}
function vipCard(){
  const on=profVip(A.profile);
  return `<section class="card" id="vipcard"><h2>${IC.crown}${t('vipWhat')}</h2><ul>${t('vipList').map(x=>`<li>${esc(x)}</li>`).join('')}</ul>${on?(MODE==='cloud'?`<p class="note">${t('vipOffline')}</p>`:''):`<h2 style="margin-top:4px">${t('vipHow')}</h2>${vipHowHtml()}`}</section>`;
}
const achCard=a=>{const on=S.ach&&S.ach[a.id];return `<div class="badge ${on?'on':'off'}"><span class="bi">${IC[a.ic]||IC.star}</span><b>${esc(tx(a.t))}</b><small>${esc(tx(a.d))}</small></div>`;};
function questTitle(q){return (q.title&&tx(q.title))||t('q_'+(q.type||q.id)).replace('{n}',q.n);}
function questCard(q){
  const p=questProg(q),done=p>=q.n,cl=qClaimed(q.id);
  const title=questTitle(q);
  return `<div class="quest ${cl?'done':''}"><div class="q-h"><span>${esc(title)}</span><span>${p}/${q.n}</span></div><div class="bar"><i style="width:${Math.round(p/q.n*100)}%"></i></div>${
    cl?`<span class="note" style="color:inherit">${t('claimed')} · +${q.r} XP</span>`
      :`<button class="sbtn" data-a="claim" data-id="${q.id}" ${done?'':'disabled'}>${done?t('claim')+' · ':''}+${q.r} XP</button>`}</div>`;
}

function homeSay(hasProg,g){
  const away=S.last?dayDiff(S.last,today()):0;
  if(!hasProg)return ['wave','new'];
  if(away>=3)return ['encouraging','back'];
  if(g>=S.goal)return ['celebrating','goal'];
  if(streakRisk()&&new Date().getHours()>=17)return ['surprised','risk'];
  return ['happy','welcome'];
}
const safeLink=u=>/^https:\/\//i.test(u||'')?u:'';
function bannersHtml(){
  const dis=S.dis||{};
  return CONTENT.filter(c=>(c.kind==='banner'||c.kind==='announcement')&&liveC(c)&&!dis[c.id]).slice(0,3).map(c=>{
    const lk=safeLink(c.link);
    return `<div class="promo ${c.kind}" role="region" aria-label="${esc(tx(c.title))}"><span class="promo-i">${c.kind==='banner'?IC.bolt:IC.bell}</span><div class="promo-t"><b>${esc(tx(c.title))}</b>${tx(c.body)?`<span>${esc(tx(c.body))}</span>`:''}${lk?`<a href="${esc(lk)}" target="_blank" rel="noopener noreferrer">${esc(t('seeAll'))}</a>`:''}</div><button class="iconb" data-a="dismiss" data-id="${esc(c.id)}" aria-label="${esc(t('dismiss'))}">${IC.x}</button></div>`;
  }).join('');
}
function statStrip(){
  const bl=boostLeft(),ev=G.multiplier&&G.multiplier.value>1&&(!G.multiplier.until||new Date(G.multiplier.until)>new Date());
  return `<section class="strip" aria-label="${esc(t('pt_stats'))}">
   <div class="sc ${streakRisk()?'risk':''}"><span class="si f">${IC.flame}</span><b data-count="${streakNow()}">${streakNow()}</b><small>${t('statStreak')}</small></div>
   <div class="sc"><span class="si b">${IC.bolt}</span><b data-count="${S.xp}">${S.xp}</b><small>XP</small></div>
   <div class="sc" title="${esc(t('freezeInfo'))}"><span class="si s">${IC.shield}</span><b>${S.freeze||0}</b><small>${t('statFreeze')}</small></div>
   <div class="sc"><span class="si l">${IC.trophy}</span><b>${esc(leagueName(myTier()))}</b><small>${t('leagueT')}</small></div></section>
   ${bl?`<div class="boostbar">${IC.bolt}<span>${t('boostBadge').replace('{n}',bl)}</span></div>`:''}${ev?`<div class="boostbar ev">${IC.bolt}<span>${esc(tx(G.multiplier.label)||t('eventBadge'))} ×${G.multiplier.value}</span></div>`:''}`;
}
function challengeCard(){
  const c=G.challenge;if(!c||!c.on||!(c.n>0))return '';
  const pr=chProg(),done=pr>=c.n,cl=chClaimed(),left=7-((new Date().getDay()+6)%7);
  const desc=t('chType_'+(c.type||'xp')).replace('{n}',c.n);
  return `<section class="card chal ${cl?'done':''}"><div class="q-h"><span>${IC.trophy}${esc(tx(c.title)||t('chT'))}</span><span>${pr}/${c.n}</span></div><p class="note">${esc(desc)} · ${esc(t('chEnds').replace('{n}',left))}</p><div class="bar"><i style="width:${Math.round(pr/c.n*100)}%"></i></div>${cl?`<span class="note" style="color:inherit">${t('claimed')} · +${c.r||0} XP</span>`:`<button class="sbtn" data-a="claimch" ${done?'':'disabled'}>${done?t('claim')+' · ':''}+${c.r||0} XP</button>`}</section>`;
}
function recommended(){
  const out=[];
  const ni=FLAT.findIndex((f,i)=>stateOf(i)==='open');
  if(ni>=0)out.push({i:ni,tag:t('recNext'),ic:IC.star});
  FLAT.map((f,i)=>({f,i})).filter(x=>S.done[x.f.id]&&S.done[x.f.id]<3).sort((a,b)=>S.done[a.f.id]-S.done[b.f.id]).slice(0,2).forEach(x=>out.push({i:x.i,tag:t('recImprove'),ic:IC.check}));
  return out.slice(0,3);
}
function recHtml(){
  const rs=recommended();let h=rs.map(r=>{const f=FLAT[r.i];return `<button class="rec" data-a="node" data-i="${r.i}"><span class="ri">${r.ic}</span><span class="rt"><b>${esc(lessonLabel(f))}</b><small>${esc(r.tag)} · ${esc(tx(f.u.t))}</small></span><i class="go">${IC.next}</i></button>`;}).join('');
  if(canPractice()){const due=Object.keys(S.miss||{}).length;h+=`<button class="rec" data-a="practice"><span class="ri">${IC.heart}</span><span class="rt"><b>${t('practice')}</b><small>${due?t('recWeak')+' · '+due:t('recReview')}</small></span><i class="go">${IC.next}</i></button>`;}
  return h;
}
function lbPreview(){
  const rows=boardRows();if(rows.length<2)return '';
  const top=rows.slice(0,3),me=rows.find(r=>r.me),list=me&&top.indexOf(me)<0?top.concat([me]):top;
  return `<section class="card"><div class="sec-h"><h2>${t('lbPrev')} · ${esc(leagueName(myTier()))}</h2><button class="link" data-a="gotorank">${t('seeAll')}</button></div><div class="lb">${list.map(r=>`<div class="lb-row ${r.me?'me':''}"><span class="rk">${r.rk}</span>${avatar(r.name,'',r.me)}<span class="nm">${esc(r.name)}${r.me?' ('+esc(t('you'))+')':''}</span><span class="xp">${r.xp} XP</span></div>`).join('')}</div></section>`;
}
function achPreview(){
  const all=allAch(),got=all.filter(a=>S.ach&&S.ach[a.id]),next=all.filter(a=>!(S.ach&&S.ach[a.id])),show=got.slice(-3).concat(next.slice(0,Math.max(1,4-Math.min(3,got.length))));
  return `<section class="card"><div class="sec-h"><h2>${t('achPrev')} · ${got.length}/${all.length}</h2><button class="link" data-a="gotoach">${t('seeAll')}</button></div><div class="badges mini">${show.map(achCard).join('')}</div></section>`;
}
function rankView(){
  const rows=boardRows(),me=rows.find(r=>r.me),top=rows.length>=3?rows.slice(0,3):[];
  const pod=r=>`<div class="pod p${r.rk} ${r.me?'me':''}"><span class="medal">${r.rk}</span>${avatar(r.name,'',r.me)}<span class="nm">${esc(r.name)}</span><span class="xp">${r.xp} XP</span></div>`;
  let list=top.length?rows.slice(3,23):rows.slice(0,20);
  if(me&&top.indexOf(me)<0&&list.indexOf(me)<0)list=list.concat([me]);
  const lg=leagueNames().map((n,i)=>`<span class="lgchip ${i===myTier()?'on':''} l${i}">${esc(tx(n))}</span>`).join('');
  return `<div class="rank-h">${gloro(me&&me.rk===1?'celebrating':'encouraging',76)}<div><h1 class="ph">${t('board')}</h1><p class="note">${t('boardNote')}</p></div></div>
   <section class="card lgcard"><div class="lgchips" role="img" aria-label="${esc(t('leagueT'))}: ${esc(leagueName(myTier()))}">${lg}</div><p class="note">${esc(A.league&&P4()?t('leagueRule').replace('{p}',A.league.promote_xp).replace('{d}',A.league.demote_xp)+' · '+t('leagueWeek')+': '+A.league.week_xp:t('leagueNote').replace('{p}',G.leagues.promote).replace('{d}',G.leagues.demote))}</p></section>
   ${top.length?`<div class="podium">${[top[1],top[0],top[2]].map(pod).join('')}</div>`:''}
   ${rows.length<2?`<div class="say">${gloro('curious',56)}<span>${t('leagueOnly')}</span></div><button type="button" class="btn btn-ghost rk-act" data-a="tab" data-v="friends">${esc(t('friends'))}</button>`:''}<div class="lb" role="list">${list.map(r=>`<div class="lb-row ${r.me?'me':''}" role="listitem"><span class="rk">${r.rk}</span>${avatar(r.name,'',r.me)}<span class="nm">${esc(r.name)}${r.me?' ('+esc(t('you'))+')':''}</span><span class="xp">${r.xp} XP</span></div>`).join('')}</div>`;
}
function courseCard(c){
  const st=courseStats(c.id),on=curCourse().id===c.id;
  return `<div class="course ${on?'on':''}">${on?`<span class="selmark">${IC.check}</span>`:''}<div class="course-h"><span class="code">${c.flag}</span><div style="min-width:0"><b>${esc(c.name[S.lang])}</b><div class="note">${esc(c.note[S.lang])}</div></div></div>
   <div class="meta">${c.level?`<span class="tag">${esc(c.level)}</span>`:''}<span class="tag">${t('diff_'+c.diff)}</span>${((c.raw&&c.raw.categories)||[]).slice(0,3).map(x=>`<span class="tag">${esc(x)}</span>`).join('')}<span class="tag">≈ ${c.months} ${t('months')}</span><span class="tag ${c.draft?'draft':c.real?'full':'sample'}">${t(c.draft?'draftTag':c.real?'fullCourse':'sampleCourse')}</span></div>
   ${courseHealth(CAT,c.id).verified<courseHealth(CAT,c.id).published?`<p class="note">${t('unverifiedT')}</p>`:''}
   <div class="goal-h"><span>${t('progress')} · ${st.done}/${st.total}</span><span>${st.pct}%</span></div><div class="bar"><i style="width:${st.pct}%"></i></div>
   <button class="btn ${on?'btn-ghost':'btn-purple'}" data-a="course" data-id="${c.id}">${on?t('current'):(st.done?t('continue'):t('startCourse'))}</button></div>`;
}
function coursesView(){
  return `<h1 class="ph">${t('courses')}</h1><p class="note" style="margin:-4px 0 14px">${t('coursesSub')}</p><div class="cgrid">${courseCards().map(courseCard).join('')}</div><p class="note" style="margin-top:14px">${t('estNote')}</p>`;
}
function weekChart(){
  const days=[];
  for(let i=6;i>=0;i--){const d=new Date(Date.now()-i*864e5);days.push({k:dstr(d),w:d.getDay(),xp:0});}
  (S.log||[]).forEach(e=>{const d=days.find(x=>x.k===dstr(new Date(e.t)));if(d)d.xp+=e.xp;});
  const mx=Math.max(S.goal,...days.map(d=>d.xp),1);
  return `<div class="bars">${days.map((d,i)=>`<div class="bcol ${i===6?'now':''}"><span class="bv">${d.xp}</span><i style="height:${Math.round(d.xp/mx*100)}%"></i><span class="bd">${esc(t('wd')[d.w])}</span></div>`).join('')}</div>`;
}
function lessonName(id){const f=FLAT.find(x=>x.id===id);return f?(f.u.t[S.lang]||f.u.t.hy)+' · '+lessonLabel(f):id;}
function xpHistCard(){
  if(!ECON())return '';
  if(!A.xph&&!A.xphBusy){A.xphBusy=true;B.xpHistory(30).then(r=>{A.xph=r;A.xphBusy=false;if(tab==='me')render();}).catch(()=>{A.xph=[];A.xphBusy=false;});}
  const rows=(A.xph||[]).map(e=>{
    let ds='';try{ds=new Date(e.created_at).toLocaleString(S.lang==='hy'?'hy-AM':'en-GB',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});}catch(x){ds=e.day;}
    const k=/^(lesson|practice|streak|quest)$/.test(e.kind)?'k_'+e.kind:'k_other',nm=e.kind==='lesson'&&e.ref?lessonName(e.ref):t(k);
    return `<div class="hist"><div><b>${esc(nm)}</b><span>${esc(ds)} · ${esc(t(k))}</span></div><b class="x">${e.amount>0?'+':''}${e.amount} XP</b></div>`;
  }).join('');
  return `<section class="card" id="xph"><h2>${t('xpHist')}</h2><p class="note">${esc(t('srvXp'))}</p>${A.xph?(rows||`<p class="note">${esc(t('xpNone'))}</p>`):`<div class="skel" aria-hidden="true"></div>`}</section>`;
}
function historyHtml(n){
  const log=(S.log||[]).slice(-(n||8)).reverse();
  if(!log.length)return '';
  return log.map(e=>{
    let ds='';try{ds=new Date(e.t).toLocaleDateString(S.lang==='hy'?'hy-AM':'en-GB',{day:'numeric',month:'short'});}catch(x){ds=dstr(new Date(e.t));}
    return `<div class="hist"><div><b>${esc(e.id==='practice'?t('practice'):lessonName(e.id))}</b><span>${esc(ds)} · ${e.acc}%</span></div><b class="x">+${e.xp} XP</b></div>`;
  }).join('');
}
function streakCal(){
  const have={};(S.log||[]).forEach(e=>{have[dstr(new Date(e.t))]=1;});
  let h='';
  for(let i=13;i>=0;i--){const d=new Date(Date.now()-i*864e5),k=dstr(d);h+=`<span class="cd ${have[k]?'on':''} ${i===0?'now':''}" title="${esc(k)}">${d.getDate()}</span>`;}
  return `<div class="cal" role="img" aria-label="${esc(t('streakHist'))}">${h}</div><p class="note">${t('streak')}: ${streakNow()} · ${t('bestStreak')}: ${S.best||0}</p>`;
}

const totalWords=()=>FLAT.reduce((n,f)=>n+(QBY[f.id]||[]).filter(q=>q.type==='intro').length,0);
function profileView(){
  const earned=allAch().filter(a=>S.ach&&S.ach[a.id]).length;
  const tabs=[['over','pt_over','user'],['stats','pt_stats','chart'],['ach','pt_ach','award'],['mist','pt_mist','alert'],['set','pt_set','sliders']];
  const tabsBar=`<div class="seg tabs ptabs p2-tabs" role="tablist" aria-label="${esc(t('pt_over'))}">${tabs.map(x=>`<button role="tab" aria-selected="${ptab===x[0]}" aria-pressed="${ptab===x[0]}" data-a="ptab" data-v="${x[0]}">${LI(x[2])}<span>${esc(t(x[1]))}</span></button>`).join('')}</div>`;
  let body='';
  if(ptab==='ach'){
    body=`<div class="say">${gloro(earned?'celebrating':'encouraging',56)}<span>${earned}/${allAch().length} · ${t('ach')}</span></div><div class="badges">${allAch().map(achCard).join('')}</div>`;
  }else if(ptab==='mist'){
    body=mistakesView();
  }else if(ptab==='set'){
    body=settingsPage()+(A.user?`<section class="p2-sec"><div class="p2-list"><button class="p2-row" data-a="signout"><span class="p2-ic">${LI('logout')}</span><span class="p2-tx"><b>${esc(t('signout'))}</b></span>${LI('chev')}</button></div></section>`:'');
  }else if(ptab==='stats'){
    body=`${recordsCard()}
     <section class="card"><h2>${t('weekly')}</h2>${weekChart()}</section>
     <section class="card"><h2>${t('streakHist')}</h2>${streakCal()}</section>
     ${(S.log||[]).length?`<section class="card"><h2>${t('history')}</h2><div>${historyHtml(6)}</div></section>`:''}
     ${xpHistCard()}
     ${reportBlock()}`;
  }else{
    body=profileOverview();
  }
  return `${profileHero()}
  ${MODE==='demo'?`<div class="banner">${t('demo')}</div>`:''}${tabsBar}<div class="stack p2-prof">${body}</div>`;
}
function profileOverview(){
  const c=curCourse(),cs=c?courseStats(c.id):{done:0,total:0,pct:0},p=A.profile||{},rec=S.rv||{},px=pxPx();
  const doneL=FLAT.filter(f=>S.done[f.id]).length;
  const cloud=showGems();
  const tile=(ic,cls,v,l)=>`<div class="p2-stat ${cls}"><span class="p2-si">${LI(ic)}</span><b>${v}</b><small>${esc(l)}</small></div>`;
  const log=S.log||[],rl=log.slice(-20),acc=rl.length?Math.round(rl.reduce((n,e)=>n+(e.acc||0),0)/rl.length):null;
  const stats=`<section class="p2-sec" aria-label="${esc(t('pt_stats'))}"><div class="p2-stats">
    ${tile('star','xp',nfmt(S.xp),t('totalXp'))}
    ${tile('flame','fire',streakNow(),t('streak'))}
    ${cloud?tile('gem','gem',nfmt(S.gems||0),t('gems')):''}
    ${tile('check','ok',doneL+'/'+FLAT.length,t('doneL'))}
    ${tile('book','',countWords(),t('learned'))}
    ${acc!=null?tile('target','',acc+'%',t('avgAcc')):tile('trophy','',Math.max(S.best||0,streakNow()),t('bestStreak'))}
  </div></section>`;
  const lvl=(px.cefr||'').trim();
  const prog=c?`<section class="p2-card"><div class="pg-row"><h2>${esc(t('learnProg'))}</h2><span>${cs.pct}%</span></div>
    <p class="note"><span class="p2-flag">${c.flag}</span> ${esc(c.name[S.lang])}${c.level?' · '+esc(c.level):''}${lvl?' · '+esc(t('pr_cefr'))+' '+esc(lvl):''}</p>
    <div class="bar purple" role="img" aria-label="${cs.pct}%"><i style="width:${cs.pct}%"></i></div>
    <div class="mini"><div><b>${cs.done}/${cs.total}</b><small>${t('doneL')}</small></div><div><b>${rec.t||0}</b><small>${esc(pt('rvSumRev'))}</small></div><div><b>${rec.t?Math.round((rec.o||0)/rec.t*100)+'%':'—'}</b><small>${esc(pt('rvSumAcc'))}</small></div></div></section>`:'';
  const all=allAch(),got=all.filter(a=>S.ach&&S.ach[a.id]);
  const ach=got.length?`<section class="p2-card"><div class="sec-h"><h2>${esc(t('achPrev'))} · ${got.length}/${all.length}</h2><button class="link" data-a="gotoach">${t('seeAll')}</button></div><div class="badges mini">${got.slice(-4).map(achCard).join('')}</div></section>`:'';
  const vip=profVip(p),adm=!!p.is_admin;
  const vipCard=A.user&&!adm?`<section class="p2-card p2-vip ${vip?'on':''}"><span class="p2-ic">${LI('crown')}</span><div><h2>${vip?esc(t('vipOn')):esc(t('vipOff'))}</h2><p class="note">${vip?esc(t('vipUntil')+' '+new Date(p.vip_until).toLocaleDateString()):esc(t('vipPitch'))}</p></div></section>`:'';
  const row=(ic,l,act,v)=>`<button class="p2-row" data-a="${act}"${v?` data-v="${v}"`:''}><span class="p2-ic">${LI(ic)}</span><span class="p2-tx"><b>${esc(l)}</b></span>${LI('chev')}</button>`;
  const cloudOk=MODE==='cloud'&&A.user;
  const links=`<section class="p2-sec"><h2>${esc(t('pAccount'))}</h2><div class="p2-list">
    ${A.user?`<div class="p2-row static"><span class="p2-ic">${LI('mail')}</span><span class="p2-tx"><b>${esc(A.user.email||'')}</b><small>${esc(t('pEmail'))}</small></span></div>`:''}
    ${row('pencil',t('pEdit'),'pedit')}${row('book',t('words'),'tab','words')}
    ${row('trophy',t('rank'),'tab','rank')}${cloudOk?row('users',t('friends'),'tab','friends')+row('map',t('world'),'tab','world')+row('bag',t('shop'),'tab','shop'):''}
    ${row('settings',t('pt_set'),'ptab','set')}
    ${isStaff()?row('shield',t('admin'),'tab','admin'):''}
    ${A.user?row('logout',t('signout'),'signout'):MODE!=='local'?row('user',t('signin'),'signinfirst','me'):''}
  </div></section>`;
  return stats+prog+ach+vipCard+links;
}
Object.assign(UI.hy,{pt_over:'Ակնարկ',pAccount:'Հաշիվ',pEmail:'Էլ. փոստ',vipOn:'VIP անդամ',vipOff:'VIP չկա',vipPitch:'VIP-ով բացվում են բոլոր դասերը, բացառիկ հնարավորություններ և ամենօրյա բոնուս։'});
Object.assign(UI.en,{pt_over:'Overview',pAccount:'Account',pEmail:'Email',vipOn:'VIP member',vipOff:'Not VIP',vipPitch:'VIP unlocks every lesson, extra features and a daily bonus.'});


Object.assign(UI.hy,{diff_beginner:'Սկսնակ',diff_elementary:'Տարրական',diff_intermediate:'Միջին',diff_upper_intermediate:'Միջինից բարձր',diff_advanced:'Առաջադեմ'});
Object.assign(UI.en,{diff_beginner:'Beginner',diff_elementary:'Elementary',diff_intermediate:'Intermediate',diff_upper_intermediate:'Upper intermediate',diff_advanced:'Advanced'});
