/* ---------- lesson completion screen (view only) ----------
   Everything shown here is read from the finished lesson object L (filled by award() from local state or the server's answer).
   Nothing in this file awards XP / gems, writes progress or calls the server: rendering it any number of times is harmless. */
Object.assign(UI.hy,{
 dcT_perfect:'Կատարյալ դաս։',dcT_great:'Գերազանց աշխատանք։',dcT_good:'Հիանալի առաջընթաց։',dcT_base:'Դասն ավարտված է։',dcT_course:'Դասընթացն ավարտված է։',
 dcS_perfect:'Ոչ մի սխալ՝ երեք աստղ։',dcS_great:'Շատ բան արդեն ամրացել է։',dcS_good:'Սխալները սովորելու մասն են. նայիր դրանք ներքևում։',dcS_base:'Ամեն դաս քեզ ավելի ուժեղ է դարձնում։',dcS_course:'Դու անցար այս դասընթացի բոլոր դասերը։',
 dcRewards:'Վաստակածդ',dcXp:'XP',dcGems:'Գոհար',dcStars:'Աստղեր',dcMult:'XP բազմապատկիչ',dcNoRew:'Այս անգամ պարգևներ չեն գրանցվել։',dcPrevNote:'Նախադիտում. ոչինչ չի պահվում։',
 dcPerf:'Արդյունքներդ',dcAtt:'Պատասխաններ',dcOk:'Ճիշտ',dcBad:'Սխալ',dcDoneS:'Ավարտված է',
 dcLearn:'Ինչ սովորեցիր',dcWords:'Նոր բառեր',dcEx:'Օրինակներ',dcObj:'Նպատակներ',dcGram:'Քերականություն',dcMore:'ևս {n}',
 dcMist:'Սխալների վերանայում',dcYou:'Քո պատասխանը',dcRight:'Ճիշտ պատասխանը',dcMistB:'Վերանայել իմ սխալները',dcWordsB:'Կրկնել բառերը',dcSumB:'Դասի ամփոփումը',dcPathB:'Ուսումնական ուղի',
 dcNext:'Հաջորդ քայլը',dcNextU:'Անցնել հաջորդ բաժնին',dcNextMist:'Նախ կրկնիր սխալներդ',dcNextMistS:'Սխալներից սովորելը ամենաարագ ճանապարհն է։',dcNextPath:'Վերադառնալ ուղի',dcNextPathS:'Ընտրիր, թե ինչ անել հետո։',dcCourses:'Ընտրել հաջորդ դասընթացը',dcCoursesS:'Սկսիր նոր լեզու կամ մակարդակ։',
 dcCourseStat:'{n} դաս ավարտված · {s}/{m} աստղ',dcSaveRetry:'Փորձել նորից',dcErrKeep:'Այս դասի արդյունքը դեռ պահված չէ։ Փորձիր նորից, նախքան դուրս գալը։',dcSaved:'Պահվում է…'});
Object.assign(UI.en,{
 dcT_perfect:'Perfect lesson!',dcT_great:'Excellent work!',dcT_good:'Amazing progress!',dcT_base:'Lesson completed!',dcT_course:'Course completed!',
 dcS_perfect:'No mistakes at all: three stars.',dcS_great:'A lot of this has already stuck.',dcS_good:'Mistakes are part of learning. Have a look at them below.',dcS_base:'Every lesson makes you stronger.',dcS_course:'You have finished every lesson in this course.',
 dcRewards:'What you earned',dcXp:'XP',dcGems:'Gems',dcStars:'Stars',dcMult:'XP multiplier',dcNoRew:'No rewards were recorded this time.',dcPrevNote:'Preview: nothing is saved.',
 dcPerf:'Your performance',dcAtt:'Answers',dcOk:'Correct',dcBad:'Incorrect',dcDoneS:'Completed',
 dcLearn:'What you learned',dcWords:'New words',dcEx:'Examples',dcObj:'Goals',dcGram:'Grammar',dcMore:'{n} more',
 dcMist:'Mistake review',dcYou:'Your answer',dcRight:'Correct answer',dcMistB:'Review my mistakes',dcWordsB:'Review vocabulary',dcSumB:'Lesson summary',dcPathB:'Learning path',
 dcNext:'Next step',dcNextU:'Continue to the next unit',dcNextMist:'Review your mistakes first',dcNextMistS:'Learning from mistakes is the fastest way forward.',dcNextPath:'Back to the learning path',dcNextPathS:'Choose what to do next.',dcCourses:'Choose your next course',dcCoursesS:'Start a new language or level.',
 dcCourseStat:'{n} lessons completed · {s}/{m} stars',dcSaveRetry:'Try again',dcErrKeep:'This lesson’s result is not saved yet. Try again before leaving.',dcSaved:'Saving…'});

const dcFill=(s,o)=>{Object.keys(o).forEach(k=>{s=s.replace('{'+k+'}',o[k]);});return s;};
/* a short, readable text for a question step (only what the step really contains) */
function dcQ(s){
  const q=s.prompt||(s.before!=null?s.before+' … '+(s.after||''):'')||s.text||s.speak||s.passage||s.en||s.ans||'';
  return String(q).replace(/\s+/g,' ').trim().slice(0,160);
}
function dcGiven(s){
  try{
    if(s.k==='build')return L.ans.map(i=>s.tiles[i]).join(' ');
    if(s.k==='type'||s.k==='listen_type'||s.k==='write'||s.k==='speak')return String(L.typed||'');
    if(L.sel!=null&&s.opts)return String(s.opts[L.sel]==null?'':s.opts[L.sel]);
  }catch(e){}
  return '';
}
/* called by the runner on a wrong answer: remember the first miss per question for this lesson's review (display only) */
function dcMiss(s,given,rightOverride){
  if(!L||L.preview||!s)return;
  const w=L.wrong=L.wrong||[],id=s.id||s.key||dcQ(s);
  if(!id||w.some(x=>x.id===id))return;
  const q=dcQ(s),a=String(rightOverride!=null?rightOverride:(s.k==='build'?(s.sent||''):(s.ans==null?'':s.ans)));
  if(!q||!a)return;
  w.push({id,q,you:String(given||'').slice(0,160),right:a.slice(0,160),expl:String(s.expl||'')});
}
/* vocabulary the learner really met in this lesson */
function dcVocab(){
  const seen={},out=[];
  (L.steps||[]).slice(0,L.base||0).forEach(s=>{if(s&&s.k==='intro'&&s.en&&!seen[s.en]){seen[s.en]=1;out.push(s);}});
  return out;
}
const dcLines=x=>String(x||'').split('\n').map(v=>v.trim()).filter(Boolean);
function dcTier(){
  const miss=L.attempts-L.correct;
  if(L.courseDone)return 'course';
  if(!L.practice&&L.attempts>0&&miss===0&&L.stars>=3)return 'perfect';
  if(L.attempts>0&&L.acc>=90)return 'great';
  if(L.attempts>0&&L.acc>=60)return 'good';
  return 'base';
}
/* the single most useful next action, from the learner's real state */
function dcPlan(){
  const bad=(L.wrong||[]).length,miss=L.attempts-L.correct,first=FLAT.findIndex((f,k)=>stateOf(k)==='open');
  let nxt=-1;
  if(!L.practice&&L.idx>=0&&FLAT[L.idx+1]&&stateOf(L.idx+1)==='open')nxt=L.idx+1;else nxt=first;
  const goNext=nxt>=0?{k:'next',i:nxt,id:FLAT[nxt].id,label:FLAT[nxt].u!==(FLAT[L.idx]||{}).u&&!L.practice&&L.idx>=0?t('dcNextU'):t('nextL'),desc:lessonName(FLAT[nxt].id)}:null;
  const mist=bad?{k:'mist',label:t('dcNextMist'),desc:t('dcNextMistS')}:null;
  if(L.courseDone)return {main:{k:'courses',label:t('dcCourses'),desc:t('dcCoursesS')},alt:mist};
  if(mist&&(miss>=3||L.acc<60)||(mist&&!goNext))return {main:mist,alt:goNext};
  if(goNext)return {main:goNext,alt:mist};
  return {main:{k:'path',label:t('dcNextPath'),desc:t('dcNextPathS')},alt:mist};
}
const dcStat=(ic,v,l,cls)=>`<div class="dc-stat ${cls||''}"><span class="dc-ic" aria-hidden="true">${ic||''}</span><b>${esc(v)}</b><span>${esc(l)}</span></div>`;
function dcRewards(){
  if(L.preview)return `<section class="dc-card"><p class="note">${esc(t('dcPrevNote'))}</p></section>`;
  if(L.err)return '';
  const c=curCourse();
  let h=dcStat(IC.bolt,'+'+L.xp,t('dcXp'),'xp');
  if(L.gems>0)h+=dcStat(IC.gem,'+'+L.gems,t('dcGems'),'gem');
  if(!L.practice)h+=dcStat(IC.star,L.stars+'/3',t('dcStars'),'star');
  if(L.mult>1)h+=dcStat(IC.bolt,'×'+L.mult,t('dcMult'),'mult');
  if(L.attempts>0)h+=dcStat(IC.check,L.acc+'%',t('acc'),'acc');
  void c;
  return `<section class="dc-card dc-rew" aria-label="${esc(t('dcRewards'))}"><h2>${esc(t('dcRewards'))}</h2><div class="dc-stats">${h}</div>${L.mult>1?`<p class="note">${esc(t('boostOn').replace('{n}',L.mult))} · ${L.raw} → ${L.xp} XP</p>`:''}</section>`;
}
function dcPerf(){
  if(L.preview||L.err||!(L.attempts>0))return '';
  const bad=L.attempts-L.correct,p=Math.round(L.correct/L.attempts*100);
  return `<section class="dc-card" aria-label="${esc(t('dcPerf'))}"><h2>${esc(t('dcPerf'))}</h2><div class="dc-grid3">${dcStat('',L.attempts,t('dcAtt'))}${dcStat('',L.correct,t('dcOk'),'good')}${dcStat('',bad,t('dcBad'),bad?'bad':'')}</div><div class="dc-meter" role="img" aria-label="${p}%"><i style="width:${p}%"></i></div><p class="dc-done">${IC.check}<span>${esc(t('dcDoneS'))}</span></p></section>`;
}
function dcLearned(){
  if(L.err||!L.lesson&&!L.preview)return '';
  const les=L.lesson||{},v=dcVocab(),objs=dcLines(les.objectives),gram=String(les.grammar||'').trim(),sum=String(les.summary||'').trim();
  const exs=v.filter(s=>s.ex).slice(0,4);
  if(!v.length&&!objs.length&&!gram&&!sum)return '';
  const lim=12,more=v.length-lim;
  let h=`<section class="dc-card" id="dc-sum" aria-label="${esc(t('dcLearn'))}"><h2>${esc(t('dcLearn'))}</h2>`;
  if(objs.length)h+=`<h3>${esc(t('dcObj'))}</h3><ul class="objs">${objs.map(o=>`<li>${esc(o)}</li>`).join('')}</ul>`;
  if(v.length)h+=`<h3>${esc(t('dcWords'))}</h3><ul class="dc-words">${v.slice(0,lim).map(s=>`<li><b lang="${tl()}">${esc(s.en)}</b><span>${esc(s.hy||'')}</span></li>`).join('')}</ul>${more>0?`<p class="note">+${esc(dcFill(t('dcMore'),{n:more}))}</p>`:''}`;
  if(exs.length)h+=`<h3>${esc(t('dcEx'))}</h3><ul class="dc-ex">${exs.map(s=>`<li><span lang="${tl()}">${esc(s.ex)}</span>${s.exTr?`<small>${esc(s.exTr)}</small>`:''}</li>`).join('')}</ul>`;
  if(gram)h+=`<h3>${esc(t('dcGram'))}</h3><div class="gram">${esc(gram).replace(/\n/g,'<br>')}</div>`;
  if(sum)h+=`<div class="gram dc-sumtxt">${esc(sum).replace(/\n/g,'<br>')}</div>`;
  return h+'</section>';
}
function dcMistakes(){
  const w=L.wrong||[];
  if(L.preview||L.err||!w.length)return '';
  const lim=5;
  return `<section class="dc-card" aria-label="${esc(t('dcMist'))}"><h2>${esc(t('dcMist'))}</h2><ul class="dc-mist">${w.slice(0,lim).map(m=>`<li><div class="dc-q" lang="${tl()}">${esc(m.q)}</div>${m.you?`<div class="dc-you"><small>${esc(t('dcYou'))}</small><span>${esc(m.you)}</span></div>`:''}<div class="dc-right"><small>${esc(t('dcRight'))}</small><span lang="${tl()}">${esc(m.right)}</span></div>${m.expl?`<p class="note">${esc(m.expl)}</p>`:''}</li>`).join('')}</ul>${w.length>lim?`<p class="note">+${esc(dcFill(t('dcMore'),{n:w.length-lim}))}</p>`:''}<button class="btn btn-purple" data-a="dcMist">${esc(t('dcMistB'))}</button></section>`;
}
function dcNextCard(P){
  const m=P.main;
  const quick=[];
  if(P.alt&&P.alt.k==='mist'&&m.k!=='mist')quick.push(`<button class="btn btn-ghost" data-a="dcMist">${esc(t('dcMistB'))}</button>`);
  if(dcVocab().length&&!L.preview&&!L.err)quick.push(`<button class="btn btn-ghost" data-a="dcWords">${esc(t('dcWordsB'))}</button>`);
  if(document&&!L.err&&dcLearned())quick.push(`<button class="btn btn-ghost" data-a="dcSum">${esc(t('dcSumB'))}</button>`);
  return `<section class="dc-card dc-nextc" aria-label="${esc(t('dcNext'))}"><h2>${esc(t('dcNext'))}</h2><p class="dc-nl"><b>${esc(m.label)}</b>${m.desc?`<span>${esc(m.desc)}</span>`:''}</p>${quick.length?`<div class="dc-quick">${quick.join('')}</div>`:''}</section>`;
}
function dcCourseCard(){
  const c=curCourse(),n=FLAT.filter(f=>S.done[f.id]).length,s=FLAT.reduce((a,f)=>a+(S.done[f.id]||0),0);
  return `<section class="dc-card dc-course"><h2 class="dc-cname">${esc(c?(c.name[S.lang]||c.name.hy||c.name.en):'')}</h2><p>${esc(dcFill(t('dcCourseStat'),{n,s,m:FLAT.length*3}))}</p></section>`;
}
/* headline letter by letter (words never break in the middle); the text is visible even when animations are off */
function dcLetters(txt){
  let i=0;
  return String(txt).split(' ').map(w=>`<span class="dc-w">${Array.from(w).map(c=>`<span style="--i:${i++}">${esc(c)}</span>`).join('')}</span>`).join(' ');
}
function dcView(top){
  const tier=L.preview?'base':dcTier(),big=tier==='perfect'||tier==='course'||L.unitDone||L.lvl||(L.ev&&L.ev.ms);
  const m=L.preview?['celebrating','done']:(L.courseDone?['proud','unit']:doneMood());
  const still=L.dcSeen?'still':'';
  const P=(L.preview||L.err)?null:dcPlan();
  const head=L.practice||L.preview?t('doneP'):t('dc'+'T_'+tier);
  const sub=L.practice||L.preview?'':t('dcS_'+tier);
  const trophy=(L.courseDone||L.unitDone)?`<div class="dc-trophy" aria-hidden="true">${TROPHY}</div>`:'';
  const errBox=L.err?`<div class="banner err" role="alert">${esc(L.err)}<br><small>${esc(t('dcErrKeep'))}</small></div><button class="btn btn-orange dc-retry" data-a="dcRetry">${esc(t('dcSaveRetry'))}</button>`:'';
  const body=`<div class="l-body"><div class="l-in"><div class="dc ${still} dc-${tier}" data-tier="${tier}">
   <div class="dc-hero"><i class="sp-orb o1"></i><i class="sp-orb o2"></i>${still?'':confetti(big?56:16)}${[0,1,2,3,4,5].map(n=>`<i class="dc-sp s${n}" aria-hidden="true">${n%2?'\u2728':'\u2B50'}</i>`).join('')}${trophy}<div class="dsay"><div class="gl-bub">${esc(mmsg(m[1],true))}</div><div class="dc-gl"><span class="sp-ring"></span>${gloro(m[0],tier==='perfect'||trophy?160:140)}</div></div>
   <h1 class="dc-hi" aria-label="${esc(head)}">${dcLetters(head)}</h1>${sub?`<p class="dc-sub">${esc(sub)}</p>`:''}${L.practice||L.preview||L.err?'':starsBig(L.stars)}</div>
   ${errBox}${L.courseDone&&!L.err?dcCourseCard():''}${dcRewards()}<div class="dc-events">${doneExtras()}</div>${dcPerf()}${dcReinforced()}${dcCardsCta()}${dcMistakes()}${dcLearned()}${P?dcNextCard(P):''}
  </div></div></div>`;
  let foot;
  if(L.err)foot=`<div class="l-foot-in"><button id="nxt" class="btn btn-ghost" data-a="exitLesson">${t('exit')}</button></div>`;
  else if(L.preview)foot=`<div class="l-foot-in"><button id="nxt" class="btn btn-orange" data-a="exitLesson">${t('cont')}</button></div>`;
  else foot=`<div class="l-foot-in dc-foot"><button id="nxt" class="btn btn-orange" data-a="dcGo" data-k="${P.main.k}">${esc(P.main.k==='next'?(P.main.label+' →'):P.main.label)}</button>${P.main.k==='path'?'':`<button class="btn btn-ghost" data-a="dcPath">${esc(t('dcPathB'))}</button>`}</div>`;
  L.dcSeen=true;L.dcPlan=P;
  return top+body+`<div class="l-foot">${foot}</div>${L.lvl&&!L.lvDone?levelOverlay(L.lvl):''}`;
}
/* actions (called from the event switch) */
function dcAct(a,d){
  if(!L||L.end!=='done')return;
  if(a==='dcSum'){const e=$('dc-sum');if(e&&e.scrollIntoView){try{e.scrollIntoView({behavior:'smooth',block:'start'});}catch(x){}}return;}
  if(a==='dcRetry'){if(L.dcBusy)return;L.err=null;L.end=null;finish();return;}
  if(L.dcBusy)return;
  const P=L.dcPlan,course=S.course;
  if(a==='dcMist'){L.dcBusy=true;closeLesson();tab='me';ptab='mist';MB.rows=null;pgAnim=true;render();window.scrollTo(0,0);return;}
  if(a==='dcWords'){L.dcBusy=true;closeLesson();tab='words';pgAnim=true;render();window.scrollTo(0,0);return;}
  if(a==='dcPath'){L.dcBusy=true;closeLesson();tab='learn';wantScroll=true;pgAnim=true;render();return;}
  if(a==='dcGo'){
    const k=d.k;
    if(k==='mist')return dcAct('dcMist',d);
    if(k==='courses'){L.dcBusy=true;closeLesson();tab='courses';pgAnim=true;render();window.scrollTo(0,0);return;}
    if(k==='next'&&P&&P.main.k==='next'){
      const i=P.main.i,f=FLAT[i];
      /* re-check at click time: same course, same lesson, still unlocked */
      if(f&&f.id===P.main.id&&S.course===course&&stateOf(i)!=='lock'){L.dcBusy=true;closeLesson();startLesson(i);return;}
    }
    L.dcBusy=true;closeLesson();tab='learn';wantScroll=true;pgAnim=true;render();
  }
}
