/* ---------- Part 1: top bar and Home dashboard ----------
   Every number on this screen comes from real state: S.* is the learner's progress (in cloud mode the server's
   XP / gems / streak via applyState), FLAT is the real course, QUESTS are the real daily quests. Nothing is invented. */
const greetKey=()=>{const h=new Date().getHours();return h<5?'gNight':h<12?'gMorning':h<18?'gDay':'gEve';};
const nfmt=n=>{try{return Number(n||0).toLocaleString(S.lang==='hy'?'hy-AM':'en-US');}catch(e){return String(n||0);}};
const showGems=()=>MODE!=='local'&&!!A.user;

function topbar(){
  const c=curCourse(),un=unread(),home=tab==='home';
  const who=home
    ?`<div class="who">${myAvatar('md')}<div class="who-t"><small>${esc(t(greetKey()))}</small><b>${esc(displayName())}</b></div></div>`
    :`<div class="logo">${mascot('happy',34)}<span>${logoName()}</span></div>`;
  const sub=`${c?`<button class="pill plang" data-a="langsel" aria-haspopup="dialog" aria-expanded="${langOpen}" aria-label="${esc(t('chooseLang'))}"><span class="code">${c.flag}</span><span class="ln">${esc(c.name[S.lang])}</span><span class="chv">${IC.chev}</span></button>`:'<span></span>'}
    <div class="langsw" role="group" aria-label="${esc(t('st_uiLang'))}">${[['hy','ՀԱՅ'],['en','EN']].map(x=>`<button type="button" data-a="lang" data-v="${x[0]}" aria-pressed="${S.lang===x[0]}">${x[1]}</button>`).join('')}</div>`;
  const right=`${showGems()?`<button class="chip gem" data-a="tab" data-v="shop" aria-label="${esc(t('gems')+': '+(S.gems||0))}">${LI('gem')}<b>${nfmt(S.gems||0)}</b></button>`:''}
    <button class="chip bell" data-a="bell" aria-label="${esc(t('notifT'))}${un?' ('+un+')':''}">${LI('bell')}${un?`<b class="dot">${un>9?'9+':un}</b>`:''}</button>`;
  return `<header class="top ${home||tab==='learn'?'with-sub':''}">${who}<div class="top-sub">${sub}</div><div class="top-r">${right}</div></header>`;
}

/* What the coach says, derived from the learner's own data (mistakes, streak, daily goal, next lesson). */
function coachInfo(hasProg,g){
  const miss=Object.keys(S.miss||{}).length;
  const ni=FLAT.findIndex((f,i)=>stateOf(i)==='open'),nf=ni>=0?FLAT[ni]:null;
  if(!hasProg)return {k:'start',mood:'wave',body:t('coachStart'),act:'continue',cta:t('startLearn')};
  if(miss>0&&canPractice())return {k:'miss',mood:'thinking',body:t('coachMiss').replace('{n}',miss),act:'practice',cta:t('practice')};
  if(streakRisk())return {k:'streak',mood:'encouraging',body:t('coachStreak').replace('{n}',streakNow()),act:nf?'continue':'practice',cta:t('contLearn')};
  if(g>=S.goal)return {k:'goal',mood:'celebrating',body:t('coachGoal'),act:nf?'continue':'practice',cta:t('contLearn')};
  if(nf)return {k:'next',mood:'happy',body:t('coachNext').replace('{x}',lessonLabel(nf)),act:'continue',cta:t('contLearn')};
  return {k:'done',mood:'proud',body:t('coachDone'),act:canPractice()?'practice':'',cta:t('practice')};
}

function homeView(){
  if(A.booting)return `<div role="status" aria-label="${esc(t('loadingT'))}">${loading()}${skel(3)}</div>`;
  const c=curCourse();
  if(!c)return netBanner()+`<div class="empty">${gloro('curious',96)}<span>${t('noCourse')}</span></div>`;
  const g=dayXp(),pct=Math.max(0,Math.min(100,Math.round(g/Math.max(1,S.goal)*100)));
  const cs=courseStats(c.id),hasProg=S.xp>0||Object.keys(S.done).length>0;
  const ni=FLAT.findIndex((f,i)=>stateOf(i)==='open'),nf=ni>=0?FLAT[ni]:null;
  const ms=homeSay(hasProg,g),mood=nf||ms[0]!=='happy'?ms[0]:'excited';
  const li=levelInfo(S.xp),lvPct=Math.round(li.cur/li.need*100);
  const co=coachInfo(hasProg,g);
  const qDone=QUESTS.filter(q=>questProg(q)>=q.n).length,ready=claimable().length+(chReady()?1:0);
  const away=S.last?dayDiff(S.last,today()):0;

  const cloud=showGems(),sv=(A&&A.srv)||{};
  const hearts=cloud?(sv.unlimited?'∞':heartsNow()+'/'+heartsMax()):'';
  const stat=(cls,ic,v,l,extra)=>`<div class="hm-kp ${cls} ${extra||''}"><span class="hm-mi ${cls}">${LI(ic)}</span><b>${v}</b><small>${esc(l)}</small></div>`;
  const stats=`<section class="hm-kpis" aria-label="${esc(t('pt_stats'))}">
    ${stat('fire','flame',streakNow(),t('streak'),streakRisk()?'risk':'')}
    ${stat('xp','bolt',nfmt(S.xp),'XP')}
    ${cloud?`<button class="hm-kp heart" data-a="tab" data-v="shop" aria-label="${esc(t('shopHearts')+': '+hearts)}"><span class="hm-mi heart">${LI('heart')}</span><b>${hearts}</b><small>${esc(t('shopHearts'))}</small></button>`:''}
    ${cloud?`<button class="hm-kp gem" data-a="tab" data-v="shop" aria-label="${esc(t('gems')+': '+(S.gems||0))}"><span class="hm-mi gem">${LI('gem')}</span><b>${nfmt(S.gems||0)}</b><small>${esc(t('gems'))}</small></button>`:stat('lv','star',li.level,t('level'))}
  </section>`;
  const goal=`<section class="p2-card hm-goal ${pct>=100?'is-done':''}" aria-label="${esc(t('goalToday'))}">
    <div class="hm-goal-main"><div class="goal-r">${ring(Math.min(100,pct),64,t('goal')+' '+pct+'%')}</div><div class="goal-t"><h2>${t('goalToday')}</h2><p>${pct>=100?t('goalDone'):t('goalLeft').replace('{n}',Math.max(0,S.goal-g))}</p><small>${g}/${S.goal} XP · ${esc(t('level'))} ${li.level}</small></div></div></section>`;

  const cont=nf
    ?`<section class="hm-cont"><div class="cont"><div class="cont-t"><small class="say" role="status">${esc(mmsg(ms[1]))}${ms[1]==='back'?' '+esc(t('backMsg').replace('{n}',away)):''}</small>
        <h2>${esc(lessonLabel(nf))}</h2><p>${esc(tx(nf.u.t))}</p>
        <button class="cont-play" data-a="continue">${LI('play')}<span>${t(hasProg?'contLearn':'startLearn')}</span></button></div>
      <div class="cont-g">${gloro(mood,118)}</div></div></section>`
    :`<section class="hm-cont"><div class="cont done"><div class="cont-t"><h2>${t('allDone')}</h2>${canPractice()?`<button class="cont-play" data-px="cards">${LI('repeat')}<span>${esc(pt('cards'))}</span></button>`:''}</div><div class="cont-g">${gloro('proud',104)}</div></div></section>`;

  const prog=`<section class="p2-card hm-prog"><div class="pg-row"><h2>${esc(t('learnProg'))}</h2><span>${cs.pct}%</span></div>
    <div class="bar purple" role="img" aria-label="${cs.pct}%"><i style="width:${cs.pct}%"></i></div>
    <p class="note"><span class="p2-flag">${c.flag}</span> ${esc(c.name[S.lang])}${c.level?' · '+esc(c.level):''} · ${cs.done}/${cs.total} ${esc(t('doneL'))} · ${countWords()} ${esc(t('learned'))}</p></section>`;
  /* recommended lessons: lessons finished with fewer than 3 stars (replaying them mixes in older material too) */
  const rec=FLAT.map((f,i)=>({f,i,st:S.done[f.id]||0,state:stateOf(i)})).filter(x=>x.state==='done'&&x.st>0&&x.st<3&&x.f.id!==(nf&&nf.id)).sort((a,b)=>a.st-b.st).slice(0,3);
  const recHtml=rec.length?`<section class="hm-sec" aria-label="${esc(t('hmRecL'))}"><div class="sec-h"><h2>${esc(t('hmRecL'))}</h2></div><div class="hm-rec">${rec.map(x=>`<button class="hm-rec-c" data-a="node" data-i="${x.i}" aria-label="${esc(lessonLabel(x.f))}"><span class="hm-rec-s">${starRow(x.st,'stars')}</span><b>${esc(lessonLabel(x.f))}</b><small>${esc(tx(x.f.u.t))}</small><span class="hm-rec-go">${LI('play')}</span></button>`).join('')}</div></section>`:'';
  const coach=`<button class="hm-coach-c" data-a="tab" data-v="ai" aria-label="${esc(t('aiCoach')+': '+co.body)}"><span class="hm-coach-g">${gloro('encouraging',52)}</span><span class="p2-tx"><b>${t('aiCoach')}</b><small>${esc(co.body)}</small></span>${LI('right')}</button>`;
  const quick=[['trophy',t('rank'),'rank'],['users',t('friends'),'friends'],['bag',t('shop'),'shop'],['award',t('ach'),'ach']].filter(x=>cloud||x[2]==='rank'||x[2]==='ach');
  const quickHtml=`<section class="hm-sec" aria-label="${esc(t('hmMore'))}"><div class="hm-quick">${quick.map(x=>x[2]==='ach'?`<button class="hm-q" data-a="gotoach"><span class="hm-qi">${LI(x[0])}</span><b>${esc(x[1])}</b></button>`:`<button class="hm-q" data-a="tab" data-v="${x[2]}"><span class="hm-qi">${LI(x[0])}</span><b>${esc(x[1])}</b></button>`).join('')}</div></section>`;
  let h=netBanner()+sampleBanner()+bannersHtml()+`<div class="hm"><div class="hm-main">${cont}${stats}${goal}${prog}</div><div class="hm-side">${coach}${recHtml}</div></div>`;
  const ch=challengeCard();
  if(QUESTS.length||ch)h+=`<section id="quests" class="hm-more"><div class="sec-h"><h2>${t('quests')}</h2><span class="p2-count">${qDone}/${QUESTS.length}</span></div>${ready?`<div class="say">${gloro('excited',52)}<span>${t('rewardsReady')}</span></div>`:''}<div class="quests">${QUESTS.map(questCard).join('')}</div>${ch}</section>`;
  h+=homePractice()+quickHtml;
  return h;
}

Object.assign(UI.hy,{hmRecL:'Խորհուրդ տրվող դասեր',hmMore:'Արագ անցումներ'});Object.assign(UI.en,{hmRecL:'Recommended lessons',hmMore:'Quick links'});
