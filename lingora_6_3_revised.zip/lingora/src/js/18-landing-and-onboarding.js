/* ---------- landing and onboarding ---------- */
const LAND={
hy:{greet:'Բարի գալուստ',greetSub:'Քո լեզվական ճանապարհորդությունը սկսվում է այստեղ',signup:'Գրանցվել',skip:'Բաց թողնել',head:'Բացահայտիր աշխարհը լեզուների միջոցով։',sub:'Կարճ խաղային դասեր, ամենօրյա շարք և իրական առաջընթաց՝ տասնմեկ լեզվով։ Հայերեն բացատրություններով։',start:'Սկսել սովորել',login:'Մուտք',
 langs:'Լեզուներ',langsSub:'Անգլերեն, ֆրանսերեն, գերմաներեն, իտալերեն, թուրքերեն, ադրբեջաներեն և ռուսերեն լեզուներից յուրաքանչյուրն ունի A1 սկսնակ մակարդակի լրիվ դասընթաց։ Ավելի բարձր մակարդակները և նոր լեզուները ավելանում են ադմինից։ «Սևագիր» նշված դասընթացները դեռ սպասում են բնիկ խոսողի ստուգմանը։',
 feat:'Ինչու Lingora',
 f:[['Կարճ դասեր','Մեկ դասը տևում է մոտ 5 րոպե՝ 8–10 հարց, առանց ծանրաբեռնվածության։','bolt'],['Տարբեր վարժություններ','Ընտրություն, զույգեր, նախադասություն հավաքել, բաց թողնված բառ, լսել և գրել։','book'],['XP, շարք և նվաճումներ','Վաստակիր միավորներ, պահիր օրերի շարքը և բացիր նվաճումներ։','flame'],['Լսիր արտասանությունը','Բրաուզերի ձայնային շարժիչը արտասանում է բառերն ու նախադասությունները։','speaker']],
faq:'Հաճախ տրվող հարցեր',faqQ:[['Անվճար է՞','Այո։ Դասերի մեծ մասը անվճար է։ VIP-ը բացում է լրացուցիչ թեմաներ, հաշվետվություն և օֆլայն աշխատանք։'],['Ինչպե՞ս են պահվում տվյալները','Հաշվի դեպքում առաջընթացը պահվում է քո հաշվում և հասանելի է բոլոր սարքերից։'],['Կարո՞ղ եմ աշխատել հեռախոսից','Այո։ Հավելվածը ստեղծված է հեռախոսների և պլանշետների համար և տեղադրվում է հիմնական էկրանին։']], foot:'Սովորիր լեզուներ հայերենով։ Անվճար սկիզբ։',links:'Հղումներ',top:'Վերև'},
en:{greet:'Welcome',greetSub:'Your language journey starts here',signup:'Sign up',skip:'Skip',head:'Discover the World Through Languages.',sub:'Short playful lessons, daily streaks and real progress across eleven languages, explained in Armenian.',start:'Start Learning',login:'Log in',
 langs:'Languages',langsSub:'English, French, German, Italian, Turkish, Azerbaijani and Russian each have a complete A1 beginner course. Higher levels and more languages are added from the admin panel. Courses marked Draft are still awaiting native-speaker review.',
 feat:'Why Lingora',
 f:[['Short lessons','One lesson takes about 5 minutes: 8–10 questions, nothing overwhelming.','bolt'],['Varied exercises','Multiple choice, matching pairs, building sentences, missing words, listening and typing.','book'],['XP, streaks and achievements','Earn points, keep your daily streak and unlock achievements.','flame'],['Hear the pronunciation','Your browser speaks the words and sentences out loud.','speaker']],
faq:'Frequently asked questions',faqQ:[['Is it free?','Yes. Most lessons are free. VIP unlocks extra topics, a progress report and offline mode.'],['How is my data stored?','With an account, your progress is saved to it and available on every device.'],['Does it work on my phone?','Yes. The app is built for phones and tablets and can be added to your home screen.']], foot:'Learn languages through Armenian. Free to start.',links:'Links',top:'Back to top'}
};
const splashSeen=()=>{try{return sessionStorage.getItem('lg.splash')==='1';}catch(e){return false;}};
const reducedMotion=()=>!!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches);
let splashTimer=0,splashStill=false;
function splashOn(){
  if(S.onb||flow!=='landing'&&flow!==''&&flow!==undefined)return false;
  if(splashSeen()||reducedMotion())return false;
  if(navigator.webdriver&&!/splash/.test(location.hash))return false;
  return true;
}
function closeSplash(){
  clearTimeout(splashTimer);splashTimer=0;
  try{sessionStorage.setItem('lg.splash','1');}catch(e){}
  const el=document.getElementById('splash');if(!el)return;
  el.classList.add('out');setTimeout(()=>{const e2=document.getElementById('splash');if(e2)e2.remove();},520);
}
function splashHtml(L2){
  const chars=Array.from(L2.greet).map((c,i)=>`<span style="--i:${i}">${c===' '?'&nbsp;':esc(c)}</span>`).join('');
  if(!splashTimer){splashTimer=setTimeout(closeSplash,5200);splashStill=false;setTimeout(()=>{splashStill=true;const e=document.getElementById('splash');if(e)e.classList.add('show');},1300);}
  return `<div id="splash" class="splash${splashStill?' show':''}" role="dialog" aria-label="${esc(L2.greet)}" data-a="splashgo"><i class="sp-orb o1"></i><i class="sp-orb o2"></i><div class="sp-in"><div class="sp-logo"><span class="sp-ring"></span>${mascot('wave',150)}</div><div class="sp-name">${logoName()}</div><h1 class="sp-hi" aria-label="${esc(L2.greet)}">${chars}</h1><p class="sp-sub">${esc(L2.greetSub)}</p><button class="btn btn-orange sp-go" data-a="splashgo">${esc(t('cont'))}</button></div><button class="sp-skip" data-a="splashgo">${esc(L2.skip)}</button></div>`;
}
function landingView(){
  const L2=LAND[S.lang]||LAND.hy,acct=MODE!=='local';
  const links=`<div class="l-links" aria-label="${esc(L2.links)}"><button data-a="scroll" data-v="l-feat">${L2.feat}</button><button data-a="scroll" data-v="l-langs">${L2.langs}</button><button data-a="scroll" data-v="l-faq">${L2.faq}</button></div>`;
  const nav=`<div class="l-nav"><div class="logo">${mascot('happy',36)}<span>${logoName()}</span></div>${links}<div class="acts"><div class="seg" role="radiogroup">${[['hy','ՀԱՅ'],['en','EN']].map(x=>`<button role="radio" aria-checked="${String(S.lang===x[0])}" data-a="lang" data-v="${x[0]}">${x[1]}</button>`).join('')}</div>${acct?`<button class="btn btn-ghost l-login" data-a="authgo" data-v="signin">${L2.login}</button><button class="btn btn-orange l-signup" data-a="authgo" data-v="signup">${L2.signup}</button>`:''}</div></div>`;
  const hero=`<section class="hero" id="l-top"><div class="hero-t"><span class="eyebrow">${IC.star}${esc(L2.greetSub)}</span><h1><span class="grad">${esc(L2.greet)}</span></h1><p class="tag2">${L2.head}</p><p class="lead">${L2.sub}</p><div class="acts"><button class="btn btn-orange glow" data-a="start">${L2.start}</button>${acct?`<button class="btn btn-purple" data-a="authgo" data-v="signup">${L2.signup}</button><button class="btn btn-ghost" data-a="authgo" data-v="signin">${L2.login}</button>`:''}</div></div>
   <div class="stage" aria-hidden="true"><i class="orb a"></i><i class="orb b"></i><i class="spin"></i>${gloro('wave',210)}<div class="fcard fc1">Hello <small>→ Բարև</small></div><div class="fcard fc2">${IC.flame}<span>7</span></div><div class="fcard fc3">${IC.star}<span>+20 XP</span></div></div></section>`;
  const langs=`<section class="sec" id="l-langs"><h2>${L2.langs}</h2><p class="lede">${L2.langsSub}</p><div class="langs">${courseCards().map(c=>`<span class="lpill"><span class="code">${c.flag}</span>${esc(c.name[S.lang])}</span>`).join('')}</div></section>`;
  const feat=`<section class="sec" id="l-feat"><h2>${L2.feat}</h2><div class="feat">${L2.f.map(x=>`<div class="fcell"><span class="ico">${IC[x[2]]}</span><h3>${x[0]}</h3><p>${x[1]}</p></div>`).join('')}</div></section>`;
  const faq=`<section class="sec" id="l-faq"><h2>${L2.faq}</h2>${L2.faqQ.map(x=>`<details class="faq"><summary>${x[0]}</summary><p>${x[1]}</p></details>`).join('')}</section>`;
  const cta=`<section class="cta"><h2>${esc(L2.greet)}</h2><p>${esc(L2.greetSub)}</p><button class="btn btn-orange glow" data-a="start">${L2.start}</button></section>`;
  const foot=`<footer class="foot"><div class="logo">${mascot('happy',28)}<span>${logoName()}</span></div><div class="links" aria-label="${L2.links}"><button data-a="scroll" data-v="l-feat">${L2.feat}</button><button data-a="scroll" data-v="l-langs">${L2.langs}</button><button data-a="scroll" data-v="l-top">${L2.top}</button></div></footer>`;
  return (splashOn()?splashHtml(L2):'')+nav+hero+feat+langs+faq+cta+foot;
}
function loginView(){
  const su=A.form==='signup';
  return `<div class="onb"><div class="l-nav"><div class="logo">${mascot('happy',36)}<span>${logoName()}</span></div></div><div class="onb-gl">${gloro(A.user?'celebrating':'wave',104)}</div><div class="onb-card"><h1>${su?t('signup'):t('signin')}</h1>${authCard(true)}</div>${A.user?`<button class="btn btn-purple" data-a="flow" data-v="onboard">${t('next')}</button>`:''}<button class="btn btn-ghost" data-a="flow" data-v="landing">${t('back')}</button></div>`;
}
function onboardView(){
  const steps=MODE==='local'?4:5,last=ob.step===steps-1;
  const dots=`<div class="dots" aria-hidden="true">${Array.from({length:steps},(_,i)=>`<i class="${i<=ob.step?'on':''}"></i>`).join('')}</div>`;
  const choice=(act,sel,id,main,sub,lead)=>`<button class="choice ${sel?'sel':''}" data-a="${act}" data-id="${esc(id)}" aria-pressed="${String(!!sel)}">${lead||''}<span class="ct"><b>${esc(main)}</b>${sub?`<small>${esc(sub)}</small>`:''}</span></button>`;
  const words=s=>String(s).split(' ').map((w,i)=>`<span style="--i:${i}">${esc(w)} </span>`).join('');
  let body='',say='';
  if(ob.step===0){
    say=t('onbHi');
    body=`<h1>${t('onb1T')}</h1><label class="fld">${t('name')}<input id="onm" value="${esc(S.name)}" placeholder="${esc(t('onbName'))}" autocomplete="nickname" maxlength="24"></label>
     <h2>${t('onb1C')}</h2><div class="opts courses">${courseCards().map(c=>choice('onbcourse',curCourse().id===c.id,c.id,c.name[S.lang],t(c.draft?'draftTag':c.real?'fullCourse':'sampleCourse'),`<span class="code">${c.flag}</span>`)).join('')}</div>`;
  }else if(ob.step===1){
    say=t('onb3T');
    body=`<h1>${t('onb3T')}</h1><div class="opts">${['beginner','basic','inter'].map(k=>choice('onblevel',S.level===k,k,t('lv_'+k),t('lvd_'+k))).join('')}</div>`;
  }else if(ob.step===2){
    say=t('whyS');
    body=`<h1>${t('whyT')}</h1><div class="opts">${WHYS.map(k=>choice('onbwhy',S.why===k,k,t('whyL_'+k))).join('')}</div>`;
  }else if(ob.step===3){
    const mins={10:3,20:5,30:8,50:12};
    say=t('onb2T');
    body=`<h1>${t('onb2T')}</h1><div class="opts">${[10,20,30,50].map(n=>choice('onbgoal',S.goal===n,String(n),t('gl'+n),n+' XP · ≈ '+mins[n]+' '+t('minShort'))).join('')}</div>`;
  }else{
    say=t('onbReady');
    const c=curCourse();
    body=`<h1>${t('onb4T')}</h1><div class="onb-sum">${[c&&c.name[S.lang],t('lv_'+S.level),S.why&&t('whyL_'+S.why),S.goal+' XP'].filter(Boolean).map(x=>`<span class="tag">${esc(x)}</span>`).join('')}</div><p class="note">${t('onb4S')}</p>${authCard(true)}`;
  }
  const moods=['wave','curious','thinking','excited','celebrating'];
  return `<div class="onb">${dots}<div class="onb-gl"><div class="dsay sm"><div class="gl-bub ${ob.anim?'typed':''}" aria-live="polite">${ob.anim?words(say):esc(say)}</div>${gloro(moods[ob.step]||'happy',104)}</div></div><div class="onb-card ${ob.anim?'slide':''}">${body}</div>
   <div class="onb-foot ${ob.step===0?'one':''}">${ob.step>0?`<button class="btn btn-ghost" data-a="onbback">${t('back')}</button>`:''}<button class="btn ${last?'btn-orange':'btn-purple'}" data-a="onbnext">${t(last?'finish':'next')}</button></div></div>`;
}
