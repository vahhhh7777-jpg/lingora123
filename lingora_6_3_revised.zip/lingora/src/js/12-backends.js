/* ---------- backends ---------- */
function demoBackend(){
  const K='ee.demo.v1';
  const rd=()=>{try{const j=JSON.parse(localStorage.getItem(K));if(j&&j.users){if(!j.progress)j.progress={};return j;}}catch(e){}return {users:[],cat:null,progress:{},session:''};};
  const wr=d=>{try{localStorage.setItem(K,JSON.stringify(d));}catch(e){}};
  const seed=d=>{if(!d.cat){d.cat=buildSeed();delete d.units;wr(d);}};
  const me=d=>d.users.find(x=>x.id===d.session)||null;
  const needAdmin=d=>{const u=me(d);if(!u||!u.is_admin||u.suspended)throw E('denied');};
  const needEditor=d=>{const u=me(d);if(!u||u.suspended||!(u.is_admin||u.role==='editor'))throw E('denied');};
  const pub=u=>({id:u.id,email:u.email,name:u.name,is_admin:u.is_admin,role:u.role||(u.is_admin?'admin':'user'),suspended:!!u.suspended,vip_until:u.vip_until,hide_lb:!!u.hide_lb,created_at:u.created_at});
  return {
    async init(){const d=rd();seed(d);const u=d.users.find(x=>x.id===d.session);return u?{id:u.id,email:u.email}:null;},
    async getConfig(){return rd().cfg||{};},
    async saveConfig(key,val){const d=rd();needAdmin(d);d.cfg=d.cfg||{};d.cfg[key]=val;wr(d);},
    async listContent(){const d=rd(),u=me(d),all=(d.content||[]).slice().sort((a,b)=>String(b.created_at||'').localeCompare(String(a.created_at||'')));return u&&u.is_admin?all:all.filter(liveC);},
    async upsertContent(row){const d=rd();needAdmin(d);d.content=d.content||[];const i=d.content.findIndex(x=>x.id===row.id);row=Object.assign({created_at:new Date().toISOString()},i<0?{}:d.content[i],row);if(i<0)d.content.push(row);else d.content[i]=row;wr(d);},
    async removeContent(id){const d=rd();needAdmin(d);d.content=(d.content||[]).filter(x=>x.id!==id);wr(d);},
    async updateUser(id,patch){
      const d=rd();needAdmin(d);const u=d.users.find(x=>x.id===id);if(!u)throw E('other');
      if(id===d.session&&(patch.suspended||patch.is_admin===false||(patch.role&&patch.role!=='admin')))throw E('denied');
      ['suspended','role','is_admin'].forEach(k=>{if(patch[k]!==undefined)u[k]=patch[k];});wr(d);
    },
    async signUp(email,pw,name){
      const d=rd();seed(d);email=email.toLowerCase();
      if(d.users.some(u=>u.email===email))throw E('exists');
      const u={id:'u'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),email,pw,name:name||'',is_admin:d.users.length===0,role:d.users.length===0?'super_admin':'user',suspended:false,vip_until:null,created_at:new Date().toISOString()};
      d.users.push(u);d.session=u.id;wr(d);return {user:{id:u.id,email:u.email},needsConfirm:false};
    },
    async signIn(email,pw){const d=rd();const u=d.users.find(x=>x.email===email.toLowerCase()&&x.pw===pw);if(!u)throw E('invalid');if(u.suspended)throw E('suspended');d.session=u.id;wr(d);return {id:u.id,email:u.email};},
    async signOut(){const d=rd();d.session='';wr(d);},
    async resetPassword(){return true;},
    async updatePassword(pw){const d=rd();const u=d.users.find(x=>x.id===d.session);if(u){u.pw=pw;wr(d);}},
    onRecovery(){},
    async setName(name){const d=rd();const u=me(d);if(u){u.name=name;wr(d);}},
    async setEmail(email){const d=rd();const u=me(d);if(!u)throw E('other');if(d.users.some(x=>x.email===email&&x.id!==u.id))throw E('exists');u.email=email;wr(d);return {pending:false};},
    async verifyPassword(email,pw){const d=rd();const u=me(d);if(!u||u.pw!==pw)throw E('invalid');},
    async signOutAll(){const d=rd();d.session='';wr(d);},
    async setPrivacy(hide){const d=rd();const u=me(d);if(u){u.hide_lb=!!hide;wr(d);}},
    async deleteAccount(){const d=rd();const u=me(d);if(!u)throw E('other');if(u.is_admin)throw new Error('admin_cannot_delete');d.users=d.users.filter(x=>x.id!==u.id);d.session='';wr(d);},
    async profile(uid){const d=rd();const u=d.users.find(x=>x.id===uid);if(!u)throw E('other');return pub(u);},
    /* Same rules the database enforces for the cloud: visitors get published rows, VIP topics only reach VIP and admins, admins get everything. */
    async catalog(){
      const d=rd();seed(d);const u=me(d),c=d.cat;
      if(u&&(u.is_admin||u.role==='editor'))return c;
      const vip=!!u&&profVip(u);
      const units=c.units.filter(x=>x.published!==false);
      const open=new Set(units.filter(x=>!x.vip||vip).map(x=>x.id));
      const lessons=c.lessons.filter(l=>l.published!==false&&open.has(l.unit_id));
      const ok=new Set(lessons.map(l=>l.id));
      return {languages:c.languages.filter(l=>l.active!==false),courses:c.courses.filter(x=>x.published!==false&&!x.archived),units,lessons,questions:c.questions.filter(q=>ok.has(q.lesson_id))};
    },
    async upsert(table,row){const d=rd();seed(d);needEditor(d);const list=d.cat[table],i=list.findIndex(x=>x.id===row.id);if(i<0)list.push(row);else list[i]=row;wr(d);},
    async upsertMany(table,rows){const d=rd();seed(d);needEditor(d);rows.forEach(row=>{const list=d.cat[table],i=list.findIndex(x=>x.id===row.id);if(i<0)list.push(row);else list[i]=row;});wr(d);},
    async remove(table,id){const d=rd();seed(d);needEditor(d);rmRow(d.cat,table,id);wr(d);},
    async upload(blob,kind){await checkMedia(blob,kind);return await new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(r.result);r.onerror=no;r.readAsDataURL(blob);});},
    async reorder(table,ids){const d=rd();seed(d);needEditor(d);ids.forEach((id,i)=>{const r=d.cat[table].find(x=>x.id===id);if(r)r.pos=i+1;});wr(d);},
    async importAll(cat){const d=rd();needEditor(d);d.cat=cat;wr(d);},
    /* Real accounts on this device only: weekly XP from their saved progress. */
    async leaderboard(){
      const d=rd(),cut=Date.now()-7*864e5,u0=me(d);
      return d.users.filter(u=>!u.suspended).map(u=>{const p=d.progress[u.id];const xp=p?(p.log||[]).filter(e=>e.t>=cut).reduce((n,e)=>n+e.xp,0):0;return {name:u.name||t('learner'),xp,me:!!u0&&u.id===u0.id,league:(p&&p.league&&p.league.tier)||0};}).filter(r=>r.xp>0||r.me).sort((a,b)=>b.xp-a.xp).slice(0,50);
    },
    async allProgress(){const d=rd();needAdmin(d);return Object.keys(d.progress).map(k=>({user_id:k,data:d.progress[k]}));},
    async listUsers(){return rd().users.map(pub);},
    async setAdmin(id,on){const d=rd();needAdmin(d);const u=d.users.find(x=>x.id===id);if(u&&id!==d.session){u.is_admin=!!on;wr(d);}},
    async setVip(id,until){const d=rd();const u=d.users.find(x=>x.id===id);if(u)u.vip_until=until;wr(d);},
    async grantVip(id,days){const d=rd();needAdmin(d);const u=d.users.find(x=>x.id===id);if(u){const b=Math.max(Date.now(),u.vip_until?Date.parse(u.vip_until):0);u.vip_until=new Date(b+days*864e5).toISOString();wr(d);}},
    async revokeVip(id){const d=rd();needAdmin(d);const u=d.users.find(x=>x.id===id);if(u){u.vip_until=null;wr(d);}},
    async loadProgress(uid){return rd().progress[uid]||null;},
    async saveProgress(uid,data){const d=rd(),u=d.users.find(x=>x.id===uid);if(u&&u.suspended)throw E('denied');d.progress[uid]=data;wr(d);}
  };
}
function cloudBackend(){
  let sb=null,recoveryCb=function(){};
  const need=()=>{if(!sb)throw E('net');return sb;};
  const ck=r=>{if(r&&r.error)throw E(mapErr(r.error));return r;};
  const loadLib=()=>new Promise((res,rej)=>{const s=document.createElement('script');s.src=SB_SRC;s.onload=res;s.onerror=()=>rej(E('net'));document.head.appendChild(s);});
  const TABLES=['languages','courses','units','lessons','questions'];
  const fromRow=r=>{const o=Object.assign({},r);o.pos=o.position;delete o.position;delete o.created_at;delete o.updated_at;return o;};
  const toRow=o=>{const r=Object.assign({},o);r.position=r.pos||0;delete r.pos;return r;};
  /* Reads a whole table page by page. Hardened (B-004): a server/proxy that ignores the Range header, or a reply that is not an
     array, used to make this loop forever and freeze/crash the tab. Now: non-array reply = error, a page identical to the previous
     one = stop, and a hard page cap. */
  const READ_PAGE=1000,READ_MAX_PAGES=200;
  async function readAll(db,table,cols,orderBy){
    const out=[];let prevFirst=null,prevLast=null;
    for(let page=0;page<READ_MAX_PAGES;page++){
      const from=page*READ_PAGE;
      const r=ck(await db.from(table).select(cols||'*').order(orderBy||'id').range(from,from+READ_PAGE-1));
      const rows=r.data==null?[]:r.data;
      if(!Array.isArray(rows))throw E('other');
      if(rows.length&&page>0&&JSON.stringify(rows[0])===prevFirst&&JSON.stringify(rows[rows.length-1])===prevLast)break;
      out.push.apply(out,rows);
      if(rows.length<READ_PAGE)return out;
      prevFirst=JSON.stringify(rows[0]);prevLast=JSON.stringify(rows[rows.length-1]);
    }
    console.warn('readAll: stopped after '+READ_MAX_PAGES+' pages for '+table);
    return out;
  }
  return {
    async init(){
      if(!window.supabase)await loadLib();
      sb=window.supabase.createClient(CFG.SUPABASE_URL,CFG.SUPABASE_ANON_KEY,{auth:{persistSession:true,autoRefreshToken:true}});
      sb.auth.onAuthStateChange(ev=>{if(ev==='PASSWORD_RECOVERY')recoveryCb();});
      const r=ck(await sb.auth.getSession());
      const u=r.data&&r.data.session&&r.data.session.user;
      return u?{id:u.id,email:u.email,lastIn:u.last_sign_in_at}:null;
    },
    onRecovery(cb){recoveryCb=cb;},
    async signUp(email,pw,name){
      const r=ck(await need().auth.signUp({email,password:pw,options:{data:{name:name||''}}}));
      const u=r.data.user;
      return {user:u?{id:u.id,email:u.email}:null,needsConfirm:!r.data.session};
    },
    async signIn(email,pw){const r=ck(await need().auth.signInWithPassword({email,password:pw}));return {id:r.data.user.id,email:r.data.user.email};},
    async signOut(){ck(await need().auth.signOut());},
    /* Last resort when signOut() could not reach the server: supabase-js then keeps the session in storage, so the next page load would be signed in again. */
    forgetSession(){
      try{if(sb&&sb.auth.stopAutoRefresh)sb.auth.stopAutoRefresh();}catch(e){console.warn('stopAutoRefresh',e);}
      try{Object.keys(localStorage).filter(k=>/^sb-.+-auth-token(-code-verifier)?$/.test(k)).forEach(k=>localStorage.removeItem(k));}catch(e){console.warn('forgetSession',e);}
    },
    async resetPassword(email){ck(await need().auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname}));},
    async updatePassword(pw){ck(await need().auth.updateUser({password:pw}));},
    async setName(name){ck(await need().rpc('set_my_name',{n:name}));},
    async setEmail(email){ck(await need().auth.updateUser({email},{emailRedirectTo:location.origin+location.pathname}));return {pending:true};},
    async verifyPassword(email,pw){ck(await need().auth.signInWithPassword({email,password:pw}));},
    async signOutAll(){ck(await need().auth.signOut({scope:'global'}));},
    async setPrivacy(hide){ck(await need().rpc('set_privacy',{p_hide:!!hide}));},
    async deleteAccount(){ck(await need().rpc('delete_my_account'));},
    async profile(uid){const r=ck(await need().from('profiles').select('*').eq('id',uid).single());return r.data;},
    async catalog(){
      const db=need(),r=await Promise.all(TABLES.map(t=>readAll(db,t)));
      const cat={};TABLES.forEach((t,i)=>{cat[t]=r[i].map(fromRow);});
      return cat;
    },
    async upsert(table,row){ck(await need().from(table).upsert(toRow(row)));},
    async upsertMany(table,rows){for(let i=0;i<rows.length;i+=300)ck(await need().from(table).upsert(rows.slice(i,i+300).map(toRow)));},
    async remove(table,id){ck(await need().from(table).delete().eq('id',id));},
    async upload(blob,kind){
      const mime=await checkMedia(blob,kind);                                  /* type + size + real file signature */
      const db=need(),ext=({'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','audio/mpeg':'mp3','audio/mp3':'mp3','audio/ogg':'ogg','audio/wav':'wav','audio/webm':'webm','audio/mp4':'m4a'})[mime],
        path=kind+'/'+Date.now()+'-'+Math.random().toString(36).slice(2,8)+'.'+ext;
      ck(await db.storage.from('media').upload(path,blob,{contentType:mime,upsert:false}));
      const url=db.storage.from('media').getPublicUrl(path).data.publicUrl,u=(await db.auth.getUser()).data.user;
      const r=await db.from('media_assets').insert({path,kind,mime,bytes:blob.size,url,uploaded_by:u&&u.id});
      if(r.error){await db.storage.from('media').remove([path]);ck(r);}
      if(typeof P3!=='undefined')P3.media.rows=null;
      return url;
    },
    async reorder(table,ids){const db=need();const rs=await Promise.all(ids.map((id,i)=>db.from(table).update({position:i+1}).eq('id',id)));rs.forEach(ck);},
    async importAll(cat){
      const db=need();
      for(const t of TABLES){
        const rows=(cat[t]||[]).map(toRow);
        for(let i=0;i<rows.length;i+=300)ck(await db.from(t).upsert(rows.slice(i,i+300)));
      }
    },
    async getConfig(){const r=ck(await need().from('settings').select('key,value'));const o={};(r.data||[]).forEach(x=>{o[x.key]=x.value;});return o;},
    async saveConfig(key,value){ck(await need().from('settings').upsert({key,value,updated_at:new Date().toISOString()}));},
    async listContent(){const r=ck(await need().from('site_content').select('*').order('created_at',{ascending:false}));return r.data||[];},
    async upsertContent(row){const o=Object.assign({},row);delete o.created_at;ck(await need().from('site_content').upsert(o));},
    async removeContent(id){ck(await need().from('site_content').delete().eq('id',id));},
    async updateUser(id,patch){ck(await need().from('profiles').update(patch).eq('id',id));},
    async claimVipGems(){return ck(await need().rpc('claim_vip_gems')).data;},
    async grantGems(id,n,note){return ck(await need().rpc('admin_grant_gems',{p_user:id,p_amount:n,p_note:note||''})).data;},
    async setGoal(n){return ck(await need().rpc('set_my_goal',{p_goal:n})).data;},
    async econState(tz){return ck(await need().rpc('get_my_state',{p_tz:tz})).data;},
    async econStart(lesson,kind,n){return ck(await need().rpc('start_lesson',{p_lesson:lesson||'',p_kind:kind,p_questions:n||null})).data;},
    async econAnswer(att,qid,seq,answer,clientOk,lenient,ms){return ck(await need().rpc('submit_answer',{p_attempt:att,p_question:qid,p_seq:seq,p_answer:answer,p_client_ok:clientOk,p_lenient:lenient,p_ms:ms})).data;},
    async myMistakes(n){return ck(await need().rpc('my_mistakes',{p_limit:n||60})).data||[];},
    async econMiss(att){return ck(await need().rpc('lesson_miss',{p_attempt:att})).data;},
    async econDone(att,mis){return ck(await need().rpc('complete_lesson',{p_attempt:att,p_mistakes:mis})).data;},
    async econPractice(att,cor){return ck(await need().rpc('complete_practice',{p_attempt:att,p_correct:cor})).data;},
    async shopItems(){const r=ck(await need().from('shop_items').select('id,kind,category,slot,vip_only,payload,price_gems,icon,title,descr,position').eq('active',true).order('position'));return r.data||[];},
    async myWorld(){return ck(await need().rpc('my_world')).data;},
    async setWorld(room,equipped,decor){return ck(await need().rpc('set_world',{p_room:room,p_equipped:equipped,p_decor:decor})).data;},
    async myNotifs(n){return ck(await need().rpc('my_notifications',{p_limit:n||40})).data;},
    async notifsRead(ids){return ck(await need().rpc('notifications_read',{p_ids:ids||null})).data;},
    async setNotifyPrefs(p){return ck(await need().rpc('set_notify_prefs',{p_prefs:p})).data;},
    async leagueTick(){return ck(await need().rpc('league_tick')).data;},
    async challenges(){return ck(await need().rpc('my_challenges')).data||[];},
    async challengeCreate(id,days){return ck(await need().rpc('challenge_create',{p_friendship:id,p_days:days})).data;},
    async challengeRespond(id,ok){return ck(await need().rpc('challenge_respond',{p_id:id,p_accept:!!ok})).data;},
    async aiUsage(){return ck(await need().rpc('my_ai_usage')).data;},
    async askCoach(body){
      const r=await need().functions.invoke('ai-coach',{body});
      if(r.error){
        const ctx=r.error.context;                                   /* FunctionsHttpError carries the Response; FunctionsFetchError does not */
        if(!ctx||typeof ctx.status!=='number')throw E('net');
        if(ctx.status===404)throw E('ai_not_configured');            /* the ai-coach function is not deployed in this project */
        let j=null;try{j=await ctx.json();}catch(e){}
        throw E((j&&j.error)||(ctx.status===401?'unauthorized':'ai_unavailable'));
      }
      return r.data;
    },
    async tts(body){
      const r=await need().functions.invoke('tts',{body});
      if(r.error||!r.data)throw E('tts_unavailable');
      return r.data instanceof Blob?r.data:new Blob([r.data],{type:'audio/mpeg'});
    },
    async weakTopics(){return ck(await need().rpc('my_weak_topics')).data;},
    async storiesPub(lang){return ck(await need().from('stories').select('*').eq('language',lang).eq('published',true).order('position').order('created_at')).data||[];},
    async storiesAll(){return ck(await need().from('stories').select('*').order('language').order('position').order('created_at')).data||[];},
    async storySave(row){const q=need().from('stories');if(row.id){const id=row.id,r=Object.assign({},row);delete r.id;return ck(await q.update(r).eq('id',id).select().single()).data;}return ck(await q.insert(row).select().single()).data;},
    async storyDel(id){ck(await need().from('stories').delete().eq('id',id));},
    async storyProg(){return ck(await need().from('story_progress').select('story_id,stars')).data||[];},
    async storyRec(id,stars){ck(await need().rpc('record_story_progress',{p_story:id,p_stars:stars}));},
    async placeRec(lang,cefr,score,total){ck(await need().rpc('record_placement',{p_language:lang,p_cefr:cefr,p_score:score,p_total:total}));},
    async placeLast(lang){const r=ck(await need().from('placement_results').select('cefr,created_at').eq('user_id',A.user.id).eq('language',lang).order('created_at',{ascending:false}).limit(1));return (r.data||[])[0]||null;},
    async recommendations(){return ck(await need().rpc('my_recommendations',{p_limit:5})).data||[];},
    async revisionHistory(){return ck(await need().rpc('my_revision_history',{p_limit:30})).data||[];},
    async adminAiStats(){return ck(await need().rpc('admin_ai_stats')).data;},
    async shopLessons(){return ck(await need().rpc('shop_lessons')).data||[];},
    async unlockLesson(id,idem){return ck(await need().rpc('unlock_lesson',{p_lesson:id,p_idem:idem})).data;},
    async buyItem(id,idem){return ck(await need().rpc('buy_item',{p_item:id,p_idem:idem})).data;},
    async refillHearts(idem){return ck(await need().rpc('refill_hearts',{p_idem:idem})).data;},
    async xpHistory(n){return ck(await need().from('xp_events').select('id,amount,kind,ref,day,created_at').order('created_at',{ascending:false}).limit(n||30)).data||[];},
    async leaderboard(){const r=ck(await need().rpc('leaderboard'));return r.data||[];},
    async allProgress(){return await readAll(need(),'progress','user_id,data','user_id');},
    /* PART 3: server-side admin API (every call is re-checked by the database; the browser role value is never trusted) */
    async adminUsers(o){return ck(await need().rpc('admin_list_users',{p_q:o.q||'',p_filter:o.filter||'all',p_sort:o.sort||'created',p_dir:o.dir||'desc',p_limit:o.limit||20,p_offset:o.offset||0})).data;},
    async adminUser(id){return ck(await need().rpc('admin_user_detail',{p_user:id})).data;},
    async adminVipList(o){return ck(await need().rpc('admin_list_vip',{p_q:o.q||'',p_status:o.status||'active',p_limit:o.limit||20,p_offset:o.offset||0})).data;},
    async adminStats(){return ck(await need().rpc('admin_stats')).data;},
    async adminAudit(o){return ck(await need().rpc('admin_audit',{p_q:o.q||'',p_entity:o.entity||'',p_limit:o.limit||25,p_offset:o.offset||0})).data;},
    async adminPayments(o){return ck(await need().rpc('admin_payments',{p_limit:o.limit||20,p_offset:o.offset||0})).data;},
    async adminGrantVip(id,days,note,plan){return ck(await need().rpc('admin_grant_vip',{p_user:id,p_days:days,p_note:note||'',p_plan:plan||null})).data;},
    async adminSetVip(id,plan,starts,ends,note){return ck(await need().rpc('admin_set_vip',{p_user:id,p_plan:plan||'custom',p_starts:starts,p_ends:ends,p_note:note||''})).data;},
    async adminRevokeVip(id,note){return ck(await need().rpc('admin_revoke_vip',{p_user:id,p_note:note||''})).data;},
    async adminSuspend(id,on,note){return ck(await need().rpc('admin_set_suspended',{p_user:id,p_on:!!on,p_note:note||''})).data;},
    async tableList(table,order){let q=need().from(table).select('*');if(order)q=q.order(order,{ascending:true});return ck(await q).data||[];},
    async tableSave(table,row){ck(await need().from(table).upsert(row));},
    async tableDelete(table,match){ck(await need().from(table).delete().match(match));},
    async listMedia(){return ck(await need().from('media_assets').select('*').order('created_at',{ascending:false}).limit(200)).data||[];},
    async deleteMedia(row){const db=need();const r=await db.storage.from('media').remove([row.path]);ck(r);ck(await db.from('media_assets').delete().eq('id',row.id));},
    async vipPlans(){const r=ck(await need().from('vip_plans').select('id,title,days,price_cents,currency,provider_price').eq('active',true).order('days'));return (r.data||[]).filter(p=>p.price_cents!=null&&p.provider_price);},
    async startCheckout(plan){const r=await need().functions.invoke('create-checkout',{body:{plan}});if(r.error||!r.data||!r.data.url)throw E('other');return r.data.url;},
    async listUsers(){const rows=await readAll(need(),'profiles','*','id');return rows.sort((a,b)=>String(b.created_at||'').localeCompare(String(a.created_at||'')));},
    async setAdmin(id,on){ck(await need().rpc('admin_set_role',{p_user:id,p_role:on?'admin':'user'}));},
    async setRole(id,role){return ck(await need().rpc('admin_set_role',{p_user:id,p_role:role})).data;},
    async grantVip(id,days){return ck(await need().rpc('admin_grant_vip',{p_user:id,p_days:days,p_note:''})).data;},
    async revokeVip(id){return ck(await need().rpc('admin_revoke_vip',{p_user:id,p_note:''})).data;},
    async updateProfile(name,username,avatar){return ck(await need().rpc('update_my_profile',{p_name:name,p_username:username||'',p_avatar:avatar||''})).data;},
    async friends(){return ck(await need().rpc('friends_overview')).data;},
    async friendRequest(who){return ck(await need().rpc('friend_request',{p_who:who})).data;},
    async friendRespond(id,ok){return ck(await need().rpc('friend_respond',{p_id:id,p_accept:!!ok})).data;},
    async friendRemove(id){ck(await need().rpc('friend_remove',{p_id:id}));},
    async resetProgress(){ck(await need().rpc('reset_my_progress'));},
    async loadProgress(uid){const r=ck(await need().from('progress').select('data').eq('user_id',uid).maybeSingle());return r.data?r.data.data:null;},
    async saveProgress(uid,data){ck(await need().from('progress').upsert({user_id:uid,data,updated_at:new Date().toISOString()}));}
  };
}
const B=MODE==='cloud'?cloudBackend():MODE==='demo'?demoBackend():null;
