/* ---------- voice engine (Lingora 3.1): async voice loading, best-voice choice, persistence, no overlap ---------- */
const VX={voices:[],ready:false,prefs:{},tok:0,cur:null};
try{VX.prefs=JSON.parse(localStorage.getItem('lingora.voice')||'{}')||{};}catch(e){VX.prefs={};}
function vxSave(){try{localStorage.setItem('lingora.voice',JSON.stringify(VX.prefs));}catch(e){}}
function vxLoad(){
  if(!HAS_TTS)return;
  try{const v=speechSynthesis.getVoices();if(v&&v.length){VX.voices=v.slice();VX.ready=true;}}catch(e){}
}
if(HAS_TTS){
  vxLoad();
  try{speechSynthesis.addEventListener('voiceschanged',()=>{vxLoad();});}catch(e){try{speechSynthesis.onvoiceschanged=vxLoad;}catch(_){}}
  [300,1200,3000].forEach(ms=>setTimeout(vxLoad,ms));
}
const vxBase=l=>String(l||'').toLowerCase().split(/[-_]/)[0];
const vxNorm=l=>String(l||'').toLowerCase().replace('_','-');
function vxScore(v,lang){
  const vl=vxNorm(v.lang),want=vxNorm(lang);let s=0;
  if(vl===want)s+=100;else if(vxBase(vl)===vxBase(want))s+=60;else return -1;
  const n=(v.name||'').toLowerCase();
  if(/neural|natural|online|premium|enhanced|wavenet/.test(n))s+=40;
  if(/google|microsoft|siri|apple|samantha|daniel|amelie|anna|alice|luca|monica|paulina|kyoko|yuna|tingting|ting-ting|sin-ji/.test(n))s+=15;
  if(/espeak|festival/.test(n))s-=50;
  if(v.localService)s+=5;
  if(v.default&&vxBase(vl)===vxBase(want))s+=3;
  return s;
}
function vxList(lang){
  return VX.voices.map(v=>({v,s:vxScore(v,lang)})).filter(x=>x.s>=0).sort((a,b)=>b.s-a.s).map(x=>x.v);
}
const VX_FEM=/female|woman|samantha|victoria|karen|moira|tessa|amelie|anna|alice|monica|paulina|kyoko|yuna|tingting|ting-ting|sin-ji|zira|hazel|susan|helena|elsa|katja|lucia|paola|elena|sabina|heami|sun-hi|xiaoxiao|huihui|yaoyao|google .*(us|uk) english$/i;
const VX_MALE=/\bmale\b|daniel|alex|fred|thomas|diego|jorge|luca\b|markus|stefan|yannick|david|mark\b|george|ichiro|otoya|kangkang|yunyang|rishi|oliver|jorge|google deutsch$/i;
function vxGender(v){const n=v.name||'';if(/\bmale\b/i.test(n)&&!/female/i.test(n))return 'm';if(/female/i.test(n))return 'f';if(VX_FEM.test(n))return 'f';if(VX_MALE.test(n))return 'm';return '?';}
function vxPick(lang){
  const list=vxList(lang);if(!list.length)return null;
  const base=vxBase(lang),saved=VX.prefs.v&&VX.prefs.v[base];
  if(saved){const f=list.find(v=>v.voiceURI===saved||v.name===saved);if(f)return f;}
  const g=VX.prefs.g;
  if(g==='f'||g==='m'){const f=list.find(v=>vxGender(v)===g);if(f)return f;}
  return list[0];
}
function vxStop(){VX.tok++;try{if(HAS_TTS){speechSynthesis.cancel();}}catch(e){}try{if(typeof NX!=='undefined'&&NX.a)NX.a.pause();}catch(e){}VX.cur=null;}
/* split long text at sentence/clause ends so pauses sound natural and mobile engines do not cut off */
function vxChunks(text){
  const parts=String(text).replace(/\s+/g,' ').trim().match(/[^.!?。！？؟…;]+[.!?。！？؟…;]*\s*/g)||[String(text)];
  const out=[];let buf='';
  parts.forEach(p=>{if((buf+p).length<140)buf+=p;else{if(buf)out.push(buf.trim());buf=p;}});
  if(buf)out.push(buf.trim());return out.filter(Boolean);
}
/* optional neural TTS through the `tts` Edge Function (keys stay on the server). Any failure falls back to the browser voice. */
const NX={a:null,cache:new Map(),unlocked:false,tok:0};
const nxOn=()=>!!(CFG.NEURAL_TTS&&B&&B.tts&&VX.prefs.neural!==false&&navigator.onLine!==false&&typeof Audio!=='undefined');
function nxUnlock(){
  if(NX.unlocked||typeof Audio==='undefined')return;
  try{NX.a=NX.a||new Audio();NX.a.src='data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=';const p=NX.a.play();if(p&&p.then)p.then(()=>{NX.unlocked=true;try{NX.a.pause();}catch(e){}}).catch(()=>{});else NX.unlocked=true;}catch(e){}
}
document.addEventListener('click',nxUnlock,{once:true,capture:true});
document.addEventListener('touchend',nxUnlock,{once:true,capture:true});
async function nxSpeak(text,lang,rate,tok){
  const key=lang+'|'+rate+'|'+(VX.prefs.g||'')+'|'+text;
  let url=NX.cache.get(key);
  if(!url){
    const blob=await B.tts({text:text.slice(0,400),lang:lang,gender:VX.prefs.g||'',speed:rate});
    if(!blob||!blob.size)throw new Error('empty');
    url=URL.createObjectURL(blob);NX.cache.set(key,url);
    if(NX.cache.size>60){const k=NX.cache.keys().next().value;try{URL.revokeObjectURL(NX.cache.get(k));}catch(e){}NX.cache.delete(k);}
  }
  if(tok!==VX.tok)return true;
  NX.a=NX.a||new Audio();NX.a.onended=null;NX.a.src=url;
  await NX.a.play();
  return true;
}
function say(text,opt){
  opt=opt||{};
  if(!text)return false;
  const lang=opt.lang||ttsLang();
  if(nxOn()){
    vxStop();try{if(NX.a)NX.a.pause();}catch(e){}
    const tok=VX.tok,rate=opt.rate||VX.prefs.rate||.95;VX.last={text:text,lang:lang};
    nxSpeak(String(text),lang,rate,tok).catch(()=>{if(tok===VX.tok)browserSay(text,opt,lang);});
    return true;
  }
  return browserSay(text,opt,lang);
}
function browserSay(text,opt,lang){
  if(!HAS_TTS||!text)return false;
  try{
    vxStop();vxLoad();
    const tok=VX.tok,voice=vxPick(lang),rate=opt.rate||VX.prefs.rate||.95;
    VX.last={text:text,lang:lang};
    const chunks=vxChunks(text);
    /* some mobile browsers need a tiny delay after cancel() */
    setTimeout(()=>{
      if(tok!==VX.tok)return;
      chunks.forEach((c,i)=>{
        const u=new SpeechSynthesisUtterance(c);
        u.lang=voice?voice.lang:lang;if(voice){try{u.voice=voice;}catch(e){u.lang=lang;}}
        u.rate=Math.max(.5,Math.min(1.4,rate));u.pitch=1;u.volume=1;
        u.onerror=()=>{};
        if(i===0)u.onstart=()=>{VX.cur=u;};
        speechSynthesis.speak(u);
      });
    },60);
    return true;
  }catch(e){return false;}
}
function sayAgain(){if(VX.last)say(VX.last.text,{lang:VX.last.lang});}
function vxCoverage(lang){const l=vxList(lang);return l.length?(vxNorm(l[0].lang)===vxNorm(lang)?'exact':'base'):'none';}
function vxSettingsHtml(){
  if(!HAS_TTS)return `<div class="snote">${LI('info')}<span>${esc(t('vxNone'))}</span></div>`;
  const c=curCourse(),lang=c?c.tts:'en-US',base=vxBase(lang),list=vxList(lang),sel=vxPick(lang);
  const g=VX.prefs.g||'';
  const nx=CFG.NEURAL_TTS&&B&&B.tts?`<label class="vx-l"><input type="checkbox" data-vx="neural" ${VX.prefs.neural!==false?'checked':''}> ${esc(t('vxNeural'))}</label>`:'';
  const opts=list.length?list.map(v=>`<option value="${esc(v.voiceURI||v.name)}"${sel&&sel.name===v.name?' selected':''}>${esc(v.name)} (${esc(v.lang)})${vxGender(v)==='f'?' ♀':vxGender(v)==='m'?' ♂':''}</option>`).join(''):`<option value="">${esc(t('vxMissing'))}</option>`;
  const rate=VX.prefs.rate||.95;
  return `<div class="vx" data-vx-root>
   ${nx}
   <label class="vx-l">${esc(t('vxVoice'))} · <b>${esc(lang)}</b></label>
   <select class="vx-sel" data-vx="voice" data-base="${esc(base)}" aria-label="${esc(t('vxVoice'))}">${opts}</select>
   <div class="vx-row" role="group" aria-label="${esc(t('vxGender'))}">
    ${[['','vxAny'],['f','vxF'],['m','vxM']].map(x=>`<button type="button" class="btn btn-ghost sb${g===x[0]?' on':''}" data-vx="gender" data-v="${x[0]}" aria-pressed="${g===x[0]}">${esc(t(x[1]))}</button>`).join('')}
   </div>
   <label class="vx-l">${esc(t('vxSpeed'))}: <b data-vx-rv>${rate.toFixed(2)}×</b></label>
   <input type="range" min="0.6" max="1.3" step="0.05" value="${rate}" data-vx="rate" aria-label="${esc(t('vxSpeed'))}">
   <div class="vx-row"><button type="button" class="btn btn-ghost sb" data-vx="test">${LI('vol')}<span>${esc(t('vxTest'))}</span></button></div>
   ${list.length?'':`<div class="snote">${LI('info')}<span>${esc(t('vxMissingLong'))}</span></div>`}
   <div class="snote">${LI('info')}<span>${esc(t('vxHonest'))}</span></div></div>`;
}
document.addEventListener('input',e=>{const el=e.target.closest&&e.target.closest('[data-vx="rate"]');if(!el)return;VX.prefs.rate=+el.value;vxSave();const b=document.querySelector('[data-vx-rv]');if(b)b.textContent=(+el.value).toFixed(2)+'×';});
document.addEventListener('change',e=>{const nz=e.target.closest&&e.target.closest('[data-vx="neural"]');if(nz){VX.prefs.neural=!!nz.checked;vxSave();return;}
  const el=e.target.closest&&e.target.closest('[data-vx="voice"]');if(!el)return;VX.prefs.v=Object.assign({},VX.prefs.v);VX.prefs.v[el.dataset.base]=el.value;vxSave();});
document.addEventListener('click',e=>{
  const el=e.target.closest&&e.target.closest('[data-vx]');if(!el)return;const k=el.dataset.vx;
  if(k==='gender'){VX.prefs.g=el.dataset.v;VX.prefs.v={};vxSave();try{render();}catch(_){}}
  else if(k==='test'){const c=curCourse();const demo={en:'Hello, how are you today?',es:'Hola, ¿cómo estás hoy?',fr:'Bonjour, comment allez-vous aujourd’hui ?',de:'Hallo, wie geht es dir heute?',it:'Ciao, come stai oggi?',ja:'こんにちは、お元気ですか。',ko:'안녕하세요, 오늘 어떠세요?',zh:'你好，你今天好吗？',pt:'Olá, como está hoje?'};say(demo[vxBase(c?c.tts:'en')]||'Hello');}
});
Object.assign(UI.hy,{vxVoice:'Ձայն',vxGender:'Ձայնի տեսակ',vxAny:'Ավտո',vxF:'Կին',vxM:'Տղամարդ',vxSpeed:'Արագություն',vxTest:'Լսել օրինակ',vxMissing:'Այս լեզվի ձայն չկա',vxMissingLong:'Քո սարքում այս լեզվի ձայն տեղադրված չէ։ Տեղադրիր ձայնը սարքի կարգավորումներից (Text-to-speech), կամ օգտագործիր այլ բրաուզեր։',vxNeural:'Բնական (սերվերային) ձայն, երբ հասանելի է',vxNone:'Այս բրաուզերը ձայնի սինթեզ չի աջակցում։',vxHonest:'Ձայները տրամադրում է քո սարքը/բրաուզերը, որակը տարբեր է։ Վերջնական որակը պետք է ստուգել քո սարքում։'});
Object.assign(UI.en,{vxVoice:'Voice',vxGender:'Voice type',vxAny:'Auto',vxF:'Female',vxM:'Male',vxSpeed:'Speed',vxTest:'Play sample',vxMissing:'No voice for this language',vxMissingLong:'No voice for this language is installed on your device. Install one in the device text-to-speech settings, or try another browser.',vxNeural:'Natural (server) voice when available',vxNone:'This browser does not support speech synthesis.',vxHonest:'Voices come from your device/browser and vary in quality. Check the result on your own device.'});
let ac;
function tone(freqs,dur){
  if(!S.sound)return;dur=dur||.12;
  try{
    ac=ac||new (window.AudioContext||window.webkitAudioContext)();
    const t0=ac.currentTime;
    freqs.forEach((f,i)=>{
      const o=ac.createOscillator(),g=ac.createGain();
      o.type='sine';o.frequency.value=f;
      g.gain.setValueAtTime(.0001,t0+i*dur);
      g.gain.exponentialRampToValueAtTime(.16,t0+i*dur+.02);
      g.gain.exponentialRampToValueAtTime(.0001,t0+i*dur+dur);
      o.connect(g);g.connect(ac.destination);o.start(t0+i*dur);o.stop(t0+i*dur+dur+.03);
    });
  }catch(e){}
}
function distract(W,w,key){
  let pool=W.filter(x=>x.en!==w.en).map(x=>x[key]);
  pool=Array.from(new Set(pool.filter(v=>v&&v!==w[key])));
  return pick(pool,3);
}
const qMc=(w,W,dir)=>{const k=dir==='en2hy'?'hy':'en';return {k:'mc',dir,w,ans:w[k],opts:shuffle([w[k]].concat(distract(W,w,k)))};};
const qPic=(w,W)=>({k:'pic',w,ans:w.en,opts:shuffle([w.en].concat(distract(W,w,'en')))});
const qListen=(w,W)=>({k:'listen',w,ans:w.en,opts:shuffle([w.en].concat(distract(W,w,'en')))});
const qType=w=>({k:'type',w,ans:w.en});
const qBuild=s=>{const words=s.en.replace(/[?.!,]/g,'').split(' ').filter(Boolean);return {k:'build',s,words,tiles:shuffle(words.concat(s.x))};};
const qSmc=(s,all,W)=>{
  const pool=Array.from(new Set(all.filter(x=>x.en!==s.en).map(x=>x.hy).concat((W||[]).map(w=>w.hy)))).filter(v=>v&&v!==s.hy);
  return {k:'smc',s,ans:s.hy,opts:shuffle([s.hy].concat(pick(pool,3)))};
};
const qMatch=F=>{const pairs=F.map((w,i)=>({id:i,en:w.en,hy:w.hy}));return {k:'match',pairs,left:shuffle(pairs.map(p=>p.id)),right:shuffle(pairs.map(p=>p.id))};};
const STOP=['a','an','the','is','am','are','i','my','your','to','in','at','of','and','you','he','she','it','we','they','this','that','what','where'];
function qFill(s,W){
  const words=s.en.replace(/[?.!,]/g,'').split(' ').filter(Boolean);
  const cand=[];words.forEach((w,i)=>{if(STOP.indexOf(w.toLowerCase())<0)cand.push(i);});
  const bi=cand.length?cand[Math.floor(Math.random()*cand.length)]:words.length-1;
  const ans=words[bi];
  const up=ans.charAt(0)!==ans.charAt(0).toLowerCase();
  const fix=w=>up?w.charAt(0).toUpperCase()+w.slice(1):w.toLowerCase();
  const pool=Array.from(new Set((s.x||[]).concat(W.map(w=>w.en)).filter(w=>w&&w.indexOf(' ')<0&&norm(w)!==norm(ans)).map(fix)));
  const end=/[?.!]$/.test(s.en)?s.en.slice(-1):'';
  return {k:'fill',s,words,bi,ans,end,opts:shuffle([ans].concat(pick(pool,3)))};
}
