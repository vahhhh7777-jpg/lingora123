/* ---------- Lingora 3.0, step 1: home "Recommended practice". Everything is derived from the learner's real data:
   due flashcards (SRS), the mistake book, the first story not finished yet. A card is shown only when it has something real to offer. ---------- */
function homePractice(){
  if(!canPractice()&&!S.xp)return '';
  try{pxLoadStories();}catch(e){}
  const items=[];
  const due=pxDueCards().length;
  if(due)items.push(['repeat',pt('cards'),pt('dueN',{n:due}),'cards']);
  const miss=Object.keys(S.miss||{}).length;
  if(miss)items.push(['badge',pt('mist'),String(miss),'mist']);
  if(!items.length)return '';
  return `<section class="hm-more" aria-label="${esc(t('hmRec'))}"><div class="sec-h"><h2>${esc(t('hmRec'))}</h2></div><div class="px-grid">${
    items.map(x=>`<button class="px-card" data-hm="${esc(x[3])}"><span class="px-ic">${LI(x[0])}</span><span class="px-tx"><b>${esc(x[1])}</b><small>${esc(x[2])}</small></span></button>`).join('')}</div></section>`;
}
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-hm]');if(!b)return;
  const a=b.dataset.hm;pgAnim=true;
  if(a==='cards'){pxCardsStart();window.scrollTo(0,0);return;}
  if(a==='mist'){ptab='mist';tab='me';}
  else if(a==='ai'){tab='learn';PX.v='hub';}
  else return;
  render();window.scrollTo(0,0);
});
Object.assign(UI.hy,{hmRec:'Խորհուրդ տրվող պրակտիկա'});Object.assign(UI.en,{hmRec:'Recommended practice'});

