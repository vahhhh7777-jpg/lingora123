/* ---------- placement test (adaptive staircase over a graded bank; English) ---------- */
const PBANK=[
 [['She ___ a student.','is',['am','are','be'],'With “she” we use “is”.'],['I ___ coffee every morning.','drink',['drinks','drinking','drank'],'Present simple with “I”: drink.'],['What is the opposite of “hot”?','cold',['warm','big','slow'],'The opposite of hot is cold.'],['There ___ two books on the table.','are',['is','am','be'],'Plural “books” takes “are”.'],['How old ___ you?','are',['is','am','do'],'“How old are you?”'],['What do you say at 8 a.m.? “Good ___!”','morning',['night','evening','bye'],'Morning greeting.']],
 [['Yesterday I ___ to the market.','went',['go','gone','going'],'Past simple of “go” is “went”.'],['He is taller ___ his brother.','than',['then','that','as'],'Comparatives use “than”.'],['I don’t have ___ money.','any',['some','a','an'],'Negative sentences use “any”.'],['We ___ TV when the phone rang.','were watching',['watched','watch','have watched'],'Past continuous for an action in progress.'],['Which word means “a place where you borrow books”?','library',['bakery','pharmacy','station'],'A library lends books.'],['She asked me ___ I lived.','where',['what','who','why'],'Indirect question: “where I lived”.']],
 [['If it rains tomorrow, we ___ at home.','will stay',['stay','would stay','stayed'],'First conditional: if + present, will + verb.'],['I have lived here ___ 2019.','since',['for','from','during'],'“Since” goes with a point in time.'],['The report ___ by the manager yesterday.','was written',['wrote','is writing','has wrote'],'Passive past: was written.'],['He suggested ___ a taxi.','taking',['to take','take','took'],'“Suggest” is followed by -ing.'],['She is interested ___ photography.','in',['on','at','for'],'“Interested in”.'],['I’m not used ___ getting up so early.','to',['for','with','at'],'“Be used to” + -ing.']],
 [['If I ___ more time, I would learn Italian.','had',['have','would have','will have'],'Second conditional: if + past simple.'],['By the time we arrived, the film ___.','had already started',['already started','has already started','was already starting'],'Past perfect: an earlier past action.'],['She denied ___ the window.','breaking',['to break','break','to have break'],'“Deny” is followed by -ing.'],['I wish I ___ speak French.','could',['can','would','will'],'“Wish” + past form: could.'],['Hardly ___ the house when it began to rain.','had he left',['he left','did he left','he had left'],'Inversion after “hardly”.'],['The company’s profits have ___ significantly this year.','risen',['raised','rose','rising'],'“Rise” is intransitive: risen.']],
 [['Not only ___ late, but he also forgot the documents.','was he',['he was','he is','is he'],'Inversion after “not only”.'],['The policy has been widely criticised, ___ its supporters insist it is necessary.','although',['despite','because','unless'],'“Although” introduces a contrast clause.'],['She has an excellent ___ of the subject.','command',['hand','touch','force'],'“A good command of” a subject.'],['The accident was caused by a ___ lapse in concentration.','momentary',['momentous','momently','moment'],'“Momentary” means lasting a very short time.'],['Had I known about the delay, I ___ earlier.','would have left',['would leave','had left','will have left'],'Third conditional with inversion.'],['Choose the word closest in meaning to “ubiquitous”.','present everywhere',['very rare','extremely old','dangerous'],'Ubiquitous means found everywhere.']],
 [['Choose the word closest in meaning to “ephemeral”.','short-lived',['eternal','fragile','hidden'],'Ephemeral things last a very short time.'],['“He was at pains to point out…” means he…','made a careful effort to',['was suffering','felt guilty','refused to'],'“At pains to” = took trouble to.'],['The committee’s decision was, to put it ___, controversial.','mildly',['mild','mildest','mildness'],'“To put it mildly” is a fixed phrase.'],['Neither of the proposals ___ satisfactory.','was',['were','are','have been'],'“Neither” takes a singular verb in formal English.'],['She spoke with such ___ that nobody dared interrupt.','gravitas',['grave','gravely','gravitate'],'“Gravitas” = serious dignity.'],['The minister’s remarks were deliberately ___, allowing several interpretations.','equivocal',['unequivocal','emphatic','explicit'],'Equivocal = open to more than one meaning.']]
];
const PN=12;
function pxPlaceStart(){
  PX.place={n:0,lv:1,used:{},hist:[],cur:null,sel:null,res:null,done:false};PX.v='place';pxPlaceNext();render();
}
function pxPlaceNext(){
  const P=PX.place,lv=P.lv,bank=PBANK[lv];
  let idx=bank.map((_,i)=>i).filter(i=>!P.used[lv+'-'+i]);
  if(!idx.length)idx=bank.map((_,i)=>i);
  const i=idx[Math.floor(Math.random()*idx.length)];P.used[lv+'-'+i]=1;
  const q=bank[i];P.cur={lv,q:q[0],a:q[1],o:shuffle([q[1]].concat(q[2])),x:q[3]};P.sel=null;P.res=null;
}
function pxPlaceView(){
  if(!pxEn())return `${pxBack()}<div class="say">${gloro('curious',56)}<span>${esc(pt('pOnlyEn'))}</span></div>`;
  const P=PX.place;
  if(!P)return `${pxBack()}<section class="card"><h1>${esc(pt('place'))}</h1><p>${esc(pt('pIntro'))}</p><button class="btn btn-purple" data-px="pstart">${esc(pt('start'))}</button></section>`;
  if(P.done){
    const c=P.hist.filter(h=>h.ok).length,last=P.hist.slice(-6),est=Math.min(5,Math.max(0,Math.round(last.reduce((n,h)=>n+h.lv,0)/last.length)));
    P.est=CEFR[est];
    return `${pxBack()}<section class="card px-result"><div class="say">${gloro('celebrating',72)}<span>${esc(pt('pRes',{l:P.est}))}</span></div>
      <p class="px-lvl big on">${esc(P.est)}</p><p>${esc(pt('pDesc_'+P.est))}</p><p class="note">${esc(pt('pScore',{c,n:P.hist.length}))}</p>
      <div class="px-ans"><button class="btn btn-ghost" data-px="pstart">${esc(pt('pRetake'))}</button><button class="btn btn-orange" data-px="psave">${esc(pt('pSave'))}</button></div><p class="note">${esc(pt('pNote'))}</p></section>`;
  }
  const c=P.cur,pct=Math.round(P.n/PN*100);
  return `${pxBack()}<div class="px-prog" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}"><i style="width:${pct}%"></i></div>
   <p class="note px-cnt">${esc(pt('pQ',{i:P.n+1,n:PN}))}</p>
   <section class="card"><h2 lang="en">${esc(c.q)}</h2><div class="opts">${c.o.map((o,i)=>{let k='opt';if(P.res){if(o===c.a)k+=' ok';else if(i===P.sel)k+=' no';}else if(i===P.sel)k+=' sel';
     return `<button class="${k}" data-px="pans" data-i="${i}" ${P.res?'disabled':''}><span class="k">${i+1}</span><span class="ot">${esc(o)}</span></button>`;}).join('')}</div>
   ${P.res?`<div class="px-fb ${P.res}" role="status"><b>${P.res==='ok'?'✓':'✗'}</b> ${esc(c.x)}</div><button class="btn btn-purple" data-px="pnext">${esc(P.n+1>=PN?pt('pFinish'):pt('pNext'))}</button>`:''}</section>`;
}
function pxPlaceAnswer(i){
  const P=PX.place;if(!P||P.res)return;const c=P.cur;P.sel=i;const ok=c.o[i]===c.a;P.res=ok?'ok':'no';
  P.hist.push({lv:c.lv,ok});P.lv=ok?Math.min(5,P.lv+1):Math.max(0,P.lv-1);
  render();
}
function pxPlaceSave(){
  const P=PX.place;if(!P||!P.est)return;
  const p=pxPx();p.cefr=P.est;p.placed=Date.now();
  const m={A1:'beginner',A2:'basic'};S.level=m[P.est]||'inter';
  save();pushProgress();toast(pt('pSaved'),'celebrating');render();
  if(pxCloud()){const c=P.hist.filter(h=>h.ok).length;B.placeRec(S.course||'en',P.est,c,P.hist.length).catch(()=>toast(pt('plSyncErr')));}
}

