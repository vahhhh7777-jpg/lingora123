/* ---------- server-authoritative economy (cloud mode) ----------
   In cloud mode XP, streak, freezes, boosts, gems and hearts are decided by the database
   (start_lesson / complete_lesson / lesson_miss / complete_practice). The browser only displays them.
   Demo and local modes keep the old in-browser rules. */
Object.assign(UI.hy,{payWait:'Վճարումը ստացվեց․ VIP-ը մի քանի վայրկյանից կակտիվանա։',payOk:'VIP-ը ակտիվ է։ Շնորհակալություն։',payCancel:'Վճարումը չեղարկվեց։ Ոչինչ չի գանձվել։',buyFail:'Չհաջողվեց սկսել վճարումը։ Փորձիր կրկին կամ գրիր մեզ։',resetPend:'Սերվերում զրոյացումը դեռ չի կատարվել․ սարքիդ վրա արդեն մաքրվել է, և կկրկնենք, երբ կապը վերականգնվի։',saving:'Պահպանում ենք առաջընթացդ…',e_no_hearts:'Սրտերը վերջացել են։ Սպասիր, մինչև նորից լցվեն։',e_too_fast:'Դասն անցել է չափազանց արագ, XP չի շնորհվել։ Փորձիր կրկին։',e_rate_limited:'Այսօրվա սահմանաչափը լրացել է։',e_net:'Կապ չկա։ XP-ն չի գրանցվել, փորձիր կրկին։',e_other:'Չհաջողվեց պահպանել։ Փորձիր կրկին։',xpHist:'XP պատմություն',xpNone:'XP շարժ դեռ չկա։',k_lesson:'Դաս',k_practice:'Կրկնություն',k_streak:'Շարքի մրցանակ',k_quest:'Առաքելություն',k_other:'Այլ',lvUp:'Նոր մակարդակ',lvNext:'մինչև մակարդակ',lvGo:'Շարունակել',lvUnlock:'Շարունակիր սովորել՝ հաջորդ նպատակին հասնելու համար։',srvXp:'XP-ն հաշվում է սերվերը'});
Object.assign(UI.en,{payWait:'Payment received. VIP will activate in a few seconds.',payOk:'VIP is active. Thank you.',payCancel:'Payment cancelled. Nothing was charged.',buyFail:'Could not start the payment. Try again or contact us.',resetPend:'The reset has not reached the server yet. It is cleared on this device and will be retried when the connection is back.',saving:'Saving your progress…',e_no_hearts:'You are out of hearts. Wait for them to refill.',e_too_fast:'That was too fast, so no XP was awarded. Try again.',e_rate_limited:'Today’s limit has been reached.',e_net:'No connection. XP was not recorded. Please retry.',e_other:'Could not save. Please retry.',xpHist:'XP history',xpNone:'No XP activity yet.',k_lesson:'Lesson',k_practice:'Practice',k_streak:'Streak reward',k_quest:'Quest',k_other:'Other',lvUp:'New level',lvNext:'to level',lvGo:'Continue',lvUnlock:'Keep learning to reach the next goal.',srvXp:'XP is counted by the server'});
const ECON=()=>(MODE==='cloud'&&!!A.user&&!!B&&!!B.econStart);
const tzMin=()=>-new Date().getTimezoneOffset();
function applyState(st){
  if(!st||typeof st.xp!=='number')return;
  A.srv=st;
  S.xp=st.xp;S.gems=st.gems||0;
  S.streak=st.streak||0;S.best=Math.max(S.best||0,st.best_streak||0,S.streak);
  if(st.streak>0)S.last=st.streak_today?today():yesterday();
  S.freeze=st.freezes||0;
  S.boost=st.boost_until?{until:Date.parse(st.boost_until),mult:st.boost_mult||2}:null;
  S.day=today();S.dayXp=st.day_xp||0;
  if(st.goal)S.goal=st.goal;
  Object.keys(st.done||{}).forEach(k=>{S.done[k]=Math.max(S.done[k]||0,st.done[k]);});
}
async function econSync(){
  if(!ECON()||resetPending())return;
  try{applyState(await B.econState(tzMin()));save();}catch(e){}
}
const econErr=e=>t('e_'+((e&&e.code)||'other'))||t('e_other');
/* Starts a server attempt. Returns false (with a message) when the server refuses. */
async function econBegin(kind,lessonId,n){
  try{
    if(resetPending())await resetFlush();   /* B-006: a pending reset reaches the server before any new lesson */
    const r=await B.econStart(lessonId,kind,n);
    L.att=r.attempt_id;applyState(r.state);
    if(r.state&&typeof r.state.hearts==='number'&&!r.state.unlimited)L.hearts=Math.min(L.hearts,r.state.hearts);
    return true;
  }catch(e){toast(econErr(e),'confused');return false;}
}
function econMiss(){
  if(!L||!L.att||L.preview)return;
  B.econMiss(L.att).then(applyState).catch(warnErr('heart loss not recorded on the server'));
}
async function econFinish(mistakes,correct){
  let last=null;
  for(let i=0;i<3;i++){
    try{return L.practice?await B.econPractice(L.att,correct):await B.econDone(L.att,mistakes);}
    catch(e){last=e;if(e&&e.code&&e.code!=='net')break;await new Promise(r=>setTimeout(r,1200));}
  }
  throw last||E('other');
}
Object.assign(UI.hy,{dAll:'Բոլորը',dNew:'Նոր',dLearning:'Սովորում եմ',dReview:'Կրկնելու',dLearned:'Սովորած',markLearned:'Նշել որպես սովորած',dEmpty:'Դեռ բառեր չկան։ Անցիր առաջին դասը, և հանդիպած բառերը կհայտնվեն այստեղ։',dSort:'Դասավորել',dSortAz:'Ա–Զ',dSortProg:'Ըստ առաջընթացի',dReviewCta:'Կրկնել {n} բառ'});
Object.assign(UI.en,{dAll:'All met',dNew:'New',dLearning:'Learning',dReview:'To review',dLearned:'Learned',markLearned:'Mark as learned',dEmpty:'No words yet. Finish your first lesson and the words you meet will appear here.',dSort:'Sort',dSortAz:'A–Z',dSortProg:'By progress',dReviewCta:'Review {n} words'});
