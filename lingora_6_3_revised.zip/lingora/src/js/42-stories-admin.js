/* ---------- stories admin ---------- */
const PXA={rows:null,busy:false,edit:null,err:'',arm:'',lm:['en','fr','de','it','tr','az','ru']};
async function pxAdminLoad(){
  if(PXA.busy||PXA.rows||!pxCloud())return;PXA.busy=true;
  try{PXA.rows=await B.storiesAll();PXA.err='';}catch(e){PXA.rows=[];PXA.err=(e&&/relation|42P01|schema cache|stories/i.test(String(e.message||e.code)))?pt('sErrMig'):pt('sErrSave');}
  PXA.busy=false;if(tab==='admin'&&adm.sub==='stories')render();
}
const pxLines=s=>String(s||'').split('\n').map(x=>x.trim());
function pxToText(r){
  return {p:(r.paragraphs||[]).map(x=>[x.t,x.tr].concat(x.audio?[x.audio]:[]).join(' || ')).join('\n'),
          v:(r.vocab||[]).map(x=>x.w+' = '+x.tr).join('\n'),
          q:(r.questions||[]).map(x=>[(+x.p||0)+1,x.q,x.a,(x.o||[]).join(' ; '),x.x||''].join(' | ')).join('\n')};
}
function pxParse(f){
  const err=[],title={hy:f.th.trim(),en:f.te.trim()};
  if(!title.hy&&!title.en)err.push(pt('vTitle'));
  if(f.pub&&!f.lessonId)err.push(pt('sNeedLesson'));
  const paragraphs=[];pxLines(f.p).forEach((l,i)=>{if(!l)return;const a=l.split('||').map(x=>x.trim());if(!a[0]||!a[1]){err.push(pt('vParaLine',{n:i+1}));return;}
    const o={t:a[0],tr:a[1]};if(a[2]){if(!/^https:\/\//i.test(a[2])){err.push(pt('vAudio',{n:i+1}));return;}o.audio=a[2];}paragraphs.push(o);});
  if(!paragraphs.length)err.push(pt('vParaMin'));
  const vocab=[];pxLines(f.v).forEach((l,i)=>{if(!l)return;const k=l.indexOf('=');if(k<1||!l.slice(k+1).trim()){err.push(pt('vVocabLine',{n:i+1}));return;}vocab.push({w:l.slice(0,k).trim(),tr:l.slice(k+1).trim()});});
  if(!vocab.length)err.push(pt('vVocabMin'));
  const questions=[];pxLines(f.q).forEach((l,i)=>{if(!l)return;const a=l.split('|').map(x=>x.trim());const n=parseInt(a[0],10);const wrong=(a[3]||'').split(';').map(x=>x.trim()).filter(Boolean);
    if(!(n>=1)||!a[1]||!a[2]||!wrong.length){err.push(pt('vQLine',{n:i+1}));return;}
    if(n>paragraphs.length){err.push(pt('vQPara',{n:i+1}));return;}
    questions.push({p:n-1,q:a[1],a:a[2],o:wrong,x:a[4]||''});});
  if(!questions.length&&!err.length)err.push(pt('vQMin'));
  return {err,row:{language:f.lang,level:f.level,lesson_id:f.lessonId||null,emoji:(f.emoji||'📖').trim().slice(0,8)||'📖',title,paragraphs,vocab,questions,published:!!f.pub,position:+f.pos||0}};
}
function pxAdminStories(){
  if(!pxCloud())return `<div class="say">${gloro('curious',56)}<span>${esc(pt('sNeedCloud'))}</span></div>`;
  pxAdminLoad();
  if(PXA.edit)return pxAdminForm();
  if(!PXA.rows)return `<div role="status">${loading()}${skel(3)}</div>`;
  return `${PXA.err?`<p class="msg err" role="alert">${esc(PXA.err)}</p>`:''}
   <div class="acts tb"><button class="btn btn-orange" data-px="as-new">${esc(pt('sNew'))}</button></div>
   ${PXA.rows.length?PXA.rows.map(r=>{const ok=(r.paragraphs||[]).length&&(r.questions||[]).length;return `<div class="px-arow"><span class="px-em" aria-hidden="true">${esc(r.emoji||'📖')}</span>
     <div class="px-tx"><b>${esc(tx(r.title))}</b><small>${esc(r.language)} · ${esc(r.level)}${r.lesson_id?' · '+esc((FLAT.find(f=>f.id===r.lesson_id)&&lessonLabel(FLAT.find(f=>f.id===r.lesson_id)))||r.lesson_id):' · '+esc(pt('sNoLesson'))} · ${(r.paragraphs||[]).length} ¶ · ${(r.questions||[]).length} ?${ok?'':' · ⚠'}</small></div>
     <span class="px-bd ${r.published?'ok':''}">${esc(r.published?pt('sPub'):pt('sDraft'))}</span>
     <div class="px-acts"><button class="sbtn" data-px="as-pub" data-v="${esc(r.id)}">${esc(r.published?pt('sUnpub'):pt('sPubBtn'))}</button><button class="sbtn" data-px="as-edit" data-v="${esc(r.id)}">${esc(pt('sEdit'))}</button><button class="sbtn ${PXA.arm===r.id?'bad':''}" data-px="as-del" data-v="${esc(r.id)}">${esc(PXA.arm===r.id?pt('sSure'):pt('sDel'))}</button></div></div>`;}).join(''):`<div class="empty">${esc(pt('sNone'))}</div>`}`;
}
function pxAdminForm(){
  const e=PXA.edit,f=e.f;
  const opt=(arr,cur)=>arr.map(x=>`<option ${x===cur?'selected':''}>${esc(x)}</option>`).join('');
  const lessonOpts=`<option value="">— ${esc(pt('sNoLesson'))} —</option>`+FLAT.map(x=>`<option value="${esc(x.id)}" ${x.id===f.lessonId?'selected':''}>${esc(lessonLabel(x)+' · '+tx(x.u.t))}</option>`).join('');
  return `<section class="card px-form"><h2>${esc(pt(e.id?'sEdit':'sNew'))}</h2>${PXA.err?`<div class="msg err" role="alert">${esc(PXA.err).replace(/\n/g,'<br>')}</div>`:''}
   <div class="px-fgrid"><label class="fld"><span>${esc(pt('sLang'))}</span><select id="sf-lang">${opt(PXA.lm,f.lang)}</select></label>
   <label class="fld"><span>${esc(pt('sLevel'))}</span><select id="sf-level">${opt(CEFR,f.level)}</select></label>
   <label class="fld"><span>${esc(pt('sLesson'))}</span><select id="sf-lesson">${lessonOpts}</select></label>
   <label class="fld"><span>${esc(pt('sEmoji'))}</span><input id="sf-emoji" maxlength="8" value="${esc(f.emoji)}"></label></div>
   <label class="fld"><span>${esc(pt('sTitleHy'))}</span><input id="sf-th" maxlength="120" value="${esc(f.th)}"></label>
   <label class="fld"><span>${esc(pt('sTitleEn'))}</span><input id="sf-te" maxlength="120" value="${esc(f.te)}"></label>
   <label class="fld"><span>${esc(pt('sParas'))}</span><textarea id="sf-p" rows="7">${esc(f.p)}</textarea><small class="hint">${esc(pt('sParasH'))}</small></label>
   <label class="fld"><span>${esc(pt('sVocab'))}</span><textarea id="sf-v" rows="4">${esc(f.v)}</textarea><small class="hint">${esc(pt('sVocabH'))}</small></label>
   <label class="fld"><span>${esc(pt('sQs'))}</span><textarea id="sf-q" rows="6">${esc(f.q)}</textarea><small class="hint">${esc(pt('sQsH'))}</small></label>
   <label class="chk"><input type="checkbox" id="sf-pub" ${f.pub?'checked':''}> ${esc(pt('sPub'))}</label>
   <div class="px-ans"><button class="btn btn-ghost" data-px="as-cancel">${esc(pt('sCancel'))}</button><button class="btn btn-orange" data-px="as-save" ${PXA.busy?'disabled':''}>${esc(pt('sSave'))}</button></div></section>`;
}
function pxFormRead(){
  const v=id=>{const x=$(id);return x?x.value:'';};
  return {lang:v('sf-lang'),level:v('sf-level'),lessonId:v('sf-lesson'),emoji:v('sf-emoji'),th:v('sf-th'),te:v('sf-te'),p:v('sf-p'),v:v('sf-v'),q:v('sf-q'),pub:!!($('sf-pub')||{}).checked,pos:0};
}
async function pxAdminSave(){
  if(PXA.busy)return;const e=PXA.edit,f=pxFormRead();e.f=f;
  const r=pxParse(f);if(r.err.length){PXA.err=r.err.join('\n');render();return;}
  PXA.busy=true;PXA.err='';render();
  try{const row=Object.assign({},r.row,{updated_at:new Date().toISOString()});if(e.id)row.id=e.id;await B.storySave(row);PXA.rows=null;PXA.edit=null;PXDB.list=null;toast(pt('sSaved'),'celebrating');}
  catch(x){PXA.err=/stories_publish_ready/.test(String(x&&x.message))?pt('vQMin'):pt('sErrSave');}
  PXA.busy=false;render();pxAdminLoad();
}
async function pxAdminToggle(id){
  const r=(PXA.rows||[]).find(x=>x.id===id);if(!r)return;
  if(!r.published&&!r.lesson_id){PXA.err=pt('sNeedLesson');render();return;}
  try{await B.storySave({id:r.id,published:!r.published,updated_at:new Date().toISOString()});PXA.rows=null;PXDB.list=null;PXA.err='';}
  catch(x){PXA.err=pt('vQMin');}
  render();pxAdminLoad();
}
async function pxAdminDelete(id){
  if(PXA.arm!==id){PXA.arm=id;render();return;}
  PXA.arm='';try{await B.storyDel(id);PXA.rows=null;PXDB.list=null;PXA.err='';}catch(x){PXA.err=pt('sErrSave');}
  render();pxAdminLoad();
}
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-px^="as-"]');if(!b||!isStaff())return;
  const a=b.dataset.px,v=b.dataset.v;
  if(a==='as-new'){PXA.edit={id:'',f:{lang:S.course||'en',level:'A1',lessonId:'',emoji:'📖',th:'',te:'',p:'',v:'',q:'',pub:false,pos:0}};PXA.err='';render();}
  else if(a==='as-edit'){const r=PXA.rows.find(x=>x.id===v);if(!r)return;const tt=pxToText(r);PXA.edit={id:r.id,f:{lang:r.language,level:r.level,lessonId:r.lesson_id||'',emoji:r.emoji,th:(r.title||{}).hy||'',te:(r.title||{}).en||'',p:tt.p,v:tt.v,q:tt.q,pub:r.published,pos:r.position}};PXA.err='';render();}
  else if(a==='as-cancel'){PXA.edit=null;PXA.err='';render();}
  else if(a==='as-save')pxAdminSave();
  else if(a==='as-pub')pxAdminToggle(v);
  else if(a==='as-del')pxAdminDelete(v);
});

