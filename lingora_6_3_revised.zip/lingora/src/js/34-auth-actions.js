/* ---------- auth actions ---------- */
async function doAuth(){
  const v=id=>($(id)||{}).value||'';
  const em=v('em').trim(),pw=v('pw'),nm=v('nm').trim();
  A.em=em;A.nm=nm;A.err='';A.msg='';
  const su=A.form==='signup',pw2=v('pw2');
  if(su)A.tm=!!($('tm')||{}).checked;
  if(!/^\S+@\S+\.\S+$/.test(em)){A.err='email';render();return;}
  if(su&&!(pw.length>=8&&/[A-Za-z\u0531-\u058F]/.test(pw)&&/\d/.test(pw))){A.err='weak';render();return;}
  if(!su&&pw.length<6){A.err='short';render();return;}
  if(su&&pw!==pw2){A.err='match';render();return;}
  if(su&&!A.tm){A.err='terms';render();return;}
  A.busy=true;render();
  try{
    if(A.form==='signup'){
      const r=await B.signUp(em,pw,nm);
      if(r.needsConfirm){A.msg='confirm';A.form='signin';}
      else await afterLogin(r.user);
    }else{
      await afterLogin(await B.signIn(em,pw));
    }
  }catch(e){A.err=mapErr(e);}
  A.busy=false;
  if(A.user&&!S.onb)flow='onboard';
  if(A.user&&S.onb){flow='landing';if(A.next){const n=A.next;A.next='';tab=guardRoute(n);pgAnim=true;enterTab(tab);}else tab=guardRoute(tab);}
  render();
}
async function doForgot(){
  const em=($('em')||{}).value||'';
  A.em=em.trim();A.err='';A.msg='';
  if(!/^\S+@\S+\.\S+$/.test(A.em)){A.err='email';render();return;}
  try{await B.resetPassword(A.em);A.msg='reset';}catch(e){A.err=mapErr(e);}
  render();
}
async function doSetPw(){
  const pw=($('np')||{}).value||'';A.err='';
  if(pw.length<6){A.err='short';render();return;}
  try{await B.updatePassword(pw);A.recovery=false;A.msg='pw';}catch(e){A.err=mapErr(e);}
  render();
}
async function saveName(){
  const v=(($('pn')||{}).value||'').trim().slice(0,24);
  S.name=v;save();
  if(A.user&&B){try{await B.setName(v);if(A.profile)A.profile.name=v;saveCache();pushProgress();}catch(e){toast(t('e_'+mapErr(e)));render();return;}}
  toast(t('saved'));render();
}
async function doSignOut(){
  /* P1-01: deliver unsynced progress first; if the server cannot be reached keep a snapshot for the next sign-in of this account */
  if(B&&A.user&&!resetPending()&&(syncWasPending()||SYNC.st==='pending'||SYNC.st==='offline'||SYNC.st==='syncing'||SYNC.st==='denied')){
    try{await Promise.race([syncNow(),new Promise(r=>setTimeout(r,5000))]);}catch(e){console.warn('sign-out: final sync failed',e);}
    if(syncWasPending()||SYNC.st==='pending'||SYNC.st==='offline'||SYNC.st==='denied')stashSave();
  }
  let outErr=null;
  try{if(B)await B.signOut();}catch(e){outErr=e;console.warn('sign-out request failed',e);}
  if(outErr&&B&&B.forgetSession)B.forgetSession();                  /* P1-03: the session must not come back on the next load */
  try{syncReset();aiChatWipe();AI.usage=null;AI.out=null;AI.err='';}catch(e){console.warn('sign-out cleanup',e);}
  A.user=null;A.profile=null;A.rawCat=null;A.dbCount=0;A.next='';SOC.data=null;SOC.err='';SOC.q='';SOC.fb=null;PE.open=false;PE.nm=PE.un=PE.av=PE.lg=null;
  resetProgress(true);save();saveCache();syncOffline();
  try{if(B)await refreshCatalog();else setCatalog(null);}catch(e){setCatalog(null);}
  tab='home';flow='landing';render();
  if(outErr)toast(t('signoutPartial'),'confused',6500);
}

