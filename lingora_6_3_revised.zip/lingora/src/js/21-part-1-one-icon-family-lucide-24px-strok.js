/* ---------- Part 1: one icon family (Lucide, 24px stroke icons) and the avatar system ----------
   LUC / LI come from 72_settings.js. Everything new in the interface draws its icons from LI() so the
   look stays consistent; the older filled glyphs in IC remain only inside lessons and the landing page. */
Object.assign(LUC,{
  home:'<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  learn:'<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
  book:'<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20"/>',
  sparkles:'<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/><path d="M20 3v4"/><path d="M22 5h-4"/><path d="M4 17v2"/><path d="M5 18H3"/>',
  bot:'<path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/>',
  users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  userplus:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" x2="19" y1="8" y2="14"/><line x1="22" x2="16" y1="11" y2="11"/>',
  gem:'<circle cx="12" cy="12" r="11" fill="#FF922B" stroke="#C96A0A" stroke-width="1"/><circle cx="12" cy="12" r="8.9" fill="#FFB15C" stroke="#FFD9A3" stroke-width=".7"/><path d="M9.4 8.3 9.1 6.5M14.6 8.3 14.9 6.5" stroke="#8A4B12" stroke-width="1" stroke-linecap="round" fill="none"/><circle cx="9.1" cy="6.3" r=".9" fill="#8A4B12" stroke="none"/><circle cx="14.9" cy="6.3" r=".9" fill="#8A4B12" stroke="none"/><ellipse cx="7" cy="10.4" rx="1.5" ry="1" fill="#F5A25A" stroke="none"/><ellipse cx="17" cy="10.4" rx="1.5" ry="1" fill="#F5A25A" stroke="none"/><ellipse cx="12" cy="12.6" rx="5.1" ry="4.6" fill="#FFE2B4" stroke="none"/><circle cx="9.7" cy="9.9" r=".8" fill="#E8791A" stroke="none"/><circle cx="14.4" cy="10.2" r=".7" fill="#E8791A" stroke="none"/><circle cx="12.2" cy="8.9" r=".55" fill="#E8791A" stroke="none"/><circle cx="10.2" cy="12" r=".75" fill="#101827" stroke="none"/><circle cx="13.8" cy="12" r=".75" fill="#101827" stroke="none"/><ellipse cx="12" cy="14.7" rx="2.4" ry="1.6" fill="#FFF4DE" stroke="none"/><circle cx="11.2" cy="14.2" r=".38" fill="#8A4B12" stroke="none"/><circle cx="12.8" cy="14.2" r=".38" fill="#8A4B12" stroke="none"/><path d="M11 15.2q1 .8 2 0" stroke="#8A4B12" stroke-width=".6" stroke-linecap="round" fill="none"/>',
  gift:'<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"/>',
  play:'<polygon points="6 3 20 12 6 21 6 3"/>',
  right:'<path d="m9 18 6-6-6-6"/>',
  plus:'<path d="M5 12h14"/><path d="M12 5v14"/>',
  copy:'<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  settings:'<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  bag:'<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>',
  map:'<path d="M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z"/><path d="M15 5.764v15"/><path d="M9 3.236v15"/>',
  heart:'<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
  bulb:'<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/>',
  repeat:'<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/>',
  badge:'<path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><path d="m9 12 2 2 4-4"/>',
  usercheck:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="16 11 18 13 22 9"/>',
  search:'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  hourglass:'<path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/>',
  star:'<path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/>',
  eye:'<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>'
});

/* Preset avatars: gradients that are always available, synced to the account (profiles.avatar).
   A photo chosen in Settings still wins on that device. */
const AVATARS=[
  {id:'sun',a:'#FFC15E',b:'#FF8A3D'},{id:'grape',a:'#6FB1FF',b:'#0F5FD6'},{id:'mint',a:'#6EE7B7',b:'#10B981'},
  {id:'sky',a:'#7DD3FC',b:'#3B82F6'},{id:'rose',a:'#FDA4AF',b:'#F43F5E'},{id:'night',a:'#818CF8',b:'#312E81'}
];
const avatarBg=id=>{const a=AVATARS.find(x=>x.id===id);return a?`background:linear-gradient(135deg,${a.a},${a.b})`:'';};
/* mine=true: this is the signed-in learner, so their device photo and saved preset apply.
   Everyone else gets their own preset (when we know it) or an initial; never somebody else's photo. */
function avatar(name,cls,mine,preset){
  const ini=esc((name||'?').trim().charAt(0).toUpperCase()||'?');
  if(mine&&S.avatar)return `<span class="av ${cls||''}" aria-hidden="true"><img src="${esc(S.avatar)}" alt=""></span>`;
  const pr=preset!==undefined?preset:(mine&&A.profile?A.profile.avatar:'');
  return `<span class="av ${cls||''} ${pr?'pre':''}" style="${avatarBg(pr)}" aria-hidden="true">${ini}</span>`;
}
const myAvatar=cls=>avatar(displayName(),cls,true);

/* The role shown to the learner. VIP is derived from the subscription, never stored as a role. */
const ROLE_ICON={super:'crown',admin:'shield',editor:'pencil',vip:'crown',free:'user',guest:'user',suspended:'lock'};
function roleBadge(){
  const k=roleKey();
  return `<span class="rbadge r-${k}">${LI(ROLE_ICON[k]||'user')}${esc(t('role_'+k))}</span>`;
}
