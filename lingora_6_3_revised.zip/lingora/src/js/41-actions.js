/* ---------- actions ---------- */
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-px]');if(!b)return;
  const a=b.dataset.px,v=b.dataset.v;
  switch(a){
    case 'hub':PX.v='hub';break;
    case 'cards':pxCardsStart();return;
    case 'flip':if(PX.cards)PX.cards.flip=!PX.cards.flip;break;
    case 'know':pxCardGrade(true);return;
    case 'dunno':pxCardGrade(false);return;
    case 'stories':PX.v='hub';tab='learn';break;
    case 'story':case 'lesson-story':PX.story=v;PX.sTr={};PX.v='story';tab='learn';if(L)closeLesson();break;
    case 'tr':PX.sTr[v]=!PX.sTr[v];break;
    case 'quiz':pxStartQuiz(v);return;
    case 'listen':pxStartListen();return;
    case 'speak':pxStartSpeak();return;
    case 'place':PX.v='place';PX.place=null;tab='learn';break;
    case 'pstart':pxPlaceStart();return;
    case 'pans':pxPlaceAnswer(+b.dataset.i);return;
    case 'pnext':{const P=PX.place;if(!P)return;P.n++;if(P.n>=PN)P.done=true;else pxPlaceNext();break;}
    case 'psave':pxPlaceSave();return;
    case 'cgoal':pxCardGoalCycle();break;
    case 'mist':ptab='mist';tab='me';pgAnim=true;break;
    case 'vocab':tab='words';pgAnim=true;break;
    case 'ai':tab='learn';PX.v='hub';pgAnim=true;break;
    case 'scn':PX.scn=v||'';AI.out=null;AI.err='';break;
    default:return;
  }
  render();window.scrollTo(0,0);
});


/* =====================================================================================================
   LINGORA 2.1: stories and placement results stored in Supabase (migration 011), stories admin.
   ===================================================================================================== */
Object.assign(UI.hy,{s_stories:'Պատմություններ'});Object.assign(UI.en,{s_stories:'Stories'});
Object.assign(PXS.hy,{sLesson:'Դաս',sNoLesson:'Ընտրիր դասը',sNeedLesson:'Հրապարակելուց առաջ ընտրիր դասը։',sAdmin:'Պատմություններ',sNew:'Նոր պատմություն',sEdit:'Խմբագրել',sDel:'Ջնջել',sSure:'Սեղմիր նորից՝ հաստատելու համար',sPub:'Հրապարակված',sDraft:'Սևագիր',sPubBtn:'Հրապարակել',sUnpub:'Հանել հրապարակումից',
 sLang:'Լեզու',sLevel:'Մակարդակ',sTitleHy:'Վերնագիր (հայերեն)',sTitleEn:'Վերնագիր (անգլերեն)',sEmoji:'Էմոջի',sParas:'Պարբերություններ (յուրաքանչյուրը նոր տողում)',sParasH:'Ձևաչափ՝ տեքստ || թարգմանություն || աուդիոյի https հղում (ըստ ցանկության)',
 sVocab:'Բառեր (յուրաքանչյուրը նոր տողում)',sVocabH:'Ձևաչափ՝ բառ = թարգմանություն',sQs:'Հարցեր (յուրաքանչյուրը նոր տողում)',sQsH:'Ձևաչափ՝ պարբերության համար | հարց | ճիշտ պատասխան | սխալ1 ; սխալ2 ; սխալ3 | բացատրություն',
 sSave:'Պահպանել',sCancel:'Չեղարկել',sSaved:'Պատմությունը պահպանվեց։',sNone:'Պատմություններ դեռ չկան։',sNeedCloud:'Պատմությունների կառավարումը պահանջում է Supabase ռեժիմ և մուտք։',
 sErrMig:'Պատմությունների աղյուսակը կամ նոր դաշտը հասանելի չէ։ Գործարկիր migrations/011_stories_placement.sql և migrations/016_stories_lesson_link.sql ֆայլերը Supabase SQL Editor-ում։',sErrSave:'Չհաջողվեց պահպանել։',
 vParaMin:'Ավելացրու առնվազն մեկ պարբերություն։',vParaLine:'Պարբերության տողը պետք է ունենա տեքստ և թարգմանություն․ տող {n}։',vVocabLine:'Բառի տողը պետք է լինի «բառ = թարգմանություն»․ տող {n}։',
 vQMin:'Ավելացրու առնվազն մեկ հարց։',vQLine:'Հարցի տող {n}․ պահանջվում է՝ պարբերության համար | հարց | ճիշտ | սխալ ; սխալ։',vQPara:'Հարցի տող {n}․ պարբերության համարը սխալ է։',vTitle:'Վերնագիրը պարտադիր է։',vAudio:'Աուդիոն պետք է լինի https հղում․ տող {n}։',
 sCloudNote:'Պատմությունները բեռնվում են հաշվից․ առաջընթացը պահվում է Supabase-ում։',plSyncErr:'Արդյունքը պահվեց սարքում, բայց սերվերին չուղարկվեց։'});
Object.assign(PXS.en,{sLesson:'Lesson',sNoLesson:'Choose a lesson',sNeedLesson:'Choose a lesson before publishing this story.',sAdmin:'Stories',sNew:'New story',sEdit:'Edit',sDel:'Delete',sSure:'Press again to confirm',sPub:'Published',sDraft:'Draft',sPubBtn:'Publish',sUnpub:'Unpublish',
 sLang:'Language',sLevel:'Level',sTitleHy:'Title (Armenian)',sTitleEn:'Title (English)',sEmoji:'Emoji',sParas:'Paragraphs (one per line)',sParasH:'Format: text || translation || https audio link (optional)',
 sVocab:'Vocabulary (one per line)',sVocabH:'Format: word = translation',sQs:'Questions (one per line)',sQsH:'Format: paragraph number | question | correct answer | wrong1 ; wrong2 ; wrong3 | explanation',
 sSave:'Save',sCancel:'Cancel',sSaved:'Story saved.',sNone:'No stories yet.',sNeedCloud:'Managing stories needs Supabase mode and a signed-in admin.',
 sErrMig:'The stories table or lesson link column is missing. Run migrations/011_stories_placement.sql and migrations/016_stories_lesson_link.sql in the Supabase SQL Editor.',sErrSave:'Could not save.',
 vParaMin:'Add at least one paragraph.',vParaLine:'Paragraph line needs text and a translation: line {n}.',vVocabLine:'Vocabulary line must be “word = translation”: line {n}.',
 vQMin:'Add at least one question.',vQLine:'Question line {n}: needs paragraph number | question | correct | wrong ; wrong.',vQPara:'Question line {n}: paragraph number is out of range.',vTitle:'A title is required.',vAudio:'Audio must be an https link: line {n}.',
 sCloudNote:'Stories load from your account; progress is saved in Supabase.',plSyncErr:'The result was saved on this device but not sent to the server.'});

const PXDB={lang:'',list:null,busy:false,prog:{},err:false,plDone:false};
const pxCloud=()=>MODE==='cloud'&&!!A.user&&typeof B.storiesPub==='function';
const pxStoryOk=s=>!!(s&&s.p&&s.p.length&&s.q&&s.q.length&&s.p.every(x=>x[0])&&s.q.every(q=>q.q&&q.a&&q.o&&q.o.length>=1&&s.p[q.p]));
function pxNormStory(r){
  try{
    const p=(r.paragraphs||[]).map(x=>[String(x.t||''),String(x.tr||''),x.audio||'']);
    const q=(r.questions||[]).map(x=>({p:+x.p||0,q:String(x.q||''),a:String(x.a||''),o:(x.o||[]).map(String).filter(Boolean),x:String(x.x||'')}));
    const s={id:r.id,db:true,lessonId:r.lesson_id||'',lv:r.level,e:r.emoji||'📖',t:r.title||{},p,v:(r.vocab||[]).map(x=>[String(x.w||''),String(x.tr||'')]).filter(x=>x[0]),q};
    return pxStoryOk(s)?s:null;
  }catch(e){return null;}
}
async function pxLoadStories(){
  if(!pxCloud()||PXDB.busy||(PXDB.lang===S.course&&PXDB.list))return;
  PXDB.busy=true;
  try{const [rows,pr]=await Promise.all([B.storiesPub(S.course),B.storyProg()]);PXDB.list=rows.map(pxNormStory).filter(Boolean);PXDB.prog={};pr.forEach(x=>{PXDB.prog[x.story_id]=x.stars;});PXDB.lang=S.course;PXDB.err=false;}
  catch(e){PXDB.list=[];PXDB.lang=S.course;PXDB.err=true;}
  PXDB.busy=false;if(tab==='learn'||tab==='home'){render();if(L&&L.intro&&typeof renderLesson==='function')renderLesson();}
}
function pxLoadPlace(){
  if(!pxCloud()||PXDB.plDone||!A.user)return;PXDB.plDone=true;
  B.placeLast(S.course).then(r=>{if(r&&r.cefr&&pxPx().cefr!==r.cefr){pxPx().cefr=r.cefr;save();if(tab==='learn')render();}}).catch(warnErr('placement result not loaded'));
}
const pxStoryList=()=>{
  const cloud=(PXDB.lang===S.course&&PXDB.list)?PXDB.list:[];
  const linked=new Set(cloud.map(s=>s.lessonId).filter(Boolean));
  const local=pxEn()?STORIES.filter(s=>!s.lessonId||!linked.has(s.lessonId)):[];
  return cloud.concat(local).filter(pxStoryOk);
};
function pxLessonHasStory(lessonId){return !!lessonId&&pxStoryList().some(s=>s.lessonId===lessonId);}
const pxStars=s=>s.db?(PXDB.prog[s.id]||0):(pxPx().stories[s.id]||0);
function pxNarr(x){
  const u=typeof x[2]==='string'&&safeUrl(x[2],'audio')?x[2]:'';
  return u?`<button class="spk" data-a="aud" data-t="${esc(u)}" data-f="${esc(x[0])}" aria-label="Audio">${IC.speaker}</button>`:spkBtn(x[0]);
}

