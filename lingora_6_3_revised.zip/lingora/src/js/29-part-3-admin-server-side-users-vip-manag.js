/* ---------- PART 3 admin: server-side users, VIP management, audit log, modules, secure media ---------- */
Object.assign(UI.hy,{
 s_vip:'VIP',s_audit:'Գործողությունների մատյան',s_modules:'Մոդուլներ',
 uplType:'Թույլատրված են միայն JPG, PNG, WebP, GIF (նկար) և MP3, OGG, WAV, M4A, WebM (աուդիո)։',uplSize:'Ֆայլը մեծ է 5 ՄԲ-ից։',
 p3cloud:'Այս բաժինը աշխատում է միայն Supabase ռեժիմում (իրական բազայով)։',p3load:'Բեռնվում է…',p3empty:'Ոչինչ չի գտնվել։',p3retry:'Փորձել նորից',p3fail:'Չհաջողվեց բեռնել։',
 p3q:'Որոնել անունով կամ էլ. փոստով…',p3all:'Բոլորը',p3free:'Անվճար',p3vip:'VIP',p3exp:'Ավարտված VIP',p3staff:'Անձնակազմ',p3susp:'Արգելափակված',
 p3sort:'Դասավորել',p3s_created:'Գրանցում',p3s_xp:'XP',p3s_name:'Անուն',p3s_vip:'VIP ավարտ',p3asc:'աճող',p3desc:'նվազող',
 p3prev:'Նախորդ',p3next:'Հաջորդ',p3page:'Էջ',p3of:'/',p3total:'Ընդամենը',p3open:'Բացել',p3back:'← Ցանկ',
 p3role:'Դեր',p3xp:'XP',p3lessons:'Դասեր',p3streak:'Շարք',p3joined:'Գրանցվել է',p3answers:'Պատասխաններ',p3correct:'ճիշտ',
 p3vipNow:'VIP կարգավիճակ',p3vipActive:'Ակտիվ մինչև',p3vipSched:'Սկսվում է',p3vipEnded:'Ավարտվել է',p3vipNone:'VIP չէ',
 p3plan:'Պլան',p3custom:'Այլ (օրերով)',p3days:'Օրեր',p3note:'Նշում',p3grant:'Տալ / երկարացնել',p3setDates:'Սահմանել ամսաթվերը',p3from:'Սկիզբ',p3to:'Ավարտ',p3apply:'Կիրառել',
 p3remove:'Հանել VIP-ը',p3suspend:'Արգելափակել',p3restore:'Վերականգնել',p3history:'VIP պատմություն',p3noHist:'Պատմություն չկա։',p3by:'տվել է',p3recent:'Վերջին գործողություններ',
 p3cf:'Հաստատել',p3cfNo:'Չեղարկել',p3cfRemove:'Հանե՞լ VIP-ը այս օգտատիրոջից։',p3cfSusp:'Արգելափակե՞լ այս հաշիվը։',p3cfRest:'Վերականգնե՞լ այս հաշիվը։',p3cfGrant:'Տա՞լ VIP։',p3cfSet:'Սահմանե՞լ VIP-ի ամսաթվերը։',p3cfDel:'Ջնջե՞լ։ Սա հնարավոր չէ հետ բերել։',
 p3done:'Կատարված է։',p3tabAct:'Ակտիվ',p3tabSched:'Նախատեսված',p3tabExp:'Ավարտված',p3tabAll:'Բոլորը',p3tabPlans:'Պլաններ',p3tabPay:'Վճարումներ',
 p3payNote:'Վճարումը համարվում է հաջող միայն սերվերի webhook-ով, ստուգված ստորագրությամբ։ Բրաուզերից եկած ոչ մի տվյալ վճարում չի հաստատում։ Տես README «Վճարումներ»։ Մինչ այդ VIP-ը կարելի է տալ ձեռքով։',
 p3price2:'Գին (Lingora կոպեկ)',p3cat:'Կատեգորիա',p3slot:'Դիրք (slot)',p3newPlan:'+ Պլան',p3price:'Գին (ցենտ)',p3cur:'Արժույթ',p3provPrice:'Վճարային համակարգի գինը (price id)',p3active:'Ակտիվ',p3pos:'Դիրք',p3save:'Պահպանել',p3del:'Ջնջել',p3title:'Վերնագիր',p3descr:'Նկարագրություն',
 p3payEmpty:'Վճարումներ դեռ չկան։',p3when:'Երբ',p3who:'Ով',p3what:'Գործողություն',p3entity:'Օբյեկտ',p3allEnt:'Բոլոր օբյեկտները',
 p3mAch:'Նվաճումներ',p3mQuest:'Առաջադրանքներ',p3mNotif:'Ծանուցումներ',p3mTr:'Թարգմանություններ',p3mSet:'Կարգավորումներ',p3new:'+ Նոր',
 p3metric:'Չափանիշ',p3thr:'Շեմ',p3icon:'Պատկերակ',p3rg:'Ադամանդ',p3rx:'XP պարգև',p3period:'Ժամանակահատված',p3target:'Նպատակ',p3kind:'Տեսակ',p3body:'Տեքստ',p3link:'Հղում',p3start:'Սկիզբ',p3end:'Ավարտ',
 p3lang:'Լեզու',p3key:'Բանալի',p3value:'Արժեք',p3jsonBad:'JSON-ը սխալ է։',p3trHint:'Գրիր արժեք, որը կփոխարինի ինտերֆեյսի տեքստը ամբողջ հավելվածում։',
 p3vipC:'VIP դասընթաց',p3freeBadge:'Անվճար',p3mediaDel:'Ջնջել ֆայլը',p3mediaSize:'Չափ',p3mediaBy:'Վերբեռնել է',
 p3stUsers:'Օգտատերեր',p3stNew:'Նոր (7 օր)',p3stActive:'Ակտիվ (7 օր)',p3stVip:'Ակտիվ VIP',p3stExp:'Ավարտված VIP',p3stDone:'Ավարտված դասեր',p3stAns:'Պատասխաններ',p3stSignups:'Գրանցումներ (14 օր)',p3stPay:'Հաջող վճարումներ'
});
Object.assign(UI.en,{
 s_vip:'VIP',s_audit:'Audit log',s_modules:'Modules',
 uplType:'Only JPG, PNG, WebP, GIF (images) and MP3, OGG, WAV, M4A, WebM (audio) are allowed.',uplSize:'The file is larger than 5 MB.',
 p3cloud:'This section works only in Supabase mode (real database).',p3load:'Loading…',p3empty:'Nothing found.',p3retry:'Try again',p3fail:'Could not load.',
 p3q:'Search by name or email…',p3all:'All',p3free:'Free',p3vip:'VIP',p3exp:'Expired VIP',p3staff:'Staff',p3susp:'Suspended',
 p3sort:'Sort',p3s_created:'Joined',p3s_xp:'XP',p3s_name:'Name',p3s_vip:'VIP end',p3asc:'ascending',p3desc:'descending',
 p3prev:'Previous',p3next:'Next',p3page:'Page',p3of:'of',p3total:'Total',p3open:'Open',p3back:'← List',
 p3role:'Role',p3xp:'XP',p3lessons:'Lessons',p3streak:'Streak',p3joined:'Joined',p3answers:'Answers',p3correct:'correct',
 p3vipNow:'VIP status',p3vipActive:'Active until',p3vipSched:'Starts',p3vipEnded:'Ended',p3vipNone:'Not VIP',
 p3plan:'Plan',p3custom:'Custom (days)',p3days:'Days',p3note:'Note',p3grant:'Grant / extend',p3setDates:'Set exact dates',p3from:'Start',p3to:'End',p3apply:'Apply',
 p3remove:'Remove VIP',p3suspend:'Suspend',p3restore:'Restore',p3history:'VIP history',p3noHist:'No history.',p3by:'granted by',p3recent:'Recent actions',
 p3cf:'Confirm',p3cfNo:'Cancel',p3cfRemove:'Remove VIP from this user?',p3cfSusp:'Suspend this account?',p3cfRest:'Restore this account?',p3cfGrant:'Grant VIP?',p3cfSet:'Set these VIP dates?',p3cfDel:'Delete? This cannot be undone.',
 p3done:'Done.',p3tabAct:'Active',p3tabSched:'Scheduled',p3tabExp:'Expired',p3tabAll:'All',p3tabPlans:'Plans',p3tabPay:'Payments',
 p3payNote:'A payment counts as successful only through a signature-verified server webhook. Nothing sent from the browser can confirm a payment. See README “Payments”. Until it is configured, grant VIP manually.',
 p3price2:'Price (Lingora Coins)',p3cat:'Category',p3slot:'Slot',p3newPlan:'+ Plan',p3price:'Price (cents)',p3cur:'Currency',p3provPrice:'Payment provider price id',p3active:'Active',p3pos:'Position',p3save:'Save',p3del:'Delete',p3title:'Title',p3descr:'Description',
 p3payEmpty:'No payments yet.',p3when:'When',p3who:'Who',p3what:'Action',p3entity:'Object',p3allEnt:'All objects',
 p3mAch:'Achievements',p3mQuest:'Missions',p3mNotif:'Notifications',p3mTr:'Translations',p3mSet:'Settings',p3new:'+ New',
 p3metric:'Metric',p3thr:'Threshold',p3icon:'Icon',p3rg:'Lingora Coins',p3rx:'XP reward',p3period:'Period',p3target:'Target',p3kind:'Kind',p3body:'Text',p3link:'Link',p3start:'Starts',p3end:'Ends',
 p3lang:'Language',p3key:'Key',p3value:'Value',p3jsonBad:'The JSON is invalid.',p3trHint:'Enter a value that replaces the interface text everywhere in the app.',
 p3vipC:'VIP course',p3freeBadge:'Free',p3mediaDel:'Delete file',p3mediaSize:'Size',p3mediaBy:'Uploaded by',
 p3stUsers:'Users',p3stNew:'New (7 days)',p3stActive:'Active (7 days)',p3stVip:'Active VIP',p3stExp:'Expired VIP',p3stDone:'Lessons completed',p3stAns:'Answers',p3stSignups:'Sign-ups (14 days)',p3stPay:'Successful payments'
});
['denied_self','not_found','invalid','other'].forEach(k=>{if(!UI.en['e_'+k]){UI.en['e_'+k]={denied_self:'You cannot do this to your own account.',not_found:'Not found.',invalid:'Invalid value.',other:'Something went wrong.'}[k];UI.hy['e_'+k]={denied_self:'Սա չես կարող անել քո հաշվի հետ։',not_found:'Չի գտնվել։',invalid:'Սխալ արժեք։',other:'Ինչ-որ բան սխալ ընթացավ։'}[k];}});
if(SECS.indexOf('vip')<0){SECS.splice(SECS.indexOf('users')+1,0,'vip');SECS.splice(SECS.indexOf('media')+1,0,'modules','audit');}

const P3={
  u:{q:'',filter:'all',sort:'created',dir:'desc',page:0,per:15,rows:null,total:0,busy:false,err:false,id:'',detail:null,dbusy:false},
  v:{tab:'active',q:'',page:0,per:15,rows:null,total:0,busy:false,err:false,plans:null,pay:null,pbusy:false,peditId:'',pnew:false},
  a:{q:'',entity:'',page:0,per:25,rows:null,total:0,busy:false,err:false},
  s:{data:null,busy:false,err:false},
  m:{tab:'ach',rows:null,busy:false,err:false,edit:null,tr:{lang:'hy'},setKey:''},
  media:{rows:null,busy:false,err:false},
  cf:null,focus:''
};
const p3cloud=()=>MODE==='cloud';
const p3d=x=>x?new Date(x).toLocaleString(S.lang==='hy'?'hy-AM':'en-GB',{dateStyle:'medium',timeStyle:'short'}):'—';
const p3dd=x=>x?new Date(x).toLocaleDateString(S.lang==='hy'?'hy-AM':'en-GB',{dateStyle:'medium'}):'—';
const p3note=()=>`<div class="empty">${esc(t('p3cloud'))}</div>`;
const p3pl=o=>tx(o&&o.title)||(o&&o.id)||'';
function p3status(r){
  const now=Date.now(),u=r.vip_until&&Date.parse(r.vip_until),f=r.vip_from&&Date.parse(r.vip_from);
  if(!u)return {k:'none',l:t('p3vipNone')};
  if(u<=now)return {k:'exp',l:t('p3vipEnded')+' '+p3dd(r.vip_until)};
  if(f&&f>now)return {k:'sched',l:t('p3vipSched')+' '+p3dd(r.vip_from)};
  return {k:'on',l:t('p3vipActive')+' '+p3dd(r.vip_until)};
}
const p3badge=r=>{const s=p3status(r);return s.k==='none'?'':`<span class="p3b p3b-${s.k}">${s.k==='on'?IC.crown:''}${esc(s.l)}</span>`;};
function p3refocus(){const e=P3.focus&&$(P3.focus);if(e){e.focus();try{e.setSelectionRange(e.value.length,e.value.length);}catch(x){}}}
function p3rerender(){if(tab==='admin'){render();p3refocus();}}
function p3pager(key,total,per,page){
  const pages=Math.max(1,Math.ceil(total/per));if(pages<2)return `<div class="note">${esc(t('p3total'))}: ${total}</div>`;
  return `<div class="pager"><button class="btn btn-ghost" data-a="p3pg" data-k="${key}" data-v="-1" ${page<=0?'disabled':''}>${esc(t('p3prev'))}</button><span>${esc(t('p3page'))} ${page+1} ${esc(t('p3of'))} ${pages} · ${total}</span><button class="btn btn-ghost" data-a="p3pg" data-k="${key}" data-v="1" ${page>=pages-1?'disabled':''}>${esc(t('p3next'))}</button></div>`;
}
const p3load=h=>`<div class="empty" role="status">${esc(t('p3load'))}</div>`;
const p3err=k=>`<div class="msg err">${esc(t('p3fail'))}</div><button class="btn btn-ghost" data-a="p3reload" data-k="${k}">${esc(t('p3retry'))}</button>`;

/* ----- confirmation dialog (used for every destructive or account-changing action) ----- */
function p3confirm(msg,run,extra){P3.cf={msg,run,extra:extra||''};render();setTimeout(()=>{const b=document.querySelector('.p3cf .btn-orange');if(b)b.focus();},30);}
function p3cfHtml(){
  if(!P3.cf)return '';
  return `<div class="p3ov" role="dialog" aria-modal="true" aria-label="${esc(t('p3cf'))}"><div class="p3cf card"><p>${esc(P3.cf.msg)}</p>${P3.cf.extra||''}<div class="acts"><button class="btn btn-ghost" data-a="p3no">${esc(t('p3cfNo'))}</button><button class="btn btn-orange" data-a="p3yes">${esc(t('p3cf'))}</button></div></div></div>`;
}
async function p3run(fn,okMsg){try{await fn();toast(okMsg||t('p3done'));return true;}catch(e){toast(t('e_'+mapErr(e)));return false;}}

/* ----- dashboard statistics (server aggregates, not rows loaded into the browser) ----- */
function p3loadStats(force){
  if(!p3cloud()||P3.s.busy||(P3.s.data&&!force)||(P3.s.err&&!force))return; /* B-004: a failed load is final until the user presses Retry; it used to refetch on every render, forever */
  P3.s.busy=true;P3.s.err=false;
  B.adminStats().then(d=>{if(!d||typeof d!=='object'||Array.isArray(d))throw new Error('stats: empty reply');d.signups=Array.isArray(d.signups)?d.signups:[];d.recent=Array.isArray(d.recent)?d.recent:[];P3.s.data=d;P3.s.busy=false;p3rerender();}).catch(()=>{P3.s.busy=false;P3.s.err=true;p3rerender();});
}
function p3statsHtml(){
  if(!p3cloud())return '';
  p3loadStats();
  if(P3.s.err)return p3err('s');
  const d=P3.s.data;if(!d)return p3load();
  const st=(n,l)=>`<div class="stat"><b>${n}</b><span>${esc(l)}</span></div>`,mx=Math.max(1,...d.signups.map(x=>x.n));
  return `<div class="stats p3stats">${st(d.users,t('p3stUsers'))}${st(d.new7,t('p3stNew'))}${st(d.active7,t('p3stActive'))}${st(d.vip_active,t('p3stVip'))}${st(d.vip_expired,t('p3stExp'))}${st(d.completions,t('p3stDone'))}${st(d.answers,t('p3stAns'))}${st(d.payments_ok,t('p3stPay'))}</div>
  <section class="card"><h2>${esc(t('p3stSignups'))}</h2><div class="bars">${d.signups.map((x,i)=>`<div class="bcol ${i===13?'now':''}"><span class="bv">${x.n}</span><i style="height:${Math.round(x.n/mx*100)}%"></i><span class="bd">${esc(String(x.d).slice(8,10))}</span></div>`).join('')}</div></section>
  <section class="card"><h2>${esc(t('p3recent'))}</h2>${p3auditRows(d.recent)||`<div class="empty">${esc(t('p3empty'))}</div>`}</section>`;
}
function p3auditRows(rows){
  if(!rows||!rows.length)return '';
  return `<div class="p3tbl">${rows.map(r=>{const ch=r.detail&&r.detail.changed?(' · '+r.detail.changed.join(', ')):'',ti=r.detail&&r.detail.title?tx(r.detail.title):'';
    return `<div class="p3row"><span class="p3when">${esc(p3d(r.created_at))}</span><b>${esc(r.action)}</b><span>${esc(r.entity)} <code>${esc(r.entity_id)}</code>${ti?' · '+esc(ti):''}${esc(ch)}</span><small>${esc(r.actor_email||'')}</small></div>`;}).join('')}</div>`;
}

/* ----- users ----- */
function p3loadUsers(force){
  const u=P3.u;if(!p3cloud()||u.busy||(u.rows&&!force))return;
  u.busy=true;u.err=false;
  B.adminUsers({q:u.q,filter:u.filter,sort:u.sort,dir:u.dir,limit:u.per,offset:u.page*u.per}).then(r=>{u.rows=r.rows;u.total=r.total;u.busy=false;p3rerender();}).catch(()=>{u.busy=false;u.err=true;u.rows=u.rows||[];p3rerender();});
}
function p3openUser(id){
  const u=P3.u;u.id=id;u.detail=null;u.dbusy=true;render();
  B.adminUser(id).then(d=>{u.detail=d;u.dbusy=false;p3rerender();}).catch(e=>{u.dbusy=false;u.id='';toast(t('e_'+mapErr(e)));p3rerender();});
  if(!P3.v.plans)p3loadPlans();
}
function p3usersView(){
  if(!p3cloud())return null;
  const u=P3.u;
  if(u.id)return p3userDetail();
  p3loadUsers();
  const F=[['all','p3all'],['free','p3free'],['vip','p3vip'],['expired','p3exp'],['staff','p3staff'],['suspended','p3susp']];
  const rows=(u.rows||[]).map(r=>`<button class="p3user" data-a="p3user" data-id="${esc(r.id)}"><span class="av">${esc((r.name||r.email||'?').trim().charAt(0).toUpperCase())}</span><span class="p3who"><b>${esc(r.name||r.email)}</b><small>${esc(r.email)}</small></span><span class="p3meta">${r.role!=='user'?`<span class="p3b">${esc(r.role)}</span>`:''}${r.suspended?`<span class="p3b p3b-bad">${esc(t('p3susp'))}</span>`:''}${p3badge(r)}<small>${r.xp} XP · ${r.lessons_done} ${esc(t('p3lessons').toLowerCase())}</small></span></button>`).join('');
  return `<section class="card"><h2>${esc(t('s_users'))}</h2>
   <div class="p3bar"><input id="p3-uq" class="search" type="search" value="${esc(u.q)}" placeholder="${esc(t('p3q'))}" autocomplete="off">
   <select id="p3-usort" aria-label="${esc(t('p3sort'))}">${[['created','p3s_created'],['xp','p3s_xp'],['name','p3s_name'],['vip_until','p3s_vip']].map(x=>`<option value="${x[0]}" ${u.sort===x[0]?'selected':''}>${esc(t(x[1]))}</option>`).join('')}</select>
   <button class="btn btn-ghost" data-a="p3dir" aria-label="${esc(u.dir==='asc'?t('p3asc'):t('p3desc'))}">${u.dir==='asc'?'↑':'↓'}</button></div>
   <div class="chips" role="tablist">${F.map(f=>`<button role="tab" class="chip ${u.filter===f[0]?'on':''}" aria-selected="${u.filter===f[0]}" data-a="p3ufilter" data-v="${f[0]}">${esc(t(f[1]))}</button>`).join('')}</div>
   ${u.err?p3err('u'):u.busy&&!u.rows?p3load():(u.rows&&!u.rows.length?`<div class="empty">${esc(t('p3empty'))}</div>`:`<div class="p3list ${u.busy?'busy':''}">${rows}</div>`)}
   ${p3pager('u',u.total,u.per,u.page)}</section>`;
}
function p3userDetail(){
  const u=P3.u,d=u.detail;
  const back=`<button class="btn btn-ghost" data-a="p3uback">${esc(t('p3back'))}</button>`;
  if(u.dbusy||!d)return `<section class="card">${back}${p3load()}</section>`;
  const p=d.profile,s=d.state||{},st=p3status(p),isMe=p.id===(A.user&&A.user.id),staff=p.role!=='user',superO=isSuper();
  const plans=(P3.v.plans||[]).filter(x=>x.active);
  const kv=(k,v)=>`<div class="p3kv"><span>${esc(k)}</span><b>${v}</b></div>`;
  const hist=(d.vip_history||[]).map(h=>`<div class="p3row"><span class="p3when">${esc(p3d(h.created_at))}</span><b>${esc(h.action)}</b><span>${esc(h.plan_id||h.plan)} · ${h.days}d · ${esc(p3dd(h.starts_at))} → ${esc(p3dd(h.ends_at))}${h.note?' · '+esc(h.note):''}</span><small>${esc(h.source==='payment'?'payment':(t('p3by')+' '+(h.granted_by_email||'—')))}</small></div>`).join('');
  const aud=(d.audit||[]).map(a=>`<div class="p3row"><span class="p3when">${esc(p3d(a.created_at))}</span><b>${esc(a.action)}</b><span>${esc(Object.keys(a.detail||{}).join(', '))}</span><small>${esc(a.actor_email||'')}</small></div>`).join('');
  const act=isMe||(staff&&!superO)?'':`
   <h3>${esc(t('p3vipNow'))}</h3>
   <div class="p3form"><label>${esc(t('p3plan'))}<select id="p3-plan">${plans.map(x=>`<option value="${esc(x.id)}" data-d="${x.days}">${esc(p3pl(x))} (${x.days}d)</option>`).join('')}<option value="custom">${esc(t('p3custom'))}</option></select></label>
   <label>${esc(t('p3days'))}<input id="p3-days" type="number" min="1" max="3660" value="${plans[0]?plans[0].days:30}"></label>
   <label class="wide">${esc(t('p3note'))}<input id="p3-note" maxlength="200" autocomplete="off"></label>
   <button class="btn btn-orange" data-a="p3grant" data-id="${esc(p.id)}">${IC.crown}${esc(t('p3grant'))}</button></div>
   <details class="p3det"><summary>${esc(t('p3setDates'))}</summary><div class="p3form"><label>${esc(t('p3from'))}<input id="p3-from" type="datetime-local"></label><label>${esc(t('p3to'))}<input id="p3-to" type="datetime-local"></label>
   <button class="btn btn-ghost" data-a="p3setvip" data-id="${esc(p.id)}">${esc(t('p3apply'))}</button></div></details>
   <div class="acts">${p.vip_until?`<button class="btn btn-ghost danger" data-a="p3revoke" data-id="${esc(p.id)}">${esc(t('p3remove'))}</button>`:''}
   <button class="btn btn-ghost ${p.suspended?'':'danger'}" data-a="p3susp" data-id="${esc(p.id)}" data-v="${p.suspended?'0':'1'}">${esc(p.suspended?t('p3restore'):t('p3suspend'))}</button></div>`;
  return `<section class="card">${back}<h2>${esc(p.name||p.email)}</h2><p class="note">${esc(p.email)}</p>
   <div class="p3grid">${kv(t('p3role'),esc(p.role))}${kv(t('p3vipNow'),esc(st.l))}${kv(t('p3xp'),s.xp||0)}${kv(t('p3lessons'),d.lessons_done)}${kv(t('p3streak'),s.streak||0)}${kv(t('p3answers'),d.answers.total+' ('+d.answers.correct+' '+t('p3correct')+')')}${kv(t('p3joined'),esc(p3dd(p.created_at)))}${p.suspended?kv('',`<span class="p3b p3b-bad">${esc(t('p3susp'))}</span>`):''}</div>
   ${act}
   <h3>${esc(t('p3history'))}</h3>${hist||`<div class="empty">${esc(t('p3noHist'))}</div>`}
   ${aud?`<h3>${esc(t('p3recent'))}</h3>${aud}`:''}</section>`;
}

/* ----- VIP management ----- */
function p3loadVip(force){
  const v=P3.v;if(!p3cloud()||v.busy||(v.rows&&!force))return;
  v.busy=true;v.err=false;
  B.adminVipList({q:v.q,status:v.tab,limit:v.per,offset:v.page*v.per}).then(r=>{v.rows=r.rows;v.total=r.total;v.busy=false;p3rerender();}).catch(()=>{v.busy=false;v.err=true;v.rows=v.rows||[];p3rerender();});
}
function p3loadPlans(force){
  const v=P3.v;if(!p3cloud()||v.pbusy||(v.plans&&!force))return;
  v.pbusy=true;B.tableList('vip_plans','position').then(r=>{v.plans=r;v.pbusy=false;p3rerender();}).catch(()=>{v.pbusy=false;v.plans=v.plans||[];});
}
function p3loadPay(force){
  const v=P3.v;if(!p3cloud()||v.pbusy||(v.pay&&!force))return;
  v.pbusy=true;B.adminPayments({limit:30}).then(r=>{v.pay=(r&&Array.isArray(r.rows))?r:{rows:[],total:0};v.pbusy=false;p3rerender();}).catch(()=>{v.pbusy=false;v.pay={rows:[],total:0};});
}
function p3vipView(){
  if(!p3cloud())return p3note();
  const v=P3.v,T=[['active','p3tabAct'],['scheduled','p3tabSched'],['expired','p3tabExp'],['all','p3tabAll'],['plans','p3tabPlans'],['pay','p3tabPay']];
  const tabs=`<div class="chips" role="tablist">${T.map(x=>`<button role="tab" class="chip ${v.tab===x[0]?'on':''}" aria-selected="${v.tab===x[0]}" data-a="p3vtab" data-v="${x[0]}">${esc(t(x[1]))}</button>`).join('')}</div>`;
  let body='';
  if(v.tab==='plans')body=p3plansView();
  else if(v.tab==='pay')body=p3payView();
  else{
    p3loadVip();
    body=`<div class="p3bar"><input id="p3-vq" class="search" type="search" value="${esc(v.q)}" placeholder="${esc(t('p3q'))}" autocomplete="off"></div>`+
     (v.err?p3err('v'):v.busy&&!v.rows?p3load():(v.rows&&!v.rows.length?`<div class="empty">${esc(t('p3empty'))}</div>`:`<div class="p3list ${v.busy?'busy':''}">${(v.rows||[]).map(r=>`<button class="p3user" data-a="p3vopen" data-id="${esc(r.id)}"><span class="av">${esc((r.name||r.email||'?').charAt(0).toUpperCase())}</span><span class="p3who"><b>${esc(r.name||r.email)}</b><small>${esc(r.email)}</small></span><span class="p3meta">${p3badge(r)}<small>${esc(r.plan_id||'—')} · ${esc(r.source||'')}${r.granted_by_email?' · '+esc(r.granted_by_email):''}</small></span></button>`).join('')}</div>`))+p3pager('v',v.total,v.per,v.page);
  }
  return `<section class="card"><h2>${IC.crown}${esc(t('s_vip'))}</h2>${tabs}${body}</section>`;
}
const PLAN_F=[['id','text','id'],['title','jt','p3title'],['days','num','p3days'],['price_cents','num','p3price'],['currency','text','p3cur'],['provider_price','text','p3provPrice'],['active','chk','p3active'],['position','num','p3pos']];
function p3plansView(){
  p3loadPlans();const v=P3.v;
  if(!v.plans)return p3load();
  const list=v.plans.map(p=>`<div class="p3row"><b>${esc(p.id)}</b><span>${esc(p3pl(p))} · ${p.days}d · ${p.price_cents==null?'—':(p.price_cents/100).toFixed(2)+' '+esc(p.currency.toUpperCase())}${p.active?'':' · '+esc(t('draft')||'off')}</span><button class="btn btn-ghost" data-a="p3pedit" data-id="${esc(p.id)}">${esc(t('edit')||'Edit')}</button></div>`).join('');
  const ed=(v.peditId||v.pnew)?p3form(PLAN_F,v.pnew?{active:true,currency:'usd',days:30,position:(v.plans.length+1)}:v.plans.find(x=>x.id===v.peditId)||{},v.pnew,'p3psave','p3pdel','p3pcancel'):`<div class="acts"><button class="btn btn-orange" data-a="p3pnew">${esc(t('p3newPlan'))}</button></div>`;
  return `${list||`<div class="empty">${esc(t('p3empty'))}</div>`}${ed}`;
}
function p3payView(){
  p3loadPay();const v=P3.v;
  const note=`<div class="note p3pn">${esc(t('p3payNote'))}</div>`;
  if(!v.pay)return note+p3load();
  const rows=v.pay.rows.map(p=>`<div class="p3row"><span class="p3when">${esc(p3d(p.created_at))}</span><b>${esc(p.status)}</b><span>${esc(p.email||'')} · ${esc(p.plan_id||'')} · ${(p.amount_cents/100).toFixed(2)} ${esc(p.currency.toUpperCase())} · ${esc(p.provider)} <code>${esc(p.provider_ref)}</code></span></div>`).join('');
  return note+(rows||`<div class="empty">${esc(t('p3payEmpty'))}</div>`);
}

/* ----- generic small form used by plans / achievements / missions / notifications ----- */
function p3form(fields,row,isNew,saveA,delA,cancelA){
  const f=fields.map(([k,ty,lbl,opts])=>{
    const id='p3f-'+k,L=esc(t(lbl)||lbl),v=row[k];
    if(ty==='jt'){const o=v||{};return `<label class="wide">${L}<span class="p3two"><input id="${id}-hy" lang="hy" placeholder="HY" value="${esc(o.hy||'')}" maxlength="200"><input id="${id}-en" lang="en" placeholder="EN" value="${esc(o.en||'')}" maxlength="200"></span></label>`;}
    if(ty==='chk')return `<label class="p3chk"><input id="${id}" type="checkbox" ${v?'checked':''}> ${L}</label>`;
    if(ty==='sel')return `<label>${L}<select id="${id}">${opts.map(o=>`<option value="${o}" ${v===o?'selected':''}>${esc(o)}</option>`).join('')}</select></label>`;
    if(ty==='num')return `<label>${L}<input id="${id}" type="number" step="1" value="${v==null?'':esc(v)}"></label>`;
    if(ty==='dt')return `<label>${L}<input id="${id}" type="datetime-local" value="${v?esc(new Date(new Date(v).getTime()-new Date(v).getTimezoneOffset()*6e4).toISOString().slice(0,16)):''}"></label>`;
    if(ty==='area')return `<label class="wide">${L}<textarea id="${id}" rows="3" maxlength="400">${esc(v||'')}</textarea></label>`;
    if(ty==='json')return `<label class="wide">${L}<textarea id="${id}" rows="3" maxlength="600" spellcheck="false" style="font-family:monospace">${esc(JSON.stringify(v==null?{}:v))}</textarea></label>`;
    return `<label>${L}<input id="${id}" value="${esc(v==null?'':v)}" ${k==='id'&&!isNew?'readonly':''} maxlength="200" autocomplete="off"></label>`;
  }).join('');
  return `<div class="p3form p3edit">${f}<div class="acts wide"><button class="btn btn-orange" data-a="${saveA}">${esc(t('p3save'))}</button><button class="btn btn-ghost" data-a="${cancelA}">${esc(t('p3cfNo'))}</button>${isNew?'':`<button class="btn btn-ghost danger" data-a="${delA}">${esc(t('p3del'))}</button>`}</div></div>`;
}
function p3read(fields,base){
  const row=Object.assign({},base||{});
  for(const [k,ty] of fields){
    const id='p3f-'+k;
    if(ty==='jt'){const hy=($(id+'-hy')||{}).value||'',en=($(id+'-en')||{}).value||'';row[k]={hy:hy.trim(),en:en.trim()};}
    else if(ty==='chk')row[k]=!!($(id)||{}).checked;
    else if(ty==='num'){const v=($(id)||{}).value;row[k]=v===''||v==null?null:Math.trunc(+v);}
    else if(ty==='dt'){const v=($(id)||{}).value;row[k]=v?new Date(v).toISOString():null;}
    else if(ty==='json'){try{row[k]=JSON.parse(($(id)||{}).value||'{}');}catch(e){row[k]={};row.__badjson=true;}}
    else row[k]=(($(id)||{}).value||'').trim();
  }
  return row;
}

/* ----- audit view ----- */
const AUD_ENT=['profiles','courses','units','lessons','questions','languages','settings','site_content','shop_items','achievement_defs','quest_defs','vip_plans','ui_overrides','media_assets'];
function p3loadAudit(force){
  const a=P3.a;if(!p3cloud()||a.busy||(a.rows&&!force))return;
  a.busy=true;a.err=false;
  B.adminAudit({q:a.q,entity:a.entity,limit:a.per,offset:a.page*a.per}).then(r=>{a.rows=r.rows;a.total=r.total;a.busy=false;p3rerender();}).catch(()=>{a.busy=false;a.err=true;a.rows=a.rows||[];p3rerender();});
}
function p3auditView(){
  if(!p3cloud())return p3note();
  p3loadAudit();const a=P3.a;
  return `<section class="card"><h2>${esc(t('s_audit'))}</h2><div class="p3bar"><input id="p3-aq" class="search" type="search" value="${esc(a.q)}" placeholder="${esc(t('p3q'))}" autocomplete="off">
   <select id="p3-aent" aria-label="${esc(t('p3entity'))}"><option value="">${esc(t('p3allEnt'))}</option>${AUD_ENT.map(e=>`<option ${a.entity===e?'selected':''}>${e}</option>`).join('')}</select></div>
   ${a.err?p3err('a'):a.busy&&!a.rows?p3load():(p3auditRows(a.rows)||`<div class="empty">${esc(t('p3empty'))}</div>`)}${p3pager('a',a.total,a.per,a.page)}</section>`;
}

/* ----- modules: achievements, missions, notifications, translations, settings ----- */
const MODS={
  ach:{table:'achievement_defs',order:'position',lbl:'p3mAch',f:[['id','text','id'],['title','jt','p3title'],['descr','jt','p3descr'],['metric','sel','p3metric',['lessons','xp','best_streak','perfect','units','level','practice','friends']],['threshold','num','p3thr'],['icon','text','p3icon'],['reward_gems','num','p3rg'],['reward_xp','num','p3rx'],['active','chk','p3active'],['position','num','p3pos']],def:{metric:'lessons',threshold:1,icon:'star',reward_gems:0,reward_xp:0,active:true,position:0,title:{},descr:{}},sum:r=>`${tx(r.title)} · ${r.metric} ≥ ${r.threshold} · +${r.reward_gems}💎 +${r.reward_xp}XP`},
  quest:{table:'quest_defs',order:'position',lbl:'p3mQuest',f:[['id','text','id'],['title','jt','p3title'],['period','sel','p3period',['daily','weekly','monthly']],['metric','sel','p3metric',['xp','lessons','perfect','practice','words','speaking','days']],['target','num','p3target'],['reward_gems','num','p3rg'],['reward_xp','num','p3rx'],['starts_at','dt','p3start'],['ends_at','dt','p3end'],['active','chk','p3active'],['position','num','p3pos']],def:{period:'daily',metric:'xp',target:20,reward_gems:0,reward_xp:0,active:true,position:0,title:{}},sum:r=>`${tx(r.title)} · ${r.period} · ${r.metric} ${r.target} · +${r.reward_gems}💎 +${r.reward_xp}XP`},
  shop:{table:'shop_items',order:'position',lbl:'p3mShop',f:[['id','text','id'],['title','jt','p3title'],['descr','jt','p3descr'],['kind','sel','p3kind',['cosmetic','heart_refill','streak_freeze','xp_boost','unlimited_hearts']],['category','sel','p3cat',['item','room','costume']],['slot','sel','p3slot',['','head','eyes','neck','room','decor']],['price_gems','num','p3price2'],['vip_only','chk','p3vipC'],['icon','text','p3icon'],['payload','json','payload'],['active','chk','p3active'],['position','num','p3pos']],def:{kind:'cosmetic',category:'item',slot:'decor',price_gems:50,vip_only:false,icon:'gem',payload:{emoji:'⭐'},active:true,position:50,title:{},descr:{}},sum:r=>`${tx(r.title)} · ${r.category}${r.slot?'/'+r.slot:''} · ${r.price_gems}💎${r.vip_only?' · VIP':''}${r.active?'':' · off'}`},
  notif:{table:'site_content',order:'created_at',lbl:'p3mNotif',f:[['id','text','id'],['kind','sel','p3kind',['announcement','banner','notification']],['title','jt','p3title'],['body','jt','p3body'],['link','text','p3link'],['starts_at','dt','p3start'],['ends_at','dt','p3end'],['active','chk','p3active']],def:{kind:'announcement',active:true,title:{},body:{},link:''},sum:r=>`${r.kind} · ${tx(r.title)}${r.active?'':' · off'}`,filter:r=>r.kind!=='mascot'}
};
function p3loadMod(force){
  const m=P3.m;if(!p3cloud()||m.busy||(m.rows&&!force))return;
  if(m.tab==='tr'){m.busy=true;B.tableList('ui_overrides','key').then(r=>{m.rows=r;m.busy=false;p3rerender();}).catch(()=>{m.busy=false;m.err=true;m.rows=[];p3rerender();});return;}
  if(m.tab==='ai'){m.busy=true;Promise.all([B.adminAiStats(),B.getConfig()]).then(r=>{m.rows={stats:r[0],cfg:(r[1]||{}).ai||{}};m.busy=false;p3rerender();}).catch(()=>{m.busy=false;m.err=true;m.rows={};p3rerender();});return;}
  if(m.tab==='set'){m.busy=true;B.getConfig().then(o=>{m.rows=o;m.busy=false;p3rerender();}).catch(()=>{m.busy=false;m.err=true;m.rows={};p3rerender();});return;}
  const M=MODS[m.tab];m.busy=true;m.err=false;
  B.tableList(M.table,M.order).then(r=>{m.rows=M.filter?r.filter(M.filter):r;m.busy=false;p3rerender();}).catch(()=>{m.busy=false;m.err=true;m.rows=[];p3rerender();});
}
function p3modulesView(){
  if(!p3cloud())return p3note();
  const m=P3.m;p3loadMod();
  const T=[['ach','p3mAch'],['quest','p3mQuest'],['shop','p3mShop'],['ai','admAi'],['notif','p3mNotif'],['tr','p3mTr'],['set','p3mSet']];
  const tabs=`<div class="chips" role="tablist">${T.map(x=>`<button role="tab" class="chip ${m.tab===x[0]?'on':''}" aria-selected="${m.tab===x[0]}" data-a="p3mtab" data-v="${x[0]}">${esc(t(x[1]))}</button>`).join('')}</div>`;
  let body='';
  if(m.err)body=p3err('m');
  else if(!m.rows)body=p3load();
  else if(m.tab==='tr')body=p3trView();
  else if(m.tab==='set')body=p3setView();
  else if(m.tab==='ai')body=p3aiView();
  else{
    const M=MODS[m.tab];
    body=m.edit?p3form(M.f,m.edit.row,m.edit.isNew,'p3msave','p3mdel','p3mcancel'):
      `<div class="acts"><button class="btn btn-orange" data-a="p3mnew">${esc(t('p3new'))}</button></div>`+
      (m.rows.length?m.rows.map(r=>`<div class="p3row"><b>${esc(r.id)}</b><span>${esc(M.sum(r))}</span><button class="btn btn-ghost" data-a="p3medit" data-id="${esc(r.id)}">${esc(t('edit')||'Edit')}</button></div>`).join(''):`<div class="empty">${esc(t('p3empty'))}</div>`);
  }
  return `<section class="card"><h2>${esc(t('s_modules'))}</h2>${tabs}${body}</section>`;
}
function p3aiView(){
  const r=P3.m.rows||{},st=r.stats||{},cfg=Object.assign({enabled:true,daily_free:3,daily_vip:25,monthly_budget_micro:20000000},r.cfg||{});
  const usd=v=>'$'+(Number(v||0)/1e6).toFixed(4);
  const sx=(n,l)=>`<div class="stat"><b>${n}</b><span>${esc(l)}</span></div>`;
  return `<div class="stats p3stats">${sx(nfmt(st.today_calls||0),t('admAiCalls'))}${sx(nfmt(st.month_calls||0),t('admAiMonth'))}${sx(usd(st.month_cost_micro),t('admAiCost'))}${sx(nfmt(st.month_tokens||0),t('admAiTok'))}${sx(usd(st.budget_micro),t('admAiBudget'))}</div>
   <label class="wide">${esc(t('admAiCfg'))}<textarea id="p3-aicfg" rows="6" spellcheck="false" style="font-family:monospace;width:100%">${esc(JSON.stringify(cfg,null,2))}</textarea></label><div class="acts"><button class="btn btn-orange" data-a="p3aisave">${esc(t('p3save'))}</button></div>`;
}
function p3trView(){
  const m=P3.m,lang=m.tr.lang,rows=m.rows.filter(r=>r.lang===lang);
  return `<p class="note">${esc(t('p3trHint'))}</p><div class="chips">${['hy','en','ru'].map(l=>`<button class="chip ${lang===l?'on':''}" data-a="p3trlang" data-v="${l}">${l.toUpperCase()}</button>`).join('')}</div>
   <div class="p3form"><label>${esc(t('p3key'))}<input id="p3-trkey" list="p3keys" maxlength="40" autocomplete="off"><datalist id="p3keys">${Object.keys(UI.en).slice(0,2000).map(k=>`<option value="${esc(k)}">`).join('')}</datalist></label>
   <label class="wide">${esc(t('p3value'))}<input id="p3-trval" maxlength="400" autocomplete="off"></label><button class="btn btn-orange" data-a="p3trsave">${esc(t('p3save'))}</button></div>
   ${rows.map(r=>`<div class="p3row"><b>${esc(r.key)}</b><span>${esc(r.value)}</span><button class="btn btn-ghost danger" data-a="p3trdel" data-id="${esc(r.key)}">${esc(t('p3del'))}</button></div>`).join('')||`<div class="empty">${esc(t('p3empty'))}</div>`}`;
}
function p3setView(){
  const m=P3.m,keys=Object.keys(m.rows||{});
  const cur=m.setKey&&m.rows[m.setKey]!==undefined?JSON.stringify(m.rows[m.setKey],null,2):'';
  return `<div class="chips">${keys.map(k=>`<button class="chip ${m.setKey===k?'on':''}" data-a="p3setpick" data-v="${esc(k)}">${esc(k)}</button>`).join('')||`<span class="note">${esc(t('p3empty'))}</span>`}</div>
   ${m.setKey?`<label class="wide">${esc(m.setKey)}<textarea id="p3-setjson" rows="12" spellcheck="false" style="font-family:monospace;width:100%">${esc(cur)}</textarea></label><div class="acts"><button class="btn btn-orange" data-a="p3setsave">${esc(t('p3save'))}</button></div>`:''}`;
}

/* ----- media library backed by the media_assets registry ----- */
function p3loadMedia(force){
  const r=P3.media;if(!p3cloud()||r.busy||(r.rows&&!force))return;
  r.busy=true;B.listMedia().then(x=>{r.rows=x;r.busy=false;p3rerender();}).catch(()=>{r.busy=false;r.err=true;r.rows=[];p3rerender();});
}
function p3mediaHtml(){
  if(!p3cloud())return '';
  p3loadMedia();const r=P3.media;
  if(!r.rows)return p3load();
  return `<section class="card"><h2>${esc(t('mediaT'))} · ${r.rows.length}</h2><div class="mgrid">${r.rows.map(m=>`<div class="mitem">${m.kind==='image'?`<img src="${esc(m.url)}" loading="lazy" alt="${esc(m.alt||'')}">`:`<audio controls preload="none" src="${esc(m.url)}"></audio>`}<small>${esc(m.path)} · ${Math.ceil(m.bytes/1024)} KB</small><div class="acts"><button class="btn btn-ghost" data-a="mediacopy" data-u="${esc(m.url)}">${esc(t('mediaCopy'))}</button><button class="btn btn-ghost danger" data-a="p3mediadel" data-id="${esc(m.id)}">${esc(t('p3mediaDel'))}</button></div></div>`).join('')||`<div class="empty">${esc(t('p3empty'))}</div>`}</div></section>`;
}

/* ----- actions ----- */
const P3KEY={u:()=>{P3.u.rows=null;p3loadUsers();},v:()=>{P3.v.rows=null;p3loadVip();},a:()=>{P3.a.rows=null;p3loadAudit();},s:()=>{P3.s.data=null;P3.s.err=false;p3loadStats();},m:()=>{P3.m.rows=null;P3.m.err=false;p3loadMod();}};
const p3dbusy=(k)=>{if(P3[k]){P3[k].busy=false;}};
let p3timer=0;
function p3debounce(fn){clearTimeout(p3timer);p3timer=setTimeout(fn,350);}
async function act3(a,d,el){if(await act3a(a,d,el))return true;const r=await act3i(a,d,el);if(r&&tab==='admin')render();return r;}
async function act3i(a,d,el){
  if(a==='cdup'||a==='udup'){await p3dupBranch(a==='cdup'?'course':'unit',d.id);return true;}
  if(a==='mediacopy')return await copyMediaUrl(d.u||'',el); /* B-001: this case sat inside the p3-only switch below and could never run */
  if(a.slice(0,2)!=='p3')return false;
  const U=P3.u,V=P3.v,M=P3.m;
  switch(a){
    case 'p3reload':P3[d.k]&&(P3[d.k].err=false);(P3KEY[d.k]||(()=>{}))();render();return true;
    case 'p3pg':{const o=P3[d.k];o.page=Math.max(0,o.page+(+d.v));o.rows=null;render();return true;}
    case 'p3no':P3.cf=null;render();return true;
    case 'p3yes':{const c=P3.cf;P3.cf=null;if(c)await c.run();render();return true;}
    case 'p3ufilter':U.filter=d.v;U.page=0;U.rows=null;render();return true;
    case 'p3dir':U.dir=U.dir==='asc'?'desc':'asc';U.page=0;U.rows=null;render();return true;
    case 'p3user':p3openUser(d.id);return true;
    case 'p3vopen':adm.sub='users';p3openUser(d.id);return true;
    case 'p3uback':U.id='';U.detail=null;U.rows=null;render();return true;
    case 'p3grant':{
      const sel=$('p3-plan'),plan=sel.value==='custom'?null:sel.value,days=+$('p3-days').value,note=$('p3-note').value;
      if(!(days>=1&&days<=3660)){toast(t('e_invalid'));return true;}
      p3confirm(t('p3cfGrant')+' '+(plan||t('p3custom'))+' · '+days+' '+t('p3days').toLowerCase(),async()=>{if(await p3run(()=>B.adminGrantVip(d.id,days,note,plan)))p3openUser(d.id);});return true;}
    case 'p3setvip':{
      const f=$('p3-from').value,to=$('p3-to').value,sel=$('p3-plan'),plan=sel&&sel.value!=='custom'?sel.value:null,note=$('p3-note').value;
      if(!to){toast(t('e_invalid'));return true;}
      const sI=f?new Date(f).toISOString():null,eI=new Date(to).toISOString();
      p3confirm(t('p3cfSet')+' '+(f||'now')+' → '+to,async()=>{if(await p3run(()=>B.adminSetVip(d.id,plan,sI,eI,note)))p3openUser(d.id);});return true;}
    case 'p3revoke':p3confirm(t('p3cfRemove'),async()=>{if(await p3run(()=>B.adminRevokeVip(d.id,($('p3-note')||{}).value||'')))p3openUser(d.id);});return true;
    case 'p3susp':{const on=d.v==='1';p3confirm(on?t('p3cfSusp'):t('p3cfRest'),async()=>{if(await p3run(()=>B.adminSuspend(d.id,on,($('p3-note')||{}).value||'')))p3openUser(d.id);});return true;}
    case 'p3vtab':V.tab=d.v;V.page=0;V.rows=null;V.peditId='';V.pnew=false;render();return true;
    case 'p3pnew':V.pnew=true;V.peditId='';render();return true;
    case 'p3pedit':V.peditId=d.id;V.pnew=false;render();return true;
    case 'p3pcancel':V.peditId='';V.pnew=false;render();return true;
    case 'p3psave':{
      const old=V.pnew?{}:V.plans.find(x=>x.id===V.peditId)||{},row=p3read(PLAN_F,old);
      if(!/^[a-z0-9_-]{2,24}$/.test(row.id)||!(row.days>=1&&row.days<=3660)||!(row.title.hy||row.title.en)||(row.price_cents!=null&&row.price_cents<0)||!/^[a-z]{3}$/.test(row.currency=(row.currency||'usd').toLowerCase())){toast(t('e_invalid'));return true;}
      if(!row.provider_price)row.provider_price=null;
      if(await p3run(()=>B.tableSave('vip_plans',row))){V.peditId='';V.pnew=false;V.plans=null;p3loadPlans(true);}return true;}
    case 'p3pdel':{const id=V.peditId;p3confirm(t('p3cfDel'),async()=>{if(await p3run(()=>B.tableDelete('vip_plans',{id}))){V.peditId='';V.plans=null;p3loadPlans(true);}});return true;}
    case 'p3mtab':M.tab=d.v;M.rows=null;M.edit=null;M.err=false;render();return true;
    case 'p3mnew':M.edit={isNew:true,row:Object.assign({},MODS[M.tab].def,M.tab==='notif'?{id:'n'+Date.now().toString(36)}:{})};render();return true;
    case 'p3medit':M.edit={isNew:false,row:M.rows.find(x=>x.id===d.id)};render();return true;
    case 'p3mcancel':M.edit=null;render();return true;
    case 'p3msave':{
      const Md=MODS[M.tab],row=p3read(Md.f,M.edit.row);
      if(row.__badjson){toast(t('p3jsonBad'));return true;}
      if(!/^[A-Za-z0-9_-]{2,40}$/.test(row.id)||!(row.title&&(row.title.hy||row.title.en))){toast(t('e_invalid'));return true;}
      if(await p3run(()=>B.tableSave(Md.table,row))){M.edit=null;M.rows=null;}return true;}
    case 'p3mdel':{const Md=MODS[M.tab],id=M.edit.row.id;p3confirm(t('p3cfDel'),async()=>{if(await p3run(()=>B.tableDelete(Md.table,{id}))){M.edit=null;M.rows=null;}});return true;}
    case 'p3aisave':{let v;try{v=JSON.parse($('p3-aicfg').value);}catch(e){toast(t('p3jsonBad'));return true;}
      if(!v||typeof v!=='object'||Array.isArray(v)||(v.daily_free!=null&&!(v.daily_free>=0&&v.daily_free<=1000))||(v.daily_vip!=null&&!(v.daily_vip>=0&&v.daily_vip<=1000))||(v.monthly_budget_micro!=null&&!(v.monthly_budget_micro>=0))){toast(t('e_invalid'));return true;}
      if(await p3run(()=>B.saveConfig('ai',v))){M.rows=null;}return true;}
    case 'p3trlang':M.tr.lang=d.v;render();return true;
    case 'p3trsave':{
      const key=$('p3-trkey').value.trim(),value=$('p3-trval').value.trim();
      if(!/^[A-Za-z0-9_]{1,40}$/.test(key)||!value||value.length>400){toast(t('e_invalid'));return true;}
      if(await p3run(()=>B.tableSave('ui_overrides',{lang:M.tr.lang,key,value,updated_at:new Date().toISOString()}))){M.rows=null;}return true;}
    case 'p3trdel':{const key=d.id,lang=M.tr.lang;p3confirm(t('p3cfDel'),async()=>{if(await p3run(()=>B.tableDelete('ui_overrides',{lang,key})))M.rows=null;});return true;}
    case 'p3setpick':M.setKey=d.v;render();return true;
    case 'p3setsave':{let v;try{v=JSON.parse($('p3-setjson').value);}catch(e){toast(t('p3jsonBad'));return true;}
      p3confirm(M.setKey+': '+t('p3cf'),async()=>{if(await p3run(()=>B.saveConfig(M.setKey,v)))M.rows=null;});return true;}
    case 'mediacopy':return await copyMediaUrl(d.u||'',el);
    case 'p3mediadel':{const row=(P3.media.rows||[]).find(x=>x.id===d.id);if(!row)return true;p3confirm(t('p3cfDel')+' '+row.path,async()=>{if(await p3run(()=>B.deleteMedia(row)))P3.media.rows=null;});return true;}
  }
  return false;
}
/* live inputs: search boxes (debounced), selects */
document.addEventListener('input',e=>{
  const id=e.target&&e.target.id;
  if(id==='p3-uq'){P3.focus=id;p3debounce(()=>{P3.u.q=e.target.value;P3.u.page=0;P3.u.rows=null;render();p3refocus();});}
  else if(id==='p3-vq'){P3.focus=id;p3debounce(()=>{P3.v.q=e.target.value;P3.v.page=0;P3.v.rows=null;render();p3refocus();});}
  else if(id==='p3-aq'){P3.focus=id;p3debounce(()=>{P3.a.q=e.target.value;P3.a.page=0;P3.a.rows=null;render();p3refocus();});}
});
document.addEventListener('change',e=>{
  const id=e.target&&e.target.id;
  if(id==='p3-usort'){P3.u.sort=e.target.value;P3.u.page=0;P3.u.rows=null;render();}
  else if(id==='p3-aent'){P3.a.entity=e.target.value;P3.a.page=0;P3.a.rows=null;render();}
  else if(id==='p3-plan'){const o=e.target.selectedOptions[0];if(o&&o.dataset.d)$('p3-days').value=o.dataset.d;}
});
/* translation overrides are applied at start-up (and after saving) so the app text changes without a deploy */
async function applyUiOverrides(){
  if(!p3cloud()||!B||!B.tableList)return;
  try{const rows=await B.tableList('ui_overrides');rows.forEach(r=>{if(UI[r.lang]&&/^[A-Za-z0-9_]{1,40}$/.test(r.key))UI[r.lang][r.key]=r.value;});}catch(e){console.warn('ui_overrides not loaded',e);}
}

/* duplicate a whole course or unit (units, lessons, exercises), always as an unpublished draft */
async function p3dupBranch(kind,id){
  const c=rawC(),cp=o=>JSON.parse(JSON.stringify(o)),sfx=o=>({hy:tx(o,'hy')+' (copy)',en:tx(o,'en')+' (copy)'});
  const units=kind==='course'?c.units.filter(u=>u.course_id===id):c.units.filter(u=>u.id===id);
  const src=kind==='course'?c.courses.find(x=>x.id===id):units[0];if(!src)return;
  const nid=mkId(kind),out={courses:[],units:[],lessons:[],questions:[]};
  if(kind==='course')out.courses.push(Object.assign(cp(src),{id:nid,title:sfx(src.title),published:false,archived:false,sample:false,pos:Math.max(0,...c.courses.map(x=>x.pos||0))+1}));
  const parent=kind==='course'?nid:src.course_id;
  units.forEach((u,ui)=>{
    const uid=kind==='unit'?nid:mkId('unit');
    out.units.push(Object.assign(cp(u),{id:uid,course_id:parent,published:false,title:kind==='unit'?sfx(u.title):u.title,pos:kind==='unit'?Math.max(0,...c.units.filter(x=>x.course_id===u.course_id).map(x=>x.pos||0))+1:u.pos}));
    c.lessons.filter(l=>l.unit_id===u.id).forEach(l=>{
      const lid=mkId('lesson');
      out.lessons.push(Object.assign(cp(l),{id:lid,unit_id:uid,published:false}));
      c.questions.filter(q=>q.lesson_id===l.id).forEach((q,i)=>out.questions.push(Object.assign(cp(q),{id:lid+'-q'+(i+1),lesson_id:lid,pos:q.pos||i+1})));
    });
  });
  try{
    for(const [tb,rows] of Object.entries(out)){if(rows.length){await B.upsertMany(tb,rows);rows.forEach(r=>localPut(tb,r));}}
    reapply();toast(t('saved'));
  }catch(e){toast(t('e_'+mapErr(e)));}
  render();
}
