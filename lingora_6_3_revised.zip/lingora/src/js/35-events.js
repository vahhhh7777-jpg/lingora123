/* ---------- events ---------- */
async function act(a,el){
  const d=el.dataset||{};
  if(await act4(a,d,el))return;
  if(await act3(a,d,el))return;
  if(await act2(a,d,el))return;
  if(await actS(a,d,el))return;
  switch(a){
    case 'tab':{if(guardDirty())break;PX.v='hub';langOpen=false;pgAnim=true;tab=d.v;resetArm=false;adm.edit=null;const ws=(d.v==='learn');wantScroll=ws;render();if(!ws)window.scrollTo(0,0);if(tab==='admin'&&(adm.sub==='dash'||adm.sub==='users'))loadUsers();if(tab==='home'||tab==='rank')loadBoard();break;}
    case 'node':{
      const i=+d.i;
      if(stateOf(i)==='lock'){toast(t('locked'));el.classList.remove('shake');void el.offsetWidth;el.classList.add('shake');return;}
      startLesson(i);break;
    }
    case 'practice':startPractice();break;
    case 'vipinfo':tab='me';render();window.scrollTo(0,0);break;
    case 'say':say(d.t);break;
    case 'sayslow':say(d.t,{rate:.65});break;
    case 'fav':{if(S.fav[d.t])delete S.fav[d.t];else S.fav[d.t]=1;save();pushProgress();render();break;}
    case 'qpage':adm.qp.p=Math.max(0,adm.qp.p+(+d.v));render();break;
    case 'dgo':if(d.v==='learner'){tab='courses';pgAnim=true;render();}else{adm.sub=d.v;adm.wiz=null;render();}break;
    case 'cexport':{
      const c=rawC(),blob=new Blob([JSON.stringify({lingora:1,exported:new Date().toISOString(),languages:c.languages,courses:c.courses,units:c.units,lessons:c.lessons,questions:c.questions},null,1)],{type:'application/json'});
      const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='lingora-curriculum.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),2000);break;
    }
    case 'dfilter':dictF=d.v||'';dictMax=60;render();break;
    case 'dsort':dictSort=dictSort==='az'?'prog':'az';render();break;
    case 'wlearn':{if(!S.lw)S.lw={};if(S.lw[d.t])delete S.lw[d.t];else S.lw[d.t]=Date.now();save();pushProgress();render();break;}
    case 'reload':{A.booting=false;try{if(B){await refreshCatalog();A.net=true;}}catch(e){A.net=false;toast(t('e_net'));}render();break;}
    case 'aud':playAudio(d.t,d.f);break;
    case 'hint':if(L){L.hint=true;renderLesson();}break;
    case 'mic':startMic();break;
    case 'micself':if(L&&!L.res){L.typed=cur().ans;renderLesson();check();}break;
    case 'lang':S.lang=d.v;touchPref();render();break;
    case 'anim':S.noanim=d.v!=='1';save();applyAnim();render();break;
    case 'sound':S.sound=d.v==='1';save();render();break;
    case 'dmore':dictMax+=60;$('dlist').innerHTML=dictList();break;
    case 'dunit':dictU=d.v;dictMax=60;render();break;
    case 'goal':setGoal(+d.v);render();break;
    case 'buyvip':{
      if(PAYX.busy||!d.v||!payOnline())break;
      PAYX.busy=d.v;PAYX.err='';render();
      B.startCheckout(d.v).then(u=>{if(!/^https:\/\/checkout\.stripe\.com\//.test(String(u)))throw new Error('url');location.href=u;}).catch(()=>{PAYX.busy='';PAYX.err=t('buyFail');render();});
      break;}
    case 'reset':
      if(!resetArm){resetArm=true;render();}
      else{resetArm=false;render();startReset().then(ok=>{if(ok)toast(t('resetDone'));render();});}
      break;
    case 'pwtoggle':{const inp=el.parentNode.querySelector('input');if(inp){const show=inp.type==='password';inp.type=show?'text':'password';el.setAttribute('aria-pressed',String(show));el.setAttribute('aria-label',t(show?'hidePw':'showPw'));el.innerHTML=show?IC.eyeoff:IC.eye;}break;}
    case 'authmode':A.form=A.form==='signup'?'signin':'signup';A.err='';A.msg='';render();break;
    case 'forgot':await doForgot();break;
    case 'signout':await doSignOut();break;
    case 'asub':if(guardDirty())break;adm.sub=d.v;adm.edit=null;adm.wiz=null;adm.menu=false;adm.delArm='';adm.nav.lesson='';pgAnim=true;render();if(adm.sub==='dash'||adm.sub==='users'||adm.sub==='settings')loadUsers();break;
    case 'claimgems':claimGems();break;
    case 'gemadd':{try{await B.grantGems(d.id,+d.n,'admin');toast(t('gGrantOk'));}catch(e){toast(t('e_'+mapErr(e)));}break;}
    case 'vipadd':{
      const u=adm.users.find(x=>x.id===d.id);if(!u)break;
      try{await B.grantVip(u.id,+d.n);toast(t('vipOk'));}catch(e){toast(t('e_'+mapErr(e)));}
      await loadUsers();break;
    }
    case 'admretry':await loadUsers();break;
    case 'roleset':try{if(!isSuper())throw E('denied');await B.setAdmin(d.id,d.v==='1');toast(t('vipOk'));}catch(e){toast(t('e_'+mapErr(e)));}await loadUsers();break;
    case 'bulkw':{
      const lines=(($('bulkw')||{}).value||'').split('\n').map(x=>x.trim()).filter(Boolean).slice(0,200);
      const rows=lines.map(l=>{const [a,rest]=[l.split('=')[0],l.split('=').slice(1).join('=')];const [tr,ex]=rest.split(';');return [a.trim(),(tr||'').trim(),(ex||'').trim()];}).filter(r=>r[0]&&r[1]);
      if(!rows.length){toast(t('errQ'));break;}
      const n=adm.nav,start=Math.max(0,...qsOf(n.lesson).map(q=>q.pos||0)),withMc=!!($('bulkmc')||{}).checked&&rows.length>=4;
      const out=[];
      rows.forEach((r,i)=>{const d0={en:r[0],hy:r[1]};if(r[2])d0.example=r[2];out.push({id:mkId('q')+i,lesson_id:n.lesson,type:'intro',data:d0,pos:start+out.length+1});});
      if(withMc)rows.forEach((r,i)=>{const others=pick(rows.filter((x,k)=>k!==i).map(x=>x[1]).filter(x=>x!==r[1]),3);if(others.length<1)return;out.push({id:mkId('q')+'m'+i,lesson_id:n.lesson,type:'mc',data:{prompt:r[0],speak:r[0],answer:r[1],options:[r[1]].concat(others)},pos:start+out.length+1});});
      adm.busy=true;render();
      try{await B.upsertMany('questions',out);out.forEach(q=>localPut('questions',q));reapply();toast(t('saved'));}catch(e){toast(t('e_'+mapErr(e)));}
      adm.busy=false;render();break;
    }
    case 'vipdel':try{await B.revokeVip(d.id);toast(t('vipOk'));}catch(e){toast(t('e_'+mapErr(e)));}await loadUsers();break;
    case 'anav':{if(guardDirty())break;const n=adm.nav,v=d.v;if(v==='root'){n.lang=n.course=n.unit=n.lesson='';}else if(v==='lang')n.course=n.unit=n.lesson='';else if(v==='course')n.unit=n.lesson='';else if(v==='unit')n.lesson='';adm.edit=null;adm.delArm='';render();break;}
    case 'eopen':{
      const n=adm.nav,k={languages:'lang',courses:'course',units:'unit',lessons:'lesson'}[d.t];
      if(k){n[k]=d.id;if(k==='lang')n.course=n.unit=n.lesson='';if(k==='course')n.unit=n.lesson='';if(k==='unit')n.lesson='';}
      adm.delArm='';render();window.scrollTo(0,0);break;
    }
    case 'enew':adm.err='';adm.edit={table:d.t,isNew:true,row:newRow(d.t)};render();break;
    case 'eedit':{const r=rawC()[d.t].find(x=>x.id===d.id);if(!r)break;adm.err='';adm.edit={table:d.t,isNew:false,row:JSON.parse(JSON.stringify(r))};render();break;}
    case 'carch':{
      const r=rawC().courses.find(x=>x.id===d.id);if(!r)break;
      const row=Object.assign({},r,r.archived?{archived:false}:{archived:true,published:false});
      try{await persist('courses',row);}catch(e){toast(t('e_'+mapErr(e)));}
      render();break;
    }
    case 'epub':{
      const r=rawC()[d.t].find(x=>x.id===d.id);if(!r)break;
      const row=Object.assign({},r);if(d.t==='languages')row.active=r.active===false;else row.published=r.published===false;
      if(row.published===true&&d.t==='lessons'&&lessonIssues(r,qsOf(r.id)).some(x=>x[0]==='err')){toast(t('errPublish'));break;}
      if(row.published===true&&d.t==='courses'&&courseHealth(rawC(),r.id).published===0){toast(t('errPublishC'));break;}
      if(row.published===true&&d.t==='courses')row.archived=false;
      try{await persist(d.t,row);}catch(e){toast(t('e_'+mapErr(e)));}
      render();break;
    }
    case 'emove':{
      const r=rawC()[d.t].find(x=>x.id===d.id);if(!r)break;
      const P=PARENT[d.t],nav=P?{[P[1]]:r[P[0]]}:{};
      const ids=sib(d.t,nav).map(x=>x.id),i=ids.indexOf(d.id),j=i+(+d.d);
      if(i<0||j<0||j>=ids.length)break;
      [ids[i],ids[j]]=[ids[j],ids[i]];
      try{await B.reorder(d.t,ids);ids.forEach((id,k)=>{rawC()[d.t].find(x=>x.id===id).pos=k+1;});reapply();}catch(e){toast(t('e_'+mapErr(e)));}
      render();break;
    }
    case 'edel':{
      const key=delKey(d.t,d.id);
      if(adm.delArm!==key){adm.delArm=key;render();break;}
      adm.delArm='';
      try{await B.remove(d.t,d.id);rmRow(rawC(),d.t,d.id);const n=adm.nav;if(d.t==='languages'&&n.lang===d.id)n.lang=n.course=n.unit=n.lesson='';
        if(d.t==='courses'&&n.course===d.id)n.course=n.unit=n.lesson='';if(d.t==='units'&&n.unit===d.id)n.unit=n.lesson='';if(d.t==='lessons'&&n.lesson===d.id)n.lesson='';
        reapply();toast(t('deleted'));}catch(e){toast(t('e_'+mapErr(e)));}
      render();break;
    }
    case 'eprev':startPreview(qsOf(d.id),rawC().lessons.find(x=>x.id===d.id));break;
    case 'begin':if(L){L.intro=false;L.fresh=true;renderLesson();}break;
    case 'ldup':{
      const l=rawC().lessons.find(x=>x.id===d.id);if(!l)break;
      const nid=mkId('lesson'),pos=Math.max(0,...sib('lessons',{unit:l.unit_id}).map(x=>x.pos||0))+1;
      const copy=Object.assign(JSON.parse(JSON.stringify(l)),{id:nid,pos,published:false,title:{hy:tx(l.title,'hy')+' (copy)',en:tx(l.title,'en')+' (copy)'}});
      const qs=qsOf(l.id).map((q,i)=>Object.assign(JSON.parse(JSON.stringify(q)),{id:nid+'-q'+(i+1),lesson_id:nid,pos:i+1}));
      try{await B.upsert('lessons',copy);await B.upsertMany('questions',qs);localPut('lessons',copy);qs.forEach(q=>localPut('questions',q));reapply();toast(t('saved'));}
      catch(e){toast(t('e_'+mapErr(e)));}
      render();break;
    }
    case 'qnew':{
      const ty=($('qtype')||{}).value||'mc',n=adm.nav;
      adm.err='';adm.edit={table:'questions',isNew:true,row:{id:'',lesson_id:n.lesson,type:ty,data:{},pos:Math.max(0,...qsOf(n.lesson).map(q=>q.pos||0))+1}};render();break;
    }
    case 'qedit':{const q=rawC().questions.find(x=>x.id===d.id);if(!q)break;adm.err='';adm.edit={table:'questions',isNew:false,row:JSON.parse(JSON.stringify(q))};render();break;}
    case 'qdup':{
      const q=rawC().questions.find(x=>x.id===d.id);if(!q)break;
      const row=Object.assign(JSON.parse(JSON.stringify(q)),{id:mkId('q'),pos:Math.max(0,...qsOf(q.lesson_id).map(x=>x.pos||0))+1});
      try{await persist('questions',row);}catch(e){toast(t('e_'+mapErr(e)));}
      render();break;
    }
    case 'qprev':{
      const e=adm.edit,dd=questionData(e.row.type,readForm());
      if(!dd){adm.err=t('errQ');render();break;}
      startPreview([{id:'p',lesson_id:'',type:e.row.type,data:dd,pos:1}]);break;
    }
    case 'unitimport':
      adm.busy=true;render();
      try{await B.importAll(buildSeed());await refreshCatalog();saveCache();toast(t('imported'));}catch(e){toast(t('e_'+mapErr(e)));}
      adm.busy=false;render();break;
    case 'ucancel':if(guardDirty())break;adm.edit=null;adm.err='';render();break;
    case 'mt':matchPick(d.s,+d.i);break;
    case 'continue':{
      const i=FLAT.findIndex((f,k)=>stateOf(k)==='open');
      if(i>=0)startLesson(i);else if(canPractice())startPractice();else{tab='learn';wantScroll=true;render();}
      break;
    }
    case 'langsel':langOpen=!langOpen;render();break;
    case 'noop':break;
    case 'popclose':langOpen=false;if(notifOpen){notifOpen=false;markAllRead();}render();break;
    case 'fixgo':if(L){L.fixIntro=false;saveResume();renderLesson();}break;
    case 'buy':buyShop(d.v);break;
    case 'unlock':shopAsk('lesson',d.v);break;
    case 'shopyes':shopConfirm();break;
    case 'shopno':shopCancel();break;
    case 'openles':openUnlocked(d.v);break;
    case 'shopsec':SHOP.sec=d.v;render();break;
    case 'shopretry':SHOP.items=null;SHOP.err=false;render();break;
    case 'bell':notifOpen=true;langOpen=false;render();break;
    case 'dismiss':if(!S.dis)S.dis={};S.dis[d.id]=1;save();render();break;
    case 'gotoach':tab='me';ptab='ach';render();window.scrollTo(0,0);break;
    case 'gotorank':tab='rank';render();window.scrollTo(0,0);break;
    case 'claimch':if(claimChallenge()){tone([660,880,1047]);toast('+'+(G.challenge.r||0)+' XP','celebrating');}render();break;
    case 'remtoggle':{S.rem=Object.assign({on:false,time:'19:00',day:'',risk:''},S.rem);S.rem.on=!S.rem.on;save();render();break;}
    case 'remallow':{try{Notification.requestPermission().then(()=>render());}catch(e){toast(t('e_other'));}break;}
    case 'ptab':ptab=d.v;if(d.v==='mist')MB.rows=null;render();break;
    case 'mbPractice':startMistakePractice();break;
    case 'mbReload':mbLoad(true);render();break;
    case 'course':langOpen=false;pgAnim=true;S.course=d.id;applyCourse();save();pushProgress();tab='learn';wantScroll=true;render();window.scrollTo(0,0);break;
    case 'claim':{
      const q=QUESTS.find(x=>x.id===d.id);
      if(claimQuest(d.id)){toast('+'+q.r+' XP');tone([660,880]);}
      render();break;
    }
    case 'theme':{const r=document.documentElement;r.classList.add('theme-anim');S.theme=d.v;save();render();setTimeout(()=>r.classList.remove('theme-anim'),500);break;}
    case 'level':S.level=d.v;save();pushProgress();render();break;
    case 'authgo':A.form=d.v==='signup'?'signup':'signin';A.err='';A.msg='';flow='login';render();window.scrollTo(0,0);break;
    case 'splashgo':closeSplash();break;
    case 'flow':flow=d.v;render();window.scrollTo(0,0);break;
    case 'start':flow='onboard';ob.step=0;ob.anim=true;render();window.scrollTo(0,0);break;
    case 'scroll':{const e=$(d.v);if(e&&e.scrollIntoView){try{e.scrollIntoView({behavior:'smooth',block:'start'});}catch(x){}}break;}
    case 'onbcourse':S.course=d.id;applyCourse();save();ob.anim=false;render();break;
    case 'onbgoal':S.goal=+d.id;save();ob.anim=false;render();break;
    case 'onblevel':S.level=d.id;save();ob.anim=false;render();break;
    case 'onbwhy':S.why=d.id;save();ob.anim=false;render();break;
    case 'onbback':if(ob.step>0)ob.step--;ob.anim=true;render();window.scrollTo(0,0);break;
    case 'onbnext':{
      const steps=MODE==='local'?4:5;
      if(ob.step<steps-1){ob.step++;ob.anim=true;render();window.scrollTo(0,0);}
      else{S.onb=true;S.league={tier:0,w:curWeek()};save();pushProgress();tab='home';wantScroll=false;pgAnim=true;render();window.scrollTo(0,0);}
      break;
    }
    case 'opt':if(L&&!L.res&&!L.busy){L.sel=+d.i;const st=cur();if(st&&st.k==='imgsel'&&S.sound!==false)say(st.opts[L.sel]);renderLesson();}break;
    case 'tileAdd':if(L&&!L.res){L.ans.push(+d.i);renderLesson();}break;
    case 'tileDel':if(L&&!L.res){L.ans=L.ans.filter(i=>i!==+d.i);renderLesson();}break;
    case 'check':check();break;
    case 'next':next();break;
    case 'skip':skipListen();break;
    case 'lvclose':if(L){L.lvDone=true;renderLesson();}break;
    case 'quit':if(L){L.quit=true;renderLesson();}break;
    case 'quitNo':if(L){L.quit=false;renderLesson();}break;
    case 'quitYes':case 'exitLesson':closeLesson();break;
    case 'dcGo':case 'dcMist':case 'dcWords':case 'dcPath':case 'dcSum':case 'dcRetry':dcAct(a,d);break;
    case 'dcCards':closeLesson();pxCardsStart();window.scrollTo(0,0);break;
    case 'exitHome':closeLesson();tab='home';render();window.scrollTo(0,0);break;
    case 'retry':{const p=L.practice,i=L.idx;if(L.preview)startPreview(L.pq);else if(p)startPractice();else startLesson(i);break;}
  }
}
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-a]');
  if(b)act(b.dataset.a,b);
});
document.addEventListener('submit',e=>{
  const id=e.target.id;
  if(id==='authform'){e.preventDefault();doAuth();}
  else if(id==='pwform'){e.preventDefault();doSetPw();}
  else if(id==='eform'){e.preventDefault();saveForm();}
  else if(id==='nameform'){e.preventDefault();saveName();}
});
document.addEventListener('change',async e=>{
  if(e.target.id==='cimport'&&e.target.files&&e.target.files[0]){
    const file=e.target.files[0];e.target.value='';
    try{
      if(file.size>8e6)throw new Error('big');
      const r=await importCurriculum(JSON.parse(await file.text()));
      await refreshCatalog();saveCache();toast(t('impDone').replace('{n}',r.q).replace('{l}',r.l).replace('{s}',r.skip));render();
    }catch(x){toast(t('impBad'));}
    return;
  }
  const f=e.target;if(!f.matches||!f.matches('input[type=file][data-up]')||!f.files||!f.files[0])return;
  const kind=f.dataset.up==='audio'?'audio':'image',file=f.files[0],box=f.closest('.fld').querySelector('input[data-f]');
  const max=kind==='audio'?5e6:3e6;
  if(file.type.indexOf(kind+'/')!==0||file.size>max||(kind==='image'&&/svg/i.test(file.type))){toast(t('uplBad'));f.value='';return;}
  try{
    const blob=kind==='image'?await shrinkImage(file):file;
    box.value=await B.upload(blob,kind);toast(t('uplOk'));box.dispatchEvent(new Event('change',{bubbles:true}));
  }catch(x){const c=mapErr(x);toast(t(c==='uplType'||c==='uplSize'?c:'uplBad'));}
  f.value='';
});
document.addEventListener('input',e=>{
  if(e.target.id==='typed'&&L){L.typed=e.target.value;const c=$('chk');if(c)c.disabled=!L.typed.trim();}
  if(e.target.id==='dq'){dictQ=e.target.value;dictMax=60;$('dlist').innerHTML=dictList();}
  if(e.target.id==='onm'){S.name=e.target.value.slice(0,24);save();}
  if(e.target.id==='remtime'&&/^\d\d:\d\d$/.test(e.target.value)){S.rem=Object.assign({on:false,time:'19:00',day:'',risk:''},S.rem);S.rem.time=e.target.value;S.rem.day='';save();}
  if(e.target.id==='uq'){adm.uq=e.target.value;$('ulist').innerHTML=userRows();}
});
document.addEventListener('keydown',e=>{
  if(DLG)return;
  if(e.key==='Escape'&&typeof SHOP!=='undefined'&&SHOP.ask&&!SHOP.busy){shopCancel();return;}
  if(e.key==='Escape'&&(langOpen||notifOpen)){langOpen=false;if(notifOpen){notifOpen=false;markAllRead();}render();return;}
  if(!L)return;
  if(e.key==='Escape'){if(!L.end){L.quit=!L.quit;renderLesson();}return;}
  if(L.intro){if(e.key==='Enter'&&e.target.tagName!=='BUTTON'){e.preventDefault();L.intro=false;L.fresh=true;renderLesson();}return;}
  if(L.quit||L.end)return;
  const s=cur();
  if(e.key==='Enter'){
    if(e.target.tagName==='BUTTON')return;
    e.preventDefault();
    if(L.fixIntro){L.fixIntro=false;renderLesson();}else if(L.res||s.k==='intro')next();else check();
    return;
  }
  if(/^[1-4]$/.test(e.key)&&!L.res&&e.target.tagName!=='INPUT'&&s.opts&&s.opts[+e.key-1]!==undefined){L.sel=+e.key-1;renderLesson();}
});


/* drag and drop ordering in the course builder (the up/down buttons stay for touch screens) */
let dragRow=null;
document.addEventListener('dragstart',e=>{const r=e.target.closest&&e.target.closest('.dnd');if(!r)return;dragRow={t:r.dataset.dnd,id:r.dataset.id};r.classList.add('dragging');try{e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',r.dataset.id);}catch(x){}});
document.addEventListener('dragend',e=>{dragRow=null;document.querySelectorAll('.dragging,.dragover').forEach(n=>n.classList.remove('dragging','dragover'));});
document.addEventListener('dragover',e=>{const r=e.target.closest&&e.target.closest('.dnd');if(!r||!dragRow||r.dataset.dnd!==dragRow.t)return;e.preventDefault();document.querySelectorAll('.dragover').forEach(n=>n.classList.remove('dragover'));r.classList.add('dragover');});
document.addEventListener('drop',async e=>{
  const r=e.target.closest&&e.target.closest('.dnd');if(!r||!dragRow||r.dataset.dnd!==dragRow.t||r.dataset.id===dragRow.id)return;
  e.preventDefault();
  const tb=dragRow.t,row=rawC()[tb].find(x=>x.id===dragRow.id);if(!row){return;}
  const P=PARENT[tb],nav=P?{[P[1]]:row[P[0]]}:{};
  const ids=sib(tb,nav).map(x=>x.id),from=ids.indexOf(dragRow.id),to=ids.indexOf(r.dataset.id);
  if(from<0||to<0)return;
  ids.splice(to,0,ids.splice(from,1)[0]);dragRow=null;
  try{await B.reorder(tb,ids);ids.forEach((id,k)=>{rawC()[tb].find(x=>x.id===id).pos=k+1;});reapply();}catch(x){toast(t('e_'+mapErr(x)));}
  render();
});
/* unsaved changes: warn before leaving the page while an admin form has edits */
document.addEventListener('input',e=>{if(e.target.closest&&e.target.closest('#eform')){adm.dirty=true;}});
window.addEventListener('beforeunload',e=>{if(adm&&adm.dirty&&adm.edit){e.preventDefault();e.returnValue='';}});

function guardDirty(){
  if(!(adm.edit&&adm.dirty)||adm.discardArm)return false;
  adm.discardArm=true;toast(t('unsaved'),'confused');return true;
}
setCatalog(null);
/* =====================================================================================================
   LINGORA 2.0 LEARNING HUB: Practice hub, Flashcards, Stories, Placement test, AI role-play scenarios.
   Everything reuses the existing engines: the lesson runner (hearts, feedback, XP awarded by award()/the server),
   the spaced-repetition store S.srs, and the ai-coach Edge Function. Nothing here invents progress or AI answers.
   Local-only extras live in S.px = {cefr, stories:{id:stars}, placed:ts}.
   ===================================================================================================== */
const PXS={
 hy:{hubT:'Կրկնություն',hubSub:'Ամրապնդիր սովորածդ և փորձիր նոր ձևաչափեր',back:'Հետ',
  cards:'Քարտեր',cardsD:'Բառերի քարտեր՝ ինտերվալային կրկնությամբ',stories:'Պատմություններ',storiesD:'Կարդա, լսիր և պատասխանիր հարցերին',
  place:'Մակարդակի թեստ',placeD:'Որոշիր քո մակարդակը A1–ից C2',listen:'Լսելու վարժանք',listenD:'Լսիր բառը և ընտրիր թարգմանությունը',
  speak:'Խոսելու վարժանք',speakD:'Բարձրաձայն կրկնիր նախադասությունները',mist:'Սխալների վերանայում',mistD:'Վերադարձիր այն հարցերին, որտեղ սխալվել ես',
  vocab:'Բառապաշար',vocabD:'Քո բառարանը և նշված բառերը',ai:'AI խոսակցություն',aiD:'Կյանքի իրավիճակներ՝ ռեստորան, օդանավակայան, հյուրանոց',
  dueN:'կրկնելու {n}',yourLevel:'Քո մակարդակը',notTaken:'Թեստը դեռ չես հանձնել',
  needMore:'Սկզբում ավարտիր մի քանի դաս, որպեսզի այստեղ բառեր հայտնվեն։',noCourseData:'Դասընթացի տվյալները դեռ չեն բեռնվել։',
  flip:'Շրջել',know:'Գիտեմ',dunno:'Դեռ չգիտեմ',cardOf:'Քարտ {i} / {n}',front:'Սեղմիր՝ թարգմանությունը տեսնելու համար',
  cdone:'Այսօրվա քարտերն ավարտված են։',cknown:'Գիտեմ՝ {n}',cunk:'Կրկնելու՝ {n}',again:'Նորից',noDue:'Այսօր կրկնելու բառեր չկան։ Վաղը նորից եկ։',
  start:'Սկսել',read:'Կարդալ',done:'Ավարտված',stars:'աստղ',vocabList:'Բառեր',showTr:'Թարգմանություն',hideTr:'Թաքցնել',listenP:'Լսել',vVocabMin:'Պատմությանը ավելացրու առնվազն մեկ բառ։',
  toQ:'Անցնել հարցերին',storyEn:'Պատմությունները հասանելի են անգլերենի դասընթացում։',storyReward:'Հարցերի ավարտին կստանաս XP։',
  pIntro:'Թեստը հարմարվում է քո պատասխաններին։ 12 հարց, մոտ 3 րոպե։ Սա միայն անգլերենի համար է։',pOnlyEn:'Մակարդակի թեստը ներկայումս անգլերենի համար է։ Անցիր անգլերենի դասընթացին։',
  pQ:'Հարց {i} / {n}',pNext:'Հաջորդը',pFinish:'Տեսնել արդյունքը',pRes:'Քո մակարդակը՝ {l}',pSave:'Պահպանել արդյունքը',pSaved:'Մակարդակը պահպանվեց։',
  pRetake:'Նորից հանձնել',pScore:'Ճիշտ պատասխաններ՝ {c} / {n}',pNote:'Արդյունքը գնահատական է, ոչ պաշտոնական վկայական։ Դասերի առաջընթացը չի փոխվում՝ այն միշտ վաստակվում է դասերով։',
  pDesc_A1:'Սկսնակ. պարզ բառեր և արտահայտություններ։',pDesc_A2:'Տարրական. առօրյա պարզ նախադասություններ։',pDesc_B1:'Միջին. հասկանում ես հիմնական թեմաները։',
  pDesc_B2:'Միջինից բարձր. ազատ խոսում ես շատ թեմաներով։',pDesc_C1:'Առաջադեմ. ճկուն և ճշգրիտ լեզու։',pDesc_C2:'Վարպետ. գրեթե մայրենի մակարդակ։',
  scnT:'Խոսակցության իրավիճակ',scnRestaurant:'Ռեստորան',scnAirport:'Օդանավակայան',scnHotel:'Հյուրանոց',scnShop:'Խանութ',scnDoctor:'Բժիշկ',scnDirections:'Ճանապարհ հարցնել',
  scnOn:'Իրավիճակ՝ {s}. գրիր քո առաջին նախադասությունը անգլերենով։',scnOff:'Անջատել',scnNeed:'AI խոսակցությունը պահանջում է հաշիվ և կարգավորված ai-coach ֆունկցիա։ Եթե այն կարգավորված չէ, կտեսնես համապատասխան հաղորդագրություն։'},
 en:{hubT:'Practice',hubSub:'Reinforce what you know and try new formats',back:'Back',
  cards:'Flashcards',cardsD:'Vocabulary cards with spaced repetition',stories:'Stories',storiesD:'Read, listen and answer questions',
  place:'Placement test',placeD:'Find your level from A1 to C2',listen:'Listening practice',listenD:'Hear a word and pick its translation',
  speak:'Speaking practice',speakD:'Repeat sentences out loud',mist:'Review mistakes',mistD:'Go back to the questions you missed',
  vocab:'Vocabulary',vocabD:'Your dictionary and starred words',ai:'AI conversation',aiD:'Real-life scenarios: restaurant, airport, hotel',
  dueN:'{n} to review',yourLevel:'Your level',notTaken:'Placement test not taken yet',
  needMore:'Finish a few lessons first so words show up here.',noCourseData:'Course data has not loaded yet.',
  flip:'Flip',know:'I know it',dunno:'Still learning',cardOf:'Card {i} / {n}',front:'Tap to see the translation',
  cdone:'Today’s cards are done.',cknown:'Known: {n}',cunk:'To review: {n}',again:'Again',noDue:'Nothing to review today. Come back tomorrow.',
  start:'Start',read:'Read',done:'Completed',stars:'stars',vocabList:'Vocabulary',showTr:'Translation',hideTr:'Hide',listenP:'Listen',vVocabMin:'Add at least one vocabulary item to this story.',
  toQ:'Go to questions',storyEn:'Stories are available in the English course.',storyReward:'You earn XP when the questions are finished.',
  pIntro:'The test adapts to your answers. 12 questions, about 3 minutes. English only.',pOnlyEn:'The placement test is currently for English. Switch to the English course.',
  pQ:'Question {i} / {n}',pNext:'Next',pFinish:'See result',pRes:'Your level: {l}',pSave:'Save result',pSaved:'Level saved.',
  pRetake:'Retake',pScore:'Correct answers: {c} / {n}',pNote:'This is an estimate, not an official certificate. Lesson progress is not changed; it is always earned through lessons.',
  pDesc_A1:'Beginner: simple words and phrases.',pDesc_A2:'Elementary: simple everyday sentences.',pDesc_B1:'Intermediate: you handle the main topics.',
  pDesc_B2:'Upper-intermediate: you speak freely on many topics.',pDesc_C1:'Advanced: flexible and precise language.',pDesc_C2:'Mastery: close to native level.',
  scnT:'Conversation scenario',scnRestaurant:'Restaurant',scnAirport:'Airport',scnHotel:'Hotel',scnShop:'Shop',scnDoctor:'Doctor',scnDirections:'Asking directions',
  scnOn:'Scenario: {s}. Write your first sentence in English.',scnOff:'Turn off',scnNeed:'AI conversation needs an account and a configured ai-coach function. If it is not configured you will see a clear message.'}
};
const pt=(k,o)=>{let s=(PXS[S.lang]||PXS.hy)[k];if(s==null)s=PXS.en[k]||k;if(o)Object.keys(o).forEach(x=>{s=s.replace('{'+x+'}',o[x]);});return s;};
const CEFR=['A1','A2','B1','B2','C1','C2'];
const PX={v:'hub',cards:null,story:null,sTr:{},sVw:null,place:null,scn:'',stat:null};
const pxPx=()=>{if(!S.px||typeof S.px!=='object')S.px={cefr:'',stories:{},placed:0};if(!S.px.stories)S.px.stories={};return S.px;};
const pxEn=()=>(S.course||'en')==='en';

