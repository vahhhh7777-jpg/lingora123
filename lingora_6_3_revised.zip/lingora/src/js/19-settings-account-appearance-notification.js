/* ---------- Settings: account, appearance, notifications, learning, privacy, VIP, accessibility ---------- */
const LUC={
chart:'<path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
award:'<circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>',
sliders:'<line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/>',
user:'<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
mail:'<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
camera:'<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/>',
lock:'<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
key:'<path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z"/><circle cx="16.5" cy="7.5" r=".5" fill="currentColor"/>',
palette:'<circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/>',
sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2m-7.07-17.07 1.41 1.41m11.32 11.32 1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41m11.32-11.32 1.41-1.41"/>',
moon:'<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
monitor:'<rect width="20" height="14" x="2" y="3" rx="2"/><path d="M8 21h8M12 17v4"/>',
bell:'<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
cap:'<path d="M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z"/><path d="M22 10v6"/><path d="M6 12.5V16a6 3 0 0 0 12 0v-3.5"/>',
shield:'<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
crown:'<path d="M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z"/><path d="M5 21h14"/>',
access:'<circle cx="16" cy="4" r="1"/><path d="m18 19 1-7-6 1"/><path d="m5 8 3-3 5.5 3-2.36 3.5"/><path d="M4.24 14.5a5 5 0 0 0 6.88 6"/><path d="M13.76 17.5a5 5 0 0 0-6.88-6"/>',
logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
trash:'<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
vol:'<path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/><path d="M16 9a5 5 0 0 1 0 6"/><path d="M19.364 18.364a9 9 0 0 0 0-12.728"/>',
zap:'<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>',
type:'<polyline points="4 7 4 4 20 4 20 7"/><line x1="9" x2="15" y1="20" y2="20"/><line x1="12" x2="12" y1="4" y2="20"/>',
contrast:'<circle cx="12" cy="12" r="10"/><path d="M12 18a6 6 0 0 0 0-12v12z"/>',
compact:'<path d="m14 10 7-7"/><path d="M20 10h-6V4"/><path d="m3 21 7-7"/><path d="M4 14h6v6"/>',
globe:'<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
target:'<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
gauge:'<path d="m12 14 4-4"/><path d="M3.34 19a10 10 0 1 1 17.32 0"/>',
laptop:'<path d="M20 16V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9m16 0H4m16 0 1.28 2.55a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45L4 16"/>',
download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
eyeoff:'<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/>',
check:'<path d="M20 6 9 17l-5-5"/>',
x:'<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
alert:'<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
reset:'<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
clock:'<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
flame:'<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
trophy:'<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>',
tasks:'<path d="m3 17 2 2 4-4"/><path d="m3 7 2 2 4-4"/><path d="M13 6h8"/><path d="M13 12h8"/><path d="M13 18h8"/>',
trend:'<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
pencil:'<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/>',
chev:'<path d="m6 9 6 6 6-6"/>',
info:'<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>'
};
const LI=(n,cls)=>`<svg class="li ${cls||''}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${LUC[n]||''}</svg>`;

Object.assign(UI.hy,{
 st_acc:'Հաշիվ',st_app:'Տեսք',st_not:'Ծանուցումներ',st_lrn:'Սովորելը',st_sec:'Անվտանգություն',st_vip:'VIP',st_acs:'Մատչելիություն',st_mgt:'Հաշվի կառավարում',
 st_photo:'Պրոֆիլի նկար',st_photoUp:'Փոխել նկարը',st_photoRm:'Հեռացնել',st_photoBad:'Ընտրիր նկար (JPG, PNG կամ WebP, մինչև 5 ՄԲ)',
 st_uname:'Օգտանուն',st_unameBad:'2–24 նիշ',st_unameOk:'Անունը պահպանվեց',st_email:'Էլ. փոստ',st_emailNew:'Նոր էլ. փոստ',st_emailBad:'Մուտքագրիր ճիշտ էլ. փոստ',st_emailSame:'Սա արդեն քո էլ. փոստն է',st_emailSent:'Հաստատման հղումը ուղարկվեց նոր հասցեին',st_emailOk:'Էլ. փոստը փոխվեց',
 st_signinNeed:'Մուտք գործիր, որ պահես կարգավորումները հաշվիդ մեջ և օգտվես այս տարբերակներից։',st_signin:'Մուտք / Գրանցում',
 st_theme:'Թեմա',st_accent:'Գունային շեշտ',st_dense:'Կոմպակտ դասավորություն',st_denseD:'Ավելի փոքր տարածություններ քարտերի միջև',
 st_light:'Բաց',st_dark:'Մուգ',st_sys:'Համակարգի',st_brand:'Lingora',st_ocean:'Օվկիանոս',st_teal:'Փիրուզ',st_berry:'Հապալաս',
 st_nProg:'Առաջընթաց',st_nProgD:'Մակարդակ, թեմա, օրական նպատակ',st_nStreak:'Շարք',st_nStreakD:'Շարքի ռիսկ և նվաճումներ',st_nQuest:'Առաքելություններ',st_nQuestD:'Առաքելություններ և մարտահրավեր',st_nAch:'Նվաճումներ',st_nAchD:'Նոր նշաններ',st_nLeague:'Լիգա',st_nLeagueD:'Շաբաթվա արդյունքներ',
 st_remind:'Օրական հիշեցում',st_remindD:'Ծանուցում քո ընտրած ժամին, երբ հավելվածը բաց է',st_remT:'Ժամ',st_remDenied:'Զննարկիչը արգելել է ծանուցումները',st_remNo:'Այս զննարկիչը ծանուցումներ չի աջակցում',
 st_uiLang:'Ինտերֆեյսի լեզու',st_course:'Սովորելու լեզու',st_goal:'Օրական նպատակ',st_diff:'Դժվարություն',st_dEasy:'Հեշտ',st_dNorm:'Սովորական',st_dHard:'Խիստ',st_diffD:'Հեշտ՝ ներում է փոքր վրիպակներ։ Խիստ՝ պահանջում է ճշգրիտ գրություն։',
 st_goalMin:'րոպե',
 st_curPw:'Ընթացիկ գաղտնաբառ',st_newPw:'Նոր գաղտնաբառ',st_newPw2:'Կրկնիր նոր գաղտնաբառը',st_pwChange:'Փոխել գաղտնաբառը',st_pwWrong:'Ընթացիկ գաղտնաբառը սխալ է',st_pwBad:'Նոր գաղտնաբառը՝ առնվազն 8 նիշ, տառով և թվով',st_pwMatch:'Գաղտնաբառերը չեն համընկնում',st_pwDone:'Գաղտնաբառը փոխվեց',
 st_sess:'Ակտիվ սեսիաներ',st_thisDev:'Այս սարքը',st_active:'Ակտիվ է հիմա',st_lastIn:'Վերջին մուտք',st_outAll:'Դուրս գալ բոլոր սարքերից',st_outAllD:'Բոլոր սարքերում սեսիաները կավարտվեն',st_outAllOk:'Բոլոր սարքերից դուրս եկար',
 st_priv:'Գաղտնիություն',st_hideLb:'Թաքնվել առաջատարների աղյուսակից',st_hideLbD:'Քո անունը չի երևա այլ սովորողների համար',st_export:'Ներբեռնել իմ տվյալները',st_exportD:'JSON ֆայլ՝ առաջընթաց, նվաճումներ, կարգավորումներ',st_exportOk:'Տվյալները ներբեռնվեցին',
 st_vipS:'VIP կարգավիճակ',st_vipOn:'VIP ակտիվ է',st_vipFree:'Անվճար հաշիվ',st_vipExp:'Ավարտվում է',st_vipLeft:'օր է մնացել',st_vipAdmin:'Ադմինիստրատոր (VIP ընդմիշտ)',st_vipBen:'Առավելություններ',
 st_sound:'Ձայն',st_soundD:'Ձայնային էֆեկտներ և արտասանություն',st_anim:'Անիմացիաներ',st_animD:'Անջատիր՝ շարժումը նվազեցնելու համար',st_fs:'Տառի չափ',st_hc:'Բարձր կոնտրաստ',st_hcD:'Ավելի ընդգծված եզրագծեր և տեքստ',
 st_logout:'Դուրս գալ',st_logoutD:'Դուրս կգաս այս սարքից',st_reset:'Զրոյացնել առաջընթացը',st_resetD:'Կջնջվեն XP, շարքը և դասերի առաջընթացը',st_del:'Ջնջել հաշիվը',st_delD:'Հաշիվը և բոլոր տվյալները կջնջվեն ընդմիշտ',st_delLocal:'Ջնջել տվյալներս',st_delLocalD:'Այս սարքի բոլոր տվյալները կջնջվեն ընդմիշտ',
 st_cancel:'Չեղարկել',st_confirm:'Հաստատել',st_saved:'Պահպանվեց',st_fail:'Չհաջողվեց, փորձիր կրկին',
 st_dlgOut:'Դուրս գա՞լ հաշվից',st_dlgOutB:'Առաջընթացդ պահված է հաշվիդ մեջ։ Կարող ես ցանկացած պահի վերադառնալ։',
 st_dlgReset:'Զրոյացնե՞լ առաջընթացը',st_dlgResetB:'XP-ն, շարքը, դասերի և բառերի առաջընթացը կջնջվեն։ Կարգավորումները կմնան։ Սա հնարավոր չէ հետ բերել։',
 st_dlgDel:'Ջնջե՞լ հաշիվը',st_dlgDelB:'Հաշիվը, առաջընթացը, XP-ն և գոհարները կջնջվեն ընդմիշտ։ Հետ բերել հնարավոր չէ։',st_dlgDelType:'Հաստատելու համար մուտքագրիր՝',st_delWord:'ՋՆՋԵԼ',st_delBad:'Մուտքագրածը չի համընկնում',st_delAdmin:'Ադմինիստրատորի հաշիվը չի կարելի ջնջել այստեղից',st_delDone:'Հաշիվը ջնջվեց',
 st_ago:'',st_noSupport:'Չի աջակցվում'});
Object.assign(UI.en,{
 st_acc:'Account',st_app:'Appearance',st_not:'Notifications',st_lrn:'Learning',st_sec:'Security',st_vip:'VIP',st_acs:'Accessibility',st_mgt:'Account management',
 st_photo:'Profile picture',st_photoUp:'Change photo',st_photoRm:'Remove',st_photoBad:'Choose an image (JPG, PNG or WebP, up to 5 MB)',
 st_uname:'Username',st_unameBad:'2–24 characters',st_unameOk:'Name saved',st_email:'Email',st_emailNew:'New email',st_emailBad:'Enter a valid email address',st_emailSame:'That is already your email',st_emailSent:'A confirmation link was sent to the new address',st_emailOk:'Email updated',
 st_signinNeed:'Sign in to save your settings to your account and unlock these options.',st_signin:'Sign in / Sign up',
 st_theme:'Theme',st_accent:'Accent colour',st_dense:'Compact layout',st_denseD:'Tighter spacing between cards',
 st_light:'Light',st_dark:'Dark',st_sys:'System',st_brand:'Lingora',st_ocean:'Ocean',st_teal:'Teal',st_berry:'Berry',
 st_nProg:'Progress',st_nProgD:'Level-ups, units, daily goal',st_nStreak:'Streak',st_nStreakD:'Streak risk and freezes',st_nQuest:'Quests',st_nQuestD:'Quests and challenge',st_nAch:'Achievements',st_nAchD:'New badges',st_nLeague:'League',st_nLeagueD:'Weekly results',
 st_remind:'Daily reminder',st_remindD:'A notification at your chosen time while the app is open',st_remT:'Time',st_remDenied:'Notifications are blocked in your browser',st_remNo:'This browser does not support notifications',
 st_uiLang:'Interface language',st_course:'Learning language',st_goal:'Daily goal',st_diff:'Difficulty',st_dEasy:'Easy',st_dNorm:'Normal',st_dHard:'Strict',st_diffD:'Easy forgives small typos. Strict needs exact spelling.',
 st_goalMin:'min',
 st_curPw:'Current password',st_newPw:'New password',st_newPw2:'Repeat new password',st_pwChange:'Change password',st_pwWrong:'Current password is wrong',st_pwBad:'New password: at least 8 characters with a letter and a number',st_pwMatch:'Passwords do not match',st_pwDone:'Password changed',
 st_sess:'Active sessions',st_thisDev:'This device',st_active:'Active now',st_lastIn:'Last sign-in',st_outAll:'Sign out of all devices',st_outAllD:'Ends sessions on every device',st_outAllOk:'Signed out everywhere',
 st_priv:'Privacy',st_hideLb:'Hide me from the leaderboard',st_hideLbD:'Your name will not show to other learners',st_export:'Download my data',st_exportD:'A JSON file with progress, achievements and settings',st_exportOk:'Data downloaded',
 st_vipS:'VIP status',st_vipOn:'VIP is active',st_vipFree:'Free account',st_vipExp:'Expires',st_vipLeft:'days left',st_vipAdmin:'Administrator (VIP forever)',st_vipBen:'Benefits',
 st_sound:'Sound',st_soundD:'Sound effects and pronunciation',st_anim:'Animations',st_animD:'Turn off to reduce motion',st_fs:'Text size',st_hc:'High contrast',st_hcD:'Stronger borders and text',
 st_logout:'Log out',st_logoutD:'You will be signed out on this device',st_reset:'Reset progress',st_resetD:'Clears XP, streak and lesson progress',st_del:'Delete account',st_delD:'Your account and all data are removed permanently',st_delLocal:'Delete my data',st_delLocalD:'Everything on this device is removed permanently',
 st_cancel:'Cancel',st_confirm:'Confirm',st_saved:'Saved',st_fail:'Something went wrong. Try again',
 st_dlgOut:'Log out?',st_dlgOutB:'Your progress is saved to your account. You can come back any time.',
 st_dlgReset:'Reset progress?',st_dlgResetB:'XP, streak, lesson and word progress will be cleared. Settings stay. This cannot be undone.',
 st_dlgDel:'Delete your account?',st_dlgDelB:'Your account, progress, XP and Lingora Coins will be deleted permanently. This cannot be undone.',st_dlgDelType:'To confirm, type:',st_delWord:'DELETE',st_delBad:'That does not match',st_delAdmin:'An administrator account cannot be deleted here',st_delDone:'Account deleted',
 st_ago:'',st_noSupport:'Not supported'});

/* ----- preferences: apply, snapshot, sync ----- */
const PREF=['lang','theme','sound','goal','noanim','accent','dense','fs','diff','nset','avatar','hc','rem'];
const prefSnap=s=>{const o={t:s.pfT||0};PREF.forEach(k=>{o[k]=s[k];});return o;};
function setGoal(n){S.goal=n;touchPref();if(ECON())B.setGoal(n).then(st=>{if(st&&typeof st.xp==='number'){applyState(st);save();render();}}).catch(e=>{console.warn('daily goal not saved on the server',e);toast(econErr(e),'confused');});}
function applyPf(){
  const p=S.pf;if(!p||(p.t||0)<=(S.pfT||0))return false;
  PREF.forEach(k=>{if(p[k]!==undefined)S[k]=p[k];});S.pfT=p.t;save();return true;
}
function applyPrefs(){
  const r=document.documentElement,c=r.classList;
  c.toggle('dense',!!S.dense);c.toggle('hc',!!S.hc);c.toggle('fs112',S.fs===112);c.toggle('fs125',S.fs===125);
  r.removeAttribute('data-accent');
}
let prefTimer=0;
function touchPref(){S.pfT=Date.now();save();clearTimeout(prefTimer);prefTimer=setTimeout(()=>{pushProgress();},500);}
const NGROUP={friend:'social',goal:'prog',unit:'prog',level:'prog',streak:'streak',freeze:'streak',risk:'streak',quest:'quest',challenge:'quest',ach:'ach',league:'league'};
const notifOn=kind=>{const g=NGROUP[kind];return !g||!S.nset||S.nset[g]!==false;};

/* ----- helpers ----- */
const SET={nm:null,em:'',pcur:'',pnew:'',pnew2:'',del:'',err:{},busy:''};
let DLG=null;
const setErr=(k,m)=>{SET.err[k]=m||'';};
const ferr=k=>SET.err[k]?`<p class="ferr" role="alert">${LI('alert')}${esc(SET.err[k])}</p>`:'';
const okToast=m=>toast(m||t('st_saved'),'happy');
const badToast=m=>toast(m||t('st_fail'),'confused');
const emailOk=e=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);
const pwValid=p=>p.length>=8&&/[A-Za-z\u0400-\u04FF\u0531-\u058F]/.test(p)&&/\d/.test(p);
const srow=(ic,label,desc,ctl,cls)=>`<div class="srow ${cls||''}"><span class="si">${LI(ic)}</span><div class="st"><b>${label}</b>${desc?`<small>${desc}</small>`:''}</div><div class="sc-ctl">${ctl}</div></div>`;
const sw=(k,on,label)=>`<button type="button" class="sw" role="switch" aria-checked="${on?'true':'false'}" aria-label="${esc(label)}" data-a="stog" data-k="${k}"><i></i></button>`;
const sseg=(k,cur,items)=>`<div class="seg sseg" role="radiogroup">${items.map(it=>`<button type="button" role="radio" aria-checked="${String(String(cur)===String(it[0]))}" data-a="sset" data-k="${k}" data-v="${it[0]}" ${it[2]?`aria-label="${esc(it[2])}" title="${esc(it[2])}"`:''}>${it[1]}</button>`).join('')}</div>`;
const ssel=(k,cur,items)=>`<span class="selw"><select class="sel" data-sel="${k}" aria-label="${esc(k)}">${items.map(it=>`<option value="${esc(it[0])}" ${String(cur)===String(it[0])?'selected':''}>${esc(it[1])}</option>`).join('')}</select>${LI('chev')}</span>`;
const sbtn=(key,label,cls,ic,attrs)=>`<button type="${attrs&&attrs.type||'button'}" class="btn ${cls||'btn-ghost'} sb ${SET.busy===key?'busy':''}" ${attrs&&attrs.a?`data-a="${attrs.a}"`:''} ${SET.busy===key?'disabled aria-busy="true"':''}>${SET.busy===key?'<i class="spin-i" aria-hidden="true"></i>':(ic?LI(ic):'')}<span>${label}</span></button>`;
const field=(id,key,label,type,val,auto,ph)=>`<label class="fld">${label}<input id="${id}" type="${type}" value="${esc(val||'')}" data-sf="${key}" autocomplete="${auto||'off'}" ${ph?`placeholder="${esc(ph)}"`:''} ${SET.err[key]?'aria-invalid="true"':''}>${ferr(key)}</label>`;
const hasAcct=()=>MODE!=='local'&&!!A.user;
function devLabel(){
  const u=navigator.userAgent||'',b=/Edg\//.test(u)?'Edge':/OPR\//.test(u)?'Opera':/Firefox\//.test(u)?'Firefox':/Chrome\//.test(u)?'Chrome':/Safari\//.test(u)?'Safari':'Browser';
  const o=/Windows/.test(u)?'Windows':/Android/.test(u)?'Android':/iPhone|iPad/.test(u)?'iOS':/Mac OS/.test(u)?'macOS':/Linux/.test(u)?'Linux':'';
  return b+(o?' · '+o:'');
}
const fmtDate=d=>{try{return new Date(d).toLocaleDateString(S.lang==='hy'?'hy-AM':'en-GB',{day:'numeric',month:'long',year:'numeric'});}catch(e){return String(d);}};
const delWord=()=>t('st_delWord');

/* ----- the page ----- */
const SNAV=[['account','user','st_acc'],['appearance','palette','st_app'],['notif','bell','st_not'],['learn','cap','st_lrn'],['vip','crown','st_vip'],['access','access','st_acs'],['manage','logout','st_mgt']];
function secCard(id,ic,title,inner){return `<section class="card scard" id="s-${id}"><h2 class="sh"><span class="hic">${LI(ic)}</span>${esc(title)}</h2>${inner}</section>`;}
function settingsPage(){
  const p=A.profile||{},nm=SET.nm===null?(S.name||p.name||''):SET.nm;
  const snav=`<nav class="snav" aria-label="${esc(t('pt_set'))}">${SNAV.map(x=>`<button type="button" data-a="sscroll" data-v="${x[0]}" aria-label="${esc(t(x[2]))}" title="${esc(t(x[2]))}">${LI(x[1])}</button>`).join('')}</nav>`;
  /* account */
  let acc=`<div class="srow"><span class="avbig">${S.avatar?`<img src="${esc(S.avatar)}" alt="">`:esc((nm||'?').trim().charAt(0).toUpperCase()||'?')}</span><div class="st"><b>${t('st_photo')}</b><small>JPG · PNG · WebP</small></div><div class="sc-ctl sc-acts"><label class="btn btn-ghost sb" tabindex="0" role="button" aria-label="${esc(t('st_photoUp'))}" title="${esc(t('st_photoUp'))}">${LI('camera')}<input type="file" id="avfile" accept="image/png,image/jpeg,image/webp" hidden></label>${S.avatar?`<button type="button" class="btn btn-ghost sb ic-danger" data-a="avrm" aria-label="${esc(t('st_photoRm'))}" title="${esc(t('st_photoRm'))}">${LI('trash')}</button>`:''}</div></div>${ferr('avatar')}
   <form id="sname" class="sform" novalidate>${field('snm','nm',t('st_uname'),'text',nm,'nickname')}${sbtn('name',t('save'),'btn-purple','check',{type:'submit'})}</form>`;
  if(hasAcct())acc+=`<div class="srow"><span class="si">${LI('mail')}</span><div class="st"><b>${t('st_email')}</b><small class="brk">${esc(A.user.email)}</small></div></div>
   <form id="semail" class="sform" novalidate>${field('sem','em',t('st_emailNew'),'email',SET.em,'email')}${sbtn('email',t('st_email'),'btn-ghost','mail',{type:'submit'})}</form>`;
  else acc+=`<div class="snote">${LI('info')}<span>${t('st_signinNeed')}</span><button type="button" class="btn btn-purple sb" data-a="authgo" data-v="signin" onclick="">${t('st_signin')}</button></div>`;
  /* appearance */
  const app=srow('sun',t('st_theme'),'',sseg('theme',S.theme||'dark',[['light',LI('sun'),t('st_light')],['dark',LI('moon'),t('st_dark')],['system',LI('monitor'),t('st_sys')]]))+
   srow('compact',t('st_dense'),t('st_denseD'),sw('dense',!!S.dense,t('st_dense')));
  /* notifications */
  const ns=S.nset||{},on=g=>ns[g]!==false;
  const supN='Notification' in window,perm=supN?Notification.permission:'denied';
  let not=[['prog','trend','st_nProg','st_nProgD'],['streak','flame','st_nStreak','st_nStreakD'],['quest','tasks','st_nQuest','st_nQuestD'],['ach','trophy','st_nAch','st_nAchD'],['league','trophy','st_nLeague','st_nLeagueD']].concat(MODE==='cloud'?[['social','users','st_nSocial','st_nSocialD']]:[]).map(x=>srow(x[1],t(x[2]),t(x[3]),sw('n:'+x[0],on(x[0]),t(x[2])))).join('');
  const r=S.rem||{on:false,time:'19:00'};
  not+=srow('clock',t('st_remind'),supN?(perm==='denied'?t('st_remDenied'):t('st_remindD')):t('st_remNo'),supN?sw('rem',!!r.on&&perm==='granted',t('st_remind')):'')+(supN&&r.on?`<div class="srow sub"><span class="si">${LI('clock')}</span><div class="st"><b>${t('st_remT')}</b></div><div class="sc-ctl"><input id="remtime" type="time" class="tinp" value="${esc(r.time||'19:00')}" aria-label="${esc(t('st_remT'))}"></div></div>`:'');
  /* learning */
  const mins={10:3,20:5,30:8,50:12};
  const lrn=srow('target',t('st_goal'),'',ssel('goal',S.goal,[10,20,30,50].map(n=>[n,n+' XP · ≈'+mins[n]+' '+t('st_goalMin')])))+
   srow('gauge',t('st_diff'),t('st_diffD'),sseg('diff',S.diff||'normal',[['easy',t('st_dEasy')],['normal',t('st_dNorm')],['hard',t('st_dHard')]]),'wrapc');
  /* vip */
  let vip='';
  if(hasAcct()){
    const on=profVip(p),left=p.vip_until?Math.ceil((new Date(p.vip_until)-new Date())/864e5):0;
    vip+=`<div class="vipst ${on?'on':''}"><span class="hic">${LI('crown')}</span><div><b>${on?t('st_vipOn'):t('st_vipFree')}</b><small>${p.is_admin?t('st_vipAdmin'):on&&p.vip_until?t('st_vipExp')+' '+esc(fmtDate(p.vip_until))+' · '+left+' '+t('st_vipLeft'):''}</small></div></div>`;
    vip+=`<h3 class="sh3">${t('st_vipBen')}</h3><ul class="vlist">${t('vipList').map(x=>`<li>${LI('check')}<span>${esc(x)}</span></li>`).join('')}</ul>${on?'':`<h3 class="sh3">${t('vipHow')}</h3>${vipHowHtml()}`}`;
  }else vip+=`<div class="snote">${LI('info')}<span>${t('st_signinNeed')}</span></div><ul class="vlist">${t('vipList').map(x=>`<li>${LI('check')}<span>${esc(x)}</span></li>`).join('')}</ul>`;
  /* accessibility */
  const acs=srow('vol',t('st_sound'),t('st_soundD'),sw('sound',!!S.sound,t('st_sound')))+
   srow('zap',t('st_anim'),t('st_animD'),sw('anim',!S.noanim,t('st_anim')))+
   srow('type',t('st_fs'),'',sseg('fs',S.fs||100,[[100,'A'],[112,'A+'],[125,'A++']]))+
   srow('contrast',t('st_hc'),t('st_hcD'),sw('hc',!!S.hc,t('st_hc')))+
   `<div class="srow" style="display:block">${vxSettingsHtml()}</div>`;
  /* management */
  let mgt='';
  if(hasAcct())mgt+=srow('logout',t('st_logout'),t('st_logoutD'),`<button type="button" class="btn btn-ghost sb" data-a="slogout">${LI('logout')}<span>${t('st_logout')}</span></button>`);
  /* the reset row had been lost from this screen: its handler (sreset) and texts existed but nothing rendered the button */
  mgt+=srow('reset',t('st_reset'),t('st_resetD'),`<button type="button" class="btn btn-ghost sb" data-a="sreset">${LI('reset')}<span>${t('st_reset')}</span></button>`);
  mgt+=`<div class="srow danger">${`<span class="si">${LI('trash')}</span>`}<div class="st"><b>${hasAcct()?t('st_del'):t('st_delLocal')}</b><small>${hasAcct()?t('st_delD'):t('st_delLocalD')}</small></div><div class="sc-ctl"><button type="button" class="btn btn-danger sb" data-a="sdelete">${LI('trash')}<span>${hasAcct()?t('st_del'):t('st_delLocal')}</span></button></div></div>`;
  return snav+secCard('account','user',t('st_acc'),acc)+secCard('appearance','palette',t('st_app'),app)+secCard('notif','bell',t('st_not'),not)+secCard('learn','cap',t('st_lrn'),lrn)+secCard('vip','crown',t('st_vip'),vip)+secCard('access','access',t('st_acs'),acs)+secCard('manage','logout',t('st_mgt'),mgt);
}
function dlgHtml(){
  if(!DLG)return '';
  const d=DLG;
  return `<div class="pop-bg dlg-bg" data-a="dlgno"><div class="dlg ${d.danger?'danger':''}" role="alertdialog" aria-modal="true" aria-labelledby="dlgt" aria-describedby="dlgb" data-a="noop"><span class="dlg-ic">${LI(d.icon||'alert')}</span><h2 id="dlgt">${esc(d.title)}</h2><p id="dlgb">${esc(d.body)}</p>${d.type?`<label class="fld">${esc(t('st_dlgDelType'))} <b class="word">${esc(d.type)}</b><input id="dlgin" type="text" autocomplete="off" autocapitalize="characters" value="${esc(SET.del)}" ${SET.err.del?'aria-invalid="true"':''}>${ferr('del')}</label>`:''}<div class="dlg-acts"><button type="button" class="btn btn-ghost" data-a="dlgno">${esc(t('st_cancel'))}</button><button type="button" id="dlgok" class="btn ${d.danger?'btn-danger':'btn-purple'} ${SET.busy==='dlg'?'busy':''}" data-a="dlgok" ${SET.busy==='dlg'?'disabled aria-busy="true"':''}>${SET.busy==='dlg'?'<i class="spin-i" aria-hidden="true"></i>':''}${esc(d.ok)}</button></div></div></div>`;
}
const openDlg=d=>{DLG=d;SET.del='';setErr('del','');render();setTimeout(()=>{const i=document.getElementById('dlgin')||document.getElementById('dlgok');if(i)i.focus();},30);};
const closeDlg=()=>{DLG=null;SET.busy='';SET.del='';setErr('del','');render();};

/* ----- image helper ----- */
function avatarFrom(file){
  return new Promise((res,rej)=>{
    const img=new Image(),url=URL.createObjectURL(file);
    img.onload=()=>{try{
      const n=160,c=document.createElement('canvas');c.width=c.height=n;const x=c.getContext('2d');
      const s=Math.min(img.width,img.height),sx=(img.width-s)/2,sy=(img.height-s)/2;
      x.fillStyle='#fff';x.fillRect(0,0,n,n);x.drawImage(img,sx,sy,s,s,0,0,n,n);
      URL.revokeObjectURL(url);res(c.toDataURL('image/jpeg',.82));
    }catch(e){rej(e);}};
    img.onerror=()=>{URL.revokeObjectURL(url);rej(new Error('img'));};
    img.src=url;
  });
}

/* ----- actions ----- */
async function actS(a,d,el){
  switch(a){
    case 'sscroll':{const e=document.getElementById('s-'+d.v);if(e)e.scrollIntoView({behavior:S.noanim?'auto':'smooth',block:'start'});return true;}
    case 'sset':{
      const k=d.k,v=d.v;
      if(k==='theme'){const r=document.documentElement;r.classList.add('theme-anim');S.theme=v;setTimeout(()=>r.classList.remove('theme-anim'),500);}
      else if(k==='lang')S.lang=v;
      else if(k==='fs')S.fs=+v;
      else if(k==='accent')S.accent=v;
      else if(k==='diff')S.diff=v;
      touchPref();render();okToast();return true;
    }
    case 'stog':{
      const k=d.k;
      if(k==='dense')S.dense=!S.dense;
      else if(k==='hc')S.hc=!S.hc;
      else if(k==='sound')S.sound=!S.sound;
      else if(k==='anim')S.noanim=!S.noanim;
      else if(k.indexOf('n:')===0){const g=k.slice(2);S.nset=Object.assign({},S.nset);S.nset[g]=S.nset[g]===false;ntPushPrefs();}
      else if(k==='rem'){
        S.rem=Object.assign({on:false,time:'19:00',day:'',risk:''},S.rem);
        if(!S.rem.on){
          if(!('Notification' in window)){badToast(t('st_remNo'));return true;}
          let pm=Notification.permission;
          if(pm==='default'){try{pm=await Notification.requestPermission();}catch(e){}}
          if(pm!=='granted'){badToast(t('st_remDenied'));render();return true;}
          S.rem.on=true;
        }else S.rem.on=false;
      }
      else if(k==='hidelb'){
        const want=!(A.profile&&A.profile.hide_lb);
        try{await B.setPrivacy(want);A.profile=Object.assign({},A.profile,{hide_lb:want});A.boardAt=0;okToast();}catch(e){badToast();}
        render();return true;
      }
      touchPref();render();okToast();return true;
    }
    case 'avrm':S.avatar='';touchPref();render();okToast();return true;
    case 'sexport':{
      try{
        const data={app:'Lingora',exported:new Date().toISOString(),account:hasAcct()?{email:A.user.email,name:(A.profile||{}).name}:null,progress:progOf(S),settings:prefSnap(S)};
        const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),u=URL.createObjectURL(blob),l=document.createElement('a');
        l.href=u;l.download='lingora-data.json';document.body.appendChild(l);l.click();l.remove();setTimeout(()=>URL.revokeObjectURL(u),1500);okToast(t('st_exportOk'));
      }catch(e){badToast();}
      return true;
    }
    case 'soutall':{
      SET.busy='outall';render();
      try{await B.signOutAll();SET.busy='';await doSignOut();toast(t('st_outAllOk'),'happy');}catch(e){SET.busy='';badToast();render();}
      return true;
    }
    case 'slogout':
      openDlg({icon:'logout',title:t('st_dlgOut'),body:t('st_dlgOutB'),ok:t('st_logout'),run:async()=>{await doSignOut();}});return true;
    case 'sreset':
      openDlg({icon:'reset',title:t('st_dlgReset'),body:t('st_dlgResetB'),ok:t('st_reset'),danger:true,run:async()=>{if(await startReset())toast(t('resetDone'),'happy');}});return true;
    case 'sdelete':
      openDlg({icon:'trash',title:hasAcct()?t('st_dlgDel'):t('st_delLocal'),body:hasAcct()?t('st_dlgDelB'):t('st_delLocalD'),ok:hasAcct()?t('st_del'):t('st_delLocal'),danger:true,type:delWord(),run:async()=>{
        if(hasAcct()){const delUid=A.user&&A.user.id;await B.deleteAccount();A.user=null;A.profile=null;if(delUid){stashDrop(delUid);try{localStorage.removeItem(syncPKey());localStorage.removeItem(resetKey());}catch(e){}}try{await B.signOut();}catch(e){console.warn('delete account: sign-out failed',e);}
          try{localStorage.removeItem(CKEY);}catch(e){}
          resetProgress(true);S.avatar='';S.name='';save();A.rawCat=null;A.dbCount=0;try{await refreshCatalog();}catch(e){setCatalog(null);}
          tab='home';flow='landing';toast(t('st_delDone'),'happy');
        }else{
          const keep={lang:S.lang};try{localStorage.removeItem(KEY);localStorage.removeItem(CKEY);}catch(e){}
          S=Object.assign(fresh(),keep);applyCourse();save();tab='home';flow='landing';toast(t('st_delDone'),'happy');
        }}});return true;
    case 'dlgno':if(DLG&&SET.busy!=='dlg')closeDlg();return true;
    case 'dlgok':{
      const d=DLG;if(!d||SET.busy==='dlg')return true;
      if(d.type){
        const v=(document.getElementById('dlgin')||{}).value||'';SET.del=v;
        const w=v.trim().toUpperCase();
        if(w!==UI.hy.st_delWord&&w!==UI.en.st_delWord){setErr('del',t('st_delBad'));render();const i=document.getElementById('dlgin');if(i)i.focus();return true;}
      }
      SET.busy='dlg';render();
      try{await d.run();DLG=null;SET.busy='';render();}
      catch(e){SET.busy='';const m=String((e&&e.message)||e);
        if(/admin_cannot_delete/.test(m)){setErr('del',t('st_delAdmin'));}else{setErr('del',t('st_fail'));}
        badToast(SET.err.del);render();}
      return true;
    }
  }
  return false;
}
async function submitSettings(id){
  if(id==='sname'){
    const v=(SET.nm===null?'':SET.nm).trim();setErr('nm','');
    if(v.length<2||v.length>24){setErr('nm',t('st_unameBad'));render();return;}
    SET.busy='name';render();
    try{if(B&&A.user)await B.setName(v);S.name=v;if(A.profile)A.profile=Object.assign({},A.profile,{name:v});SET.nm=null;touchPref();pushProgress();okToast(t('st_unameOk'));}catch(e){badToast();}
    SET.busy='';render();
  }else if(id==='semail'){
    const v=(SET.em||'').trim().toLowerCase();setErr('em','');
    if(!emailOk(v)){setErr('em',t('st_emailBad'));render();return;}
    if(v===String(A.user.email).toLowerCase()){setErr('em',t('st_emailSame'));render();return;}
    SET.busy='email';render();
    try{const r=await B.setEmail(v);SET.em='';if(r&&r.pending)okToast(t('st_emailSent'));else{A.user=Object.assign({},A.user,{email:v});okToast(t('st_emailOk'));}}
    catch(e){setErr('em',mapErr(e)==='exists'?t('e_exists'):t('st_fail'));badToast(SET.err.em);}
    SET.busy='';render();
  }else if(id==='spw'){
    ['pcur','pnew','pnew2'].forEach(k=>setErr(k,''));
    if(!SET.pcur){setErr('pcur',t('st_pwWrong'));}
    if(!pwValid(SET.pnew||'')){setErr('pnew',t('st_pwBad'));}
    else if(SET.pnew2!==SET.pnew){setErr('pnew2',t('st_pwMatch'));}
    if(SET.err.pcur||SET.err.pnew||SET.err.pnew2){render();return;}
    SET.busy='pw';render();
    try{
      try{await B.verifyPassword(A.user.email,SET.pcur);}catch(e){setErr('pcur',t('st_pwWrong'));throw e;}
      await B.updatePassword(SET.pnew);SET.pcur=SET.pnew=SET.pnew2='';okToast(t('st_pwDone'));
    }catch(e){if(!SET.err.pcur){badToast();}}
    SET.busy='';render();
  }
}
document.addEventListener('submit',e=>{const id=e.target.id;if(id==='sname'||id==='semail'||id==='spw'){e.preventDefault();submitSettings(id);}});
document.addEventListener('input',e=>{
  const f=e.target;
  if(f.dataset&&f.dataset.sf){SET[f.dataset.sf]=f.value;if(SET.err[f.dataset.sf]){setErr(f.dataset.sf,'');const p=f.parentNode.querySelector('.ferr');if(p)p.remove();f.removeAttribute('aria-invalid');}}
  if(f.id==='dlgin'){SET.del=f.value;}
  if(f.id==='remtime'&&/^\d\d:\d\d$/.test(f.value)){touchPref();}
});
document.addEventListener('change',async e=>{
  const f=e.target;
  if(f.dataset&&f.dataset.sel){
    const k=f.dataset.sel;
    if(k==='goal'){setGoal(+f.value);render();okToast();}
    else if(k==='course'){S.course=f.value;applyCourse();save();pushProgress();render();okToast();}
    return;
  }
  if(f.id==='avfile'&&f.files&&f.files[0]){
    const file=f.files[0];setErr('avatar','');
    if(!/^image\/(png|jpeg|webp)$/.test(file.type)||file.size>5e6){setErr('avatar',t('st_photoBad'));f.value='';render();return;}
    try{S.avatar=await avatarFrom(file);touchPref();okToast();}catch(x){setErr('avatar',t('st_photoBad'));}
    f.value='';render();
  }
});
document.addEventListener('keydown',e=>{
  if(!DLG)return;
  if(e.key==='Escape'){e.preventDefault();if(SET.busy!=='dlg')closeDlg();}
  else if(e.key==='Enter'&&e.target.id==='dlgin'){e.preventDefault();act('dlgok',document.getElementById('dlgok'));}
  else if(e.key==='Tab'){const els=[...document.querySelectorAll('.dlg input,.dlg button:not([disabled])')];if(!els.length)return;const i=els.indexOf(document.activeElement);const n=e.shiftKey?(i<=0?els.length-1:i-1):(i===els.length-1?0:i+1);e.preventDefault();els[n].focus();}
});

/* Difficulty changes how strictly typed answers are judged. easy: tolerates one slip in longer words. normal: ignores case, accents and punctuation. hard: also needs the exact accents. */
function lev1(a,b){
  if(a===b)return true;if(Math.abs(a.length-b.length)>1)return false;
  let i=0;while(i<a.length&&i<b.length&&a[i]===b[i])i++;
  if(a.length===b.length)return a.slice(i+1)===b.slice(i+1)||(a[i]===b[i+1]&&a[i+1]===b[i]&&a.slice(i+2)===b.slice(i+2));
  return a.length>b.length?a.slice(i+1)===b.slice(i):b.slice(i+1)===a.slice(i);
}
const lenientOn=()=>(S.diff||'normal')==='easy';
function typeOk(s,typed){
  if(s.k==='write'&&s.keywords&&s.keywords.length&&!fold(typed)){return false;}
  if(s.k==='write'&&s.keywords&&s.keywords.length&&![s.ans].concat(s.accept||[]).some(x=>fold(x)===fold(typed)))return s.keywords.every(k=>fold(typed).indexOf(fold(k))>=0);
  const all=[s.ans].concat(s.accept||[]),d=S.diff||'normal';
  if(d==='hard'){const n=x=>norm(x);return all.some(x=>n(x)===n(typed));}
  const nt=fold(typed);
  if(all.some(x=>fold(x)===nt))return true;
  return d==='easy'&&nt.length>=5&&all.some(x=>{const f=fold(x);return f.length>=5&&lev1(f,nt);});
}
