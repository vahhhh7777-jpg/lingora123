/* ---------- Part 1: Friends and AI Coach ----------
   Friends: real friendship graph in the database (migration 007). Only cloud mode with a signed-in account has it;
   every other state says so plainly instead of showing invented people.
   AI Coach: insights computed from the learner's own progress. There is no chat here yet: a conversational tutor
   needs a server-side model key (an Edge Function), which is Part 2. Nothing in this file pretends otherwise. */
const SOC={data:null,loading:false,err:'',busy:false,q:'',at:0,rm:'',fb:null};
const socOK=()=>MODE==='cloud'&&!!A.user&&!!B&&!!B.friends;

async function loadFriends(force){
  if(!socOK()){SOC.data=null;return;}
  if(SOC.loading||(!force&&SOC.data&&Date.now()-SOC.at<20000))return;
  SOC.loading=true;SOC.err='';
  try{SOC.data=await B.friends();SOC.at=Date.now();}catch(e){SOC.err=mapErr(e);}
  SOC.loading=false;
  if(tab==='friends'||tab==='home')render();
}
const friendRows=()=>(SOC.data&&SOC.data.friends)||[];

function socGate(){
  if(MODE!=='cloud')return `<div class="empty">${gloro('curious',88)}<span>${t('frNeedCloud')}</span></div>`;
  if(!A.user)return `<div class="empty">${gloro('wave',88)}<span>${t('frNeedAcct')}</span><button class="btn btn-purple" data-a="signinfirst" data-v="friends">${t('signin')}</button></div>`;
  return '';
}

/* friend row: only what the database function exposes (name, username, avatar, level, streak, 7-day XP) */
function friendRow(f){
  const hidden=f.show===false;
  return `<li class="fr-row"><div class="fr-av">${avatar(f.name,'md',false,f.avatar||'')}</div>
    <div class="fr-t"><b>${esc(f.name)}</b><small>${f.username?'@'+esc(f.username):''}${hidden?` ${esc(t('frPrivate'))}`:''}</small></div>
    <div class="fr-s">${hidden?'':`<span class="fr-lv">${t('level')} ${f.level}</span><span class="fr-xp">+${nfmt(f.week_xp||0)} XP</span>`}</div>
    ${SOC.rm===f.id?`<button class="sbtn pom" data-a="frrm" data-id="${esc(f.id)}">${t('frConfirm')}</button>`
      :`<button class="ico-btn" data-a="frrm" data-id="${esc(f.id)}" aria-label="${esc(t('frRemove')+': '+f.name)}">${LI('x')}</button>`}</li>`;
}

/* dashboard preview: the first three friends, or an honest empty / sign-in state */
function friendsPreview(){
  const head=`<div class="c2-h"><h2>${LI('users')}${t('yourFriends')}</h2>${socOK()?`<button class="link-s" data-a="tab" data-v="friends">${t('seeAll')}</button>`:''}</div>`;
  let body='';
  if(!socOK()){
    body=MODE!=='cloud'?`<p class="note">${t('frNeedCloud')}</p>`:`<p class="note">${t('frNeedAcct')}</p><button class="sbtn" data-a="signinfirst" data-v="friends">${t('signin')}</button>`;
  }else if(SOC.loading&&!SOC.data){body=skel(2);}
  else if(SOC.err&&!SOC.data){body=`<p class="note">${t('frErr')}</p><button class="sbtn" data-a="frreload">${t('retry')}</button>`;}
  else{
    const rows=friendRows().slice(0,3);
    body=rows.length?`<ul class="fr-list">${rows.map(f=>`<li class="fr-mini">${avatar(f.name,'md',false,f.avatar||'')}<b>${esc(f.name)}</b><small>${f.show===false?'':'+'+nfmt(f.week_xp||0)+' XP'}</small></li>`).join('')}</ul>`
      :`<p class="note">${t('frEmptyShort')}</p><button class="sbtn" data-a="tab" data-v="friends">${LI('userplus')}${t('frAdd')}</button>`;
  }
  return `<section class="c2 hm-friends">${head}${body}</section>`;
}

function friendsView(){
  const g=socGate();
  if(g)return `<h1 class="ph">${t('friends')}</h1>${g}`;
  const d=SOC.data;
  let h=`<h1 class="ph">${t('friends')}</h1>`;
  if(SOC.loading&&!d)return h+skel(3);
  if(SOC.err&&!d)return h+`<div class="empty">${gloro('confused',88)}<span>${t('frErr')}</span><button class="btn btn-purple" data-a="frreload">${t('retry')}</button></div>`;
  const code=d&&d.code?d.code:'';
  h+=`<div class="fr-grid"><section class="c2 fr-me"><h2>${LI('userplus')}${t('frAdd')}</h2>
    <p class="note">${t('frAddHelp')}</p>
    <form id="frform" class="fr-form" novalidate><label class="fld"><span class="sr">${t('frAdd')}</span><input id="frq" value="${esc(SOC.q)}" maxlength="40" autocomplete="off" autocapitalize="none" placeholder="${esc(t('frPlaceholder'))}" ${SOC.busy?'disabled':''}></label>
      <button class="btn btn-purple" type="submit" ${SOC.busy?'disabled':''}>${t('frSend')}</button></form>
    ${SOC.fb?`<div class="msg ${SOC.fb.ok?'':'err'}" role="status">${esc(SOC.fb.text)}</div>`:''}
    <div class="code-box"><div><small>${t('frMyCode')}</small><b class="code-v">${esc(code)}</b></div><button class="sbtn" data-a="frcopy" data-v="${esc(code)}" ${code?'':'disabled'}>${LI('copy')}${t('frCopy')}</button></div>
    ${d&&d.outgoing?`<p class="note">${t('frPending').replace('{n}',d.outgoing)}</p>`:''}</section>`;
  const inc=(d&&d.incoming)||[];
  if(inc.length)h+=`<section class="c2"><h2>${LI('usercheck')}${t('frRequests')} <span class="count">${inc.length}</span></h2><ul class="fr-list">${inc.map(r=>`<li class="fr-row">${avatar(r.name,'md',false,r.avatar||'')}<div class="fr-t"><b>${esc(r.name)}</b><small>${r.username?'@'+esc(r.username):''}</small></div>
      <div class="fr-acts"><button class="sbtn good" data-a="fracc" data-id="${esc(r.id)}" ${SOC.busy?'disabled':''}>${LI('check')}${t('frAccept')}</button><button class="ico-btn" data-a="frdec" data-id="${esc(r.id)}" aria-label="${esc(t('frDecline'))}" ${SOC.busy?'disabled':''}>${LI('x')}</button></div></li>`).join('')}</ul></section>`;
  const rows=friendRows();
  h+=`<section class="c2 fr-all"><h2>${LI('users')}${t('yourFriends')} <span class="count">${rows.length}</span></h2>${rows.length?`<ul class="fr-list">${rows.map(friendRow).join('')}</ul>`
    :`<div class="empty sm">${gloro('curious',80)}<span>${t('frEmpty')}</span></div>`}</section></div>`;
  h+=challengesCard()+leagueCard()+(lbPreview()||'');
  return h;
}

