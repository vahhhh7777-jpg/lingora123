/* =====================================================================================================
   LINGORA 6.0: review is part of ordinary lessons (there is no separate Review section any more).
   This engine only SELECTS what to mix into a lesson (mixReview) and summarises it afterwards (dcReinforced).
   Earlier description: smart repetition. Everything here is computed from the learner's REAL history (S.done, S.srs, S.miss), never invented.
   items  = words the learner has met + grammar / sentence questions from lessons they completed
   class  = difficult (repeated mistakes, low box) > forgotten (overdue a week+ / idle 2 weeks+) > due (interval reached) > new (met, never reviewed) > strong (not due)
   a session = the highest scored items, at most 40% question items, shown as ordinary practice steps; every answer moves the SRS box (1, 2, 4, 8, 16 days)
   ===================================================================================================== */
const RV_N=10,RV_GOAL=10,RV_QT={mc:1,tf:1,fill:1,fix:1,order:1,type:1,read:1};
function rvQKey(q){
  const d=q.data||{};
  if(q.type==='tf')return d.statement||d.prompt||null;
  if(q.type==='order')return d.sentence||d.answer||null;
  return d.answer||null;
}
function rvClassify(it){
  const e=it.e,T=today(),miss=it.miss,b=e?(e.b||0):0;
  it.box=b;
  it.due=e?e.d<=T:miss>0;
  it.overdue=e&&it.due?Math.max(0,dayDiff(e.d,T)):0;
  it.idle=e&&e.t?Math.floor((Date.now()-e.t)/864e5):null;
  const hard=(miss>=2&&b<=3)||(miss>=1&&b<=1);
  const forgot=!!e&&it.due&&(it.overdue>=7||(it.idle!=null&&it.idle>=14));
  it.why=hard?'hard':forgot?'forgot':it.due?(e?'due':'hard'):(!e?'new':'strong');
  if(it.why==='hard'&&!e&&miss<1)it.why='new';
  const base={hard:50+miss*5,forgot:35+Math.min(it.overdue,30),due:20+Math.min(it.overdue,14)*1.5,new:12,strong:0}[it.why];
  it.score=base+(it.why==='new'||it.why==='strong'?0:(5-b)*2)+(it.why==='strong'?(5-b):0);
  return it;
}
function rvItems(skipId){
  const out=[],seen=new Set(),srs=S.srs||{},miss=S.miss||{};
  const {met}=pxWords();
  met.forEach(w=>{
    const k=wordKey(w);if(seen.has(k))return;seen.add(k);seen.add(w.hy);
    const m=(miss[w.en]||0)+(w.hy!==w.en?(miss[w.hy]||0):0);
    out.push(rvClassify({kind:'word',key:k,w,e:srs[k]||srs[w.hy],miss:m}));
  });
  FLAT.forEach(f=>{
    if(!S.done[f.id]||f.id===skipId)return;
    (QBY[f.id]||[]).forEach(q=>{
      if(!RV_QT[q.type])return;
      const k=rvQKey(q);if(!k||seen.has(k))return;seen.add(k);
      out.push(rvClassify({kind:'q',key:k,q,e:srs[k],miss:miss[k]||0}));
    });
  });
  return out;
}
function rvCounts(items){
  items=items||rvItems();
  const c={hard:0,forgot:0,due:0,new:0,strong:0,total:items.length,learned:items.length};
  items.forEach(i=>{c[i.why]++;});
  c.todo=c.hard+c.forgot+c.due+c.new;
  c.urgent=c.hard+c.forgot+c.due;
  return c;
}
const rvHasHistory=()=>FLAT.some(f=>S.done[f.id])||Object.keys(S.srs||{}).length>0||Object.keys(S.miss||{}).length>0;
function rvRec(){
  const r=S.rv&&typeof S.rv==='object'?S.rv:(S.rv={d:'',n:0,ok:0,t:0,o:0,last:null});
  if(r.d!==today()){r.d=today();r.n=0;r.ok=0;}
  return r;
}
function rvPlan(n,extra,items){
  const all=items||rvItems(),T=all.filter(i=>i.why!=='strong').sort((a,b)=>b.score-a.score);
  let pool=T;
  if(extra||!pool.length)pool=T.concat(all.filter(i=>i.why==='strong').sort((a,b)=>a.box-b.box||(a.e&&b.e?a.e.t-b.e.t:0)));
  const maxQ=Math.floor(n*.4),pk=[];let q=0;
  for(const it of pool){if(pk.length>=n)break;if(it.kind==='q'){if(q>=maxQ)continue;q++;}pk.push(it);}
  for(const it of pool){if(pk.length>=n)break;if(pk.indexOf(it)<0)pk.push(it);}
  return pk;
}
function rvWordStep(it,i,all){
  const w=it.w,hyFirst=(it.box+i)%2===1;
  const others=shuffle(all.filter(x=>x.en!==w.en));
  let st=null;
  if(it.box>=3&&!/\s/.test(w.en.trim())&&w.en.length>2){
    st=toStep({id:'rv-w-'+i,type:'type',data:{prompt:w.hy,answer:w.en,explanation:w.en+' = '+w.hy}});
  }else{
    const ans=hyFirst?w.en:w.hy,opts=others.slice(0,3).map(x=>hyFirst?x.en:x.hy).filter((x,j,a)=>x&&x!==ans&&a.indexOf(x)===j);
    if(opts.length>=1)st=toStep({id:'rv-w-'+i,type:'mc',data:{prompt:hyFirst?w.hy:w.en,options:opts,answer:ans,speak:hyFirst?null:w.en,explanation:w.en+' = '+w.hy}});
  }
  if(!st)return null;
  st.key=it.key;st.loc=true;st.rvLabel=w.en+' = '+w.hy;st.rvItem=it;
  return st;
}
function rvBuild(items){
  const {all}=pxWords(),steps=[];
  items.forEach((it,i)=>{
    let s=null;
    if(it.kind==='word')s=rvWordStep(it,i,all);
    else{s=toStep(it.q);if(s){s.key=it.key;s.rvLabel=s.prompt||s.sent||s.ans||it.key;s.rvItem=it;}}
    if(s)steps.push(s);
  });
  return steps;
}
/* ---- review inside lessons ----
   A lesson gets 2-4 extra steps taken from material the learner already finished (words met, questions of completed lessons),
   chosen by priority: difficult > forgotten > due > new > strong. They are judged locally (never sent to the server as answers of
   this lesson), never cost hearts, never change the lesson's stars, but they do move the spaced-repetition box of each item. */
const RV_MIX_MAX=4;
function rvMixCount(baseLen,pool){return Math.max(0,Math.min(RV_MIX_MAX,Math.floor(baseLen/3),pool));}
function mixReview(steps,f){
  try{
    if(!f||!steps.length)return steps;
    const own=new Set();
    steps.forEach(s=>{[s.key,s.en,s.hy,s.ans].forEach(x=>{if(x&&typeof x==='string')own.add(x);});});
    (QBY[f.id]||[]).forEach(q=>{const k=rvQKey(q);if(k)own.add(k);});
    const items=rvItems(f.id).filter(i=>!own.has(i.key)&&!(i.kind==='word'&&(own.has(i.w.en)||own.has(i.w.hy))));
    const core=steps.filter(s=>s.k!=='intro').length,n=rvMixCount(core,items.length);
    if(!n)return steps;
    const add=rvBuild(rvPlan(n,true,items));
    if(!add.length)return steps;
    const out=steps.slice(),lead=steps.length-core;
    add.forEach((s,j)=>{
      s.review=true;s.loc=true;
      const pos=Math.min(out.length,lead+Math.round((j+1)*core/(add.length+1))+j);
      out.splice(pos,0,s);
    });
    return out;
  }catch(e){try{console.warn('review mix skipped',e);}catch(_){}return steps;}
}
/* an answer to a mixed-in step: spaced-repetition box moves, the lesson's own accuracy / hearts / stars are untouched */
function rvSettle(s,ok){
  const R=L.rvm||(L.rvm={log:[],seen:{}});
  if(!R.seen[s.id]){R.seen[s.id]=1;R.log.push({id:s.id,key:s.key,ok:!!ok,label:s.rvLabel||s.key||'',why:s.rvItem?s.rvItem.why:'',kind:s.rvItem?s.rvItem.kind:''});}
  if(!L.preview&&s.key){
    srsMark(s.key,ok);
    if(!ok){S.miss[s.key]=(S.miss[s.key]||0)+1;}
    save();
  }
}
function rvMixDone(l){
  if(!l||!l.rvm||!l.rvm.log.length)return;
  const lg=l.rvm.log,r=rvRec(),n=lg.length,ok=lg.filter(x=>x.ok).length;
  r.n+=n;r.ok+=ok;r.t=(r.t||0)+n;r.o=(r.o||0)+ok;r.last={t:Date.now(),n,ok};
}
const rvWhen=k=>{const e=(S.srs||{})[k];if(!e)return '';const d=dayDiff(today(),e.d);return d<=0?pt('rvToday'):d===1?pt('rvTomorrow'):pt('rvInDays',{n:d});};
function dcReinforced(){
  const R=L&&L.rvm;if(!R||!R.log.length||L.preview)return '';
  const lg=R.log,n=lg.length,ok=lg.filter(x=>x.ok).length,bad=lg.filter(x=>!x.ok);
  const row=(x,cls)=>`<li class="rv-it ${cls}"><b lang="${tl()}">${esc(x.label)}</b><small>${esc(rvWhen(x.key))}</small></li>`;
  return `<section class="dc-card rm-sum" aria-label="${esc(pt('rmT'))}"><h2>${LI('repeat')} ${esc(pt('rmT'))}</h2>
   <p class="note">${esc(pt('rmB',{ok,n}))}</p>
   <ul class="rv-list">${lg.map(x=>row(x,x.ok?'ok':'bad')).join('')}</ul>
   ${bad.length?`<p class="note">${esc(pt('rvSumAgain'))}</p>`:''}</section>`;
}
/* flashcards for the words of the lesson just finished plus whatever is due: reachable from the completion screen and from Learn */
const rvCardsDue=()=>{try{return pxDueCards().length;}catch(e){return 0;}};
function dcCardsCta(){
  if(!L||L.preview||L.err)return '';
  const n=rvCardsDue();if(!n)return '';
  return `<section class="dc-card dc-cards" aria-label="${esc(pt('cards'))}"><button class="btn btn-ghost" data-a="dcCards">${LI('repeat')} ${esc(pt('cards'))} · ${esc(pt('dueN',{n}))}</button></section>`;
}

Object.assign(PXS.hy,{
 rv_hard:'դժվար',rv_forgot:'մոռացված',rv_due:'հերթը եկել է',rv_new:'նոր',rv_strong:'ամուր',
 rvSumRev:'կրկնվեց',rvSumAcc:'ճշտություն',
 rmT:'Կրկնվեց նախորդ դասերից',rmB:'Նախորդ դասերի նյութից {ok}/{n} ճիշտ։ Սա չի ազդում դասի աստղերի վրա։',rmTag:'Կրկնություն',
 rvSumAgain:'Սրանք նորից կհայտնվեն հաջորդ դասերում։',rvToday:'նորից՝ այսօր',rvTomorrow:'նորից՝ վաղը',rvInDays:'նորից՝ {n} օրից'});
Object.assign(PXS.en,{
 rv_hard:'difficult',rv_forgot:'forgotten',rv_due:'due',rv_new:'new',rv_strong:'strong',
 rvSumRev:'reviewed',rvSumAcc:'accuracy',
 rmT:'Reinforced from earlier lessons',rmB:'{ok}/{n} correct from earlier lessons. This does not affect this lesson\'s stars.',rmTag:'Review',
 rvSumAgain:'These will come back in your next lessons.',rvToday:'again today',rvTomorrow:'again tomorrow',rvInDays:'again in {n} days'});
