/* ---------- admin-written content: announcements, banners, notifications, mascot messages ---------- */
let CONTENT=[];
const liveC=c=>c.active!==false&&(!c.starts_at||new Date(c.starts_at)<=new Date())&&(!c.ends_at||new Date(c.ends_at)>new Date());
const msgCache={};
const rnd=a=>a[Math.floor(Math.random()*a.length)];
/* What the mascot says in a situation. Messages written in Admin > Mascot replace the built-in ones for that situation. */
function mmsg(ctx,fresh){
  const custom=CONTENT.filter(c=>c.kind==='mascot'&&c.context===ctx&&liveC(c)).map(c=>tx(c.body)).filter(Boolean);
  const d=t('m_'+ctx),pool=custom.length?custom:(Array.isArray(d)?d:d?[d]:['']);
  const fill=x=>x.replace(/\{name\}/g,displayName()).replace(/\{streak\}/g,String(streakNow())).replace(/\{why\}/g,S.why?t('why_'+S.why):'');
  if(!fresh&&msgCache[ctx]&&pool.indexOf(msgCache[ctx])>=0)return fill(msgCache[ctx]);
  return fill(msgCache[ctx]=rnd(pool));
}

