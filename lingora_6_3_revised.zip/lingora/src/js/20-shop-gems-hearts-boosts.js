/* ---------- shop (gems, hearts, boosts) ----------
   Cloud mode: items come from public.shop_items and every purchase goes through the buy_item / refill_hearts
   RPCs (server checks balance, caps and idempotency). Local/demo mode has no gems, so the shop explains that. */
Object.assign(UI.hy,{shop:'Խանութ',gems:'Lingora կոպեկ',hearts:'Սրտեր',shopT:'Խանութ',shopSub:'Ծախսիր Lingora կոպեկդ սրտերի, շարքի պաշտպանության և XP-ի ուժեղացման վրա։',shopBal:'Քո Lingora կոպեկը',shopHearts:'Սրտեր',shopFull:'Արդեն լիքն է',shopBuy:'Գնել',shopNeed:'Չի բավականացնում',shopLoad:'Բեռնվում է…',shopErr:'Չհաջողվեց բեռնել խանութը։ Փորձիր նորից։',shopLocal:'Lingora կոպեկն ու խանութը աշխատում են հաշվի հետ։ Մուտք գործիր, որ վաստակես Lingora կոպեկ և գնես իրեր։',shopDone:'Գնումը կատարվեց։',shopDup:'Այս գնումը արդեն կատարվել է։',shopFail:'Գնումը չհաջողվեց։',shopUnl:'Անսահմանափակ սրտեր',shopNext:'Հաջորդ սիրտը՝ ',shopEarn:'Lingora կոպեկը ստանում են VIP անդամները կամ կարելի է գնել փաթեթով։',e_not_enough_gems:'Lingora կոպեկը չի բավականացնում։',e_already_full:'Արդեն լիքն է։',e_not_found:'Իրը չի գտնվել։'});
Object.assign(UI.en,{shop:'Shop',gems:'Lingora Coins',hearts:'Hearts',shopT:'Shop',shopSub:'Spend your Lingora Coins on hearts, streak protection and XP boosts.',shopBal:'Your Lingora Coins',shopHearts:'Hearts',shopFull:'Already full',shopBuy:'Buy',shopNeed:'Not enough Lingora Coins',shopLoad:'Loading…',shopErr:'Could not load the shop. Try again.',shopLocal:'Lingora Coins and the shop work with an account. Sign in to earn Lingora Coins and buy items.',shopDone:'Purchase complete.',shopDup:'That purchase was already made.',shopFail:'The purchase failed.',shopUnl:'Unlimited hearts',shopNext:'Next heart in ',shopEarn:'Lingora Coins are for VIP members, or you can buy a pack.',e_not_enough_gems:'Not enough Lingora Coins.',e_already_full:'Already full.',e_not_found:'Item not found.'});
const SB=()=>B;
Object.assign(UI.hy,{gGet:'Ստանալ Lingora կոպեկ',gVipT:'VIP բոնուս',gVipD:'VIP անդամները ամեն օր ստանում են Lingora կոպեկ և վաստակում են այն դասերից։',gClaim:'Վերցնել օրվա բոնուսը',gClaimed:'Այսօրվա բոնուսը վերցված է',gClaimOk:'Բոնուսը ավելացվեց։',gPacks:'Գնել փաթեթ',gOnly:'Lingora կոպեկը ստանում են VIP անդամները կամ կարելի է գնել փաթեթով։',gBecome:'Դառնալ VIP',gBuyHow:'Ինչպես գնել',gPackLine:'{n} Lingora կոպեկ',e_vip_only:'Սա միայն VIP-ների համար է։',gGrant:'Lingora կոպեկ',gGrantOk:'Lingora կոպեկը ավելացվեց։'});
Object.assign(UI.en,{gGet:'Get Lingora Coins',gVipT:'VIP bonus',gVipD:'VIP members get Lingora Coins every day and earn them from lessons.',gClaim:'Claim daily bonus',gClaimed:'Today\'s bonus claimed',gClaimOk:'Bonus added.',gPacks:'Buy a pack',gOnly:'Lingora Coins are for VIP members, or you can buy a pack.',gBecome:'Become VIP',gBuyHow:'How to buy',gPackLine:'{n} Lingora Coins',e_vip_only:'This is for VIP members only.',gGrant:'Lingora Coins',gGrantOk:'Lingora Coins added.'});
Object.assign(UI.hy,{fPicItems:'Նկարներ',picItemsNote:'Առաջինը ճիշտ պատասխանն է։ Յուրաքանչյուրի համար՝ բառը ուսումնասիրվող լեզվով (հնչում է), հայերեն ստորագրությունը և emoji կամ վերբեռնած նկար։',picCorrect:'1 · Ճիշտը',picW:'Բառը (հնչում է)',picL:'Ստորագրություն (հայերեն)',picE:'Emoji',picImg:'Կամ նկար',picGen:'Ստեղծել նկարով վարժություններ բառերից',picGenNote:'Վերցնում է դասի բառերը, որոնք ունեն emoji կամ նկար, և յուրաքանչյուրի համար կառուցում նկարով ընտրություն (3 այլ բառ՝ շեղող)։',picGenNeed:'Պետք է առնվազն 3 բառ emoji-ով կամ նկարով։',picGenOk:'Ստեղծվեց {n} վարժություն։'});
Object.assign(UI.en,{fPicItems:'Pictures',picItemsNote:'The first one is the correct answer. For each: the word in the language being learned (spoken), its Armenian caption, and an emoji or an uploaded picture.',picCorrect:'1 · Correct',picW:'Word (spoken)',picL:'Caption (Armenian)',picE:'Emoji',picImg:'Or picture',picGen:'Generate picture exercises from the words',picGenNote:'Takes the lesson words that have an emoji or a picture and builds a picture-choice exercise for each (3 other words as distractors).',picGenNeed:'You need at least 3 words with an emoji or picture.',picGenOk:'{n} exercises created.'});
Object.assign(UI.hy,{unitWord:'ԹԵՄԱ',pathHi:'Բարև։ Սկսենք։',pathRev:'Կրկնելը հիշողությունն է։',pathThink:'Մտածիր, դու կարող ես։',pathGo:'Արդեն լավ է գնում։',pathYou:'Շարունակիր շարքդ։'});
Object.assign(UI.en,{unitWord:'UNIT',pathHi:'Hi! Let\'s start.',pathRev:'Repeating builds memory.',pathThink:'Think it through.',pathGo:'You\'re doing great.',pathYou:'Keep your streak going.'});
Object.assign(UI.hy,{animT:'Շարժանկարներ'});Object.assign(UI.en,{animT:'Animations'});
Object.assign(UI.hy,{shCatItems:'Իրեր',shCatRooms:'Սենյակներ',shCatCostumes:'Հագուստ',shOwned:'Քոնն է',shVipOnly:'Միայն VIP',shWorld:'Բացել Lingora աշխարհը',shEquipHint:'Գնածդ կարող ես հագցնել կամ դասավորել աշխարհում։',e_not_owned:'Այս իրը քոնը չէ։',e_already_owned:'Արդեն ունես։'});
Object.assign(UI.en,{shCatItems:'Items',shCatRooms:'Rooms',shCatCostumes:'Costumes',shOwned:'Owned',shVipOnly:'VIP only',shWorld:'Open Lingora World',shEquipHint:'Wear what you buy or place it in your world.',e_not_owned:'You do not own this item.',e_already_owned:'You already own this.'});
let SHOP={items:null,lessons:null,loading:false,err:false,busy:'',cat:'item',sec:'lessons',ask:null};
const SHOP_CATS=[['item','shCatItems'],['room','shCatRooms'],['costume','shCatCostumes']];
const itemTitle=it=>(it.title||{})[S.lang]||(it.title||{}).en||it.id;
const heartsNow=()=>{const s=A&&A.srv;return s&&typeof s.hearts==='number'?s.hearts:5;};
const heartsMax=()=>{const s=A&&A.srv;return s&&s.hearts_max?s.hearts_max:5;};
const newIdem=()=>{try{return (crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random().toString(36).slice(2))}catch(e){return String(Date.now())+Math.random().toString(36).slice(2);}};
async function loadShop(){
  if(SHOP.loading||!ECON())return;
  SHOP.loading=true;SHOP.err=false;
  try{const r=await Promise.all([SB().shopItems(),SB().shopLessons()]);SHOP.items=r[0];SHOP.lessons=r[1]||[];}catch(e){console.warn('shop load failed: '+(e&&(e.message||e.code)||e));SHOP.err=true;
    /* right after a page load the backend may not be connected yet: retry quietly a few times before showing the error */
    if(e&&e.code==='net'&&(SHOP.tries=(SHOP.tries||0)+1)<=4){SHOP.err=false;setTimeout(()=>{SHOP.loading=false;loadShop();},1500);return;}}
  SHOP.loading=false;if(!SHOP.err)SHOP.tries=0;if(tab==='shop')render();
}
/* every purchase asks first; the idempotency key is made when the question opens, so a double tap on "Confirm" can never pay twice */
function shopAsk(kind,id){
  if(SHOP.busy||!ECON())return;
  SHOP.ask={kind,id,idem:newIdem()};render();
  setTimeout(()=>{const b=document.getElementById('shopyes');if(b)b.focus();},30);
}
function shopCancel(){SHOP.ask=null;render();}
async function shopConfirm(){
  const q=SHOP.ask;if(!q||SHOP.busy||!ECON())return;
  SHOP.busy=q.id;render();
  try{
    let r;
    if(q.kind==='lesson'){
      r=await SB().unlockLesson(q.id,q.idem);
      if(r&&r.state)applyState(r.state);
      try{await refreshCatalog();}catch(e){console.warn('catalog refresh after unlock failed',e);}
      const l=(SHOP.lessons||[]).find(x=>x.id===q.id);if(l)l.owned=true;
      SHOP.done={lesson:q.id};
    }else{
      r=await SB().buyItem(q.id,q.idem);
      if(r&&r.state)applyState(r.state);
      const it=(SHOP.items||[]).find(x=>x.id===q.id);
      if(it&&it.kind==='cosmetic'&&typeof worldRefresh==='function')await worldRefresh();
    }
    save();toast(r&&r.duplicate?t('shopDup'):t('shopDone'),'celebrating');
  }catch(e){console.warn('purchase failed',e);toast((e&&e.code&&t('e_'+e.code))||t('shopFail'),'confused');}
  SHOP.busy='';SHOP.ask=null;render();
}
const buyShop=id=>shopAsk('item',id);
function openUnlocked(id){
  const i=FLAT.findIndex(f=>f.id===id);
  SHOP.done=null;
  if(i>=0){startLesson(i);}else{tab='learn';wantScroll=true;render();}
}
function shopPreview(it){
  const p=it.payload||{};
  if(it.category==='room'&&p.sky)return `<span class="shop-ic shop-room" style="background:linear-gradient(${esc(p.sky[0])},${esc(p.sky[1])})" aria-hidden="true"><i style="background:${esc(p.floor||'#ccc')}"></i></span>`;
  if(p.emoji)return `<span class="shop-ic shop-emoji" aria-hidden="true">${esc(p.emoji)}</span>`;
  return `<span class="shop-ic" aria-hidden="true">${IC[it.icon]||IC.gem}</span>`;
}
function shopCard(it){
  const price=it.price_gems,have=S.gems||0,s=A.srv||{},cos=it.kind==='cosmetic';
  const owned=cos&&(price===0&&it.category==='room'||(W4.inv||[]).indexOf(it.id)>=0);
  const needVip=!!it.vip_only&&!isVip();
  const full=(it.kind==='heart_refill'&&!s.unlimited&&heartsNow()>=heartsMax())||(it.kind==='streak_freeze'&&(S.freeze||0)>=2)||owned;
  const poor=have<price;
  const lab=owned?t('shOwned'):needVip?t('shVipOnly'):full?t('shopFull'):poor?t('shopNeed'):t('shopBuy');
  return `<article class="shop-item shop-${esc(it.kind)} ${owned?'owned':''}">${shopPreview(it)}<div class="shop-tx"><h3>${esc(itemTitle(it))}${it.vip_only?` <span class="vipbadge">${IC.crown}VIP</span>`:''}</h3><p>${esc((it.descr||{})[S.lang]||(it.descr||{}).en||'')}</p></div><button class="btn shop-buy" data-a="buy" data-v="${esc(it.id)}" ${full||poor||needVip||SHOP.busy?'disabled':''}>${SHOP.busy===it.id?'…':`${lab}${full||poor||needVip?'':` <span class="px">${IC.gem}${price}</span>`}`}</button></article>`;
}
async function claimGems(){
  if(SHOP.busy||!ECON())return;
  SHOP.busy='claim';render();
  try{
    const r=await SB().claimVipGems();
    if(r&&r.state)applyState(r.state);
    S.vipClaim=today();save();
    toast(r&&r.claimed?t('gClaimOk'):t('gClaimed'),'celebrating');
  }catch(e){toast((e&&e.code&&t('e_'+e.code))||t('shopFail'),'confused');}
  SHOP.busy='';render();
}
function gemsCard(){
  const vip=ECON()&&isVip(),packs=(CFG.GEM_PACKS||[]),txt=(CFG.GEM_TEXT&&(CFG.GEM_TEXT[S.lang]||CFG.GEM_TEXT.hy))||'';
  const claimed=S.vipClaim===today();
  const packRows=packs.map(p=>`<div class="gpack">${IC.gem}<b>${t('gPackLine').replace('{n}',esc(p.gems))}</b><span>${esc(p.price)}</span></div>`).join('');
  const link=CFG.CONTACT_URL?`<a class="btn btn-purple" href="${esc(CFG.CONTACT_URL)}" target="_blank" rel="noopener">${esc(CFG.CONTACT_LABEL||'Contact')}</a>`:'';
  let h=`<section class="card gems-card"><h2>${t('gGet')}</h2>`;
  if(vip)h+=`<div class="gvip"><div><b>${t('gVipT')}</b><p class="note">${t('gVipD')}</p></div><button class="btn btn-purple" data-a="claimgems" ${claimed||SHOP.busy?'disabled':''}>${SHOP.busy==='claim'?'…':claimed?t('gClaimed'):t('gClaim')}</button></div>`;
  else h+=`<p class="note">${t('gOnly')}</p>`;
  if(packs.length)h+=`<h3>${t('gPacks')}</h3><div class="gpacks">${packRows}</div><p class="note">${esc(txt)}</p>${link}`;
  if(!vip)h+=`<h3>${t('gBecome')}</h3>${vipHowHtml()}`;
  return h+'</section>';
}
function lessonCard(l){
  const have=S.gems||0,price=l.price,poor=have<price,own=!!l.owned,vip=isVip();
  const ttl=tx(l.title)||l.id,unit=tx(l.unit)||'';
  const cls=own?'own':vip?'vip':poor?'poor':'ok';
  let btn;
  if(own)btn=`<button class="btn btn-purple shop-buy" data-a="openles" data-v="${esc(l.id)}">${esc(t('shStart'))}</button>`;
  else if(vip)btn=`<span class="shop-st">${LI('crown')}${esc(t('shVipHas'))}</span>`;
  else btn=`<button class="btn ${poor?'btn-ghost':'btn-orange'} shop-buy" data-a="unlock" data-v="${esc(l.id)}" ${poor||SHOP.busy?'disabled':''} aria-label="${esc(t('shUnlock')+': '+ttl+' — '+price)}">${SHOP.busy===l.id?'…':`${esc(t('shUnlock'))} <span class="px">${IC.gem}${price}</span>`}</button>`;
  return `<article class="shop-item shop-lesson ${cls}"><span class="shop-ic" aria-hidden="true">${own?LI('check'):LI('lock')}</span>
   <div class="shop-tx"><h3>${esc(ttl)}</h3><p>${esc(unit)}${unit?' · ':''}${esc(t('shLesInfo').replace('{q}',l.questions||0).replace('{x}',l.xp||0))}</p>
   <span class="shop-state ${own?'on':''}">${own?LI('check')+esc(t('shOwned')):LI('lock')+esc(t('shLocked'))}${!own&&!vip&&poor?' · '+esc(t('shNeedMore').replace('{n}',price-have)):''}</span></div>${btn}</article>`;
}
function shopAskSheet(){
  const q=SHOP.ask;if(!q)return '';
  let name='',price=0;
  if(q.kind==='lesson'){const l=(SHOP.lessons||[]).find(x=>x.id===q.id);if(!l)return '';name=tx(l.title)||l.id;price=l.price;}
  else{const it=(SHOP.items||[]).find(x=>x.id===q.id);if(!it)return '';name=itemTitle(it);price=it.price_gems;}
  const have=S.gems||0;
  return `<div class="p2-scrim" data-a="shopno"><div class="p2-sheet" role="dialog" aria-modal="true" aria-labelledby="shq-t" data-a="noop">
   <h2 id="shq-t">${esc(t('shAskT'))}</h2><p class="shq-n">${esc(name)}</p>
   <div class="shq-rows"><div><span>${esc(t('shPrice'))}</span><b>${IC.gem}${price}</b></div><div><span>${esc(t('shBalance'))}</span><b>${IC.gem}${have}</b></div><div><span>${esc(t('shAfter'))}</span><b>${IC.gem}${Math.max(0,have-price)}</b></div></div>
   <div class="shq-acts"><button class="btn btn-ghost" data-a="shopno">${esc(t('st_cancel'))}</button><button id="shopyes" class="btn btn-orange" data-a="shopyes" ${SHOP.busy?'disabled aria-busy="true"':''}>${esc(t('shConfirm'))}</button></div></div></div>`;
}
function shopView(){
  const head=`<h1 class="ph">${t('shopT')}</h1>`;
  if(!ECON())return `${head}<section class="p2-card shop-bal-card"><div class="shop-bal">${IC.gem}<b>${S.gems||0}</b><span>${t('shopBal')}</span></div><p class="note">${t('shopLocal')}</p></section>${gemsCard()}`;
  if(SHOP.items===null&&!SHOP.loading&&!SHOP.err)setTimeout(loadShop,0);
  const s=A.srv||{};
  const bal=`<section class="p2-card shop-bal-card"><div class="shop-bal main">${IC.gem}<b>${nfmt(S.gems||0)}</b><span>${t('shopBal')}</span></div>
    <div class="shop-bal hr">${IC.heart}<b>${s.unlimited?'∞':heartsNow()+'/'+heartsMax()}</b><span>${s.unlimited?t('shopUnl'):t('shopHearts')}</span></div></section>
    <details class="p2-how shop-earn"><summary>${esc(t('shEarnT'))}</summary><ul>${t('shEarn').map(x=>`<li>${esc(x)}</li>`).join('')}</ul></details>`;
  const tabs=`<div class="seg tabs shop-tabs" role="tablist" aria-label="${esc(t('shopT'))}">${[['lessons','shTabLessons'],['items','shTabItems']].map(x=>`<button role="tab" type="button" aria-selected="${SHOP.sec===x[0]}" aria-pressed="${SHOP.sec===x[0]}" data-a="shopsec" data-v="${x[0]}">${esc(t(x[1]))}</button>`).join('')}</div>`;
  let body;
  if(SHOP.err)body=`<div class="empty"><span>${t('shopErr')}</span><button class="btn btn-ghost" data-a="shopretry">${t('retry')}</button></div>`;
  else if(SHOP.items===null)body=`<div class="empty" role="status"><span>${t('shopLoad')}</span></div>${skel(2)}`;
  else if(SHOP.sec==='lessons'){
    const ls=SHOP.lessons||[];
    body=ls.length?`<p class="note">${esc(isVip()?t('shVipAll'):t('shLesNote'))}</p><div class="shop-list">${ls.map(lessonCard).join('')}</div>`
      :`<div class="empty">${gloro('curious',72)}<span>${esc(t('shNoLessons'))}</span><button type="button" class="btn btn-purple" data-a="tab" data-v="learn">${esc(t('contLearn'))}</button></div>`;
  }else{
    const cats=`<div class="chips shop-cats" role="tablist" aria-label="${esc(t('shTabItems'))}">${SHOP_CATS.map(c=>`<button role="tab" type="button" class="chip ${SHOP.cat===c[0]?'on':''}" aria-selected="${SHOP.cat===c[0]}" data-a="shopcat" data-v="${c[0]}">${esc(t(c[1]))}</button>`).join('')}</div>`;
    body=`${cats}<div class="shop-list">${SHOP.items.filter(x=>(x.category||'item')===SHOP.cat).map(shopCard).join('')}</div><button class="btn btn-ghost shop-world" data-a="tab" data-v="world">${LI('map')}${esc(t('shWorld'))}</button><p class="note">${esc(t('shEquipHint'))}</p>`;
  }
  return `${head}${bal}${tabs}${body}<details class="p2-how shop-more"${typeof payOnline==="function"&&payOnline()&&!isVip()?" open":""}><summary>${esc(t('gGet'))}</summary>${gemsCard()}</details>${shopAskSheet()}`;
}
Object.assign(UI.hy,{shTabLessons:'VIP դասեր',shTabItems:'Խթաններ և իրեր',shUnlock:'Բացել',shStart:'Սկսել դասը',shOwned:'Բացված է',shLocked:'Փակ է',shNeedMore:'պակասում է {n}',shVipHas:'Ներառված է VIP-ում',
 shLesInfo:'{q} հարց · {x} XP',shLesNote:'Այս դասերը VIP են։ Կարող ես որևէ մեկը բացել հավերժ՝ Lingora կոպեկով, առանց VIP-ի։',shVipAll:'VIP անդամդ բոլոր այս դասերը արդեն բաց է։',shNoLessons:'Առայժմ կոպեկով բացվող դասեր չկան։ Սովորիր շարունակ, նորերը կհայտնվեն։',
 shAskT:'Հաստատե՞լ գնումը',shPrice:'Գին',shBalance:'Քո մնացորդը',shAfter:'Գնումից հետո',shConfirm:'Հաստատել',
 shEarnT:'Ինչպես վաստակել կոպեկ',shEarn:['Դասի առաջին ավարտը (կրկնությունը կոպեկ չի տալիս)','Օրական նպատակի կատարումը՝ օրական մեկ անգամ','Շարքի հանգրվանները՝ 3, 7, 14 և այլ օրեր','Օրվա առաջադրանքները և ձեռքբերումները','Կրկնության սեանսները՝ սահմանափակ քանակով օրական'],
 e_not_unlockable:'Այս դասը չի կարելի գնել առանձին։',e_already_vip:'VIP անդամդ արդեն ունի այս դասերը։'});
Object.assign(UI.en,{shTabLessons:'VIP lessons',shTabItems:'Boosts & items',shUnlock:'Unlock',shStart:'Start lesson',shOwned:'Unlocked',shLocked:'Locked',shNeedMore:'{n} more needed',shVipHas:'Included with VIP',
 shLesInfo:'{q} questions · {x} XP',shLesNote:'These lessons are VIP. You can unlock any of them for good with Lingora Coins, without VIP.',shVipAll:'Your VIP membership already includes all of these lessons.',shNoLessons:'No lessons can be unlocked with coins yet. Keep learning, new ones will appear.',
 shAskT:'Confirm purchase?',shPrice:'Price',shBalance:'Your balance',shAfter:'After purchase',shConfirm:'Confirm',
 shEarnT:'How to earn coins',shEarn:['Finishing a lesson for the first time (replays pay nothing)','Reaching your daily goal, once a day','Streak milestones: 3, 7, 14 days and more','Daily challenges and achievements','Review sessions, up to a small daily limit'],
 e_not_unlockable:'This lesson cannot be bought on its own.',e_already_vip:'Your VIP membership already includes these lessons.'});
