/* ---------- mistake book: what the learner got wrong, what is due again, practise it ---------- */
Object.assign(UI.hy,{pt_mist:'Սխալներ',mbTitle:'Սխալների գիրք',mbEmpty:'Դեռ սխալներ չկան։ Շարունակիր սովորել, և սխալները կհայտնվեն այստեղ՝ կրկնելու համար։',mbDue:'Կրկնելու ժամանակն է',mbMastered:'Յուրացված',mbBox:'Մակարդակ',mbWrong:'սխալ',mbPractice:'Կրկնել սխալները',mbLoad:'Բեռնվում է…',mbFail:'Չհաջողվեց բեռնել։',mbRetry:'Փորձել նորից',mbNext:'Հաջորդ կրկնություն'});
Object.assign(UI.en,{pt_mist:'Mistakes',mbTitle:'Mistake book',mbEmpty:'No mistakes yet. Keep learning and anything you get wrong will appear here to review.',mbDue:'Due now',mbMastered:'Mastered',mbBox:'Box',mbWrong:'wrong',mbPractice:'Practise mistakes',mbLoad:'Loading…',mbFail:'Could not load.',mbRetry:'Try again',mbNext:'Next review'});
const MB={rows:null,busy:false,err:false};
function mbLoad(force){
  if(MB.busy||(MB.rows&&!force))return;
  if(!ECON()){MB.rows=mbLocal();return;}
  MB.busy=true;MB.err=false;
  B.myMistakes(100).then(r=>{MB.rows=r||[];MB.busy=false;if(tab==='me'&&ptab==='mist')render();}).catch(()=>{MB.busy=false;MB.err=true;MB.rows=[];if(tab==='me'&&ptab==='mist')render();});
}
/* demo / local: derived from what this device recorded */
function mbLocal(){
  const rows=[];
  FLAT.forEach(f=>(QBY[f.id]||[]).forEach(q=>{
    if(q.type==='intro')return;const s=toStep(q);if(!s||!s.key)return;
    const n=(S.miss||{})[s.key];if(!n)return;
    const e=(S.srs||{})[s.key]||{b:0};
    rows.push({question_id:q.id,lesson_id:f.id,qtype:q.type,wrong_count:n,box:Math.max(1,e.b||1),next_review:e.d||today(),due:!e.d||e.d<=today(),mastered:(e.b||0)>=5,data:q.data,key:s.key});
  }));
  return rows.sort((a,b)=>b.wrong_count-a.wrong_count);
}
const mbTitleOf=r=>{const d=r.data||{};return String(d.prompt||d.statement||d.text||d.sentence||d.wrong||d.answer||(d.pairs&&d.pairs[0]&&d.pairs[0][0])||r.qtype);};
function mistakesView(){
  mbLoad();
  if(!MB.rows)return `<div role="status">${esc(t('mbLoad'))}</div>`;
  if(MB.err)return `<p class="msg err">${esc(t('mbFail'))}</p><button class="btn btn-ghost" data-a="mbReload">${esc(t('mbRetry'))}</button>`;
  const rows=MB.rows,due=rows.filter(r=>r.due&&!r.mastered);
  if(!rows.length)return `<div class="say">${gloro('encouraging',56)}<span>${esc(t('mbEmpty'))}</span></div>`;
  return `<section class="card"><h2>${esc(t('mbTitle'))}</h2><p class="note">${esc(t('mbDue'))}: <b>${due.length}</b> · ${esc(t('mbMastered'))}: <b>${rows.filter(r=>r.mastered).length}</b></p>
   <button class="btn btn-orange" data-a="mbPractice" ${rows.some(r=>!r.mastered)?'':'disabled'}>${esc(t('mbPractice'))}</button>
   <div class="mb-list">${rows.map(r=>`<div class="weak mb ${r.mastered?'done':''}"><b lang="${tl()}">${esc(mbTitleOf(r))}</b><span>×${r.wrong_count} ${esc(t('mbWrong'))} · ${esc(t('mbBox'))} ${r.box}/5${r.due&&!r.mastered?' · '+esc(t('mbDue')):''}${r.mastered?' · '+esc(t('mbMastered')):''}</span></div>`).join('')}</div></section>${weakBlock()}`;
}
function startMistakePractice(){
  const rows=(MB.rows||[]).filter(r=>!r.mastered);
  rows.sort((a,b)=>(b.due?1:0)-(a.due?1:0));
  const steps=rows.slice(0,10).map(r=>toStep({id:r.question_id,type:r.qtype,data:r.data})).filter(Boolean);
  if(!steps.length)return;
  L=newLesson({practice:true,steps});
  beginOrOpen('practice','',steps.length);
  MB.rows=null;
}
