/* ---------- shell ---------- */
function tabs(){
  const a=[['home','home'],['learn','learn'],['me','user']];
  if(isStaff())a.push(['admin','shield']);
  return a;
}
const ROUTE_LABEL={home:'home',learn:'learn',rank:'rank',shop:'shop',friends:'friends',me:'me',admin:'admin'};
function nav(){
  const cur=NAV_OF[tab]||tab;
  return `<nav class="nav" aria-label="Lingora"><div class="logo nav-logo">${mascot('happy',34)}<span>${logoName()}</span></div>${tabs().map(x=>`<button type="button" class="${x[0]==='admin'?'nav-admin':''}" data-a="tab" data-v="${x[0]}" data-nav="${x[0]}" aria-label="${esc(t(ROUTE_LABEL[x[0]]))}" title="${esc(t(ROUTE_LABEL[x[0]]))}" ${cur===x[0]?'aria-current="page"':''}>${LI(x[1])}<span>${esc(t(ROUTE_LABEL[x[0]]))}</span></button>`).join('')}</nav>`;
}
function applyAnim(){document.documentElement.classList.toggle('no-anim',!!S.noanim);}
function applyTheme(){
  applyAnim();applyPrefs();
  const r=document.documentElement;
  const was=r.getAttribute('data-theme')||'';
  const sysDk=!!(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches);
  const th=S.theme==='light'?'light':S.theme==='system'?(sysDk?'dark':'light'):'dark';
  r.setAttribute('data-theme',th);themeSet=true;
  const mc=document.querySelector('meta[name=theme-color]');
  if(mc){mc.content=th==='dark'?'#101827':'#F3F7FE';}
}
/* application-level error boundary: a rendering exception shows a recovery screen instead of a blank page */
let rndFail=0;
function render(){
  try{renderCore();rndFail=0;}
  catch(e){
    try{console.error('render failed',e);}catch(_){}
    rndFail++;
    const app=document.getElementById('app');if(!app)return;
    const hy=S&&S.lang==='hy';
    app.innerHTML='<div class="pg"><div class="card" role="alert" style="max-width:480px;margin:40px auto;padding:24px;text-align:center"><h2>'+(hy?'Ինչ-որ բան այն չէ':'Something went wrong')+'</h2><p>'+(hy?'Էջը չբացվեց։ Քո առաջընթացը պահպանված է։':'This page could not be shown. Your progress is saved.')+'</p><div class="acts" style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap"><button class="btn" id="rec-retry">'+(hy?'Նորից փորձել':'Try again')+'</button><button class="btn btn-ghost" id="rec-home">'+(hy?'Գլխավոր էջ':'Go home')+'</button><button class="btn btn-ghost" id="rec-reload">'+(hy?'Թարմացնել':'Reload')+'</button></div></div></div>';
    const q=id=>document.getElementById(id);
    if(q('rec-retry'))q('rec-retry').onclick=()=>render();
    if(q('rec-home'))q('rec-home').onclick=()=>{try{tab='home';}catch(_){}render();};
    if(q('rec-reload'))q('rec-reload').onclick=()=>location.reload();
  }
}
function renderCore(){
  document.documentElement.lang=S.lang==='hy'?'hy':'en';
  applyTheme();
  const bc=document.body.classList;
  if(!S.onb||(flow==='login'&&!A.user)){
    bc.add('nonav');
    $('app').innerHTML=`<div class="pg">${flow==='onboard'?onboardView():flow==='login'?loginView():landingView()}</div>`;
    return;
  }
  bc.remove('nonav');
  if(tab==='admin'&&A.ready&&!isStaff())tab='home';
  /* Stories now open inside Learn; AI Coach is no longer a learner-facing page. */
  if(tab==='stories'||tab==='ai'){tab='learn';}
  const body=tab==='admin'&&!A.ready&&!isStaff()?`<div role="status" aria-label="${esc(t('loadingT'))}">${loading()}${skel(3)}</div>`:tab==='home'?homeView():tab==='learn'?learnTab():tab==='friends'?friendsView():tab==='courses'?coursesView():tab==='words'?wordsView():tab==='rank'?rankView():tab==='shop'?shopView():tab==='world'?worldView():tab==='admin'?adminView():profileView();
  routeSync();
  const SB={rank:'home',friends:'home',shop:'home',words:'learn',courses:'learn',world:'me'};
  const back=SB[tab]?`<button type="button" class="px-back sub-back" data-a="tab" data-v="${SB[tab]}">${LI('right')}<span>${esc(pt('back'))}</span></button>`:'';
  const an=pgAnim;pgAnim=false;
  $('app').innerHTML=`<div class="wrap tab-${tab} ${an?'anim':''} ${tab==='admin'?'wide':''}">${topbar()}<main class="${an?'pg-in':''}">${back}${body}</main></div>${nav()}${popups()}`;
  if(an)countUp();
  if(tab==='learn'&&wantScroll){
    wantScroll=false;
    const c=document.querySelector('.st-open');
    if(c&&c.scrollIntoView){try{c.scrollIntoView({block:'center'});}catch(e){}}
  }
}


/* XP and streak numbers count up when a page appears (skipped with reduced motion) */
function countUp(){
  if(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  document.querySelectorAll('[data-count]').forEach(el=>{
    const to=+el.dataset.count||0;if(to<2)return;const t0=performance.now(),D=700;
    const step=n=>{const k=Math.min(1,(n-t0)/D);el.textContent=Math.round(to*(1-Math.pow(1-k,3)));if(k<1)requestAnimationFrame(step);};
    el.textContent='0';requestAnimationFrame(step);
  });
}
