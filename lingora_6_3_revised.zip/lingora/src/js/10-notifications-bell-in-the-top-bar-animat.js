/* ---------- notifications (bell in the top bar, animated toast with the mascot) ---------- */
function notify(kind,title,body,mood,id){
  if(!notifOn(kind))return;
  if(!S.notifs)S.notifs=[];
  const n={id:id||kind+':'+Date.now()+':'+Math.floor(Math.random()*999),t:Date.now(),kind,title:String(title||''),body:String(body||''),mood:mood||'happy',read:false};
  if(S.notifs.some(x=>x.id===n.id))return;
  S.notifs=[n].concat(S.notifs).slice(0,40);save();
  if(!L)toast((n.title+(n.body?' · '+n.body:'')).trim(),n.mood,4200);
  const bell=document.querySelector('.bell');if(bell)bell.classList.add('ring');
}
const unread=()=>(S.notifs||[]).filter(n=>!n.read).length;
function syncContentNotes(){
  if(!S.seenC)S.seenC={};
  CONTENT.filter(c=>(c.kind==='notification'||c.kind==='announcement')&&liveC(c)&&!S.seenC[c.id]).forEach(c=>{
    S.seenC[c.id]=1;
    notify(c.kind==='announcement'?'news':'info',tx(c.title),tx(c.body),'excited','c:'+c.id);
  });
}
/* Reminders only run while the app is open: a browser cannot wake a closed page without a push server. */
function reminderTick(){
  if(!S.onb||L)return;
  const now=new Date(),hm=p2(now.getHours())+':'+p2(now.getMinutes()),rem=S.rem||{};
  if(rem.on&&S.last!==today()&&rem.day!==today()&&hm>=(rem.time||'19:00')){
    S.rem.day=today();save();
    notify('reminder',t('n_remT'),mmsg('remind',true),'wave');
    try{if(window.Notification&&Notification.permission==='granted')new Notification(BRAND.name||'Lingora',{body:t('n_remT'),icon:'icon-192.png'});}catch(e){}
  }
  if(streakRisk()&&now.getHours()>=18&&rem.risk!==today()){
    S.rem.risk=today();save();
    notify('risk',t('n_riskT').replace('{n}',streakNow()),mmsg('risk',true),'surprised');
  }
}
const weekXp=()=>{const cut=Date.now()-7*864e5;return (S.log||[]).filter(e=>e.t>=cut).reduce((n,e)=>n+e.xp,0);};
const displayName=()=>(A.profile&&A.profile.name)||S.name||t('learner');
const myTier=()=>(S.league&&S.league.tier)||0;
function boardRows(){
  const my=myTier();
  let rows=(A.board||[]).map(r=>({name:r.name,xp:Number(r.xp)||0,me:!!r.me,league:r.me?my:(Number(r.league)||0)}));
  if(!rows.some(r=>r.me))rows.push({name:displayName(),xp:weekXp(),me:true,league:my});
  rows=rows.filter(r=>r.league===my);
  rows.sort((a,b)=>b.xp-a.xp||(a.me?-1:1));
  return rows.map((r,i)=>Object.assign(r,{rk:i+1}));
}
const stateOf=i=>S.done[FLAT[i].id]?'done':(i===0||S.done[FLAT[i-1].id]?'open':'lock');
const countWords=()=>FLAT.reduce((n,f)=>S.done[f.id]?n+(QBY[f.id]||[]).filter(q=>q.type==='intro').length:n,0);
const canPractice=()=>FLAT.some(f=>S.done[f.id]);
let toastT;
function toast(m,mood,ms){const e=$('toast');e.innerHTML=gloro(mood||'happy',34)+'<span></span>';e.lastChild.textContent=m;e.classList.add('show');clearTimeout(toastT);toastT=setTimeout(()=>e.classList.remove('show'),ms||2200);}
