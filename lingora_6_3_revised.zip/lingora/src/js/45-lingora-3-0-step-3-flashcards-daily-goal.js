/* ---------- Lingora 3.0, step 3: flashcards daily goal + real example sentences ---------- */
const PX_GOALS=[5,10,20,30];
function pxCardGoal(){const g=+pxPx().cg;return PX_GOALS.indexOf(g)>=0?g:10;}
function pxCardToday(){const c=pxPx().cd;return c&&c.d===today()?(+c.n||0):0;}
function pxCardCount(){const P=pxPx();P.cd={d:today(),n:pxCardToday()+1};}
function pxCardGoalCycle(){const P=pxPx(),i=PX_GOALS.indexOf(pxCardGoal());P.cg=PX_GOALS[(i+1)%PX_GOALS.length];save();}
/* an example is shown only when a real sentence of the course contains the word as a whole word */
function pxExample(w){
  const re=new RegExp('(^|[^\\p{L}])'+String(w.en).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'($|[^\\p{L}])','iu');
  let hit=null;
  (UNITS||[]).forEach(u=>{if(hit||u.locked)return;(u.sents||[]).forEach(x=>{if(!hit&&x&&x.en&&x.hy&&re.test(x.en))hit=x;});});
  return hit;
}
function pxExampleHtml(w){
  let x=null;try{x=pxExample(w);}catch(e){}
  return x?`<em class="px-ex" lang="${tl()}">${esc(x.en)}<br><small>${esc(x.hy)}</small></em>`:'';
}
Object.assign(PXS.hy,{cgToday:'Այսօր՝ {n}/{g} քարտ',cgSet:'Օրական նպատակ՝ {g} քարտ'});
Object.assign(PXS.en,{cgToday:'Today: {n}/{g} cards',cgSet:'Daily goal: {g} cards'});

boot();

/* a picture that fails to load (bad URL, deleted file) never leaves a broken icon: the card falls back to its emoji / label */
document.addEventListener('error',e=>{
  const im=e.target;if(!im||im.tagName!=='IMG'||!(im.classList.contains('iimg')||im.classList.contains('qimg')))return;
  im.onerror=null;im.classList.add('img-broken');im.removeAttribute('src');im.alt=t('imgErr');
},true);
Object.assign(UI.hy,{vxPlay:'Լսել / կրկնել',vxSlow:'Դանդաղ լսել',offline:'Կապ չկա։ Աշխատում եմ օֆլայն ռեժիմով։'});Object.assign(UI.en,{vxPlay:'Listen / repeat',vxSlow:'Listen slowly',offline:'You are offline. Working in offline mode.'});
/* global safety nets: uncaught errors never leave a blank screen; offline notice */
window.addEventListener('unhandledrejection',e=>{try{console.warn('unhandled',e.reason);}catch(_){}try{e.preventDefault();}catch(_){}});
window.addEventListener('error',e=>{if(e.target&&e.target!==window)return;const app=document.getElementById('app');if(app&&!app.firstElementChild&&document.getElementById('lesson').hidden){try{render();}catch(_){}}});
(function(){const b=document.createElement('div');b.id='offbar';b.setAttribute('role','status');b.hidden=true;document.body.appendChild(b);
const upd=()=>{b.textContent=t('offline');b.hidden=navigator.onLine!==false;};window.addEventListener('online',upd);window.addEventListener('offline',upd);upd();})();
Object.assign(UI.hy,{imgErr:'Նկարը չի բացվում'});Object.assign(UI.en,{imgErr:'Image could not be loaded'});

/* test-only read access: exists only when the page's config.js sets TEST_HOOK (the browser tests do; a real deployment never does) */
if(CFG.TEST_HOOK){window.__ee={S:()=>S,L:()=>L,cur:()=>cur(),rvCounts:()=>rvCounts(),rvItems:()=>rvItems(),B:()=>B,save:()=>save(),render:()=>renderLesson()};}
