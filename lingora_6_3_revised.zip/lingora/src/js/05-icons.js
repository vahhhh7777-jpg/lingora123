/* ---------- icons ---------- */
const IC={
gem:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="#FF922B" stroke="#C96A0A" stroke-width="1"/><circle cx="12" cy="12" r="8.9" fill="#FFB15C" stroke="#FFD9A3" stroke-width=".7"/><path d="M9.4 8.3 9.1 6.5M14.6 8.3 14.9 6.5" stroke="#8A4B12" stroke-width="1" stroke-linecap="round" fill="none"/><circle cx="9.1" cy="6.3" r=".9" fill="#8A4B12" stroke="none"/><circle cx="14.9" cy="6.3" r=".9" fill="#8A4B12" stroke="none"/><ellipse cx="7" cy="10.4" rx="1.5" ry="1" fill="#F5A25A" stroke="none"/><ellipse cx="17" cy="10.4" rx="1.5" ry="1" fill="#F5A25A" stroke="none"/><ellipse cx="12" cy="12.6" rx="5.1" ry="4.6" fill="#FFE2B4" stroke="none"/><circle cx="9.7" cy="9.9" r=".8" fill="#E8791A" stroke="none"/><circle cx="14.4" cy="10.2" r=".7" fill="#E8791A" stroke="none"/><circle cx="12.2" cy="8.9" r=".55" fill="#E8791A" stroke="none"/><circle cx="10.2" cy="12" r=".75" fill="#101827" stroke="none"/><circle cx="13.8" cy="12" r=".75" fill="#101827" stroke="none"/><ellipse cx="12" cy="14.7" rx="2.4" ry="1.6" fill="#FFF4DE" stroke="none"/><circle cx="11.2" cy="14.2" r=".38" fill="#8A4B12" stroke="none"/><circle cx="12.8" cy="14.2" r=".38" fill="#8A4B12" stroke="none"/><path d="M11 15.2q1 .8 2 0" stroke="#8A4B12" stroke-width=".6" stroke-linecap="round" fill="none"/></svg>',
shop:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M4 10h16v9.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 19.5z"/><path fill="currentColor" d="M3.2 4.5A1 1 0 0 1 4 4h16a1 1 0 0 1 .8.5L22 8.3c.2 1.4-.9 2.7-2.4 2.7a2.6 2.6 0 0 1-2.8-2.3 2.6 2.6 0 0 1-2.4 2.3 2.6 2.6 0 0 1-2.4-2.3 2.6 2.6 0 0 1-2.4 2.3 2.6 2.6 0 0 1-2.4-2.3A2.6 2.6 0 0 1 4.4 11C2.9 11 1.8 9.700 2 8.300z"/></svg>',
bell:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 22a2.3 2.3 0 0 0 2.3-2.3H9.7A2.3 2.3 0 0 0 12 22zm7-6.2V11a7 7 0 0 0-5.2-6.8V3.5a1.8 1.8 0 0 0-3.6 0v.7A7 7 0 0 0 5 11v4.8l-1.6 1.6V18h17.2v-.6z"/></svg>',
chev:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
heart:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>',
flame:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2c1 3.5 5.5 5.5 5.5 10.2a5.5 5.5 0 0 1-11 0c0-2.2 1-3.8 2.3-5 .2 1.6 1 2.6 2.1 2.8C10.4 7.6 10.8 4.6 12 2z"/></svg>',
star:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2l3.1 6.9 7.4.8-5.5 5 1.6 7.3L12 18.2 5.4 22l1.6-7.3-5.5-5 7.4-.8z"/></svg>',
lock:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2.5" fill="currentColor"/><path d="M8 11V8a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>',
check:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
x:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/></svg>',
eye:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/><circle cx="12" cy="12" r="3" fill="currentColor"/></svg>',
eyeoff:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18M10.6 5.7A10 10 0 0 1 12 5.5c6.4 0 10 6.5 10 6.5a17 17 0 0 1-3.2 4M6.5 7.2C3.7 9 2 12 2 12s3.6 6.5 10 6.5c1.5 0 2.8-.3 4-.8" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
speaker:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M3 9v6h4l5 4V5L7 9H3z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
learn:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M4 11l8-7 8 7v8.5a1.5 1.5 0 0 1-1.5 1.5H15v-6H9v6H5.5A1.5 1.5 0 0 1 4 19.5z"/></svg>',
book:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5a2 2 0 0 1 2-2h12v15H7a2 2 0 0 0-2 2zM5 20a2 2 0 0 0 2 2h12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/></svg>',
user:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4.2" fill="currentColor"/><path fill="currentColor" d="M3.8 21c0-4.3 3.7-7 8.2-7s8.2 2.7 8.2 7z"/></svg>',
bolt:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M13.5 2L4.5 13.5H11L10 22l9-11.5h-6.5z"/></svg>',
path:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6" cy="18" r="2.6" fill="currentColor"/><circle cx="18" cy="6" r="2.6" fill="currentColor"/><path d="M6 15.4c0-6 12-3 12-6.8" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>',
globe:'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M3 12h18M12 3c3.2 3 3.2 15 0 18M12 3c-3.2 3-3.2 15 0 18" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
trophy:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M7 3h10v6a5 5 0 0 1-10 0z"/><path d="M7 5H3.5c0 3.200 1.600 5 4 5.400M17 5h3.500c0 3.200-1.600 5-4 5.400" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><rect x="10.500" y="13" width="3" height="4" fill="currentColor"/><rect x="7" y="18" width="10" height="3" rx="1.500" fill="currentColor"/></svg>',
next:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 5 7 7-7 7" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>',
crown:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M3 8l4.5 4L12 5l4.5 7L21 8l-1.5 10h-15z"/><rect x="5" y="19" width="14" height="2.2" rx="1" fill="currentColor"/></svg>',
chart:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M4 20V11h4v9zM10 20V4h4v16zM16 20v-6h4v6z"/></svg>',
shield:'<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2l8 3v6c0 5-3.4 9.3-8 11-4.6-1.7-8-6-8-11V5z"/><path d="M8.5 12l2.5 2.5 4.5-5" fill="none" stroke="var(--surface)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
};

/* Gloro — the Lingora mascot. Pure SVG + CSS animation, no external assets.
   Moods: idle happy excited explaining curious celebrating encouraging confused thinking wave correct wrong sleep */
let _gl=0;
const GLM={
  idle:{eye:'open',mouth:'smile',arms:[14,-14],ant:'n'},
  happy:{eye:'joy',mouth:'open',arms:[14,-14],ant:'n'},
  excited:{eye:'wide',mouth:'open',arms:[150,-150],ant:'up',spark:1},
  explaining:{eye:'open',mouth:'open',arms:[14,-14],ant:'n',book:1},
  curious:{eye:'open',mouth:'o',arms:[14,-14],ant:'tilt',look:[5,-4]},
  celebrating:{eye:'joy',mouth:'open',arms:[150,-150],ant:'up',spark:1,jump:1},
  encouraging:{eye:'open',mouth:'smile',arms:[14,-60],ant:'n'},
  confused:{eye:'small',mouth:'frown',arms:[14,-14],ant:'curl',q:1},
  thinking:{eye:'open',mouth:'flat',arms:[14,-14],ant:'n',chin:1,look:[-4,-6],dots:1},
  wave:{eye:'joy',mouth:'open',arms:[14,-145],ant:'n',wave:1},
  correct:{eye:'joy',mouth:'open',arms:[40,-40],ant:'up',spark:1,pop:1},
  wrong:{eye:'small',mouth:'frown',arms:[10,-10],ant:'droop',shake:1},
  sleep:{eye:'shut',mouth:'smile',arms:[14,-14],ant:'droop',zzz:1},
  sad:{eye:'small',mouth:'frown',arms:[8,-8],ant:'droop',tear:1},
  surprised:{eye:'wide',mouth:'o',arms:[70,-70],ant:'up',pop:1,look:[0,-2]},
  proud:{eye:'joy',mouth:'smile',arms:[34,-34],ant:'up',spark:1,pop:1}
};
/* Moods an admin can replace with an uploaded picture (Admin > Mascot) */
const MOODS=['idle','happy','excited','sad','surprised','thinking','confused','proud','encouraging','celebrating','sleep','wave','correct','wrong','explaining','curious'];
let BRAND={name:'Lingora',primary:'',secondary:'',mascot:{}};
function gloro(mood,size,opt){
  opt=opt||{};const m=GLM[mood]||GLM.idle,id='gl'+(++_gl),w=size||120,h=Math.round(w*1.2);
  const img=BRAND.mascot&&BRAND.mascot[mood];
  if(img&&/^(https:\/\/|data:image\/)/.test(img))return `<span class="${['gl','img','m-'+mood,m.jump?'jump':'',m.pop?'pop':'',m.shake?'shake':'',opt.cls||''].join(' ').trim()}" style="width:${w}px;height:${h}px"><img src="${img.replace(/"/g,'&quot;')}" alt="Lingora mascot" width="${w}" height="${h}"></span>`;
  const ink='#3A2216';
  const eye=cx=>{
    if(m.eye==='joy')return `<path d="M${cx-13} 88Q${cx} 70 ${cx+13} 88" fill="none" stroke="${ink}" stroke-width="5" stroke-linecap="round"/>`;
    if(m.eye==='shut')return `<path d="M${cx-12} 82Q${cx} 92 ${cx+12} 82" fill="none" stroke="${ink}" stroke-width="4.500" stroke-linecap="round"/>`;
    const rx=m.eye==='wide'?15:m.eye==='small'?11.500:13.500,ry=m.eye==='wide'?18:m.eye==='small'?14:16,p=m.look||[0,0];
    return `<g><ellipse cx="${cx}" cy="84" rx="${rx}" ry="${ry}" fill="#2E1A12"/><ellipse cx="${cx+p[0]}" cy="${84+p[1]}" rx="${rx-3}" ry="${ry-3}" fill="#4A2A1C"/><circle cx="${cx+p[0]+4.500}" cy="${84+p[1]-6}" r="5" fill="#fff"/><circle cx="${cx+p[0]-4}" cy="${84+p[1]+6}" r="2.400" fill="#fff" opacity=".85"/><path d="M${cx+(cx<100?-rx:rx)} ${84-ry*0.55}l${cx<100?-6:6} -4" stroke="${ink}" stroke-width="2.500" stroke-linecap="round"/></g>`;
  };
  const mouth={
    open:`<path d="M90 112Q100 130 110 112Z" fill="#C2395A" stroke="${ink}" stroke-width="2.500" stroke-linejoin="round"/><ellipse cx="100" cy="121" rx="5.500" ry="3.200" fill="#FF8FA3"/>`,
    smile:`<path d="M92 113Q100 121 108 113" fill="none" stroke="${ink}" stroke-width="3.500" stroke-linecap="round"/>`,
    o:`<ellipse cx="100" cy="116" rx="4.500" ry="6" fill="#C2395A" stroke="${ink}" stroke-width="2.200"/>`,
    frown:`<path d="M92 120Q100 111 108 120" fill="none" stroke="${ink}" stroke-width="3.500" stroke-linecap="round"/>`,
    flat:`<path d="M93 116Q101 113 108 116" fill="none" stroke="${ink}" stroke-width="3.500" stroke-linecap="round"/>`
  }[m.mouth];
  const arm=(x,a)=>`<g transform="translate(${x} 146) rotate(${a})"><ellipse cx="0" cy="18" rx="9.500" ry="20" fill="#FFAE36" stroke="#E98A14" stroke-width="1.500"/><circle cx="0" cy="38" r="8.500" fill="#7A4528"/></g>`;
  const waveCls=m.wave?'gl-wave':'';
  const chin=m.chin?`<path d="M148 164Q146 126 116 120" fill="none" stroke="#FFAE36" stroke-width="17" stroke-linecap="round"/><circle cx="114" cy="119" r="9.500" fill="#7A4528"/>`:'';
  const book=m.book?`<g><rect x="76" y="150" width="50" height="40" rx="6" fill="#1677FF" stroke="#0B4FB8" stroke-width="2"/><rect x="82" y="154" width="3" height="32" fill="#8F6BEA"/><circle cx="106" cy="170" r="10" fill="none" stroke="#9CC8FF" stroke-width="2.500"/><path d="M96 170h20M106 160v20" stroke="#9CC8FF" stroke-width="2"/></g>`:'';
  const cap=`<g class="gl-cap" transform="translate(100 44) scale(.88) translate(-100 -44) translate(0 -10)"><path d="M64 58Q100 76 136 58L136 70Q100 86 64 70Z" fill="#0B4FB8"/><path d="M58 52L100 34 142 52 100 68Z" fill="#1677FF" stroke="#0B4FB8" stroke-width="2" stroke-linejoin="round"/><circle cx="100" cy="51" r="4" fill="#0B4FB8"/><g class="gl-tas"><path d="M100 51L138 56 139 82" fill="none" stroke="#FFC83D" stroke-width="3" stroke-linecap="round"/><path d="M135 80h8l2 14h-12z" fill="#FFC83D"/></g></g>`;
  const extras=(m.spark?`<g class="gl-spark"><path d="M24 44l3 8 8 3-8 3-3 8-3-8-8-3 8-3z" fill="#FFC83D"/><path d="M176 30l2.500 6 6 2.500-6 2.500-2.500 6-2.500-6-6-2.500 6-2.500z" fill="#FFC83D"/><circle cx="184" cy="78" r="3" fill="#9B6BFF"/><circle cx="16" cy="92" r="3" fill="#FF8A35"/></g>`:'')
   +(m.q?`<text x="146" y="30" font-family="Bricolage Grotesque,Figtree,sans-serif" font-weight="800" font-size="32" fill="#3295FF" class="gl-q">?</text>`:'')
   +(m.dots?`<g class="gl-dots"><rect x="132" y="4" rx="12" width="52" height="28" fill="#fff" stroke="#BBD7FF" stroke-width="2"/><circle cx="148" cy="18" r="3.200" fill="#8A80A3"/><circle cx="158" cy="18" r="3.200" fill="#8A80A3"/><circle cx="168" cy="18" r="3.200" fill="#8A80A3"/></g>`:'')
   +(m.tear?`<path class="gl-tear" d="M62 100q-5 9 0 13q5-4 0-13z" fill="#7CC4FF" stroke="#4C9BE0" stroke-width="1.2"/>`:'')
   +(m.zzz?`<text class="gl-z" x="140" y="34" font-family="Bricolage Grotesque,sans-serif" font-weight="800" font-size="24" fill="#3295FF">z<tspan font-size="18" dx="3" dy="-10">z</tspan></text>`:'');
  const cls=['gl','m-'+mood,m.jump?'jump':'',m.pop?'pop':'',m.shake?'shake':'',opt.cls||''].join(' ').trim();
  const spot=(x,y,r)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="#F08A17" opacity=".75"/>`;
  return `<span class="${cls}" style="width:${w}px;height:${h}px"><svg viewBox="0 0 200 240" width="${w}" height="${h}" role="img" aria-label="Lingora giraffe"><defs>
<linearGradient id="${id}o" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFC24D"/><stop offset="1" stop-color="#FFA52B"/></linearGradient></defs>
<ellipse class="gl-sh" cx="100" cy="230" rx="52" ry="6.500" fill="#2A1450" opacity=".14"/>
<g class="gl-body">
<g class="gl-tail"><path d="M142 190Q170 186 176 160" fill="none" stroke="#FFAE36" stroke-width="7" stroke-linecap="round"/><path d="M170 158Q172 140 184 142Q188 156 176 170Z" fill="#7A4528"/></g>
<rect x="72" y="206" width="17" height="18" rx="6" fill="#FFAE36"/><rect x="111" y="206" width="17" height="18" rx="6" fill="#FFAE36"/>
<path d="M70 220h21v6q0 4-4 4H74q-4 0-4-4z" fill="#7A4528"/><path d="M109 220h21v6q0 4-4 4h-13q-4 0-4-4z" fill="#7A4528"/>
<rect x="38" y="140" width="38" height="64" rx="16" fill="#1677FF" stroke="#0B4FB8" stroke-width="2"/><path d="M54 154l2.500 5 5.500.8-4 3.900 1 5.500-5-2.600-5 2.600 1-5.500-4-3.900 5.500-.8z" fill="#FFC83D"/>
<ellipse cx="100" cy="170" rx="48" ry="44" fill="url(#${id}o)" stroke="#E98A14" stroke-width="2"/>
<ellipse cx="104" cy="178" rx="27" ry="30" fill="#FFE6B8"/>
${spot(70,176,7)}${spot(132,160,8)}${spot(126,196,6)}${spot(78,154,5)}
<rect x="82" y="118" width="36" height="34" fill="#FFAE36"/>
${book}
<g class="gl-antL"><path d="M76 46Q72 34 76 24" fill="none" stroke="#FFAE36" stroke-width="8" stroke-linecap="round"/><circle cx="76" cy="22" r="7.500" fill="#7A4528"/></g>
<g class="gl-antR"><path d="M124 46Q128 34 124 24" fill="none" stroke="#FFAE36" stroke-width="8" stroke-linecap="round"/><circle cx="124" cy="22" r="7.500" fill="#7A4528"/></g>
<g class="gl-earL"><ellipse cx="42" cy="78" rx="19" ry="12" transform="rotate(-24 42 78)" fill="#FFAE36" stroke="#E98A14" stroke-width="1.500"/><ellipse cx="44" cy="79" rx="11" ry="6.500" transform="rotate(-24 44 79)" fill="#FFA8B4"/></g>
<g class="gl-earR"><ellipse cx="158" cy="78" rx="19" ry="12" transform="rotate(24 158 78)" fill="#FFAE36" stroke="#E98A14" stroke-width="1.500"/><ellipse cx="156" cy="79" rx="11" ry="6.500" transform="rotate(24 156 79)" fill="#FFA8B4"/></g>
<ellipse cx="100" cy="88" rx="58" ry="50" fill="url(#${id}o)" stroke="#E98A14" stroke-width="2"/>
${spot(60,66,6)}${spot(140,70,7)}${spot(68,112,4.500)}
<ellipse cx="100" cy="108" rx="27" ry="19" fill="#FFE6B8"/>
<circle cx="93" cy="104" r="2.400" fill="#7A4528"/><circle cx="107" cy="104" r="2.400" fill="#7A4528"/>
<circle cx="64" cy="106" r="9" fill="#FF8FA3" opacity=".5"/><circle cx="136" cy="106" r="9" fill="#FF8FA3" opacity=".5"/>
<g class="gl-eyes">${eye(76)}${eye(124)}</g>
${mouth}
${cap}
<g class="gl-armL">${arm(54,m.arms[0])}</g>
<g class="${waveCls} gl-armR">${arm(146,m.arms[1])}</g>
${chin}
</g>${extras}</svg></span>`;
}
/* backwards-compatible helper used all over the app */
function mascot(mood,size){
  const map={cheer:'celebrating',happy:'happy',sad:'confused'};
  return gloro(map[mood]||mood,size||80);
}
