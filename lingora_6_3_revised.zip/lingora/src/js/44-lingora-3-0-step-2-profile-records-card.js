/* ---------- Lingora 3.0, step 2: profile "Records" card. Only real values: nothing is shown when it is unknown. ---------- */
function recordsCard(){
  const p=A.profile||{},rows=[];
  rows.push(['flame',t('bestStreak'),String(Math.max(S.best||0,streakNow()))]);
  const lv=(pxPx().cefr||'').trim();
  if(lv)rows.push(['target',t('pr_cefr'),lv]);
  try{pxLoadStories();}catch(e){}
  const stDone=pxStoryList().filter(x=>pxStars(x)).length;
  rows.push(['book',t('pr_stories'),String(stDone)]);
  rows.push(['learn',t('learned'),String(countWords())]);
  if(p.created_at){const d=new Date(p.created_at);if(!isNaN(d))rows.push(['clock',t('pr_joined'),fmtDate(d)]);}
  return `<section class="card" aria-label="${esc(t('pr_rec'))}"><h2>${esc(t('pr_rec'))}</h2><div class="px-grid">${
    rows.map(r=>`<div class="px-card"><span class="px-ic">${LI(r[0])}</span><span class="px-tx"><b>${esc(r[2])}</b><small>${esc(r[1])}</small></span></div>`).join('')}</div></section>`;
}
Object.assign(UI.hy,{pr_rec:'Անձնական արդյունքներ',pr_cefr:'CEFR մակարդակ',pr_stories:'Ավարտված պատմություններ',pr_joined:'Միացել է'});
Object.assign(UI.en,{pr_rec:'Personal records',pr_cefr:'CEFR level',pr_stories:'Stories completed',pr_joined:'Joined'});

