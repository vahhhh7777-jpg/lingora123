/* ---------- account state ---------- */
const A={mode:MODE,user:null,profile:null,form:'signin',busy:false,err:'',msg:'',em:'',nm:'',net:true,rawCat:null,dbCount:0,booting:false,board:null,boardAt:0,recovery:false,ready:false,next:''};
const isAdmin=()=>!!(A.profile&&(A.profile.is_admin||A.profile.role==='admin'||A.profile.role==='super_admin')&&!A.profile.suspended);
const isSuper=()=>!!(A.profile&&A.profile.role==='super_admin'&&!A.profile.suspended);
const isEditor=()=>!!(A.profile&&A.profile.role==='editor'&&!A.profile.suspended);
const isStaff=()=>isAdmin()||isEditor();
/* Fire-and-forget calls must not fail silently (P1-09): log them. */
const warnErr=l=>e=>{try{console.warn(l,e);}catch(_){}};
/* Same rule as the database (is_vip): a VIP that is scheduled to start in the future is not active yet (P1-04). */
const profVip=p=>!!p&&!!(p.is_admin||(p.vip_until&&new Date(p.vip_until)>new Date()&&(!p.vip_from||new Date(p.vip_from)<=new Date())));
/* The one place that turns a profile into a role for display. VIP is derived from the subscription, not stored as a role. */
const roleKey=()=>{const p=A.profile;if(!A.user||!p)return 'guest';if(p.suspended)return 'suspended';if(p.role==='super_admin')return 'super';if(p.is_admin||p.role==='admin')return 'admin';if(p.role==='editor')return 'editor';return profVip(p)?'vip':'free';};
const isVip=()=>MODE==='local'?true:profVip(A.profile);
const E=c=>Object.assign(new Error(c),{code:c});
/* upload validation: allowed type, size limit and the real file signature (the browser-reported type alone is not trusted) */
const MEDIA_OK={image:['image/jpeg','image/png','image/webp','image/gif'],audio:['audio/mpeg','audio/mp3','audio/ogg','audio/wav','audio/webm','audio/mp4']};
async function checkMedia(blob,kind){
  const k=kind==='audio'?'audio':'image';
  if(!blob||!blob.size)throw E('uplBad');
  if(blob.size>5242880)throw E('uplSize');
  const b=new Uint8Array(await blob.slice(0,16).arrayBuffer()),s=(i,n)=>String.fromCharCode.apply(null,b.slice(i,i+n));
  let m='';
  if(b[0]===0xFF&&b[1]===0xD8)m='image/jpeg';
  else if(s(1,3)==='PNG')m='image/png';
  else if(s(0,3)==='GIF')m='image/gif';
  else if(s(0,4)==='RIFF'&&s(8,4)==='WEBP')m='image/webp';
  else if(s(0,4)==='RIFF'&&s(8,4)==='WAVE')m='audio/wav';
  else if(s(0,3)==='ID3'||(b[0]===0xFF&&(b[1]&0xE0)===0xE0))m='audio/mpeg';
  else if(s(0,4)==='OggS')m='audio/ogg';
  else if(b[0]===0x1A&&b[1]===0x45&&b[2]===0xDF&&b[3]===0xA3)m='audio/webm';
  else if(s(4,4)==='ftyp')m='audio/mp4';
  if(!m||MEDIA_OK[k].indexOf(m)<0)throw E('uplType');
  return m;
}
function mapErr(e){
  if(e&&e.code&&/^(invalid|exists|short|email|net|denied|suspended|other|unconfirmed|rate|uplType|uplSize|uplBad)$/.test(e.code))return e.code;
  const ERRS='denied_self|username_taken|invalid_name|invalid_username|already_friends|already_sent|self|friend_limit|pending_limit';
  const m=String((e&&e.message)||e||'').toLowerCase();
  if(/^(vip_only|not_enough_gems|already_full|already_owned|not_owned|ai_limit|ai_budget|ai_disabled|no_hearts|too_fast|rate_limited|empty_lesson|not_found|admin_cannot_delete)$/.test(m))return m;
  const hit=new RegExp('(^|[^a-z_])('+ERRS+')($|[^a-z_])').exec(m);if(hit)return hit[2];
  if(m.indexOf('email not confirmed')>=0||m.indexOf('email_not_confirmed')>=0)return 'unconfirmed';   /* P1-06: Supabase default (confirmation on) */
  if(m.indexOf('rate limit')>=0||m.indexOf('too many requests')>=0||/you can only request this (after|once)/.test(m))return 'rate';
  if(m.indexOf('invalid login')>=0)return 'invalid';
  if(m.indexOf('already registered')>=0||m.indexOf('already been registered')>=0)return 'exists';
  if(m.indexOf('password should')>=0||m.indexOf('at least 6')>=0)return 'short';
  if(m.indexOf('valid email')>=0||m.indexOf('invalid email')>=0)return 'email';
  if(m.indexOf('fetch')>=0||m.indexOf('network')>=0||m.indexOf('failed to load')>=0)return 'net';
  if(m.indexOf('row-level')>=0||m.indexOf('permission')>=0)return 'denied';
  return 'other';
}

