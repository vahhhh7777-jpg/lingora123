/* ---------- lesson runner ---------- */
let L=null;
/* audio manager: one recording at a time; play / pause / replay; a broken or missing file is reported and, when we know the text, replaced by the browser's generated voice */
const AUD={a:null,u:''};
function audMark(state){
  document.querySelectorAll('[data-a="aud"]').forEach(b=>{b.classList.toggle('playing',state==='playing'&&b.dataset.t===AUD.u);b.classList.toggle('loading',state==='loading'&&b.dataset.t===AUD.u);b.classList.toggle('broken',state==='error'&&b.dataset.t===AUD.u);});
}
function audStop(){try{if(AUD.a){AUD.a.pause();AUD.a=null;}}catch(e){}try{if(HAS_TTS)vxStop();}catch(e){}}
function playAudio(u,fallback){
  if(!u)return;
  if(AUD.a&&AUD.u===u&&!AUD.a.paused&&!AUD.a.ended){AUD.a.pause();audMark('idle');return;}
  audStop();AUD.u=u;
  const fail=()=>{
    AUD.a=null;audMark('error');
    if(fallback&&HAS_TTS){toast(t('audFb'),'confused');say(fallback);}else toast(t('audErr'),'confused');
  };
  try{
    const a=new Audio();AUD.a=a;
    a.onplaying=()=>audMark('playing');a.onended=()=>audMark('idle');a.onpause=()=>{if(!a.ended)audMark('idle');};
    a.onerror=()=>{if(AUD.a===a)fail();};
    a.src=u;audMark('loading');
    const p=a.play();if(p&&p.catch)p.catch(e=>{if(e&&e.name==='NotAllowedError'){audMark('idle');toast(t('audTap'),'confused');}else if(AUD.a===a)fail();});
  }catch(e){fail();}
}
Object.assign(UI.hy,{checking:'Ստուգվում է…',audErr:'Աուդիո ֆայլը չի բացվում։',audFb:'Ձայնագրությունը չի բացվում, միացվեց սինթեզված ձայնը։',audTap:'Սեղմիր նվագարկման կոճակը ևս մեկ անգամ։',qListenType:'Լսիր և գրիր լսածդ',qWrite:'Գրիր պատասխանդ',genVoice:'Սինթեզված ձայն',recVoice:'Ձայնագրություն',tapPlay:'Սեղմիր և լսիր'});
Object.assign(UI.en,{checking:'Checking…',audErr:'This audio file could not be played.',audFb:'The recording could not be played, so the generated voice is used.',audTap:'Tap the play button once more.',qListenType:'Listen and type what you hear',qWrite:'Write your answer',genVoice:'Generated voice',recVoice:'Recording',tapPlay:'Tap to listen'});
const audBtn=(s,cls)=>s.audio?`<button class="spk ${cls||''}" data-a="aud" data-t="${esc(s.audio)}" data-f="${esc(s.text||'')}" aria-label="${esc(t('tapPlay'))}">${IC.speaker}</button><div class="note aud-src">${esc(t('recVoice'))}</div>`:spkBtn(s.text,cls)+`<div class="note aud-src">${esc(t('genVoice'))}</div>`;
const freshM=()=>({l:null,r:null,done:[],bad:null});
function newLesson(o){
  return Object.assign({steps:[],i:0,hearts:5,attempts:0,correct:0,passed:0,sel:null,ans:[],typed:'',res:null,fresh:true,end:null,quit:false,stars:0,xp:0,acc:100,practice:false,idx:-1,id:'',m:freshM(),newAch:[],lvl:0,intro:false,lesson:null,hint:false,listening:false,micErr:false},o,{base:o.steps.length});
}
function startLesson(i){
  const f=FLAT[i],own=stepsFor(f.id);
  if(!own.length){toast(t('noQ'),'confused');return;}
  const steps=mixReview(own,f);
  L=newLesson({id:f.id,idx:i,steps,xpBase:f.lesson.xp||8,lesson:f.lesson,intro:hasIntro(f.lesson)});
  const r=S.resume;
  if(r&&r.id===f.id&&r.n===steps.length&&r.i>0&&r.i<steps.length){
    Object.assign(L,{i:r.i,hearts:r.hearts,attempts:r.attempts,correct:r.correct,passed:r.passed,intro:false});
    toast(t('resumed'));
  }
  beginOrOpen('lesson',f.id,steps.length);
}
let beginBusy=false;
/* cloud: ask the server for an attempt first (it also checks hearts and VIP access); other modes open at once */
function beginOrOpen(kind,id,n){
  if(!ECON()){openLesson();return;}
  if(beginBusy){L=null;return;}
  beginBusy=true;const mine=L;
  econBegin(kind,id,n).then(ok=>{beginBusy=false;if(L!==mine)return;if(!ok){L=null;return;}openLesson();});
}
/* Admin preview of stored questions, saved or not. Nothing is recorded. */
const hasIntro=l=>!!(l&&((l.blocks&&l.blocks.length)||String(l.objectives||'').trim()||String(l.grammar||'').trim()||(l.descr&&tx(l.descr))||(typeof pxLessonHasStory==='function'&&pxLessonHasStory(l.id))));
function lessonIntroView(l){
  const objs=String(l.objectives||'').split('\n').map(x=>x.trim()).filter(Boolean);
  const para=x=>esc(x).replace(/\n/g,'<br>');
  const f=Number.isInteger(L&&L.idx)&&L.idx>=0?FLAT[L.idx]:null;
  const stories=f&&typeof pxLessonStoriesHtml==='function'?pxLessonStoriesHtml(f):'';
  return `<div class="l-body"><div class="l-in enter"><div class="onb-gl">${gloro('explaining',96)}</div>${l.cover&&safeUrl(l.cover,'image')?`<img class="qimg" src="${esc(l.cover)}" alt="">`:''}<div class="q-kind">${t('l0')}${l.minutes?' · '+l.minutes+' '+t('minU'):''}</div><h1>${esc(tx(l.title))}</h1>${tx(l.descr)?`<p>${esc(tx(l.descr))}</p>`:''}${objs.length?`<h2>${t('objH')}</h2><ul class="objs">${objs.map(o=>`<li>${esc(o)}</li>`).join('')}</ul>`:''}${String(l.grammar||'').trim()?`<h2>${t('gramH')}</h2><div class="gram">${para(l.grammar)}</div>`:''}${blocksHtml(l.blocks)}${stories}</div></div><div class="l-foot"><div class="l-foot-in"><button id="nxt" class="btn btn-orange" data-a="begin">${t('start')}</button></div></div>`;
}
function startPreview(qs,lesson){
  const steps=(qs||[]).map(toStep).filter(Boolean);
  if(!steps.length){toast(t('noQ'),'confused');return;}
  L=newLesson({preview:true,steps,pq:qs,lesson:lesson||null,intro:hasIntro(lesson)});
  openLesson();
}
function startPractice(){
  const steps=practiceSteps();
  if(!steps.length)return;
  L=newLesson({practice:true,steps});
  beginOrOpen('practice','',steps.length);
}
function openLesson(){
  document.documentElement.classList.add('lock');
  $('lesson').hidden=false;
  renderLesson();
}
function closeLesson(){
  L=null;$('lesson').hidden=true;$('lesson').innerHTML='';
  document.documentElement.classList.remove('lock');
  render();
}
const cur=()=>L.steps[L.i];
function resetStep(){L.t0=Date.now();L.busy=false;L.hint=false;L.listening=false;L.micErr=false;L.sel=null;L.ans=[];L.typed='';L.res=null;L.fresh=true;L.m=freshM();}
function canCheck(s){
  if(s.k==='match')return false;
  if(s.k==='type'||s.k==='speak'||s.k==='listen_type'||s.k==='write')return !!(L.typed||'').trim();
  if(s.k==='build')return L.ans.length>0;
  return L.sel!=null;
}
const tl=()=>esc(ttsLang().slice(0,2));
function vis(w){
  const v=w.vis;if(!v)return '';
  if(v[0]==='e')return `<div class="vis emoji" aria-hidden="true">${esc(v[1])}</div>`;
  if(v[0]==='n')return `<div class="vis num ${String(v[1]).length>1?'two':''}" aria-hidden="true">${esc(v[1])}</div>`;
  const c=v[1]||COLORS[w.en]||'#888888';
  return `<div class="vis col" style="background:${esc(c)}" aria-hidden="true"></div>`;
}
function optsHtml(s,two){
  return `<div class="opts ${two?'two':''}">`+s.opts.map((o,i)=>{
    let c='opt';
    if(L.res){if(o===s.ans)c+=' ok';else if(i===L.sel)c+=' no';}
    else if(i===L.sel)c+=' sel';
    return `<button class="${c}" data-a="opt" data-i="${i}" ${L.res?'disabled':''}><span class="k">${i+1}</span><span class="ot">${esc(o)}</span></button>`;
  }).join('')+'</div>';
}
const spkBtn=(txt,cls)=>`<button class="spk ${cls||''}" data-a="say" data-t="${esc(txt)}" aria-label="${esc(t('vxPlay'))}">${IC.speaker}</button><button class="spk spk-slow" data-a="sayslow" data-t="${esc(txt)}" aria-label="${esc(t('vxSlow'))}" title="${esc(t('vxSlow'))}">🐢</button>`;
const media=s=>(s.image?`<img class="qimg" src="${esc(s.image)}" alt="" loading="lazy">`:'')+(s.audio&&s.k!=='listen'&&s.k!=='listen_type'?`<button class="spk" data-a="aud" data-t="${esc(s.audio)}" data-f="${esc(s.text||s.ans||'')}" aria-label="Audio">${IC.speaker}</button>`:'');
const hintBox=s=>s.hint?(L.hint?`<div class="hint">${esc(s.hint)}</div>`:(L.res?'':`<button class="link" data-a="hint">${t('hintB')}</button>`)):'';
const HAS_SR=typeof window.SpeechRecognition!=='undefined'||typeof window.webkitSpeechRecognition!=='undefined';
function qView(s){
  const h=qView0(s),i=h.indexOf('</div>')+6;
  return h.slice(0,i)+(s.instr?`<div class="note instr">${esc(s.instr)}</div>`:'')+media(s)+h.slice(i)+hintBox(s);
}
const lev=(a,b)=>{const m=[];for(let i=0;i<=a.length;i++){m[i]=[i];}for(let j=1;j<=b.length;j++)m[0][j]=j;for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)m[i][j]=Math.min(m[i-1][j]+1,m[i][j-1]+1,m[i-1][j-1]+(a[i-1]===b[j-1]?0:1));return m[a.length][b.length];};
const similar=(a,b)=>{a=norm(a);b=norm(b);const n=Math.max(a.length,b.length);return n?1-lev(a,b)/n:1;};
function startMic(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR||!L||L.res)return;
  const r=new SR();r.lang=ttsLang();r.interimResults=false;r.maxAlternatives=1;
  L.listening=true;L.micErr=false;renderLesson();
  r.onresult=e=>{if(L)L.typed=e.results[0][0].transcript;};
  r.onerror=()=>{if(L)L.micErr=true;};
  r.onend=()=>{if(L){L.listening=false;if(!L.typed)L.micErr=true;renderLesson();}};
  try{r.start();}catch(x){L.listening=false;L.micErr=true;renderLesson();}
}
const glSay=inner=>`<div class="gl-say">${gloro(L.res?(L.res.ok?'happy':'confused'):'curious',78)}<div class="gl-bub prompt">${inner}</div></div>`;
function qView0(s){
  const lbl=k=>`<div class="q-kind">${t(k)}${s.review?`<span class="rm-tag">${LI('repeat')}${esc(pt('rmTag'))}</span>`:''}</div>`;
  switch(s.k){
    case 'intro':
      return lbl('newWord')+`<div class="intro">${vis(s)}<div class="intro-en" lang="${tl()}">${esc(s.en)}</div>${spkBtn(s.en,'big')}<div class="intro-hy">${esc(s.hy)}</div>${s.pron||s.pos?`<div class="note">${s.pron?'/'+esc(s.pron)+'/':''}${s.pron&&s.pos?' · ':''}${esc(s.pos)}</div>`:''}${s.def?`<div class="note">${esc(s.def)}</div>`:''}${s.ex?`<div class="intro-ex" lang="${tl()}">${esc(s.ex)}${spkBtn(s.ex)}</div>${s.exTr?`<div class="note">${esc(s.exTr)}</div>`:''}`:''}</div>`;
    case 'gmc':
      return lbl(s.lbl||(s.speak?'qTr':'qChoose'))+`<div class="prompt">${s.speak?spkBtn(s.speak):''}<span class="pw" ${s.speak?`lang="${tl()}"`:''}>${esc(s.prompt)}</span></div>`+optsHtml(s);
    case 'read':
      return lbl('qRead')+`<div class="passage" lang="${tl()}">${esc(s.passage).replace(/\n/g,'<br>')}</div><div class="prompt"><span class="pw">${esc(s.prompt)}</span></div>`+optsHtml(s);
    case 'imgsel':return lbl('qImg')+`<div class="prompt">${spkBtn(s.ans)}<span class="pw" lang="${tl()}">${esc(s.ans)}</span></div>`+`<div class="imgs">`+s.opts.map((o,i)=>{
      let c='icard';if(L.res){if(o===s.ans)c+=' ok';else if(i===L.sel)c+=' no';}else if(i===L.sel)c+=' sel';
      return `<button class="${c}" data-a="opt" data-i="${i}" ${L.res?'disabled':''}>${s.cards[i].img?`<img class="iimg" src="${esc(s.cards[i].img)}" alt="" loading="lazy">`:`<span class="ie" aria-hidden="true">${esc(s.cards[i].vis?s.cards[i].vis[1]:'')}</span>`}<span class="il">${esc(s.cards[i].hy)}</span></button>`;}).join('')+`</div>`;
    case 'pic':return lbl('qPic')+`<div class="pic">${vis(s)}</div>`+optsHtml(s,true);
    case 'listen':return lbl('qListen')+`<div class="listen">${audBtn(s,'huge')}</div>`+optsHtml(s,true)+(L.res?'':`<button class="link" data-a="skip">${t('cantListen')}</button>`);
    case 'speak':
      return lbl('qSpeak')+`<div class="prompt">${spkBtn(s.text)}<span class="pw" lang="${tl()}">${esc(s.text)}</span></div>${s.hy?`<div class="note">${esc(s.hy)}</div>`:''}
       ${L.res?'':HAS_SR?`<button class="btn ${L.listening?'btn-ghost':'btn-purple'}" data-a="mic" ${L.listening?'disabled':''}>${t(L.listening?'micOn':'micB')}</button>`:`<p class="note">${t('micNote')}</p><button class="btn btn-purple" data-a="micself">${t('micSelf')}</button>`}
       ${L.typed&&HAS_SR?`<div class="heard">${t('heard')}: <b>${esc(L.typed)}</b></div>`:''}${L.micErr&&!L.typed?`<div class="msg err">${t('micErr')}</div>`:''}`;
    case 'listen_type':
      return lbl('qListenType')+`<div class="listen">${audBtn(s,'huge')}</div><input id="typed" class="inp ${L.res?(L.res.ok?'ok':'no'):''}" type="text" lang="${tl()}" value="${esc(L.typed||'')}" placeholder="${esc(t('typeHere'))}" autocomplete="off" autocapitalize="none" spellcheck="false" enterkeyhint="done" ${L.res||L.busy?'disabled':''}>`+(L.res?'':`<button class="link" data-a="skip">${t('cantListen')}</button>`);
    case 'write':
      return lbl('qWrite')+glSay(`<span class="pw">${esc(s.prompt)}</span>`)+`<textarea id="typed" class="inp wr ${L.res?(L.res.ok?'ok':'no'):''}" rows="3" lang="${tl()}" placeholder="${esc(t('typeHere'))}" autocomplete="off" spellcheck="false" ${L.res||L.busy?'disabled':''}>${esc(L.typed||'')}</textarea>`;
    case 'type':
      return lbl(s.lbl||'qType')+glSay(`<span class="pw">${esc(s.prompt)}</span>`)+`<input id="typed" class="inp ${L.res?(L.res.ok?'ok':'no'):''}" type="text" value="${esc(L.typed||'')}" placeholder="${esc(t('typeHere'))}" autocomplete="off" autocapitalize="none" spellcheck="false" enterkeyhint="done" ${L.res||L.busy?'disabled':''}>`;
    case 'build':{
      const a=L.ans.map(i=>`<button class="tile" data-a="tileDel" data-i="${i}" ${L.res?'disabled':''}>${esc(s.tiles[i])}</button>`).join('');
      const b=s.tiles.map((w,i)=>L.ans.includes(i)?`<span class="tile ghost" aria-hidden="true">${esc(w)}</span>`:`<button class="tile" data-a="tileAdd" data-i="${i}" ${L.res?'disabled':''}>${esc(w)}</button>`).join('');
      return lbl('qBuild')+glSay(`<span class="pw">${esc(s.prompt)}</span>`)+`<div class="answer" lang="${tl()}">${a}</div><div class="bank" lang="${tl()}">${b}</div>`;
    }
    case 'fill':{
      const sent=esc(s.before)+`<span class="blank">${L.res?esc(s.ans):'&nbsp;&nbsp;&nbsp;'}</span>`+esc(s.after);
      return lbl('qFill')+(s.prompt?`<div class="note" style="margin:6px 0 4px">${esc(s.prompt)}</div>`:'')+`<div class="prompt"><span class="pw" lang="${tl()}">${sent}</span></div>`+optsHtml(s);
    }
    case 'match':{
      const m=L.m;
      const col=(side,order)=>order.map(id=>{
        const p=s.pairs.find(x=>x.id===id),txt=side==='l'?p.en:p.hy,done=m.done.indexOf(id)>=0;
        let c='mt';
        if(done)c+=' ok';else if(m.bad&&m.bad[side==='l'?0:1]===id)c+=' bad';else if((side==='l'?m.l:m.r)===id)c+=' sel';
        return `<button class="${c}" data-a="mt" data-s="${side}" data-i="${id}" ${done?'disabled':''}>${esc(txt)}</button>`;
      }).join('');
      return lbl('qMatch')+`<div class="mgrid"><div class="mcol">${col('l',s.left)}</div><div class="mcol">${col('r',s.right)}</div></div>`;
    }
  }
  return '';
}
function footView(s){
  if(L.res){
    const ok=L.res.ok;
    return `<div class="l-foot-in">${['build','type','write','listen_type'].includes(cur().k)?'':`<span class="lfb-gl">${gloro(L.res.mood||(ok?'correct':'wrong'),66)}</span>`}<div class="fb"><span class="fb-ic">${ok?IC.check:IC.x}</span><div><div class="fb-h">${esc(L.res.msg)}</div>${ok?'':`<div class="fb-ans">${esc(L.res.ans)}</div>`}${L.res.say?`<div class="fb-say">${esc(L.res.say)}</div>`:''}${L.res.bad?`<div class="fb-x">${esc(L.res.bad)}</div>`:''}${L.res.expl?`<div class="fb-x">${esc(L.res.expl)}</div>`:''}</div></div><button id="nxt" class="btn ${ok?'btn-good':'btn-pom'}" data-a="next">${t('cont')}</button></div>`;
  }
  if(s.k==='intro')return `<div class="l-foot-in"><button id="nxt" class="btn btn-orange" data-a="next">${t('cont')}</button></div>`;
  return `<div class="l-foot-in"><button id="chk" class="btn btn-orange" data-a="check" ${canCheck(s)&&!L.busy?'':'disabled'} ${L.busy?'aria-busy="true"':''}>${L.busy?t('checking'):t('check')}</button></div>`;
}
function starsBig(n){let h='';for(let i=0;i<3;i++)h+=IC.star.replace('<svg','<svg class="'+(i<n?'on pop':'')+'" style="animation-delay:'+(i*.15)+'s"');return `<div class="bigstars" aria-label="${n}/3">${h}</div>`;}
function doneMood(){
  if(L.ev&&L.ev.ms)return ['celebrating','streak'];
  if(L.lvl)return ['proud','levelup'];
  if(L.unitDone)return ['proud','unit'];
  if(L.goalHit)return ['celebrating','goal'];
  if(L.practice)return ['happy','done'];
  return [L.acc>=90?'celebrating':'happy','done'];
}
function levelOverlay(n){
  const li=levelInfo(S.xp),pct=Math.min(100,Math.round(li.cur/li.need*100));
  return `<div class="lvov" role="dialog" aria-modal="true" aria-label="${esc(t('lvUp'))}" data-a="lvclose">${confetti(48)}<div class="lvbox" data-a="noop"><div class="lvgl">${gloro('celebrating',150)}</div><small>${esc(t('lvUp'))}</small><div class="lvnum" aria-live="polite">${n}</div><div class="lvbar"><i style="width:${pct}%"></i></div><p>${li.need-li.cur} XP ${esc(t('lvNext'))} ${n+1}</p><p class="lvs">${esc(t('lvUnlock'))}</p><button class="btn btn-orange" id="lvgo" data-a="lvclose">${esc(t('lvGo'))}</button></div></div>`;
}
function doneExtras(){
  let h='';
  if(L.ev&&L.ev.ms){const m=L.ev.ms;h+=`<div class="mile pop"><span class="mile-f">${IC.flame}<b>${m.d}</b></span><div><b>${t('streakMile').replace('{n}',m.d)}</b><small>${[m.xp?'+'+m.xp+' XP':'',m.freeze?'+'+m.freeze+' '+t('freezeW'):'',m.boost?t('boostMin').replace('{n}',m.boost):''].filter(Boolean).join(' · ')}</small></div></div>`;}
  if(L.ev&&L.ev.froze)h+=`<div class="newb"><span class="tag pop">${t('n_freezeB').replace('{n}',L.ev.froze)}</span></div>`;
  if(L.unitDone)h+=`<div class="mile pop unit"><span class="mile-f">${TROPHY}</span><div><b>${t('unitDoneT')}</b><small>${esc(tx(L.unitDone.t))}${G.xp.unit?' · +'+G.xp.unit+' XP':''}</small></div></div>`;
  if(L.lvl)h+=`<div class="newb"><span class="tag pop">${t('levelUp')}: ${L.lvl}</span></div>`;
  if(L.goalHit)h+=`<div class="newb"><span class="tag pop">${t('n_goalT')}</span></div>`;
  if(L.newAch&&L.newAch.length)h+=`<div class="newb">${L.newAch.map(a=>`<span class="tag pop">${esc(t('achNew'))}: ${esc(tx(a.t))}</span>`).join('')}</div>`;
  const rd=claimable().length+(chReady()?1:0);
  if(rd)h+=`<div class="newb"><button class="sbtn" data-a="exitHome">${t('rewardsReady')}</button></div>`;
  return h;
}
function matchSubmit(s,m){
  if(!serverJudged())return;
  const pairs=m.done.map(i=>{const p=s.pairs.find(x=>x.id===i);return [p.en,p.hy];});
  (L.pend=L.pend||[]).push(submitAnswer(s,{pairs},true).catch(e=>{L.pendErr=e;}));
}
function matchPick(side,id){
  if(!L||L.res||L.end)return;
  const s=cur();if(s.k!=='match')return;
  const m=L.m;if(m.done.indexOf(id)>=0)return;
  m.bad=null;
  if(side==='l')m.l=(m.l===id?null:id);else m.r=(m.r===id?null:id);
  if(m.l!=null&&m.r!=null){
    L.attempts++;
    if(m.l===m.r){
      L.correct++;m.done.push(m.l);m.l=m.r=null;tone([660]);
      if(m.done.length===s.pairs.length){matchSubmit(s,m);L.passed++;L.res={ok:true,ans:'',msg:mmsg('correct',true),mood:'correct'};tone([660,880]);}
    }else{
      L.hearts--;L.combo=0;tone([220,170],.16);m.bad=[m.l,m.r];econMiss();
      const w=s.pairs.find(p=>p.id===m.l);
      if(w&&!L.preview){S.miss[w.en]=(S.miss[w.en]||0)+1;save();dcMiss({id:'m:'+w.en,k:'match',prompt:w.en,ans:w.hy},'',w.hy);}
      m.l=m.r=null;
      if(L.hearts<=0)L.end='fail';
    }
  }
  renderLesson();
}
function renderLesson(){
  const el=$('lesson');
  if(!L)return;
  const pc=Math.round(Math.min(1,L.passed/L.base)*100);
  const top=`<div class="l-top"><button class="iconbtn" data-a="quit" aria-label="${esc(t('exit'))}">${IC.x}</button>${(L.combo||0)>=3?`<span class="combo" aria-live="polite">${esc(t('inRow').replace('{n}',L.combo))}</span>`:''}<div class="pbar ${(L.combo||0)>=3?'hot':''}" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pc}"><i style="width:${pc}%"></i></div><div class="hearts">${IC.heart}<span>${L.hearts}</span></div>${L.preview?`<span class="tag">${t('preview')}</span>`:''}</div>`;
  if(L.end==='saving'){
    el.innerHTML=top+`<div class="l-body"><div class="l-in"><div class="center" role="status">${gloro('thinking',130)}<p>${esc(t('saving'))}</p></div></div></div>`;
    return;
  }
  if(L.end==='done'){
    el.innerHTML=dcView(top);
    const nb=$('nxt');if(nb&&!L.dcFocus){L.dcFocus=1;}
    return;
  }
  if(L.end==='fail'){
    el.innerHTML=top+`<div class="l-body"><div class="l-in"><div class="center">${gloro('wrong',130)}<h1>${t('failT')}</h1><p>${t('failS')}</p></div></div></div><div class="l-foot"><div class="l-foot-in"><button class="btn btn-orange" data-a="retry">${t('retry')}</button><button class="btn btn-ghost" data-a="exitLesson">${t('exit')}</button></div></div>`;
    return;
  }
  if(L.fixIntro){el.innerHTML=top+`<div class="l-body"><div class="l-in"><div class="center fixintro"><div class="dsay"><div class="gl-bub">${esc(t('fixT'))}</div>${gloro('encouraging',150)}</div></div></div></div><div class="l-foot"><div class="l-foot-in"><button id="nxt" class="btn btn-orange" data-a="fixgo">${t('cont')}</button></div></div>`;const n=$('nxt');if(n)n.focus();return;}
  if(L.intro){el.innerHTML=top+lessonIntroView(L.lesson);const n=$('nxt');if(n)n.focus();return;}
  const s=cur();
  el.innerHTML=top+`<div class="l-body"><div class="l-in ${L.fresh?'enter':''}">${qView(s)}</div></div><div class="l-foot ${L.res?(L.res.ok?'ok':'no'):''}">${footView(s)}</div>`+(L.quit?`<div class="sheet-bg"><div class="sheet"><div class="onb-gl">${gloro('confused',84)}</div><h2>${t('quitT')}</h2><p>${t('quitS')}</p><button class="btn btn-orange" data-a="quitNo">${t('keep')}</button><button class="btn btn-ghost" data-a="quitYes">${t('exit')}</button></div></div>`:'');
  if(L.fresh){
    if(s.k==='listen'||s.k==='listen_type'){if(s.audio)playAudio(s.audio,s.text);else say(s.text);}
    else if(s.k==='intro'&&S.sound)say(s.en);
    if(s.k==='type'||s.k==='listen_type'||s.k==='write'){const inp=$('typed');if(inp)inp.focus();}
  }
  L.fresh=false;
  if(L.res){const n=$('nxt');if(n)n.focus();}
}
/* what the server needs to judge this step (null = cannot be verified, e.g. speaking) */
function answerPayload(s){
  if(s.k==='speak')return null;
  if(s.k==='type'||s.k==='listen_type'||s.k==='write')return {text:L.typed||''};
  if(s.k==='build')return {tokens:L.ans.map(i=>s.tiles[i])};
  return {choice:s.vals?s.vals[L.sel]:s.opts[L.sel]};
}
/* sends one answer to the server (cloud only); the verdict that comes back is the one that counts */
async function submitAnswer(s,payload,clientOk){
  const seq=L.seq=(L.seq||0)+1,ms=Math.min(600000,Date.now()-(L.t0||Date.now()));
  let last=null;
  for(let i=0;i<3;i++){
    try{return await B.econAnswer(L.att,s.id,seq,payload||{},clientOk,typeof lenientOn==='function'?lenientOn():false,ms);}
    catch(e){last=e;if(e&&e.code&&e.code!=='net')break;await new Promise(r=>setTimeout(r,900*(i+1)));}
  }
  throw last||E('net');
}
const serverJudged=()=>!!(typeof ECON==='function'&&ECON()&&L&&L.att&&!L.preview);
async function check(){
  if(!L||L.res||L.end||L.busy)return;
  const s=cur();
  if(s.k==='intro'||s.k==='match'||!canCheck(s))return;
  let ok=false,ans=s.ans||'';
  if(s.k==='speak'){ok=similar(L.typed,s.ans)>=.75;}
  else if(s.k==='type'||s.k==='listen_type'||s.k==='write'){ok=typeOk(s,L.typed);}
  else if(s.k==='build'){ok=L.ans.map(i=>s.tiles[i]).join(' ').toLowerCase()===s.words.join(' ').toLowerCase();ans=s.sent;}
  else{ok=s.opts[L.sel]===s.ans;}
  if(serverJudged()&&!s.loc){
    L.busy=true;L.netErr=false;renderLesson();
    const stepNo=L.i;
    try{
      const r=await submitAnswer(s,answerPayload(s),ok);
      if(!L||L.i!==stepNo||L.res||L.end)return;
      ok=!!r.correct;
    }catch(e){
      if(!L||L.i!==stepNo)return;
      L.busy=false;L.netErr=true;
      toast(e&&e.code&&e.code!=='net'?econErr(e):t('e_net'),'confused');renderLesson();return;
    }
    L.busy=false;
  }
  settle(s,ok,ans);
}
function settle(s,ok,ans){
  if(s.review){
    rvSettle(s,ok);
    if(ok){L.combo=(L.combo||0)+1;tone([660,880]);}else{L.combo=0;tone([220,170],.16);}
    L.passed++;
    L.res={ok,ans,expl:s.expl||'',bad:ok?'':(s.wrongMsg||''),msg:ok?mmsg('correct',true):t('bad'),say:ok?'':mmsg('wrong',true),mood:ok?'correct':'wrong'};
    renderLesson();return;
  }
  L.attempts++;
  if(ok){L.correct++;L.passed++;L.combo=(L.combo||0)+1;tone([660,880]);}
  else{
    if(L.orig==null)L.orig=L.steps.length;
    dcMiss(s,dcGiven(s));
    L.hearts--;L.combo=0;L.steps.push(Object.assign({},s));tone([220,170],.16);
    if(!serverJudged())econMiss();else if(L.att)B.econMiss(L.att).then(applyState).catch(warnErr('heart loss not recorded on the server'));
    if(s.key&&!L.preview){S.miss[s.key]=(S.miss[s.key]||0)+1;save();}
  }
  if(!L.preview&&!L.practice&&s.key)srsMark(s.key,ok);
  if(!L.preview&&s.key&&L.practice)srsMark(s.key,ok);
  L.res={ok,ans,expl:s.expl||'',bad:ok?'':(s.wrongMsg||''),msg:ok?mmsg('correct',true):t('bad'),say:ok?'':mmsg(L.hearts<=1?'wrong1':'wrong',true),mood:ok?((L.combo||0)>=3?'proud':'correct'):(L.hearts<=1?'sad':'wrong')};
  renderLesson();
}
function next(){
  if(!L||L.end)return;
  const s=cur();
  if(s.k==='intro'){L.passed++;}
  else if(!L.res)return;
  if(L.res&&!L.res.ok&&!s.review&&L.hearts<=0){L.end='fail';renderLesson();return;}
  L.i++;resetStep();
  if(L.i>=L.steps.length){finish();return;}
  if(L.orig!=null&&L.i===L.orig&&!L.fixShown){L.fixShown=true;L.fixIntro=true;renderLesson();return;}
  saveResume();
  renderLesson();
}
function saveResume(){
  if(!L||L.preview||L.practice||L.end||!L.id)return;
  if(L.i>=L.base)return;
  S.resume={id:L.id,i:L.i,n:L.base,hearts:L.hearts,attempts:L.attempts,correct:L.correct,passed:L.passed,t:Date.now()};
  save();
}
const SRS_DAYS=[0,1,2,4,8,16];
function srsMark(key,ok){
  const e=S.srs[key]||{b:0},b=ok?Math.min(5,(e.b||0)+1):0;
  S.srs[key]={b,d:dstr(new Date(Date.now()+SRS_DAYS[b]*864e5)),t:Date.now()};
}
const srsDue=key=>{const e=S.srs[key];return !e||e.d<=today();};
function skipListen(){
  if(!L||L.res||L.end)return;
  L.passed++;L.i++;resetStep();
  if(L.i>=L.steps.length){finish();return;}
  renderLesson();
}
function finish(){
  if(!L||L.end==='saving'||L.end==='done')return;
  const miss=L.attempts-L.correct;
  L.acc=L.attempts?Math.round(L.correct/L.attempts*100):100;
  if(L.preview){L.xp=0;L.end='done';renderLesson();return;}
  if(S.resume&&S.resume.id===L.id)S.resume=null;
  if(ECON()&&L.att){
    /* cloud: the database decides XP; repeated calls with the same attempt return the same answer */
    L.end='saving';renderLesson();
    const cur0=L;
    Promise.all(L.pend||[]).then(()=>{if(L.pendErr)throw L.pendErr;return econFinish(miss,L.correct);}).then(sv=>{if(L===cur0)award(sv);},e=>{if(L!==cur0)return;L.end='done';L.xp=0;L.stars=0;L.err=econErr(e);renderLesson();});
    return;
  }
  award(null);
}
function award(sv){
  try{pxDone(L);rvMixDone(L);}catch(e){}
  const miss=L.attempts-L.correct;
  const fl=!L.practice&&FLAT[L.idx],fu=fl&&fl.u;
  const unitBefore=fu?FLAT.filter(f=>f.u===fu).every(f=>S.done[f.id]):false;
  const courseBefore=fu?FLAT.every(f=>S.done[f.id]):false;
  const q0=claimable().map(q=>q.id),c0=chReady(),g0=dayXp()>=S.goal;
  const lv0=levelInfo(S.xp).level;
  let raw;
  if(L.practice){L.stars=0;raw=(G.xp.practice==null?5:G.xp.practice)+L.correct;}
  else{L.stars=sv?sv.stars:(miss===0?3:miss<=2?2:1);raw=(L.xpBase||8)+L.stars*(G.xp.star==null?4:G.xp.star);if(!sv)S.done[L.id]=Math.max(S.done[L.id]||0,L.stars);}
  if(sv){
    applyState(sv.state);
    if(!L.practice)S.done[L.id]=Math.max(S.done[L.id]||0,L.stars);
    L.raw=sv.raw||sv.xp;L.mult=sv.mult||1;L.xp=sv.xp;L.gems=sv.gems||0;L.heartBack=!!sv.heart;
    const ev=sv.streak_event||{};L.ev={froze:ev.froze||0,ms:ev.milestone||null};
    if(L.ev.froze)notify('freeze',t('n_freezeT'),t('n_freezeB').replace('{n}',L.ev.froze),'happy');
    if(L.ev.ms)notify('streak',t('n_streakT').replace('{n}',L.ev.ms.d),mmsg('streak'),'celebrating');
    L.unitDone=sv.unit_done&&fu?fu:null;
  }else{
    const unitNow=fu?FLAT.filter(f=>f.u===fu).every(f=>S.done[f.id]):false;
    L.unitDone=unitNow&&!unitBefore?fu:null;
    if(L.unitDone)raw+=G.xp.unit||0;
    L.raw=raw;L.mult=xpMult();L.xp=Math.round(raw*L.mult);
    L.ev=touchDay();addXp(L.xp);
  }
  L.courseDone=!!(fu&&!courseBefore&&FLAT.length&&FLAT.every(f=>S.done[f.id]));
  S.log=(S.log||[]).concat([{t:Date.now(),id:L.practice?'practice':L.id,xp:L.xp,acc:L.acc}]).slice(-150);
  L.newAch=evalAch();const lv1=levelInfo(S.xp).level;L.lvl=sv?(sv.level_up||0):(lv1>lv0?lv1:0);
  if(L.lvl)notify('level',t('n_levelT').replace('{n}',L.lvl),mmsg('levelup',true),'proud');
  if(L.unitDone)notify('unit',t('unitDoneT'),tx(L.unitDone.t),'proud');
  L.goalHit=!g0&&dayXp()>=S.goal;
  if(L.goalHit)notify('goal',t('n_goalT'),mmsg('goal',true),'celebrating');
  claimable().filter(q=>q0.indexOf(q.id)<0).forEach(q=>notify('quest',t('n_questT'),questTitle(q),'excited'));
  if(!c0&&chReady())notify('challenge',t('n_chT'),tx(G.challenge.title),'excited');
  save();pushProgress().then(()=>loadBoard(true));
  tone([523,659,784,1047],.14);
  A.xph=null;
  L.end='done';renderLesson();
}


/* Shrinks an uploaded picture to at most 1000 px on its long side (JPEG), so lessons stay light. */
function shrinkImage(file){
  return new Promise((ok,no)=>{
    const u=URL.createObjectURL(file),im=new Image();
    im.onload=()=>{
      const k=Math.min(1,1000/Math.max(im.width,im.height)),c=document.createElement('canvas');
      c.width=Math.max(1,Math.round(im.width*k));c.height=Math.max(1,Math.round(im.height*k));
      c.getContext('2d').drawImage(im,0,0,c.width,c.height);URL.revokeObjectURL(u);
      c.toBlob(b=>b?ok(b):no(new Error('img')),'image/jpeg',.82);
    };
    im.onerror=()=>{URL.revokeObjectURL(u);no(new Error('img'));};
    im.src=u;
  });
}
