/* ---------- admin-editable platform rules (table `settings`, key 'game') ---------- */
const clone=o=>JSON.parse(JSON.stringify(o));
const DEF_GAME={
  xp:{star:4,practice:5,unit:20},
  multiplier:{value:1,until:'',label:{hy:'Կրկնակի XP',en:'Double XP'}},
  quests:[{id:'xp',type:'xp',n:30,r:10},{id:'lessons',type:'lessons',n:2,r:15},{id:'perfect',type:'perfect',n:1,r:20}],
  achievements:[],
  streak:{maxFreeze:2,milestones:[{d:3,xp:15,freeze:0,boost:0},{d:7,xp:40,freeze:1,boost:15},{d:14,xp:80,freeze:1,boost:30},{d:30,xp:200,freeze:2,boost:60}]},
  challenge:{on:true,type:'xp',n:150,r:50,title:{hy:'Շաբաթվա մարտահրավեր',en:'Weekly challenge'}},
  leagues:{names:[{hy:'Բրոնզե',en:'Bronze'},{hy:'Արծաթե',en:'Silver'},{hy:'Ոսկե',en:'Gold'},{hy:'Շափյուղա',en:'Sapphire'},{hy:'Ադամանդ',en:'Diamond'}],promote:120,demote:20}
};
let G=clone(DEF_GAME);
function setGame(v){
  const g=clone(DEF_GAME);
  if(v&&typeof v==='object')Object.keys(g).forEach(k=>{
    if(v[k]===undefined)return;
    g[k]=Array.isArray(g[k])?(Array.isArray(v[k])?v[k]:g[k]):Object.assign({},g[k],v[k]);
  });
  G=g;
  QUESTS=G.quests.filter(q=>q&&q.id&&q.n>0).map(q=>Object.assign({type:q.id},q));
}
const leagueNames=()=>G.leagues.names&&G.leagues.names.length?G.leagues.names:DEF_GAME.leagues.names;
const leagueName=i=>tx(leagueNames()[Math.max(0,Math.min(i||0,leagueNames().length-1))]);
const weekStart=d=>{d=new Date(d);d.setDate(d.getDate()-((d.getDay()+6)%7));return dstr(d);};
const curWeek=()=>weekStart(new Date());
const weekLog=w=>(S.log||[]).filter(e=>weekStart(new Date(e.t))===w);
const weekXpCal=()=>weekLog(curWeek()).reduce((n,e)=>n+e.xp,0);
function chProg(){
  const c=G.challenge,L=weekLog(curWeek()),ls=L.filter(e=>e.id!=='practice');
  const v=c.type==='lessons'?ls.length:c.type==='days'?new Set(L.map(e=>dstr(new Date(e.t)))).size:c.type==='perfect'?ls.filter(e=>e.acc===100).length:L.reduce((n,e)=>n+e.xp,0);
  return Math.min(c.n,v);
}
const chClaimed=()=>!!(S.wc&&S.wc.w===curWeek()&&S.wc.ok);
const chReady=()=>G.challenge.on&&G.challenge.n>0&&!chClaimed()&&chProg()>=G.challenge.n;
function claimChallenge(){
  if(!chReady())return false;
  S.wc={w:curWeek(),ok:true};addXp(G.challenge.r||0);
  notify('challenge',tx(G.challenge.title),'+'+(G.challenge.r||0)+' XP','celebrating');
  save();pushProgress();return true;
}
/* Leagues: once a week the learner's XP for the finished week decides promotion or demotion. */
function leagueTick(){
  if(ECON())return;   /* cloud: the server (league_tick) decides promotion and pays the reward */
  const cw=curWeek();
  if(!S.league||typeof S.league.tier!=='number')S.league={tier:0,w:cw};
  if(S.league.w===cw)return;
  const pw=weekStart(new Date(new Date(cw+'T12:00:00').getTime()-7*864e5)),xp=weekLog(pw).reduce((n,e)=>n+e.xp,0),max=leagueNames().length-1;
  let tier=S.league.tier;
  if(xp>=G.leagues.promote&&tier<max){tier++;notify('league',t('n_leagueUp'),leagueName(tier),'proud');}
  else if(xp<G.leagues.demote&&tier>0){tier--;notify('league',t('n_leagueDown'),leagueName(tier),'encouraging');}
  S.league={tier,w:cw};save();pushProgress();
}

