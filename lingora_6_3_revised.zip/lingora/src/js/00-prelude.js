const CFG=window.EE_CONFIG||{};
const WANT_CLOUD=!!(CFG.SUPABASE_URL&&CFG.SUPABASE_ANON_KEY);
const MODE=WANT_CLOUD?'cloud':(CFG.DEMO?'demo':'local');
const SB_SRC='https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js';
