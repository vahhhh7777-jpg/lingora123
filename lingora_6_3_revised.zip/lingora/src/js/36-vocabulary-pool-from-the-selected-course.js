/* ---------- vocabulary pool from the selected course ---------- */
function pxWords(){
  const all=[];(UNITS||[]).forEach(u=>{if(!u.locked)(u.words||[]).forEach(w=>{if(w&&w.en&&w.hy)all.push(w);});});
  const met=all.filter(w=>wordMet(w));
  return {all,met};
}
function pxSents(){const o=[];(UNITS||[]).forEach(u=>{if(!u.locked&&FLAT.some(f=>f.u===u&&S.done[f.id]))(u.sents||[]).forEach(s=>{if(s&&s.en&&s.hy)o.push(s);});});return o;}
function pxDueCards(){
  const {all,met}=pxWords();
  // Flashcards must only contain words the learner has actually met.
  // Never seed a new learner's review queue with arbitrary course vocabulary.
  return met.filter(w=>srsDue(wordKey(w)));
}

