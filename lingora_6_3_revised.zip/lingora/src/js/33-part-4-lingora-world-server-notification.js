/* ---------- PART 4: Lingora World, server notifications, leagues + challenges, AI coach, weak-topic analysis ----------
   Everything here is cloud-only and talks to RPCs / the ai-coach Edge Function from migration 010. In demo / local mode the views
   say so plainly instead of inventing data. No API key exists in the browser: the AI coach is called through the server. */
Object.assign(UI.hy,{
 worldNeed:'Աշխարհը պահվում է հաշվիդ մեջ։ Մուտք գործիր։',worldLoad:'Բեռնվում է…',worldErr:'Չհաջողվեց բեռնել աշխարհը։',
 wRoom:'Սենյակ',wCostume:'Հագուստ',wDecor:'Զարդեր',wNone:'Ոչինչ',wSave:'Պահպանել',wReset:'Չեղարկել փոփոխությունները',wSaved:'Աշխարհը պահպանվեց։',wUnsaved:'Չպահպանված փոփոխություններ',wEmptyInv:'Դեռ զարդեր չունես։ Գնիր խանութից։',wShop:'Խանութ',
 wMove:'Տեղափոխել',wLeft:'Ձախ',wRight:'Աջ',wUp:'Վերև',wDown:'Ներքև',wRemove:'Հեռացնել',wAdd:'Ավելացնել',wSel:'Ընտրված՝ ',wKeys:'Ընտրիր զարդը, ապա սլաքներով (կամ քաշելով) տեղափոխիր։',
 slot_head:'Գլխի',slot_eyes:'Աչքերի',slot_neck:'Պարանոցի',
 sn_ach:'Նոր նվաճում',sn_streak:'{n} օր անընդմեջ',sn_fr:'Ընկերության հարցում',sn_fr2:'Ընկերության հարցումդ ընդունվեց',sn_mission:'Առաջադրանքը կատարված է',sn_vip:'VIP կարգավիճակը փոխվեց',sn_ch_invite:'Մարտահրավեր ընկերոջից',sn_ch_accepted:'Մարտահրավերը ընդունվեց',sn_ch_won:'Հաղթեցիր մարտահրավերում',sn_ch_lost:'Մարտահրավերը ավարտվեց',sn_ch_tie:'Մարտահրավերը ավարտվեց ոչ-ոքի',sn_lg_up:'Բարձրացար լիգայում',sn_lg_down:'Իջար լիգայում',
 st_nSocial:'Ընկերներ և մարտահրավերներ',st_nSocialD:'Ընկերության հարցումներ, մարտահրավերներ',ntMark:'Նշել բոլորը կարդացված',
 ch2T:'Մարտահրավերներ',chSub:'Ով ավելի շատ XP կվաստակի ընտրված օրերի ընթացքում։ Արդյունքը հաշվում է սերվերը։',chNeed:'Մարտահրավերի համար պետք է ընկեր։',chNew:'Մարտահրավեր',chDays:'օր',chPending:'Սպասում է պատասխանի',chInvite:'Քեզ մարտահրավեր է նետում',chAcc:'Ընդունել',chDec:'Մերժել',chActive:'Ընթացքի մեջ',ch2Ends:'Ավարտ',chWon:'Հաղթեցիր',chLost:'Պարտվեցիր',chTie:'Ոչ-ոքի',chHidden:'թաքնված է',chExists:'Այս ընկերոջ հետ արդեն կա բաց մարտահրավեր։',chDone:'Կատարվեց։',chYou:'Դու',
 leagueWeek:'Շաբաթվա XP',leagueRule:'Բարձրանալու համար անհրաժեշտ է {p} XP շաբաթվա մեջ, իջնում ես {d} XP-ից պակասի դեպքում։',
 aiT:'AI մարզիչ',aiNeedCloud:'AI մարզիչը աշխատում է հաշվով և սերվերով։ Մուտք գործիր (Supabase ռեժիմ)։',aiNotCfg:'AI մարզիչը դեռ կարգավորված չէ։ Ադմինը պետք է տեղադրի ai-coach ֆունկցիան և ավելացնի ANTHROPIC_API_KEY գաղտնաբառը (տես README)։ Կեղծ պատասխաններ չենք ցույց տալիս։',
 aiPlan:'Վերլուծել իմ առաջընթացը',aiExplain:'Բացատրել սխալս',aiEx:'Ստեղծել վարժություններ',aiAsk:'Հարց',aiAskPh:'Հարցրու ուսուցման մասին…',aiSend:'Ուղարկել',aiThinking:'Մարզիչը մտածում է…',aiUsage:'Այսօր՝ {u}/{l}',aiLimit:'Այսօրվա սահմանաչափը լրացել է։ VIP-ները ավելի շատ հարցում ունեն։',aiBudget:'AI-ի ամսական բյուջեն սպառվել է։',aiDisabled:'AI մարզիչը ժամանակավորապես անջատված է։',aiFail:'AI մարզիչը չպատասխանեց։ Փորձիր ավելի ուշ։',aiPickMist:'Ընտրիր սխալ',aiNoMist:'Սխալների գիրքը դատարկ է։',aiTopic:'Թեմա (ըստ ցանկության)',aiCheck:'Ստուգել',aiWhy:'Ինչու',aiAnswered:'Պատասխանել',aiClear:'Մաքրել',aiNote:'Պատասխանները ստեղծում է արհեստական բանականությունը և կարող են սխալ լինել։',aiYou:'Դու',
 wkT:'Թույլ թեմաներ',wkNone:'Դեռ թույլ թեմաներ չկան։',wkOpen:'բաց',wkRep:'կրկնվող սխալներ',rec2T:'Խորհուրդ ենք տալիս',rec2Rev:'Կրկնել',rec2Next:'Հաջորդը',recStart:'Սկսել',histT:'Կրկնության պատմություն',histNone:'Դեռ պատմություն չկա։',histOk:'ճիշտ',histBad:'սխալ',
 admAi:'AI',admAiCalls:'Հարցումներ (այսօր)',admAiMonth:'Հարցումներ (ամիս)',admAiCost:'Արժեք (ամիս)',admAiTok:'Թոքեններ (ամիս)',admAiBudget:'Ամսական բյուջե',admAiCfg:'Կարգավորում (JSON՝ enabled, daily_free, daily_vip, monthly_budget_micro)',p3mShop:'Խանութ'
});
Object.assign(UI.en,{
 worldNeed:'Your world is saved to your account. Please sign in.',worldLoad:'Loading…',worldErr:'Could not load your world.',
 wRoom:'Room',wCostume:'Costume',wDecor:'Decorations',wNone:'None',wSave:'Save',wReset:'Discard changes',wSaved:'World saved.',wUnsaved:'Unsaved changes',wEmptyInv:'You have no decorations yet. Buy some in the shop.',wShop:'Shop',
 wMove:'Move',wLeft:'Left',wRight:'Right',wUp:'Up',wDown:'Down',wRemove:'Remove',wAdd:'Add',wSel:'Selected: ',wKeys:'Select a decoration, then move it with the arrow keys (or drag it).',
 slot_head:'Head',slot_eyes:'Eyes',slot_neck:'Neck',
 sn_ach:'New achievement',sn_streak:'{n}-day streak',sn_fr:'Friend request',sn_fr2:'Your friend request was accepted',sn_mission:'Mission completed',sn_vip:'Your VIP status changed',sn_ch_invite:'Challenge from a friend',sn_ch_accepted:'Challenge accepted',sn_ch_won:'You won a challenge',sn_ch_lost:'A challenge has ended',sn_ch_tie:'A challenge ended in a tie',sn_lg_up:'You moved up a league',sn_lg_down:'You moved down a league',
 st_nSocial:'Friends and challenges',st_nSocialD:'Friend requests and challenges',ntMark:'Mark all read',
 ch2T:'Challenges',chSub:'Whoever earns more XP during the chosen days wins. The server counts the result.',chNeed:'You need a friend to start a challenge.',chNew:'Challenge',chDays:'days',chPending:'Waiting for an answer',chInvite:'challenges you',chAcc:'Accept',chDec:'Decline',chActive:'In progress',ch2Ends:'Ends',chWon:'You won',chLost:'You lost',chTie:'Tie',chHidden:'hidden',chExists:'You already have an open challenge with this friend.',chDone:'Done.',chYou:'You',
 leagueWeek:'XP this week',leagueRule:'Earn {p} XP in a week to move up; below {d} XP you move down.',
 aiT:'AI coach',aiNeedCloud:'The AI coach needs an account and the server. Sign in (Supabase mode).',aiNotCfg:'The AI coach is not configured yet. An administrator must deploy the ai-coach function and add the ANTHROPIC_API_KEY secret (see README). We never show made-up answers.',
 aiPlan:'Analyse my progress',aiExplain:'Explain a mistake',aiEx:'Generate exercises',aiAsk:'Ask',aiAskPh:'Ask about learning…',aiSend:'Send',aiThinking:'The coach is thinking…',aiUsage:'Today: {u}/{l}',aiLimit:'Today’s limit is used up. VIP members get more requests.',aiBudget:'The monthly AI budget is used up.',aiDisabled:'The AI coach is temporarily switched off.',aiFail:'The AI coach did not answer. Try again later.',aiPickMist:'Pick a mistake',aiNoMist:'Your mistake book is empty.',aiTopic:'Topic (optional)',aiCheck:'Check',aiWhy:'Why',aiAnswered:'Answer',aiClear:'Clear',aiNote:'Answers are written by an AI and can be wrong.',aiYou:'You',
 wkT:'Weak topics',wkNone:'No weak topics yet.',wkOpen:'open',wkRep:'repeated mistakes',rec2T:'Recommended for you',rec2Rev:'Review',rec2Next:'Next',recStart:'Start',histT:'Revision history',histNone:'No history yet.',histOk:'right',histBad:'wrong',
 admAi:'AI',admAiCalls:'Requests (today)',admAiMonth:'Requests (month)',admAiCost:'Cost (month)',admAiTok:'Tokens (month)',admAiBudget:'Monthly budget',admAiCfg:'Configuration (JSON: enabled, daily_free, daily_vip, monthly_budget_micro)',p3mShop:'Shop'
});
const P4=()=>MODE==='cloud'&&!!A.user&&!!B&&!!B.myWorld;
const p4err=e=>(e&&e.code&&t('e_'+e.code))||t('e_other');

/* ===== Lingora World ===== */
const W4={world:null,inv:[],loading:false,err:false,busy:false,draft:null,sel:-1,dirty:false,drag:null};
const p4clone=o=>JSON.parse(JSON.stringify(o));
async function worldRefresh(){
  const b=SB();if(!ECON()||!b||!b.myWorld)return;
  try{const r=await b.myWorld();W4.inv=r.inventory||[];W4.world=r.world;if(!W4.dirty)W4.draft=p4clone(r.world);W4.err=false;}catch(e){W4.err=true;}
}
async function worldLoad(){
  if(W4.loading||W4.world||!ECON())return;
  W4.loading=true;await worldRefresh();
  if(SHOP.items===null&&!SHOP.loading)await loadShop();
  W4.loading=false;if(tab==='world')render();
}
const wItem=id=>(SHOP.items||[]).find(x=>x.id===id);
const wEmoji=id=>{const it=wItem(id);return it&&it.payload&&it.payload.emoji||'⭐';};
const wTitle=id=>{const it=wItem(id);return it?itemTitle(it):id;};
const ownedOf=(cat,slot)=>(SHOP.items||[]).filter(x=>x.kind==='cosmetic'&&x.category===cat&&(!slot||x.slot===slot)&&((W4.inv||[]).indexOf(x.id)>=0||(x.category==='room'&&x.price_gems===0)));
function worldScene(w,edit){
  const room=wItem(w.room),p=(room&&room.payload)||{sky:['#efe7ff','#d9c9ff'],floor:'#c9b2f5'};
  const eq=w.equipped||{};
  const dec=(w.decor||[]).map((d,i)=>`<button type="button" class="w-dec ${edit&&W4.sel===i?'sel':''}" style="left:${d.x}%;top:${d.y}%" data-a="wsel" data-v="${i}" data-wd="${i}" aria-label="${esc(wTitle(d.item))} (${Math.round(d.x)}%, ${Math.round(d.y)}%)" aria-pressed="${edit&&W4.sel===i}" ${edit?'':'tabindex="-1"'}><span aria-hidden="true">${esc(wEmoji(d.item))}</span></button>`).join('');
  const cos=['head','eyes','neck'].map(k=>eq[k]?`<span class="w-cos w-${k}" aria-hidden="true">${esc(wEmoji(eq[k]))}</span>`:'').join('');
  return `<div class="world" id="wscene" role="group" aria-label="${esc(t('world'))}" style="--sky1:${esc(p.sky[0])};--sky2:${esc(p.sky[1])};--floor:${esc(p.floor||'#ccc')}"><div class="w-floor"></div>${dec}<div class="w-gir">${gloro('happy',118)}${cos}</div></div>`;
}
function worldView(){
  const head=`<section class="shop-head"><div>${gloro('happy',72)}</div><div><h1>${t('world')}</h1><p>${t('worldSub')}</p></div></section>`;
  if(!ECON())return `${head}<section class="card"><p>${t('worldNeed')}</p><button class="btn btn-purple" data-a="signinfirst" data-v="world">${t('signin')}</button></section>`;
  if(!W4.world&&!W4.err)setTimeout(worldLoad,0);
  if(W4.err&&!W4.world)return `${head}<div class="empty"><span>${t('worldErr')}</span><button class="btn ghost" data-a="wretry">${t('retry')}</button></div>`;
  if(!W4.world||!SHOP.items)return `${head}<div role="status" aria-label="${esc(t('worldLoad'))}">${skel(3)}</div>`;
  const w=W4.draft||W4.world;
  const rooms=ownedOf('room').map(r=>`<button type="button" class="chip ${w.room===r.id?'on':''}" data-a="wroom" data-v="${esc(r.id)}" aria-pressed="${w.room===r.id}">${esc(itemTitle(r))}</button>`).join('');
  const slots=['head','eyes','neck'].map(k=>{const opts=ownedOf('costume',k);return `<label class="w-slot"><span>${esc(t('slot_'+k))}</span><select data-wslot="${k}" aria-label="${esc(t('wCostume')+': '+t('slot_'+k))}"><option value="">${esc(t('wNone'))}</option>${opts.map(o=>`<option value="${esc(o.id)}" ${(w.equipped||{})[k]===o.id?'selected':''}>${esc((o.payload&&o.payload.emoji||'')+' '+itemTitle(o))}</option>`).join('')}</select></label>`;}).join('');
  const decOwned=ownedOf('item','decor');
  const palette=decOwned.length?decOwned.map(o=>`<button type="button" class="chip" data-a="wadd" data-v="${esc(o.id)}" aria-label="${esc(t('wAdd')+': '+itemTitle(o))}"><span aria-hidden="true">${esc(o.payload&&o.payload.emoji||'⭐')}</span> ${esc(itemTitle(o))}</button>`).join(''):`<p class="note">${t('wEmptyInv')} <button class="link" data-a="tab" data-v="shop">${t('wShop')}</button></p>`;
  const sel=w.decor&&w.decor[W4.sel];
  const pad=sel?`<div class="w-pad" role="group" aria-label="${esc(t('wMove'))}"><span class="note">${esc(t('wSel'))}${esc(wTitle(sel.item))}</span>
    <button type="button" class="sbtn" data-a="wmove" data-dx="0" data-dy="-5" aria-label="${esc(t('wUp'))}">↑</button><button type="button" class="sbtn" data-a="wmove" data-dx="-5" data-dy="0" aria-label="${esc(t('wLeft'))}">←</button><button type="button" class="sbtn" data-a="wmove" data-dx="5" data-dy="0" aria-label="${esc(t('wRight'))}">→</button><button type="button" class="sbtn" data-a="wmove" data-dx="0" data-dy="5" aria-label="${esc(t('wDown'))}">↓</button>
    <button type="button" class="sbtn danger" data-a="wdel">${esc(t('wRemove'))}</button></div>`:'';
  return `${head}${worldScene(w,true)}<p class="note w-keys">${esc(t('wKeys'))}</p>${pad}
   <section class="card w-panel"><h2>${esc(t('wRoom'))}</h2><div class="chips">${rooms}</div><h2>${esc(t('wCostume'))}</h2><div class="w-slots">${slots}</div><h2>${esc(t('wDecor'))}</h2><div class="chips">${palette}</div>
   <div class="acts"><button class="btn btn-orange" data-a="wsave" ${W4.dirty&&!W4.busy?'':'disabled'}>${W4.busy?'…':esc(t('wSave'))}</button>${W4.dirty?`<button class="btn btn-ghost" data-a="wreset">${esc(t('wReset'))}</button><span class="note" role="status">${esc(t('wUnsaved'))}</span>`:''}</div></section>`;
}
function wDirty(){W4.dirty=true;render();if(W4.sel>=0)setTimeout(()=>{const e=document.querySelector('.w-dec.sel');if(e)try{e.focus();}catch(x){}},0);}
const wClamp=v=>Math.max(0,Math.min(100,Math.round(v*10)/10));
function wMoveSel(dx,dy){const d=W4.draft&&W4.draft.decor[W4.sel];if(!d)return;d.x=wClamp(d.x+dx);d.y=wClamp(d.y+dy);wDirty();}
async function wSave(){
  if(!W4.dirty||W4.busy)return;W4.busy=true;render();
  try{const r=await SB().setWorld(W4.draft.room,W4.draft.equipped||{},W4.draft.decor||[]);W4.world=r;W4.draft=p4clone(r);W4.dirty=false;toast(t('wSaved'),'celebrating');}
  catch(e){toast(p4err(e),'confused');}
  W4.busy=false;render();
}
/* drag with pointer events; keyboard arrows on a focused decoration */
document.addEventListener('pointerdown',e=>{
  const b=e.target.closest&&e.target.closest('.w-dec');if(!b||tab!=='world'||!W4.draft)return;
  const i=+b.dataset.wd;W4.sel=i;W4.drag={i,moved:false,sx:e.clientX,sy:e.clientY};
  try{b.setPointerCapture(e.pointerId);}catch(x){}
});
document.addEventListener('pointermove',e=>{
  const g=W4.drag;if(!g)return;
  const sc=document.getElementById('wscene');if(!sc)return;
  if(!g.moved&&Math.abs(e.clientX-g.sx)+Math.abs(e.clientY-g.sy)<6)return;
  g.moved=true;const r=sc.getBoundingClientRect(),d=W4.draft.decor[g.i];if(!d)return;
  d.x=wClamp((e.clientX-r.left)/r.width*100);d.y=wClamp((e.clientY-r.top)/r.height*100);
  const el=sc.querySelector(`[data-wd="${g.i}"]`);if(el){el.style.left=d.x+'%';el.style.top=d.y+'%';}
});
document.addEventListener('pointerup',()=>{const g=W4.drag;if(!g)return;W4.drag=null;if(g.moved){W4.dirty=true;render();}});
document.addEventListener('keydown',e=>{
  if(tab!=='world'||!e.target.closest||!e.target.closest('.w-dec')||!W4.draft)return;
  const k={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];
  if(k){e.preventDefault();const s=e.shiftKey?10:2;W4.sel=+e.target.closest('.w-dec').dataset.wd;wMoveSel(k[0]*s,k[1]*s);}
  else if(e.key==='Delete'||e.key==='Backspace'){e.preventDefault();W4.sel=+e.target.closest('.w-dec').dataset.wd;wDelSel();}
});
function wDelSel(){if(W4.sel<0||!W4.draft)return;W4.draft.decor.splice(W4.sel,1);W4.sel=-1;wDirty();}
document.addEventListener('change',e=>{
  const k=e.target&&e.target.dataset&&e.target.dataset.wslot;if(!k||!W4.draft)return;
  W4.draft.equipped=Object.assign({},W4.draft.equipped);if(e.target.value)W4.draft.equipped[k]=e.target.value;else delete W4.draft.equipped[k];
  W4.dirty=true;render();
});

/* ===== server notifications (merged into the bell panel) ===== */
const NT={at:0,first:true,busy:false,timer:0};
function ntText(n){
  const d=n.data||{};
  switch(n.kind){
    case 'achievement':return [t('sn_ach'),tx(d.title)||'','excited'];
    case 'streak':return [t('sn_streak').replace('{n}',d.days),'','celebrating'];
    case 'friend_request':return [t('sn_fr'),d.from||'','wave'];
    case 'friend_accepted':return [t('sn_fr2'),d.from||'','happy'];
    case 'mission':return [t('sn_mission'),'','celebrating'];
    case 'vip':return [t('sn_vip'),'','proud'];
    case 'league':return [d.up?t('sn_lg_up'):t('sn_lg_down'),typeof leagueName==='function'?leagueName(d.tier||0):'',d.up?'proud':'encouraging'];
    case 'challenge':return [d.state==='invite'?t('sn_ch_invite'):d.state==='accepted'?t('sn_ch_accepted'):d.tie?t('sn_ch_tie'):d.won?t('sn_ch_won'):t('sn_ch_lost'),d.from||'','excited'];
    default:return [String(n.kind),'','happy'];
  }
}
async function ntLoad(){
  if(!P4()||NT.busy)return;
  NT.busy=true;
  try{
    const r=await B.myNotifs(40);
    if(!S.notifs)S.notifs=[];
    let added=0;
    (r.rows||[]).slice().reverse().forEach(n=>{
      const id='srv:'+n.id,have=S.notifs.find(x=>x.id===id);
      if(have){have.read=!!n.read_at||have.read;return;}
      const tx2=ntText(n);
      S.notifs.unshift({id,t:Date.parse(n.created_at),kind:'srv_'+n.kind,title:tx2[0],body:tx2[1],mood:tx2[2],read:!!n.read_at});added++;
      if(!NT.first&&!n.read_at&&!L)toast((tx2[0]+(tx2[1]?' · '+tx2[1]:'')).trim(),tx2[2],4200);
    });
    S.notifs.sort((a,b)=>b.t-a.t);S.notifs=S.notifs.slice(0,60);
    NT.first=false;if(added)save();
    if(added&&!notifOpen&&!L&&(tab==='home'||tab==='friends'))render();
  }catch(e){console.warn('notification poll failed',e);}
  NT.busy=false;
}
function ntMarkServer(){if(P4()){const ids=(S.notifs||[]).filter(n=>n.id.indexOf('srv:')===0&&!n.read).map(n=>+n.id.slice(4));B.notifsRead(ids.length?ids:null).catch(warnErr('notifications: mark-read failed'));}}
const NSRV={ach:['achievement'],streak:['streak'],quest:['mission','challenge'],league:['league'],social:['friend_request','friend_accepted']};
function ntPushPrefs(){
  if(!P4())return;const o={};
  Object.keys(NSRV).forEach(g=>NSRV[g].forEach(k=>{o[k]=!S.nset||S.nset[g]!==false;}));
  B.setNotifyPrefs(o).catch(warnErr('notifications: preferences not saved'));
}

/* ===== leagues (server decides promotion and the reward) ===== */
async function leagueSync(){
  if(!P4())return;
  try{const r=await B.leagueTick();A.league=r;S.league={tier:r.tier,w:r.week};save();if(r.changed&&(tab==='rank'||tab==='home'))render();}catch(e){console.warn('league tick failed',e);}
}

/* ===== challenges ===== */
const CH={rows:null,busy:false,err:false,days:3};
async function chLoad(force){
  if(!P4()||CH.busy||(CH.rows&&!force))return;
  CH.busy=true;try{CH.rows=await B.challenges();CH.err=false;}catch(e){CH.err=true;CH.rows=CH.rows||[];}
  CH.busy=false;if(tab==='friends'||tab==='rank')render();
}
function challengeRow(c){
  const when=c.ends_at?new Date(c.ends_at).toLocaleDateString():'';
  let st='',acts='';
  if(c.status==='pending'){st=c.mine?t('chPending'):`${esc(c.other)} ${esc(t('chInvite'))}`;
    if(!c.mine)acts=`<button class="sbtn good" data-a="chacc" data-id="${esc(c.id)}">${esc(t('chAcc'))}</button><button class="sbtn" data-a="chdec" data-id="${esc(c.id)}">${esc(t('chDec'))}</button>`;}
  else if(c.status==='active')st=`${esc(t('chActive'))} · ${esc(t('ch2Ends'))} ${esc(when)}`;
  else if(c.status==='finished')st=c.won?t('chWon'):c.winner_other?t('chLost'):t('chLost');
  if(c.status==='finished'&&c.won===false)st=t('chLost');
  const score=c.status==='active'||c.status==='finished'?`<span class="ch-sc">${esc(t('chYou'))} <b>${nfmt(c.my_xp||0)}</b> : <b>${c.their_xp==null?esc(t('chHidden')):nfmt(c.their_xp)}</b> ${esc(c.other)}</span>`:'';
  return `<li class="fr-row ch-row"><div class="fr-t"><b>${esc(c.other)}</b><small>${st} · ${c.days} ${esc(t('chDays'))}</small>${score}</div><div class="fr-acts">${acts}</div></li>`;
}
function challengesCard(){
  if(!P4())return '';
  chLoad();
  const fr=friendRows();
  const open=new Set((CH.rows||[]).filter(c=>c.status==='pending'||c.status==='active').map(c=>c.friendship));
  const pick=fr.length?`<div class="ch-new"><label class="fld"><span class="sr">${esc(t('chDays'))}</span><select id="chdays" aria-label="${esc(t('chDays'))}">${[1,3,7].map(n=>`<option value="${n}" ${CH.days===n?'selected':''}>${n} ${esc(t('chDays'))}</option>`).join('')}</select></label>
    ${fr.map(f=>`<button class="sbtn" data-a="chnew" data-id="${esc(f.id)}" ${open.has(f.id)||CH.busy?'disabled':''} aria-label="${esc(t('chNew')+': '+f.name)}">${LI('trophy')}${esc(f.name)}</button>`).join('')}</div>`:`<p class="note">${esc(t('chNeed'))}</p>`;
  const rows=(CH.rows||[]);
  return `<section class="c2 ch-card"><h2>${LI('trophy')}${esc(t('ch2T'))}</h2><p class="note">${esc(t('chSub'))}</p>${pick}${CH.err?`<p class="note">${esc(t('frErr'))}</p>`:''}${rows.length?`<ul class="fr-list">${rows.map(challengeRow).join('')}</ul>`:''}</section>`;
}
async function chAction(a,d){
  if(CH.busy)return;CH.busy=true;render();
  try{
    if(a==='chnew'){const days=+(($('chdays')||{}).value)||CH.days;CH.days=days;await B.challengeCreate(d.id,days);}
    else await B.challengeRespond(d.id,a==='chacc');
    toast(t('chDone'),'celebrating');
  }catch(e){toast(e&&e.message&&/exists/.test(e.message)||e&&e.code==='exists'?t('chExists'):p4err(e),'confused');}
  CH.busy=false;CH.rows=null;await chLoad(true);
}
function leagueCard(){
  const l=A.league;if(!P4()||!l)return '';
  return `<section class="c2 lg-card"><h2>${LI('trophy')}${esc(t('leagueT'))}: ${esc(typeof leagueName==='function'?leagueName(l.tier):l.tier)}</h2><p>${esc(t('leagueWeek'))}: <b>${nfmt(l.week_xp||0)}</b></p><p class="note">${esc(t('leagueRule').replace('{p}',l.promote_xp).replace('{d}',l.demote_xp))}</p></section>`;
}

/* ===== AI coach (all calls go through the ai-coach Edge Function) ===== */
const AI={usage:null,busy:false,out:null,err:'',ex:null,pick:null,topic:'',text:'',lastMode:''};
async function aiLoadUsage(){if(!P4()||AI.usage)return;try{AI.usage=(await B.aiUsage())||{enabled:true,used:0,limit:0};}catch(e){AI.usage={enabled:true,used:0,limit:0};}if(tab==='ai')render();}
const AI_ERR={ai_not_configured:'aiNotCfg',limit:'aiLimit',budget:'aiBudget',disabled:'aiDisabled',timeout:'aiTimeout',provider_error:'aiProv',bad_output:'aiBad',rate_limited:'aiRate',denied:'aiDenied',unauthorized:'aiAuth',net:'aiNet'};
async function aiAsk(mode,extra){
  if(AI.busy||!P4())return;
  AI.busy=true;AI.err='';AI.out=null;AI.ex=null;AI.lastMode=mode;render();
  try{
    const r=await B.askCoach(Object.assign({mode,lang:S.lang},extra||{}));
    if(r.mode==='exercises')AI.ex=r.exercises.map(x=>Object.assign({},x,{chosen:''}));else AI.out=r.text;
    if(r.usage)AI.usage=Object.assign({},AI.usage,{used:r.usage.used,limit:r.usage.limit});
  }catch(e){const k=AI_ERR[e&&e.code];AI.err=k?t(k):t('aiFail');if(e&&(e.code==='limit'||e.code==='budget'))AI.usage=null;}
  AI.busy=false;render();
}

/* ===== AI tutor chat: mode "tutor" of the ai-coach function (multi-turn, CEFR level, corrections with explanations) =====
   The conversation lives in the browser (sessionStorage, cleared on sign-out) and the last 12 turns are sent with every request,
   so the server stays stateless and nothing is stored about what the learner wrote. */
Object.assign(UI.hy,{aiLevelT:'Մակարդակ',aiChatT:'Խոսակցական վարժանք',aiChatEmpty:'Գրիր նախադասություն {l} լեզվով՝ սկսելու համար։ Ես կպատասխանեմ և կուղղեմ սխալներդ։',aiTyp_grammar:'Քերականություն',aiTyp_vocabulary:'Բառապաշար',aiTyp_spelling:'Ուղղագրություն',aiTyp_word_order:'Բառերի կարգ',aiTyp_register:'Ոճ',aiTyp_other:'Այլ',aiFix:'Ուղղումներ',aiPerfect:'Սխալներ չկան։ Ապրես։',aiShowTr:'Ցույց տալ թարգմանությունը',aiHideTr:'Թաքցնել թարգմանությունը',aiNewWords:'Նոր բառեր',aiClearChat:'Նոր խոսակցություն',aiTimeout:'Մարզիչը չափազանց երկար սպասեցրեց։ Հաղորդագրությունդ չհաշվվեց։ Փորձիր կրկին։',aiProv:'AI ծառայությունը հիմա հասանելի չէ։ Հաղորդագրությունդ չհաշվվեց։',aiBad:'Մարզիչը անհասկանալի պատասխան տվեց։ Հաղորդագրությունդ չհաշվվեց։ Փորձիր կրկին։',aiRate:'Չափազանց շատ հարցումներ։ Մի քիչ սպասիր։',aiDenied:'Այս հաշվով AI մարզիչը հասանելի չէ։',aiAuth:'Մուտք գործիր կրկին։',aiNet:'Կապ չկա։ Հաղորդագրությունդ չհաշվվեց։',aiChatPh:'Գրիր {l} լեզվով…',aiThread:'Խոսակցություն'});
Object.assign(UI.en,{aiLevelT:'Level',aiChatT:'Practice conversation',aiChatEmpty:'Write a sentence in {l} to start. I will reply and correct your mistakes.',aiTyp_grammar:'Grammar',aiTyp_vocabulary:'Vocabulary',aiTyp_spelling:'Spelling',aiTyp_word_order:'Word order',aiTyp_register:'Style',aiTyp_other:'Other',aiFix:'Corrections',aiPerfect:'No mistakes. Well done!',aiShowTr:'Show translation',aiHideTr:'Hide translation',aiNewWords:'New words',aiClearChat:'New conversation',aiTimeout:'The coach took too long. Your message was not counted. Try again.',aiProv:'The AI service is unavailable right now. Your message was not counted.',aiBad:'The coach gave an unusable answer. Your message was not counted. Try again.',aiRate:'Too many requests. Please wait a little.',aiDenied:'The AI coach is not available for this account.',aiAuth:'Please sign in again.',aiNet:'No connection. Your message was not counted.',aiChatPh:'Write in {l}…',aiThread:'Conversation'});
const AI_LEVELS=['A1','A2','B1','B2','C1','C2'],AI_LANGS=['en','fr','de','it','tr','az','ru','es','pt','ja','ko','zh','ar','hy'];
Object.assign(AI,{chat:[],level:'',key:'',tr:{}});
const aiLang=()=>{const c=curCourse(),l=c&&c.raw&&c.raw.language_id;return AI_LANGS.indexOf(l)>=0?l:'en';};
const aiLvl=()=>{if(AI_LEVELS.indexOf(AI.level)<0){try{AI.level=sessionStorage.getItem('lingora-ailevel')||'';}catch(e){}}if(AI_LEVELS.indexOf(AI.level)>=0)return AI.level;const c=curCourse();return c&&AI_LEVELS.indexOf(c.level)>=0?c.level:'A1';};
const aiLangName=()=>{const l=langOf(aiLang());return (l&&tx(l.name))||aiLang();};
const aiChatKey=()=>'lingora-aichat:'+(A.user?A.user.id:'-')+':'+aiLang()+':'+(PX.scn||'');
function aiChatSync(){            /* load the conversation that belongs to this account + language + scenario */
  const k=aiChatKey();if(AI.key===k)return;
  AI.key=k;AI.tr={};AI.chat=[];
  try{const v=JSON.parse(sessionStorage.getItem(k)||'[]');if(Array.isArray(v))AI.chat=v.filter(m=>m&&(m.role==='user'||m.role==='assistant')&&typeof m.content==='string').slice(-20);}catch(e){}
}
function aiChatSave(){try{sessionStorage.setItem(AI.key,JSON.stringify(AI.chat.slice(-20)));}catch(e){}}
function aiChatWipe(){try{Object.keys(sessionStorage).filter(k=>k.indexOf('lingora-aichat:')===0).forEach(k=>sessionStorage.removeItem(k));}catch(e){}AI.chat=[];AI.key='';AI.tr={};}
async function aiTutorSend(text){
  if(AI.busy||!P4()||!text)return;
  aiChatSync();
  const before=AI.chat.slice(),sent=before.concat([{role:'user',content:text}]);
  AI.chat=sent;AI.text='';AI.err='';AI.out=null;AI.ex=null;AI.lastMode='tutor';AI.busy=true;render();aiChatScroll();
  try{
    const hist=sent.slice(-12).map(m=>({role:m.role,content:m.content}));
    while(hist.length&&hist[0].role!=='user')hist.shift();
    const r=await B.askCoach({mode:'tutor',language:aiLang(),level:aiLvl(),ui:S.lang,scenario:PX.scn||undefined,messages:hist});
    if(!r||typeof r.reply!=='string')throw E('bad_output');
    const u=sent[sent.length-1];u.corr=r.corrections||[];u.as=r.assessment||'';
    AI.chat=sent.concat([{role:'assistant',content:r.reply,tr:r.reply_translation||'',words:r.new_words||[]}]);
    if(r.usage)AI.usage=Object.assign({},AI.usage,{used:r.usage.used,limit:r.usage.limit});
  }catch(e){
    AI.chat=before;AI.text=text;                    /* the failed message is not part of the context; the learner can resend it */
    const k=AI_ERR[e&&e.code];AI.err=k?t(k):t('aiFail');
    if(e&&(e.code==='limit'||e.code==='budget'))AI.usage=null;
  }
  AI.busy=false;aiChatSave();render();aiChatScroll();
  setTimeout(()=>{const i=$('aitext');if(i&&!AI.busy)try{i.focus();}catch(x){}},0);
}
function aiChatScroll(){setTimeout(()=>{const e=$('aithread');if(e)e.scrollTop=e.scrollHeight;},0);}
function aiBubbles(){
  const L=aiLang();
  if(!AI.chat.length)return `<p class="note tc-empty">${esc(t('aiChatEmpty').replace('{l}',aiLangName()))}</p>`;
  return AI.chat.map((m,i)=>{
    if(m.role==='user'){
      const cs=m.corr||[];
      const fix=m.corr?(cs.length?`<div class="tc-fix" role="group" aria-label="${esc(t('aiFix'))}"><b>${LI('check')}${esc(t('aiFix'))}</b>${cs.map(c=>`<div class="tc-c"><div class="tc-diff" lang="${L}" dir="auto"><s>${esc(c.original)}</s> <span class="tc-arr" aria-hidden="true">→</span> <strong>${esc(c.corrected)}</strong></div><span class="tc-tag">${esc(t('aiTyp_'+c.type)||c.type)}</span><p>${esc(c.explanation)}</p></div>`).join('')}</div>`:`<p class="tc-ok">${LI('check')}${esc(t('aiPerfect'))}</p>`):'';
      return `<div class="tc-row tc-me"><div class="tc-b" lang="${L}" dir="auto"><span class="sr">${esc(t('aiYou'))}: </span>${esc(m.content)}</div>${fix}</div>`;
    }
    const open=!!AI.tr[i];
    return `<div class="tc-row tc-ai"><div class="tc-b" lang="${L}" dir="auto">${esc(m.content)}</div>
      ${m.tr?`<button type="button" class="link-s" data-a="aitr" data-i="${i}" aria-expanded="${open}">${esc(t(open?'aiHideTr':'aiShowTr'))}</button>${open?`<p class="tc-tr">${esc(m.tr)}</p>`:''}`:''}
      ${(m.words&&m.words.length)?`<div class="tc-w"><b>${esc(t('aiNewWords'))}:</b> ${m.words.map(w=>`<span class="tc-chip"><span lang="${L}">${esc(w.word)}</span> · ${esc(w.translation)}</span>`).join(' ')}</div>`:''}</div>`;
  }).join('');
}
function aiChatBlock(){
  aiChatSync();
  const lv=aiLvl(),L=aiLangName();
  return `<div class="tc"><h3>${LI('bot')}${esc(t('aiChatT'))} · <span class="tc-lang">${esc(L)}</span></h3>
   <div class="tc-lv" role="group" aria-label="${esc(t('aiLevelT'))}"><b>${esc(t('aiLevelT'))}</b>${AI_LEVELS.map(x=>`<button type="button" class="chip ${x===lv?'on':''}" data-a="ailvl" data-v="${x}" aria-pressed="${x===lv}">${x}</button>`).join('')}${AI.chat.length?`<button type="button" class="sbtn" data-a="aiclear">${esc(t('aiClearChat'))}</button>`:''}</div>
   <div id="aithread" class="tc-thread" role="log" aria-live="polite" aria-label="${esc(t('aiThread'))}">${aiBubbles()}${AI.busy?`<p class="note tc-wait">${esc(t('aiThinking'))}</p>`:''}</div>
   ${AI.err&&AI.lastMode==='tutor'?`<p class="msg err" role="alert">${esc(AI.err)}</p>`:''}
   <form id="aiform" class="ai-form"><label class="fld"><span class="sr">${esc(t('aiAsk'))}</span><input id="aitext" maxlength="600" lang="${aiLang()}" dir="auto" value="${esc(AI.text)}" placeholder="${esc(t('aiChatPh').replace('{l}',L))}" autocomplete="off" ${AI.busy?'disabled':''}></label><button class="btn btn-orange" type="submit" ${AI.busy?'disabled':''}>${esc(t('aiSend'))}</button></form></div>`;
}
function aiPanel(){
  if(MODE!=='cloud'||!A.user)return `<section class="c2 ai-chat"><h2>${LI('sparkles')}${esc(t('aiT'))}</h2><p class="note">${esc(t('aiNeedCloud'))}</p></section>`;
  aiLoadUsage();mbLoad();
  const u=AI.usage,mist=(MB.rows||[]).filter(r=>!r.mastered&&r.data&&typeof r.data.answer==='string').slice(0,6);
  const pickBox=AI.pick?`<div class="ai-pick" role="group" aria-label="${esc(t('aiPickMist'))}">${mist.length?mist.map((r,i)=>`<button type="button" class="sbtn" data-a="aiexp" data-i="${i}">${esc(mbTitleOf(r))}</button>`).join(''):`<p class="note">${esc(t('aiNoMist'))}</p>`}</div>`:'';
  const ex=AI.ex?`<ol class="ai-ex">${AI.ex.map((x,i)=>`<li><b>${esc(x.q)}</b><div class="chips">${x.options.map(o=>`<button type="button" class="chip ${x.chosen===o?(o===x.answer?'ok':'bad'):''}" data-a="aians" data-i="${i}" data-o="${esc(o)}" ${x.chosen?'disabled':''}>${esc(o)}</button>`).join('')}</div>${x.chosen?`<p class="note">${esc(t('aiWhy'))}: ${esc(x.why||x.answer)}</p>`:''}</li>`).join('')}</ol>`:'';
  return `<section class="c2 ai-chat"><h2>${LI('sparkles')}${esc(t('aiT'))}${u?` <small class="note">${esc(t('aiUsage').replace('{u}',u.used).replace('{l}',u.limit))}</small>`:''}</h2>
   ${pxScnBar()}<div class="ai-acts"><button class="btn btn-purple" data-a="aiplan" ${AI.busy?'disabled':''}>${esc(t('aiPlan'))}</button><button class="sbtn" data-a="aipick" ${AI.busy?'disabled':''}>${esc(t('aiExplain'))}</button></div>${pickBox}
   <form id="aiexform" class="ai-form"><label class="fld"><span class="sr">${esc(t('aiTopic'))}</span><input id="aitopic" maxlength="120" value="${esc(AI.topic)}" placeholder="${esc(t('aiTopic'))}" autocomplete="off"></label><button class="sbtn" type="submit" ${AI.busy?'disabled':''}>${esc(t('aiEx'))}</button></form>
   ${aiChatBlock()}
   <div class="ai-out" role="status" aria-live="polite">${AI.busy&&AI.lastMode!=='tutor'?`<p class="note">${esc(t('aiThinking'))}</p>`:''}${AI.err&&AI.lastMode!=='tutor'?`<p class="msg err">${esc(AI.err)}</p>`:''}${AI.out?`<div class="ai-ans">${esc(AI.out).replace(/\n/g,'<br>')}</div>`:''}${ex}</div>
   <p class="note">${esc(t('aiNote'))}</p></section>`;
}

/* ===== weak topics, recommendations, revision history (used by the mistake book) ===== */
const WK={d:null,rec:null,hist:null,busy:false};
async function wkLoad(){
  if(!P4()||WK.busy||WK.d)return;
  WK.busy=true;
  try{[WK.d,WK.rec,WK.hist]=await Promise.all([B.weakTopics(),B.recommendations(),B.revisionHistory()]);}catch(e){WK.d={lessons:[],repeated:0};WK.rec=[];WK.hist=[];}
  WK.busy=false;if(tab==='me'&&ptab==='mist')render();
}
function weakBlock(){
  if(!P4())return '';
  wkLoad();if(!WK.d)return skel(1);
  const les=WK.d.lessons||[];
  const rec=(WK.rec||[]).map(r=>`<div class="weak"><b>${esc(tx(r.title))}</b><span>${esc(r.reason==='review'?t('rec2Rev'):t('rec2Next'))}</span><button class="sbtn" data-a="recgo" data-id="${esc(r.lesson_id)}">${esc(t('recStart'))}</button></div>`).join('');
  const hist=(WK.hist||[]).slice(0,10).map(h=>`<li class="${h.correct?'ok':'bad'}">${esc(new Date(h.at).toLocaleDateString())} · ${esc(h.qtype)} · ${esc(h.correct?t('histOk'):t('histBad'))}</li>`).join('');
  return `<section class="card wk"><h2>${LI('target')}${esc(t('wkT'))}</h2>${les.length?les.map(l=>`<div class="weak"><b>${esc(tx(l.title))}</b><span>×${l.wrong} · ${l.open} ${esc(t('wkOpen'))}${l.grammar&&tx(l.grammar)?' · '+esc(tx(l.grammar)):''}</span></div>`).join(''):`<p class="note">${esc(t('wkNone'))}</p>`}${WK.d.repeated?`<p class="note">${esc(t('wkRep'))}: ${WK.d.repeated}</p>`:''}</section>
   ${rec?`<section class="card wk"><h2>${LI('bulb')}${esc(t('rec2T'))}</h2>${rec}</section>`:''}
   <section class="card wk"><h2>${LI('repeat')}${esc(t('histT'))}</h2>${hist?`<ul class="hist">${hist}</ul>`:`<p class="note">${esc(t('histNone'))}</p>`}</section>`;
}

/* ===== sync entry point (after login / boot) ===== */
function p4Sync(){
  if(!P4())return;
  ntLoad();leagueSync();worldRefresh();
  if(!NT.timer)NT.timer=setInterval(()=>{if(!document.hidden)ntLoad();},60000);
}

/* ===== actions ===== */
async function act4(a,d,el){
  switch(a){
    case 'shopcat':SHOP.cat=d.v;render();return true;
    case 'wretry':W4.err=false;W4.world=null;render();return true;
    case 'wroom':if(W4.draft){W4.draft.room=d.v;W4.dirty=true;render();}return true;
    case 'wadd':if(W4.draft){if(W4.draft.decor.length>=24){toast(t('e_invalid'));return true;}W4.draft.decor.push({item:d.v,x:24,y:76});W4.sel=W4.draft.decor.length-1;wDirty();}return true;
    case 'wsel':if(W4.draft){W4.sel=+d.v;if(!W4.drag||!W4.drag.moved)render();setTimeout(()=>{const e=document.querySelector('.w-dec.sel');if(e)try{e.focus();}catch(x){}},0);}return true;
    case 'wmove':wMoveSel(+d.dx,+d.dy);return true;
    case 'wdel':wDelSel();return true;
    case 'wsave':await wSave();return true;
    case 'wreset':W4.draft=p4clone(W4.world);W4.dirty=false;W4.sel=-1;render();return true;
    case 'chnew':case 'chacc':case 'chdec':await chAction(a,d);return true;
    case 'aiplan':await aiAsk('plan');return true;
    case 'aipick':AI.pick=!AI.pick;render();return true;
    case 'ailvl':AI.level=d.v;try{sessionStorage.setItem('lingora-ailevel',d.v);}catch(e){}render();return true;
    case 'aitr':AI.tr[+d.i]=!AI.tr[+d.i];render();return true;
    case 'aiclear':AI.chat=[];AI.tr={};AI.err='';aiChatSave();render();return true;
    case 'aiexp':{const r=(MB.rows||[]).filter(r=>!r.mastered&&r.data&&typeof r.data.answer==='string')[+d.i];AI.pick=false;if(r)await aiAsk('explain',{question:String(r.data.prompt||mbTitleOf(r)),expected:r.data.answer});return true;}
    case 'aians':{const x=AI.ex&&AI.ex[+d.i];if(x&&!x.chosen){x.chosen=d.o;render();}return true;}
    case 'recgo':{const i=FLAT.findIndex(f=>f.id===d.id);if(i>=0&&stateOf(i)!=='lock')startLesson(i);else toast(t('locked'));return true;}
  }
  return false;
}
document.addEventListener('submit',e=>{
  if(e.target.id==='aiform'){e.preventDefault();AI.text=(($('aitext')||{}).value||'').trim();if(AI.text)aiTutorSend(AI.text);}
  else if(e.target.id==='aiexform'){e.preventDefault();AI.topic=(($('aitopic')||{}).value||'').trim();aiAsk('exercises',{topic:AI.topic});}
});
