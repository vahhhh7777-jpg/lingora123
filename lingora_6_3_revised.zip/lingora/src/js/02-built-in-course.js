/* ---------- built-in course ---------- */
const COLORS={Red:'#D62839',Blue:'#2A62D9',Yellow:'#F6C523',Green:'#2E9E57',White:'#FFFFFF',Black:'#14161B',Orange:'#FF8A1F',Pink:'#F48FB1'};
const DEFAULT_UNITS=[
{id:'greet',tint:'blue',t:{hy:'Ողջույններ',en:'Greetings'},d:{hy:'Բարևել և հրաժեշտ տալ',en:'Say hello and goodbye'},
 w:[['Hello','Բարև',['e','👋']],['Goodbye','Ցտեսություն'],['Please','Խնդրում եմ'],['Thank you','Շնորհակալություն',['e','🙏']],
    ['Yes','Այո',['e','✅']],['No','Ոչ',['e','❌']],['Good morning','Բարի լույս',['e','🌅']],['Good night','Բարի գիշեր',['e','🌙']]],
 s:[['How are you?','Ինչպե՞ս ես։',['is','he','good']],['I am fine','Ես լավ եմ։',['you','is','good']],
    ['My name is Ani','Իմ անունը Անի է։',['your','are','a']],['Nice to meet you','Հաճելի է ծանոթանալ։',['see','good','me']]]},
{id:'family',tint:'apricot',t:{hy:'Ընտանիք',en:'Family'},d:{hy:'Քո մերձավոր մարդիկ',en:'The people closest to you'},
 w:[['Mother','Մայր',['e','👩']],['Father','Հայր',['e','👨']],['Brother','Եղբայր',['e','👦']],['Sister','Քույր',['e','👧']],
    ['Grandmother','Տատիկ',['e','👵']],['Grandfather','Պապիկ',['e','👴']],['Friend','Ընկեր',['e','🤝']],['Child','Երեխա',['e','🧒']]],
 s:[['This is my mother','Սա իմ մայրն է։',['her','are','father']],['I have a brother','Ես եղբայր ունեմ։',['has','an','sister']],
    ['She is my sister','Նա իմ քույրն է։',['he','are','brother']],['My father is at home','Հայրս տանն է։',['mother','in','are']]]},
{id:'food',tint:'rose',t:{hy:'Սնունդ և խմիչք',en:'Food and drink'},d:{hy:'Սեղանի շուրջ',en:'Around the table'},
 w:[['Bread','Հաց',['e','🍞']],['Water','Ջուր',['e','💧']],['Milk','Կաթ',['e','🥛']],['Apple','Խնձոր',['e','🍎']],
    ['Cheese','Պանիր',['e','🧀']],['Tea','Թեյ',['e','🍵']],['Coffee','Սուրճ',['e','☕']],['Apricot','Ծիրան']],
 s:[['I like apricots','Ես սիրում եմ ծիրան։',['likes','apricot','an']],['I want water','Ես ուզում եմ ջուր։',['wants','a','milk']],
    ['She drinks tea','Նա թեյ է խմում։',['drink','he','coffee']],['We eat bread','Մենք հաց ենք ուտում։',['eats','you','cheese']]]},
{id:'numbers',tint:'mint',t:{hy:'Թվեր',en:'Numbers'},d:{hy:'Հաշվիր մեկից տասը',en:'Count from one to ten'},
 w:[['One','Մեկ',['n','1']],['Two','Երկու',['n','2']],['Three','Երեք',['n','3']],['Four','Չորս',['n','4']],
    ['Five','Հինգ',['n','5']],['Six','Վեց',['n','6']],['Seven','Յոթ',['n','7']],['Ten','Տասը',['n','10']]],
 s:[['I have two apples','Ես երկու խնձոր ունեմ։',['has','three','an']],['I see three birds','Ես երեք թռչուն եմ տեսնում։',['two','bird','saw']],
    ['I am seven years old','Ես յոթ տարեկան եմ։',['is','a','are']],['I need four chairs','Ինձ չորս աթոռ է պետք։',['needs','two','chair']]]},
{id:'colors',tint:'blue',t:{hy:'Գույներ',en:'Colors'},d:{hy:'Նկարագրիր քո շուրջը',en:'Describe the world around you'},
 w:[['Red','Կարմիր',['c']],['Blue','Կապույտ',['c']],['Yellow','Դեղին',['c']],['Green','Կանաչ',['c']],
    ['White','Սպիտակ',['c']],['Black','Սև',['c']],['Orange','Նարնջագույն',['c']],['Pink','Վարդագույն',['c']]],
 s:[['The sky is blue','Երկինքը կապույտ է։',['red','a','are']],['The apple is red','Խնձորը կարմիր է։',['green','an','are']],
    ['My car is white','Իմ մեքենան սպիտակ է։',['black','your','are']],['The sun is yellow','Արևը դեղին է։',['moon','blue','are']]]},
{id:'daily',tint:'apricot',t:{hy:'Առօրյա',en:'Daily life'},d:{hy:'Ամենօրյա գործողություններ',en:'Everyday actions'},
 w:[['Eat','Ուտել',['e','🍽️']],['Drink','Խմել',['e','🥤']],['Sleep','Քնել',['e','😴']],['Read','Կարդալ',['e','📖']],
    ['Write','Գրել',['e','✍️']],['Go','Գնալ',['e','🚶']],['Learn','Սովորել',['e','🎓']],['Work','Աշխատել',['e','💼']]],
 s:[['I read a book','Ես գիրք եմ կարդում։',['reads','an','write']],['We go to school','Մենք դպրոց ենք գնում։',['goes','at','they']],
    ['He works every day','Նա ամեն օր աշխատում է։',['work','night','she']],['I learn English','Ես անգլերեն եմ սովորում։',['learns','a','speak']]]},
{id:'city',tint:'rose',t:{hy:'Քաղաք',en:'Around town'},d:{hy:'Փողոցներ, տներ և լեռներ',en:'Streets, homes and mountains'},
 w:[['House','Տուն',['e','🏠']],['School','Դպրոց',['e','🏫']],['Street','Փողոց',['e','🛣️']],['City','Քաղաք',['e','🏙️']],
    ['Book','Գիրք',['e','📚']],['Car','Մեքենա',['e','🚗']],['Mountain','Լեռ',['e','⛰️']],['Sun','Արև',['e','☀️']]],
 s:[['I live in Yerevan','Ես ապրում եմ Երևանում։',['lives','at','a']],['The city is big','Քաղաքը մեծ է։',['small','a','are']],
    ['Where is the school?','Որտե՞ղ է դպրոցը։',['what','are','a']],['Ararat is a big mountain','Արարատը մեծ լեռ է։',['small','an','are']]]}
];
const SAMPLE_VIP={id:'travel',vip:true,tint:'mint',t:{hy:'Ճանապարհորդություն',en:'Travel'},d:{hy:'Օդանավակայանից մինչև հյուրանոց',en:'From the airport to the hotel'},
 w:[['Airport','Օդանավակայան',['e','✈️']],['Ticket','Տոմս',['e','🎫']],['Passport','Անձնագիր',['e','🛂']],['Hotel','Հյուրանոց',['e','🏨']],
    ['Map','Քարտեզ',['e','🗺️']],['Train','Գնացք',['e','🚆']],['Bus','Ավտոբուս',['e','🚌']],['Taxi','Տաքսի',['e','🚕']]],
 s:[['Where is the airport?','Որտե՞ղ է օդանավակայանը։',['what','are','a']],['I need a ticket','Ինձ տոմս է պետք։',['needs','the','map']],
    ['The hotel is here','Հյուրանոցն այստեղ է։',['there','a','are']],['Where is my passport?','Որտե՞ղ է իմ անձնագիրը։',['what','your','are']]]};

/* Sample words are [target language, Armenian]; for Armenian they are [Armenian, English]. */
const SAMPLE_WORDS={
es:[['Hola','Բարև'],['Gracias','Շնորհակալություն'],['Por favor','Խնդրում եմ'],['Adiós','Ցտեսություն'],['Sí','Այո'],['No','Ոչ'],['Agua','Ջուր'],['Pan','Հաց']],
fr:[['Bonjour','Բարև'],['Merci','Շնորհակալություն'],["S'il vous plaît",'Խնդրում եմ'],['Au revoir','Ցտեսություն'],['Oui','Այո'],['Non','Ոչ'],['Eau','Ջուր'],['Pain','Հաց']],
de:[['Hallo','Բարև'],['Danke','Շնորհակալություն'],['Bitte','Խնդրում եմ'],['Tschüss','Ցտեսություն'],['Ja','Այո'],['Nein','Ոչ'],['Wasser','Ջուր'],['Brot','Հաց']],
it:[['Ciao','Բարև'],['Grazie','Շնորհակալություն'],['Per favore','Խնդրում եմ'],['Arrivederci','Ցտեսություն'],['Sì','Այո'],['No','Ոչ'],['Acqua','Ջուր'],['Pane','Հաց']],
ja:[['こんにちは','Բարև'],['ありがとう','Շնորհակալություն'],['お願いします','Խնդրում եմ'],['さようなら','Ցտեսություն'],['はい','Այո'],['いいえ','Ոչ'],['水','Ջուր'],['パン','Հաց']],
ko:[['안녕하세요','Բարև'],['감사합니다','Շնորհակալություն'],['부탁합니다','Խնդրում եմ'],['안녕히 가세요','Ցտեսություն'],['네','Այո'],['아니요','Ոչ'],['물','Ջուր'],['빵','Հաց']],
zh:[['你好','Բարև'],['谢谢','Շնորհակալություն'],['请','Խնդրում եմ'],['再见','Ցտեսություն'],['是','Այո'],['不','Ոչ'],['水','Ջուր'],['面包','Հաց']],
ru:[['Привет','Բարև'],['Спасибо','Շնորհակալություն'],['Пожалуйста','Խնդրում եմ'],['До свидания','Ցտեսություն'],['Да','Այո'],['Нет','Ոչ'],['Вода','Ջուր'],['Хлеб','Հաց']],
ar:[['مرحبا','Բարև'],['شكرا','Շնորհակալություն'],['من فضلك','Խնդրում եմ'],['مع السلامة','Ցտեսություն'],['نعم','Այո'],['لا','Ոչ'],['ماء','Ջուր'],['خبز','Հաց']],
pt:[['Olá','Բարև'],['Obrigado','Շնորհակալություն'],['Por favor','Խնդրում եմ'],['Adeus','Ցտեսություն'],['Sim','Այո'],['Não','Ոչ'],['Água','Ջուր'],['Pão','Հաց']],
tr:[['Merhaba','Բարև'],['Teşekkürler','Շնորհակալություն'],['Lütfen','Խնդրում եմ'],['Hoşça kal','Ցտեսություն'],['Evet','Այո'],['Hayır','Ոչ'],['Su','Ջուր'],['Ekmek','Հաց']],
hy:[['Բարև','Hello'],['Շնորհակալություն','Thank you'],['Խնդրում եմ','Please'],['Ցտեսություն','Goodbye'],['Այո','Yes'],['Ոչ','No'],['Ջուր','Water'],['Հաց','Bread']]
};
const SEED_LANGS=[
{id:'en',flag:'EN',name:{hy:'Անգլերեն',en:'English'},tts:'en-US',diff:'easy',months:3,source:'hy'},
{id:'es',flag:'ES',name:{hy:'Իսպաներեն',en:'Spanish'},tts:'es-ES',diff:'easy',months:4,source:'hy'},
{id:'fr',flag:'FR',name:{hy:'Ֆրանսերեն',en:'French'},tts:'fr-FR',diff:'medium',months:5,source:'hy'},
{id:'de',flag:'DE',name:{hy:'Գերմաներեն',en:'German'},tts:'de-DE',diff:'medium',months:5,source:'hy'},
{id:'it',flag:'IT',name:{hy:'Իտալերեն',en:'Italian'},tts:'it-IT',diff:'easy',months:4,source:'hy'},
{id:'ja',flag:'JA',name:{hy:'Ճապոներեն',en:'Japanese'},tts:'ja-JP',diff:'hard',months:8,source:'hy'},
{id:'ko',flag:'KO',name:{hy:'Կորեերեն',en:'Korean'},tts:'ko-KR',diff:'hard',months:8,source:'hy'},
{id:'zh',flag:'ZH',name:{hy:'Չինարեն (մանդարին)',en:'Chinese (Mandarin)'},tts:'zh-CN',diff:'hard',months:8,source:'hy'},
{id:'pt',flag:'PT',name:{hy:'Պորտուգալերեն',en:'Portuguese'},tts:'pt-PT',diff:'easy',months:4,source:'hy'},
{id:'tr',flag:'TR',name:{hy:'Թուրքերեն',en:'Turkish'},tts:'tr-TR',diff:'medium',months:6,source:'hy'},
{id:'az',flag:'AZ',name:{hy:'Ադրբեջաներեն',en:'Azerbaijani'},tts:'az-AZ',diff:'medium',months:6,source:'hy'},
{id:'ru',flag:'RU',name:{hy:'Ռուսերեն',en:'Russian'},tts:'ru-RU',diff:'medium',months:6,source:'hy'},
{id:'ar',flag:'AR',name:{hy:'Արաբերեն',en:'Arabic'},tts:'ar-SA',diff:'hard',months:8,source:'hy'},
{id:'hy',flag:'HY',name:{hy:'Հայերեն',en:'Armenian'},tts:'hy-AM',diff:'hard',months:8,source:'en'}
];
const nWordLessons=u=>Math.ceil(u.w.length/4);
const fixVis=w=>{const v=w.vis;if(!v)return null;return v[0]==='c'?['c',v[1]||COLORS[w.en]||'#888888']:v;};

/* Turns a generated lesson step into a stored question record. */
function toStored(s){
  switch(s.k){
    case 'intro':return {type:'intro',data:{en:s.w.en,hy:s.w.hy,vis:fixVis(s.w)}};
    case 'mc':{const en2=s.dir==='en2hy';return {type:'mc',data:{prompt:en2?s.w.en:s.w.hy,speak:en2?s.w.en:'',options:s.opts,answer:s.ans}};}
    case 'pic':return {type:'image',data:{vis:fixVis(s.w),options:s.opts,answer:s.ans}};
    case 'listen':return {type:'listen',data:{text:s.w.en,options:s.opts,answer:s.ans}};
    case 'type':return {type:'type',data:{prompt:s.w.hy,answer:s.ans,accept:[]}};
    case 'match':return {type:'match',data:{pairs:s.pairs.map(p=>[p.en,p.hy])}};
    case 'build':return {type:'order',data:{prompt:s.s.hy,sentence:s.s.en,extra:s.s.x||[]}};
    case 'fill':{const w=s.words.slice();w[s.bi]='___';return {type:'fill',data:{prompt:s.s.hy,sentence:w.join(' ')+s.end,answer:s.ans,distractors:s.opts.filter(o=>o!==s.ans)}};}
    case 'smc':return {type:'mc',data:{prompt:s.s.en,speak:s.s.en,options:s.opts,answer:s.ans}};
  }
  return null;
}
/* Generates the lessons of one unit from its word and sentence lists (used once, to build the built-in course). */
function lessonsFromUnit(u,allowType){
  const W=wordsOf(u),SS=sentsOf(u),out=[];
  const n=nWordLessons(u);
  for(let j=0;j<n;j++){
    const F=W.slice(j*4,j*4+4),steps=F.map(w=>({k:'intro',w}));
    const body=F.map(w=>qMc(w,W,'en2hy'));
    if(F.length>=3)body.push(qMatch(F));
    pick(F,2).forEach(w=>body.push(w.vis?qPic(w,W):qMc(w,W,'hy2en')));
    const a=pick(F,1)[0],b=pick(F,1)[0];
    out.push({title:{hy:'Բառեր '+(j+1),en:'Words '+(j+1)},steps:steps.concat(shuffle(body),[qListen(a,W),allowType?qType(b):qMc(b,W,'hy2en')])});
  }
  if(SS.length){
    const bl=SS.map(qBuild),fl=pick(SS,2).map(s=>qFill(s,W)),sm=pick(SS,2).map(s=>qSmc(s,SS,W));
    const w0=qMc(pick(W,1)[0],W,Math.random()<.5?'en2hy':'hy2en');
    out.push({title:{hy:'Նախադասություններ',en:'Sentences'},steps:[w0,bl[0],fl[0],bl[1],sm[0],bl[2],fl[1],bl[3],sm[1]].filter(Boolean)});
  }
  return out;
}
const SEED_TINTS=['blue','apricot','rose','mint'];
/* Languages whose A1 units come from LANG_PACKS (21_lang_packs.js). English is the original course. */
const packLang=id=>typeof LANG_PACKS!=='undefined'&&!!LANG_PACKS[id];
/* The typing exercise needs a keyboard the learner can use: Latin scripts where accents are forgiven (see fold). */
const TYPE_LANGS=['en','fr','de','it'];
/* Pairs a pack's target-language text with the Armenian column and pictures of the English course, so all languages teach the same A1 topics. */
function packUnits(L){
  const P=LANG_PACKS[L.id];
  return DEFAULT_UNITS.concat([SAMPLE_VIP]).map(b=>{
    const pk=P[b.id];
    return {id:L.id+'-'+b.id,tint:b.tint,vip:!!b.vip&&b.id==='travel',t:b.t,d:b.d,
      w:b.w.map((x,i)=>[pk.w[i],x[1],x[2]&&x[2][0]==='c'?['c',COLORS[x[0]]]:x[2]]),
      s:b.s.map((x,i)=>[pk.s[i][0],x[1],pk.s[i][1]])};
  });
}
function buildSeed(){
  const cat={languages:[],courses:[],units:[],lessons:[],questions:[]};
  SEED_LANGS.forEach((L,i)=>{
    const pack=packLang(L.id),sample=L.id!=='en'&&!pack;
    cat.languages.push({id:L.id,code:L.id,name:L.name,descr:{hy:'Սովորիր '+L.name.hy.toLowerCase(),en:'Learn '+L.name.en},flag:L.flag,difficulty:L.diff,tts:L.tts,active:true,pos:i+1});
    cat.courses.push({id:L.id,language_id:L.id,source:L.source,title:L.name,
      descr:sample?{hy:'Նմուշային դասընթաց',en:'Sample course'}:pack?{hy:'A1 մակարդակ։ Սևագիր՝ սպասում է բնիկ խոսողի ստուգման',en:'A1 level. Draft, awaiting review by a native speaker'}:{hy:'Լրիվ դասընթաց',en:'Full course'},
      difficulty:L.diff,tint:SEED_TINTS[i%4],level:'A1',published:true,sample,draft:pack,months:L.months,pos:1});
    const units=pack?packUnits(L)
      :sample?[{id:L.id+'-basics',tint:SEED_TINTS[i%4],vip:false,t:{hy:'Հիմունքներ',en:'Basics'},d:{hy:'Ողջույններ, քաղաքավարություն և առաջին բառերը',en:'Greetings, politeness and first words'},w:SAMPLE_WORDS[L.id],s:[]}]
      :DEFAULT_UNITS.map(u=>Object.assign({},u,{vip:false})).concat([SAMPLE_VIP]);
    units.forEach((u,ui)=>{
      cat.units.push({id:u.id,course_id:L.id,title:u.t,descr:u.d,tint:u.tint,vip:!!u.vip,published:true,pos:ui+1});
      lessonsFromUnit(u,TYPE_LANGS.indexOf(L.id)>=0).forEach((ls,j)=>{
        const lid=u.id+'-'+j;
        cat.lessons.push({id:lid,unit_id:u.id,title:ls.title,descr:{hy:'',en:''},xp:8,difficulty:'easy',review:'draft',minutes:5,published:true,pos:j+1});
        ls.steps.forEach((st,k)=>{const q=toStored(st);if(q)cat.questions.push({id:lid+'-q'+(k+1),lesson_id:lid,type:q.type,data:q.data,pos:k+1});});
      });
    });
  });
  return cat;
}
