/* ---------- Part 1: profile, router, route guards and the actions of the new screens ---------- */

/* ===== Router =====
   Tabs live in the URL as #/home #/learn #/stories #/ai #/me, plus the sub pages #/friends #/shop #/words #/rank #/courses #/admin.
   A refresh, the browser back button and a shared link all land on the same screen. Only a plain #/name is ever written,
   and the hash is never touched while it carries an auth token (the password-reset link), so recovery keeps working. */
const ROUTES=['home','learn','stories','ai','friends','me','shop','world','words','rank','courses','admin'];
const NAV_OF={courses:'learn',words:'learn',friends:'me',rank:'me',shop:'me',world:'me'};
/* old links: the removed Practice / Review page now lives inside Learn */
const routeOf=()=>{const m=/^#\/([a-z]+)\/?$/.exec(location.hash||'');if(!m)return '';const x=m[1]==='practice'?'learn':m[1];return ROUTES.indexOf(x)>=0?x:'';};
const hashSafe=()=>!/access_token|refresh_token|type=recovery|error_code|error_description/.test(location.hash||'');
let lastHashTab='';

/* Returns the route this person may open. Guests can learn; friends and the shop need an account; admin needs staff. */
function guardRoute(r){
  if(ROUTES.indexOf(r)<0)return 'home';
  if(!A.ready)return r;                                   /* the session is still being restored: do not bounce anyone yet */
  if(r==='admin'&&!isStaff())return 'home';
  if((r==='friends'||r==='shop'||r==='world')&&MODE==='cloud'&&!A.user){A.next=r;toast(t('needSignin'),'wave');ptab='set';return 'me';}
  if(r==='world'&&MODE!=='cloud')return 'home';
  return r;
}
function routeSync(){
  if(!hashSafe())return;
  const want='#/'+tab;
  if(location.hash===want){lastHashTab=tab;return;}
  try{if(lastHashTab&&lastHashTab!==tab&&location.hash)history.pushState(null,'',want);else history.replaceState(null,'',want);}catch(e){}
  lastHashTab=tab;
}
function enterTab(r){
  if(r==='admin'&&(adm.sub==='dash'||adm.sub==='users'))loadUsers();
  if(r==='home'||r==='rank'||r==='friends')loadBoard();
  if(r==='home'||r==='friends')loadFriends(r==='friends');
  if(r==='world')worldLoad();
  if(r==='friends'||r==='rank'){CH.rows=null;chLoad();}
  ntLoad();
}
window.addEventListener('hashchange',()=>{
  if(!S.onb||L)return;
  const r=routeOf();if(!r||r===tab)return;
  if(guardDirty()){routeSync();return;}
  tab=guardRoute(r);langOpen=false;pgAnim=true;lastHashTab=tab;render();window.scrollTo(0,0);enterTab(tab);
});
{const r0=routeOf();if(r0)tab=r0;}

/* ===== Profile ===== */
const PE={open:false,busy:false,err:'',fe:{},nm:null,un:null,av:null,lg:null};
function peCapture(){
  const v=id=>{const e=$(id);return e?e.value:null;};
  const a=v('penm'),b=v('peun'),c=v('pelg');
  if(a!==null)PE.nm=a;if(b!==null)PE.un=b;if(c!==null)PE.lg=c;
}
function profileEditCard(){
  const p=A.profile||{},cloud=!!(A.user&&B&&B.updateProfile);
  const nm=PE.nm===null?(displayName()):PE.nm,un=PE.un===null?(p.username||''):PE.un,av=PE.av===null?(p.avatar||''):PE.av,lg=PE.lg===null?S.course:PE.lg;
  const fe=k=>PE.fe[k]?`<p class="ferr" role="alert">${LI('alert')}${esc(PE.fe[k])}</p>`:'';
  return `<section class="c2 pedit" aria-label="${esc(t('pEdit'))}"><h2>${LI('pencil')}${t('pEdit')}</h2>
   <form id="peform" class="sform" novalidate>
    <label class="fld">${t('name')}<input id="penm" value="${esc(nm)}" maxlength="24" autocomplete="nickname" ${PE.fe.nm?'aria-invalid="true"':''}></label>${fe('nm')}
    ${cloud?`<label class="fld">${t('pUsername')}<input id="peun" value="${esc(un)}" maxlength="20" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="anna_lingora" ${PE.fe.un?'aria-invalid="true"':''}></label><small class="hint">${t('pUsernameHelp')}</small>${fe('un')}
    <div class="fld"><span id="pavl">${t('pAvatar')}</span><div class="av-pick" role="radiogroup" aria-labelledby="pavl">${AVATARS.map(a=>`<button type="button" role="radio" aria-checked="${av===a.id}" aria-label="${esc(a.id)}" class="av-opt ${av===a.id?'on':''}" style="${avatarBg(a.id)}" data-a="pav" data-v="${a.id}">${av===a.id?LI('check'):esc((nm||'?').trim().charAt(0).toUpperCase()||'?')}</button>`).join('')}</div>
    ${S.avatar?`<small class="hint">${t('pPhotoWins')}</small>`:''}</div>`:''}
    <label class="fld">${t('pLearning')}<select id="pelg">${courseCards().map(c=>`<option value="${esc(c.id)}" ${c.id===lg?'selected':''}>${esc(c.code+' '+c.name[S.lang])}</option>`).join('')}</select></label>
    ${PE.err?`<div class="msg err" role="alert">${esc(PE.err)}</div>`:''}
    <div class="acts"><button type="button" class="btn btn-ghost" data-a="pcancel">${t('st_cancel')}</button><button type="submit" class="btn btn-purple ${PE.busy?'busy':''}" ${PE.busy?'disabled aria-busy="true"':''}>${t('save')}</button></div>
   </form></section>`;
}
function profileHero(){
  const li=levelInfo(S.xp),nm=displayName(),p=A.profile||{},pct=Math.round(li.cur/li.need*100),c=curCourse();
  return `<section class="p2-hero"><div class="p2-hero-top"><div class="pro-av">${myAvatar('xl')}</div>
   <div class="p2-hero-id"><h1>${esc(nm)}</h1>${p.username?`<p class="pro-un">@${esc(p.username)}</p>`:''}<div class="pro-badges">${roleBadge()}${c?`<span class="p2-lang"><span class="p2-flag">${c.flag}</span>${esc(c.name[S.lang])}${c.level?' · '+esc(c.level):''}</span>`:''}</div></div>
   <button class="ico-btn pro-gear" data-a="ptab" data-v="set" aria-label="${esc(t('pt_set'))}">${LI('settings')}</button></div>
   <div class="p2-lvl"><div class="p2-lvl-t"><b>${esc(t('level'))} ${li.level}</b><span>${nfmt(S.xp)} XP · ${li.need-li.cur} ${esc(t('xpToNext'))}</span></div><div class="bar purple" role="img" aria-label="${li.cur}/${li.need} XP"><i style="width:${pct}%"></i></div></div>
   <div class="langsw pro-lang" role="group" aria-label="${esc(t('st_uiLang'))}">${[['hy','ՀԱՅ'],['en','EN']].map(x=>`<button type="button" data-a="lang" data-v="${x[0]}" aria-pressed="${S.lang===x[0]}">${x[1]}</button>`).join('')}</div>
  </section>${PE.open?profileEditCard():''}`;
}

async function saveProfile(){
  peCapture();
  const nm=(PE.nm===null?displayName():PE.nm).trim(),un=(PE.un===null?((A.profile||{}).username||''):PE.un).trim().toLowerCase();
  PE.fe={};PE.err='';
  if(!nm||nm.length>24)PE.fe.nm=t('e_invalid_name');
  if(un&&!/^[a-z0-9_]{3,20}$/.test(un))PE.fe.un=t('e_invalid_username');
  if(PE.fe.nm||PE.fe.un){render();return;}
  PE.busy=true;render();
  try{
    if(A.user&&B&&B.updateProfile){
      const r=await B.updateProfile(nm,un,PE.av===null?((A.profile||{}).avatar||''):PE.av);
      A.profile=Object.assign({},A.profile,{name:r.name,username:r.username||null,avatar:r.avatar||''});
    }else if(A.user&&B&&B.setName){await B.setName(nm);A.profile=Object.assign({},A.profile,{name:nm});}
    S.name=nm.slice(0,24);
    if(PE.lg&&PE.lg!==S.course){S.course=PE.lg;applyCourse();}
    save();pushProgress();saveCache();
    PE.open=false;PE.nm=PE.un=PE.av=PE.lg=null;
    okToast();
  }catch(e){
    const c=mapErr(e);PE.err=t('e_'+c)||t('e_other');
    if(c==='username_taken'){PE.fe.un=PE.err;PE.err='';}
  }
  PE.busy=false;render();
}

/* ===== Friend actions ===== */
const socMsg=e=>{const c=mapErr(e);return c==='not_found'?t('frNotFound'):(t('e_'+c)||t('e_other'));};
async function doFriendReq(){
  const el=$('frq');SOC.q=(el?el.value:SOC.q).trim();
  if(!SOC.q){SOC.fb={ok:false,text:t('frNeedInput')};render();return;}
  SOC.busy=true;SOC.fb=null;render();
  try{const r=await B.friendRequest(SOC.q);SOC.fb={ok:true,text:t(r&&r.status==='accepted'?'frAccepted':'frSent')};SOC.q='';await loadFriends(true);}
  catch(e){SOC.fb={ok:false,text:socMsg(e)};}
  SOC.busy=false;render();
}
async function copyText(txt){
  try{if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(txt);return true;}}catch(e){}
  try{const ta=document.createElement('textarea');ta.value=txt;ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();const ok=document.execCommand('copy');ta.remove();return ok;}catch(e){return false;}
}

/* ===== actions (called first from act()) ===== */
async function act3a(a,d,el){
  switch(a){
    case 'tab':{
      if(guardDirty())return true;
      langOpen=false;SOC.rm='';PE.open=false;pgAnim=true;resetArm=false;adm.edit=null;
      tab=guardRoute(d.v);wantScroll=(tab==='learn');
      render();if(!wantScroll)window.scrollTo(0,0);
      enterTab(tab);return true;
    }
    case 'signinfirst':{A.next=d.v||'';A.form='signin';A.err='';A.msg='';flow='login';render();window.scrollTo(0,0);return true;}
    case 'pedit':{PE.open=true;PE.err='';PE.fe={};PE.nm=PE.un=PE.av=PE.lg=null;ptab='over';render();setTimeout(()=>{const e=$('penm');if(e){try{e.scrollIntoView({block:'center'});e.focus();}catch(x){}}},30);return true;}
    case 'pcancel':PE.open=false;PE.nm=PE.un=PE.av=PE.lg=null;render();return true;
    case 'pav':peCapture();PE.av=d.v;render();return true;
    case 'frreload':loadFriends(true);if(!SOC.loading)render();return true;
    case 'frcopy':{const ok=await copyText(d.v||'');toast(ok?t('frCopied'):t('frCopyFail'),ok?'happy':'confused');return true;}
    case 'fracc':case 'frdec':{
      if(SOC.busy)return true;SOC.busy=true;render();
      try{await B.friendRespond(d.id,a==='fracc');await loadFriends(true);toast(t(a==='fracc'?'frAccepted':'frDeclined'),'happy');}catch(e){toast(socMsg(e),'confused');}
      SOC.busy=false;render();return true;
    }
    case 'frrm':{
      if(SOC.rm!==d.id){SOC.rm=d.id;render();return true;}
      SOC.rm='';try{await B.friendRemove(d.id);await loadFriends(true);toast(t('frRemoved'));}catch(e){toast(socMsg(e),'confused');}
      render();return true;
    }
  }
  return false;
}

document.addEventListener('submit',e=>{
  const id=e.target.id;
  if(id==='frform'){e.preventDefault();doFriendReq();}
  else if(id==='peform'){e.preventDefault();saveProfile();}
});
document.addEventListener('input',e=>{if(e.target.id==='frq')SOC.q=e.target.value;});
