/* ---------- stories (English course) ---------- */
const STORIES=[
 {id:'cafe',lv:'A1',e:'☕',t:{hy:'Սրճարանում',en:'At the Café'},
  p:[['Anna goes to a small café every Saturday. She likes the quiet tables near the window.','Աննան ամեն շաբաթ գնում է փոքրիկ սրճարան։ Նրան դուր են գալիս պատուհանի մոտ գտնվող հանգիստ սեղանները։'],
     ['Today she orders a cup of tea and a piece of apple cake. The waiter smiles and says, “Good morning! Here is your tea.”','Այսօր նա պատվիրում է մի բաժակ թեյ և մի կտոր խնձորի տորթ։ Մատուցողը ժպտում է և ասում․ «Բարի լույս։ Ահա ձեր թեյը։»'],
     ['After the cake, Anna reads her book for an hour. Then she pays and says, “Thank you! See you next Saturday.”','Տորթից հետո Աննան մեկ ժամ գիրք է կարդում։ Հետո վճարում է և ասում․ «Շնորհակալություն։ Կտեսնվենք հաջորդ շաբաթ։»']],
  v:[['waiter','մատուցող'],['order','պատվիրել'],['piece','կտոր'],['pay','վճարել'],['quiet','հանգիստ'],['window','պատուհան']],
  q:[{p:0,q:'When does Anna go to the café?',a:'Every Saturday',o:['Every Sunday','Every morning','Never'],x:'The first sentence says she goes every Saturday.'},
     {p:1,q:'What does she order?',a:'Tea and apple cake',o:['Coffee and bread','Juice and pizza','Water and soup'],x:'She orders a cup of tea and a piece of apple cake.'},
     {p:2,q:'What does Anna do after the cake?',a:'She reads her book',o:['She calls a friend','She goes home at once','She orders more tea'],x:'She reads her book for an hour.'}]},
 {id:'phone',lv:'A1',e:'📱',t:{hy:'Կորած հեռախոսը',en:'The Lost Phone'},
  p:[['Tom is at the train station. He wants to call his sister, but his phone is not in his bag.','Թոմը կայարանում է։ Նա ուզում է զանգահարել քրոջը, բայց հեռախոսը պայուսակում չէ։'],
     ['He asks a woman at the information desk, “Excuse me, did anyone find a black phone?” She checks a box and says, “Yes! Is it this one?”','Նա հարցնում է տեղեկատուի աշխատակցուհուն․ «Կներեք, որևէ մեկը սև հեռախոս գտե՞լ է։» Նա ստուգում է արկղը և ասում․ «Այո։ Սա՞ է։»'],
     ['Tom is very happy. He thanks her and calls his sister. “I’m at the station,” he says. “I’ll be home in twenty minutes.”','Թոմը շատ ուրախ է։ Շնորհակալություն է հայտնում և զանգահարում քրոջը։ «Ես կայարանում եմ,— ասում է նա։— Քսան րոպեից տանը կլինեմ։»']],
  v:[['station','կայարան'],['bag','պայուսակ'],['excuse me','կներեք'],['check','ստուգել'],['box','արկղ'],['minutes','րոպե']],
  q:[{p:0,q:'Where is Tom?',a:'At a train station',o:['At a café','At school','At the airport'],x:'The story begins: “Tom is at the train station.”'},
     {p:0,q:'What is missing?',a:'His phone',o:['His ticket','His bag','His book'],x:'His phone is not in his bag.'},
     {p:2,q:'How long until Tom is home?',a:'Twenty minutes',o:['Two hours','Ten minutes','One day'],x:'He says: “I’ll be home in twenty minutes.”'}]},
 {id:'trip',lv:'A2',e:'⛰️',t:{hy:'Հանգստյան օրվա ճամփորդություն',en:'A Weekend Trip'},
  p:[['Last weekend, Maria and her friends went to the mountains. They left early on Saturday because the road was long.','Անցած հանգստյան օրերին Մարիան և ընկերները գնացին լեռները։ Շաբաթ օրը վաղ դուրս եկան, քանի որ ճանապարհը երկար էր։'],
     ['When they arrived, the weather was cloudy, but nobody was worried. They walked for three hours and took many photos of the lake.','Երբ հասան, եղանակը ամպամած էր, բայց ոչ ոք չէր անհանգստանում։ Երեք ժամ քայլեցին և շատ լուսանկարներ արեցին լճի մոտ։'],
     ['In the evening it started to rain, so they stayed in a small hotel and played cards. “It was the best trip this year,” Maria said.','Երեկոյան անձրև սկսվեց, ուստի մնացին փոքրիկ հյուրանոցում և թղթախաղ խաղացին։ «Սա այս տարվա լավագույն ճամփորդությունն էր,— ասաց Մարիան։»']],
  v:[['mountains','լեռներ'],['cloudy','ամպամած'],['lake','լիճ'],['hotel','հյուրանոց'],['worried','անհանգիստ'],['trip','ճամփորդություն']],
  q:[{p:0,q:'Why did they leave early?',a:'The road was long',o:['They were late for work','It was raining','They wanted breakfast'],x:'They left early “because the road was long”.'},
     {p:1,q:'What was the weather like when they arrived?',a:'Cloudy',o:['Sunny','Snowy','Windy'],x:'The text says the weather was cloudy.'},
     {p:2,q:'What did they do in the evening?',a:'They stayed in a hotel and played cards',o:['They climbed the mountain','They went home','They swam in the lake'],x:'It started to rain, so they stayed in a small hotel and played cards.'}]},
 {id:'interview',lv:'B1',e:'💼',t:{hy:'Հարցազրույցը',en:'The Job Interview'},
  p:[['Daniel had been preparing for the interview for a week. He researched the company, practised answers to common questions and even chose his outfit the night before.','Դանիելը մեկ շաբաթ պատրաստվում էր հարցազրույցի։ Ուսումնասիրել էր ընկերությունը, կրկնել տարածված հարցերի պատասխանները և նույնիսկ նախորդ երեկոյան ընտրել հագուստը։'],
     ['During the interview, the manager asked him about a difficult situation at his previous job. Although Daniel felt nervous, he explained how he had solved the problem by organising a team meeting.','Հարցազրույցի ժամանակ ղեկավարը հարցրեց նրա նախկին աշխատանքի դժվար իրավիճակի մասին։ Թեև Դանիելը նյարդային էր, բացատրեց, թե ինչպես էր լուծել խնդիրը՝ թիմային հանդիպում կազմակերպելով։'],
     ['A few days later, he received an email. The company offered him the position, but the salary was lower than he expected. After thinking carefully, he decided to negotiate instead of refusing immediately.','Մի քանի օր անց նա նամակ ստացավ։ Ընկերությունն առաջարկեց պաշտոնը, բայց աշխատավարձը ավելի ցածր էր, քան սպասում էր։ Մտածելուց հետո որոշեց բանակցել՝ անմիջապես հրաժարվելու փոխարեն։']],
  v:[['interview','հարցազրույց'],['previous','նախկին'],['nervous','նյարդային'],['salary','աշխատավարձ'],['negotiate','բանակցել'],['position','պաշտոն'],['refuse','հրաժարվել']],
  q:[{p:0,q:'How did Daniel prepare?',a:'He researched the company and practised answers',o:['He asked a friend to attend','He bought a new phone','He did not prepare'],x:'He researched the company and practised answers to common questions.'},
     {p:1,q:'How did Daniel solve the problem at his previous job?',a:'By organising a team meeting',o:['By changing jobs','By asking his manager to do it','By ignoring it'],x:'He solved it “by organising a team meeting”.'},
     {p:2,q:'What did Daniel decide about the offer?',a:'To negotiate the salary',o:['To accept at once','To refuse at once','To wait a year'],x:'He decided to negotiate instead of refusing immediately.'}]}
];

/* Built-in stories for the seed English course. Each story is linked to a real
   lesson ID and its target vocabulary matches that lesson's four intro words. */
STORIES.push(
 {id:'lesson-greet-0',lessonId:'greet-0',lv:'A1',e:'👋',t:{hy:'Առաջին հանդիպումը',en:'A First Meeting'},
  p:[['Hello! Please come in. Thank you for visiting. Goodbye!','Բարև։ Խնդրում եմ, ներս արի։ Շնորհակալություն այցելելու համար։ Ցտեսություն։']],
  v:[['Hello','Բարև'],['Please','Խնդրում եմ'],['Thank you','Շնորհակալություն'],['Goodbye','Ցտեսություն']],
  q:[{p:0,q:'Which phrase is used to be polite?',a:'Please',o:['Goodbye','Hello','Thank you'],x:'“Please” is a polite word.'}]},
 {id:'lesson-family-0',lessonId:'family-0',lv:'A1',e:'👨‍👩‍👧‍👦',t:{hy:'Իմ ընտանիքը',en:'My Family'},
  p:[['My mother and father are at home. My brother and sister are here too. We are a happy family.','Մայրիկս և հայրիկս տանն են։ Եղբայրս ու քույրս նույնպես այստեղ են։ Մենք ուրախ ընտանիք ենք։']],
  v:[['Mother','Մայր'],['Father','Հայր'],['Brother','Եղբայր'],['Sister','Քույր']],
  q:[{p:0,q:'Who is at home?',a:'The family',o:['Only a friend','Only a teacher','Nobody'],x:'The paragraph says the family members are at home.'}]},
 {id:'lesson-food-0',lessonId:'food-0',lv:'A1',e:'🍎',t:{hy:'Նախաճաշ',en:'Breakfast'},
  p:[['I eat bread and an apple. I drink water and milk. This is my breakfast.','Ես հաց և խնձոր եմ ուտում։ Ջուր և կաթ եմ խմում։ Սա իմ նախաճաշն է։']],
  v:[['Bread','Հաց'],['Water','Ջուր'],['Milk','Կաթ'],['Apple','Խնձոր']],
  q:[{p:0,q:'What does the person drink?',a:'Water and milk',o:['Tea and coffee','Only juice','Nothing'],x:'The story says: “I drink water and milk.”'}]},
 {id:'lesson-numbers-0',lessonId:'numbers-0',lv:'A1',e:'🔢',t:{hy:'Չորս առարկա',en:'Four Things'},
  p:[['I have one apple, two books, three pens, and four cups. I count them every day.','Ես ունեմ մեկ խնձոր, երկու գիրք, երեք գրիչ և չորս բաժակ։ Ամեն օր հաշվում եմ դրանք։']],
  v:[['One','Մեկ'],['Two','Երկու'],['Three','Երեք'],['Four','Չորս']],
  q:[{p:0,q:'How many cups are there?',a:'Four',o:['One','Two','Three'],x:'The story says “four cups”.'}]},
 {id:'lesson-colors-0',lessonId:'colors-0',lv:'A1',e:'🎨',t:{hy:'Գունավոր իրեր',en:'Colorful Things'},
  p:[['The red apple is here. The blue cup is next to the yellow book and the green bag.','Կարմիր խնձորն այստեղ է։ Կապույտ բաժակը դեղին գրքի և կանաչ պայուսակի կողքին է։']],
  v:[['Red','Կարմիր'],['Blue','Կապույտ'],['Yellow','Դեղին'],['Green','Կանաչ']],
  q:[{p:0,q:'What color is the cup?',a:'Blue',o:['Red','Yellow','Green'],x:'The story says “the blue cup”.'}]},
 {id:'lesson-daily-0',lessonId:'daily-0',lv:'A1',e:'📖',t:{hy:'Իմ օրը',en:'My Day'},
  p:[['I eat in the morning and drink water. In the evening, I read a book and sleep.','Առավոտյան ուտում եմ և ջուր խմում։ Երեկոյան գիրք եմ կարդում և քնում։']],
  v:[['Eat','Ուտել'],['Drink','Խմել'],['Read','Կարդալ'],['Sleep','Քնել']],
  q:[{p:0,q:'What does the person do in the evening?',a:'Reads and sleeps',o:['Eats and drinks','Works and runs','Studies and cooks'],x:'The story says “I read a book and sleep”.'}]},
 {id:'lesson-city-0',lessonId:'city-0',lv:'A1',e:'🏙️',t:{hy:'Իմ քաղաքը',en:'My City'},
  p:[['My house is in the city. I walk down the street to my school every morning.','Իմ տունը քաղաքում է։ Ամեն առավոտ փողոցով քայլում եմ դեպի դպրոց։']],
  v:[['House','Տուն'],['School','Դպրոց'],['Street','Փողոց'],['City','Քաղաք']],
  q:[{p:0,q:'Where is the house?',a:'In the city',o:['In a village','At school','In a park'],x:'The first sentence says the house is in the city.'}]}
);

/* Stories are attached to a lesson by the admin or by the built-in seed course.
   Learners can start reading only after they have met every target vocabulary item.
   Unknown words remain unmarked and are never silently added to the learner's SRS list. */
function pxStoryKnownVocab(s){
  const met=new Set(pxWords().met.map(w=>String(w.en||'').trim().toLowerCase()));
  return (s.v||[]).filter(v=>met.has(String(v[0]||'').trim().toLowerCase()));
}
function pxStoryRequiredKnown(s){return Math.max(1,(s.v||[]).length);}
function pxStoryCanOpen(s){return !!(s&&s.v&&s.v.length&&pxStoryKnownVocab(s).length>=pxStoryRequiredKnown(s));}
function pxLessonStoriesHtml(f){
  try{pxLoadStories();}catch(e){}
  const assigned=pxStoryList().filter(s=>s.lessonId===f.id);
  if(!assigned.length)return '';
  const cards=assigned.map(s=>{
    const known=pxStoryKnownVocab(s).length,total=(s.v||[]).length,remaining=Math.max(0,pxStoryRequiredKnown(s)-known),ready=total>0&&remaining===0;
    const stars=typeof pxStars==='function'?pxStars(s):0;
    const meta=`${esc(s.lv)} · ${known}/${total} ${esc(pt('storyKnownCount'))}`;
    const status=total===0?pt('storyNoVocab'):(ready?pt('read'):pt('storyLearnMore',{n:remaining}));
    return `<button class="px-card story ${ready?'':'story-locked'}" data-px="lesson-story" data-v="${esc(s.id)}" ${ready?'':'disabled'} aria-label="${esc(tx(s.t)+' · '+status)}">
      <span class="px-em" aria-hidden="true">${esc(s.e)}</span>
      <span class="px-tx"><b>${esc(tx(s.t))}</b><small>${meta}</small>${stars?`<small class="story-stars" aria-label="${esc(pt('storyProgress',{n:stars}))}">${'★'.repeat(stars)}${'☆'.repeat(3-stars)}</small>`:''}</span>
      <span class="px-bd ${ready?'ok':''}">${esc(status)}</span>
    </button>`;
  }).join('');
  return `<section class="card px-lesson-stories"><h2>${esc(pt('lessonStories'))}</h2><p class="note">${esc(pt('storyUnlockHint'))}</p><div class="px-grid">${cards}</div></section>`;
}

function pxHl(en,vocab){
  let h=esc(en);
  vocab.forEach(v=>{const re=new RegExp('\\b('+v[0].replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')\\b','gi');h=h.replace(re,(m)=>`<mark class="px-hl" title="${esc(v[1])}">${m}</mark>`);});
  return h;
}
function pxStoryView(){
  const s=pxStoryList().find(x=>x.id===PX.story);if(!s)return `<button class="px-back" data-px="hub">${LI('right')}<span>${esc(pt('back'))}</span></button><div class="say">${gloro('curious',56)}<span>${esc(pt('storyNoLongerAvailable'))}</span></div>`;
  if(!pxStoryCanOpen(s))return `<button class="px-back" data-px="hub">${LI('right')}<span>${esc(pt('back'))}</span></button><div class="say">${gloro('thinking',56)}<span>${esc(pt('storyNeedsWords',{n:Math.max(1,pxStoryRequiredKnown(s)-pxStoryKnownVocab(s).length)}))}</span></div>`;
  const known=pxStoryKnownVocab(s);
  return `<button class="px-back" data-px="hub">${LI('right')}<span>${esc(pt('back'))}</span></button>
  <article class="card px-story"><h1>${esc(tx(s.t))} <small class="px-lvl on">${esc(s.lv)}</small></h1>
   ${s.p.map((x,i)=>`<div class="px-para"><p lang="en">${pxHl(x[0],known)}</p>${PX.sTr[i]?`<p class="px-tr">${esc(x[1])}</p>`:''}
     <div class="px-row">${pxNarr(x)}<button class="sbtn" data-px="tr" data-v="${i}">${esc(pt(PX.sTr[i]?'hideTr':'showTr'))}</button></div></div>`).join('')}
   <h2>${esc(pt('vocabList'))}</h2><div class="px-vocab">${known.map(v=>`<div class="px-v"><b lang="en">${esc(v[0])}</b><span>${esc(v[1])}</span>${spkBtn(v[0])}</div>`).join('')}</div>
   <button class="btn btn-orange" data-px="quiz" data-v="${s.id}">${esc(pt('toQ'))}</button></article>`;
}
function pxStartQuiz(id){
  const s=pxStoryList().find(x=>x.id===id);if(!s)return;if(!pxStoryCanOpen(s)){toast(pt('storyNeedsWords',{n:Math.max(1,pxStoryRequiredKnown(s)-pxStoryKnownVocab(s).length)}),'confused');return;}
  const steps=s.q.map((q,i)=>toStep({id:'px-q-'+id+'-'+i,type:'read',data:{passage:s.p[q.p][0],prompt:q.q,answer:q.a,options:q.o,explanation:q.x}})).filter(Boolean);
  pxRun(steps,{story:id});
}

