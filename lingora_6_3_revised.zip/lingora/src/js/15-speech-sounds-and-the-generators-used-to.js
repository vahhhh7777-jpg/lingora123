/* ---------- speech, sounds and the generators used to build the built-in course ---------- */
const wordsOf=u=>u.w.map(a=>({en:a[0],hy:a[1],vis:a[2]||null}));
const sentsOf=u=>u.s.map(a=>({en:a[0],hy:a[1],x:a[2]||[]}));
const HAS_TTS=typeof window.speechSynthesis!=='undefined'&&typeof window.SpeechSynthesisUtterance!=='undefined';
