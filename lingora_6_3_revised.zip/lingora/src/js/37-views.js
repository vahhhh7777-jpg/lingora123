/* ---------- views ---------- */
const pxBack=()=>`<button class="px-back" data-px="hub">${LI('right')}<span>${esc(pt('back'))}</span></button>`;
/* Stories, flashcards, listening / speaking drills, the mistake book, vocabulary and placement are opened from Learn. */
function learnTab(){
  try{pxLoadStories();}catch(e){}
  if(PX.v==='story')return pxStoryView();
  if(PX.v==='cards')return pxCardsView();
  if(PX.v==='place')return pxPlaceView();
  pxLoadPlace();
  return learnView();
}
function learnTools(){
  const p=pxPx(),due=rvCardsDue(),miss=Object.keys(S.miss||{}).length,has=canPractice()||S.xp>0;
  const tile=(ic,label,attrs,badge)=>`<button class="lt-tile" ${attrs}><span class="lt-ic">${LI(ic)}</span><b>${esc(label)}</b>${badge?`<i class="lt-bd">${esc(badge)}</i>`:''}</button>`;
  return `<section class="lt" aria-label="${esc(t('toolsT'))}"><div class="lt-grid">
   ${tile('book',t('words'),'data-a="tab" data-v="words"')}
   ${tile('repeat',pt('cards'),'data-px="cards"',due?String(due):'')}
   ${has?tile('play',pt('listen'),'data-px="listen"'):''}
   ${has?tile('bot',pt('speak'),'data-px="speak"'):''}
   ${has?tile('badge',pt('mist'),'data-px="mist"',miss?String(miss):''):''}
   ${tile('target',pt('place'),'data-px="place"',p.cefr||'')}
  </div></section>`;
}
Object.assign(UI.hy,{toolsT:'Գործիքներ',lessonStories:'Այս դասի պատմությունը',storyKnownWords:'Պատմության բոլոր բառերն արդեն անցել ես',storyNoLesson:'Այս դասի համար պատմություն դեռ ավելացված չէ։',storyNeedsWords:'Պատմությունը կբացվի, երբ անցնես դրա բոլոր բառերը։',storyNotReady:'Պատմությունն այստեղ կհայտնվի համապատասխան բառերը սովորելուց հետո։',storyNoLongerAvailable:'Այս պատմությունն այլևս հասանելի չէ։',storyKnownCount:'անցած բառ',storyNoVocab:'Պատմության բառապաշարը լրացված չէ։',storyLearnMore:'Սովորիր ևս {n} բառ՝ պատմությունը բացելու համար։',storyUnlockHint:'Պատմությունը կբացվի, երբ ավարտես դրա ամբողջ բառապաշարը։'});
Object.assign(UI.en,{toolsT:'Learning tools',lessonStories:'This lesson’s story',storyKnownWords:'You have already learned every word in this story',storyNoLesson:'No story has been added to this lesson yet.',storyNeedsWords:'This story will unlock after you learn all of its vocabulary.',storyNotReady:'The story will appear here after you learn its vocabulary.',storyNoLongerAvailable:'This story is no longer available.',storyKnownCount:'words learned',storyNoVocab:'This story has no vocabulary list yet.',storyLearnMore:'Learn {n} more words to unlock this story.',storyUnlockHint:'Complete all the vocabulary for this story to unlock it.'});

/* flashcards: front = word in the course language, back = translation. "I know it" moves the word up the SRS boxes; "still learning" keeps it due */
function pxCardsStart(){
  const q=shuffle(pxDueCards()).slice(0,12);
  PX.cards={q,i:0,flip:false,known:0,unk:0,again:[]};PX.v='cards';tab='learn';pgAnim=true;render();
}
function pxCardsView(){
  const C=PX.cards;if(!C)return pxBack();
  if(!C.q.length)return `${pxBack()}<div class="say">${gloro('happy',56)}<span>${esc(UNITS.length?pt('noDue'):pt('noCourseData'))}</span></div>`;
  if(C.i>=C.q.length){
    return `${pxBack()}<section class="card px-done"><div class="say">${gloro('celebrating',72)}<span>${esc(pt('cdone'))}</span></div>
      <div class="tile-row"><div class="stat"><b>${C.known}</b><span>${esc(pt('know'))}</span></div><div class="stat"><b>${C.unk}</b><span>${esc(pt('dunno'))}</span></div></div>
      <button class="btn btn-purple" data-px="cards">${esc(pt('again'))}</button></section>`;
  }
  const w=C.q[C.i],pct=Math.round(C.i/C.q.length*100);
  return `${pxBack()}<div class="px-prog" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}"><i style="width:${pct}%"></i></div>
   <p class="note px-cnt">${esc(pt('cardOf',{i:C.i+1,n:C.q.length}))} · ${esc(pt('cgToday',{n:pxCardToday(),g:pxCardGoal()}))}</p>
   <button class="px-flash ${C.flip?'flip':''}" data-px="flip" aria-label="${esc(pt('flip'))}">
     <span class="pf-in"><span class="pf-f"><b lang="${tl()}">${esc(w.en)}</b>${w.vis&&w.vis[0]==='e'?`<em aria-hidden="true">${esc(w.vis[1])}</em>`:''}<small>${esc(pt('front'))}</small></span>
     <span class="pf-b"><b>${esc(w.hy)}</b><small lang="${tl()}">${esc(w.en)}</small>${pxExampleHtml(w)}</span></span></button>
   <div class="px-row">${spkBtn(w.en)}</div>
   ${C.flip?`<div class="px-ans"><button class="btn btn-ghost" data-px="dunno">${esc(pt('dunno'))}</button><button class="btn btn-good" data-px="know">${esc(pt('know'))}</button></div>`:`<div class="px-ans"><button class="btn btn-purple" data-px="flip">${esc(pt('flip'))}</button></div>`}`;
}
function pxCardGrade(ok){
  const C=PX.cards;if(!C||C.i>=C.q.length)return;
  const w=C.q[C.i];srsMark(wordKey(w),ok);pxCardCount();save();pushProgress();
  if(ok)C.known++;else{C.unk++;if(C.again.indexOf(w)<0&&C.q.length<24){C.q.push(w);C.again.push(w);}}
  C.i++;C.flip=false;render();
}

/* listening + speaking practice built from words / sentences the learner has already met; they run in the normal lesson runner (hearts, feedback, XP) */
function pxStartListen(){
  const {met}=pxWords();
  if(met.length<4){toast(pt('needMore'),'confused');return;}
  const ws=pick(met,Math.min(8,met.length)),all=met.map(w=>w.hy);
  const steps=ws.map((w,i)=>toStep({id:'px-l-'+i+'-'+w.en,type:'listen',data:{text:w.en,answer:w.hy,options:pick(all.filter(x=>x!==w.hy),3),explanation:w.en+' = '+w.hy}})).filter(Boolean);
  pxRun(steps);
}
function pxStartSpeak(){
  const ss=pxSents();
  if(ss.length<2){toast(pt('needMore'),'confused');return;}
  const steps=pick(ss,Math.min(6,ss.length)).map((s,i)=>toStep({id:'px-s-'+i+'-'+s.en,type:'speak',data:{text:s.en,translation:s.hy}})).filter(Boolean);
  pxRun(steps);
}
function pxRun(steps,px){
  if(!steps.length){toast(t('noQ'),'confused');return;}
  L=newLesson({practice:true,steps,px:px||null});
  beginOrOpen('practice','',steps.length);
}
/* called from award() when a lesson that carries L.px finishes */
function pxDone(l){
  if(l&&l.px&&l.px.story){
    const miss=l.attempts-l.correct,st=miss===0?3:miss<=1?2:1,p=pxPx();
    const ds=(PXDB.list||[]).find(x=>x.id===l.px.story);
    if(ds){PXDB.prog[ds.id]=Math.max(PXDB.prog[ds.id]||0,st);if(pxCloud())B.storyRec(ds.id,st).catch(warnErr('story progress not saved'));}
    else{p.stories[l.px.story]=Math.max(p.stories[l.px.story]||0,st);save();}
  }
}

