/* ---------- Lingora 6.2: keyboard + screen-reader layer ----------
   Pure DOM helpers, no app state and no business logic. Everything here is idempotent and runs once per render
   (batched on one animation frame), so it adds no work while the page is idle.
   - skip link to the main content
   - a real <h1> on every page (visually hidden when the page has no visible one)
   - the page name is announced and put into document.title after every navigation
   - dialogs: focus moves in, Tab stays inside, focus returns to the opener when it closes */
Object.assign(UI.hy,{skipMain:'Անցնել հիմնական բովանդակությանը'});
Object.assign(UI.en,{skipMain:'Skip to main content'});
(function ux62(){
  const app=document.getElementById('app'),les=document.getElementById('lesson');
  if(!app||typeof MutationObserver==='undefined')return;
  const FOC='a[href],button:not([disabled]),input:not([disabled]):not([type=hidden]),select:not([disabled]),textarea:not([disabled]),summary,[tabindex]:not([tabindex="-1"])';
  const seeable=el=>!!(el.offsetWidth||el.offsetHeight||el.getClientRects().length);
  const skip=document.createElement('button');skip.type='button';skip.className='skip';skip.hidden=true;
  const live=document.createElement('div');live.className='sr';live.setAttribute('aria-live','polite');live.setAttribute('role','status');
  document.body.prepend(live);document.body.prepend(skip);
  skip.addEventListener('click',()=>{const m=document.querySelector('main');if(m){m.focus({preventScroll:false});}});
  let lastName='',opener=null,openerKey='',hadDlg=false,queued=false,restoreKey='',restoreUntil=0,trig='';
  // the render that opens a dialog replaces the button that was used, so remember it before that happens
  const keyOf=el=>{const b=el&&el.closest?el.closest('[data-a]'):null;return b?(b.dataset.a||'')+'|'+(b.dataset.v||''):'';};
  document.addEventListener('focusin',e=>{const k=keyOf(e.target);if(k)trig=k;},true);
  document.addEventListener('click',e=>{const k=keyOf(e.target);if(k)trig=k;},true);
  const dlg=()=>{for(const root of [les,app]){if(!root||root.hidden)continue;const d=root.querySelector('[role=dialog][aria-modal=true]');if(d&&seeable(d))return d;}return null;};
  function pass(){
    queued=false;
    const main=app.querySelector('main');
    skip.hidden=!main;skip.textContent=t('skipMain');
    if(main){
      if(!main.id)main.id='main';
      if(main.getAttribute('tabindex')===null)main.setAttribute('tabindex','-1');
      let h=main.querySelector('h1');
      if(!h){
        const cur=app.querySelector('nav.nav [aria-current=page]');
        const name=cur?(cur.getAttribute('aria-label')||cur.textContent||'').trim():'Lingora';
        h=document.createElement('h1');h.className='sr';h.textContent=name;main.prepend(h);
      }
      const name=(h.textContent||'').replace(/\s+/g,' ').trim();
      if(name){
        const want=name+' · '+((typeof BRAND!=='undefined'&&BRAND&&BRAND.name)||'Lingora');
        if(document.title!==want)document.title=want;
        if(name!==lastName){lastName=name;live.textContent=name;}
      }
    }
    const d=dlg();
    if(d){
      if(!hadDlg){const a=document.activeElement;opener=a&&a!==document.body&&!d.contains(a)?a:null;openerKey=trig;}
      hadDlg=true;
      if(!d.contains(document.activeElement)){if(d.getAttribute('tabindex')===null)d.setAttribute('tabindex','-1');d.focus({preventScroll:true});}
    }else if(hadDlg){
      hadDlg=false;
      restoreKey=openerKey;restoreUntil=Date.now()+800;
      let back=opener&&opener.isConnected?opener:null;
      if(back&&back.focus){back.focus({preventScroll:true});restoreKey='';}
      opener=null;openerKey='';
    }
    // the closing render can be followed by one more render; keep trying for a moment until focus has a home again
    if(restoreKey&&Date.now()<restoreUntil){
      const a=document.activeElement;
      if(!a||a===document.body){
        const p=restoreKey.split('|');
        const back=p[0]?document.querySelector('[data-a="'+p[0]+'"]'+(p[1]?'[data-v="'+p[1]+'"]':'')):null;
        if(back){back.focus({preventScroll:true});}
      }else restoreKey='';
    }
  }
  const queue=()=>{if(!queued){queued=true;requestAnimationFrame(pass);}};
  new MutationObserver(queue).observe(app,{childList:true});
  if(les)new MutationObserver(queue).observe(les,{childList:true,attributes:true,attributeFilter:['hidden']});
  document.addEventListener('keydown',e=>{
    if(e.key!=='Tab'||e.defaultPrevented)return;
    const d=dlg();if(!d)return;
    const f=[...d.querySelectorAll(FOC)].filter(seeable);
    if(!f.length){e.preventDefault();d.focus();return;}
    const first=f[0],last=f[f.length-1],a=document.activeElement;
    if(e.shiftKey&&(a===first||a===d||!d.contains(a))){e.preventDefault();last.focus();}
    else if(!e.shiftKey&&(a===last||!d.contains(a))){e.preventDefault();first.focus();}
  });
  queue();
})();
