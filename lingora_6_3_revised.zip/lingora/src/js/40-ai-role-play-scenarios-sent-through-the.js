/* ---------- AI role-play scenarios (sent as the structured `scenario` field of the ai-coach function, mode "tutor") ---------- */
const SCN={restaurant:'you are the waiter, I am the customer',airport:'you are the check-in agent, I am the traveller',hotel:'you are the receptionist, I am the guest',shop:'you are the shop assistant, I am the customer',doctor:'you are the doctor, I am the patient',directions:'you are a local, I ask for directions'};
function pxScnBar(){
  const keys=Object.keys(SCN);
  return `<div class="px-scn" role="group" aria-label="${esc(pt('scnT'))}"><b>${esc(pt('scnT'))}</b><div class="chips">${keys.map(k=>`<button type="button" class="chip ${PX.scn===k?'ok':''}" data-px="scn" data-v="${k}">${esc(pt('scn'+k.charAt(0).toUpperCase()+k.slice(1)))}</button>`).join('')}${PX.scn?`<button type="button" class="chip" data-px="scn" data-v="">${esc(pt('scnOff'))}</button>`:''}</div>
   ${PX.scn?`<p class="note">${esc(pt('scnOn',{s:pt('scn'+PX.scn.charAt(0).toUpperCase()+PX.scn.slice(1))}))}</p>`:''}</div>`;
}

