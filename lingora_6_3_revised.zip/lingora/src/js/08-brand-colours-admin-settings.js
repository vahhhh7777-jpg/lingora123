/* ---------- brand colours (admin > Settings) ---------- */
function shade(hex,k){
  const m=/^#?([0-9a-f]{6})$/i.exec(hex||'');if(!m)return hex;
  const n=parseInt(m[1],16),f=c=>Math.max(0,Math.min(255,Math.round(k<0?c*(1+k):c+(255-c)*k)));
  return '#'+[n>>16,(n>>8)&255,n&255].map(c=>f(c).toString(16).padStart(2,'0')).join('');
}
function applyBrand(){
  const r=document.documentElement.style,ok=c=>/^#[0-9a-f]{6}$/i.test(c||'');
  const set=(k,v)=>{if(v)r.setProperty(k,v);else r.removeProperty(k);};
  const pu=ok(BRAND.primary)?BRAND.primary:'',or=ok(BRAND.secondary)?BRAND.secondary:'';
  set('--purple',pu);set('--purple-d',pu&&shade(pu,-.22));set('--purple-t',pu&&shade(pu,-.18));set('--purple-tint',pu&&shade(pu,.86));set('--purple-deep',pu&&shade(pu,-.08));
  set('--orange',or);set('--orange-d',or&&shade(or,-.2));set('--orange-t',or&&shade(or,-.4));set('--accent-tint',or&&shade(or,.88));
  document.title=BRAND.name||'Lingora';
}
function setBrand(v){
  BRAND=Object.assign({name:'Lingora',primary:'',secondary:'',mascot:{}},v||{});
  if(!BRAND.mascot||typeof BRAND.mascot!=='object')BRAND.mascot={};
  applyBrand();
}
const logoName=()=>{const n=(BRAND.name||'Lingora');return n==='Lingora'?'Lin<b>gora</b>':esc(n);};

