/* ---------- catalog: languages > courses > units > lessons > questions ---------- */
const byPos=(a,b)=>(a.pos||0)-(b.pos||0);
const tx=(o,lang)=>o?(typeof o==='string'?o:(o[lang||S.lang]||o.hy||o.en||'')):'';
const EMPTY_CAT=()=>({languages:[],courses:[],units:[],lessons:[],questions:[]});
let CAT=EMPTY_CAT();      /* what the app shows (database catalog, or the built-in one when the database is empty) */
let QBY={};               /* lesson id -> questions in order */
let UNITS=[],FLAT=[];     /* the selected course, flattened for the learning path */
const SRC_NOTE={hy:{hy:'Հայախոսների համար',en:'For Armenian speakers'},en:{hy:'Անգլիախոսների համար',en:'For English speakers'}};
const KIDS={languages:[['courses','language_id']],courses:[['units','course_id']],units:[['lessons','unit_id']],lessons:[['questions','lesson_id']],questions:[]};
function rmRow(cat,table,id){
  KIDS[table].forEach(k=>{cat[k[0]].filter(r=>r[k[1]]===id).map(r=>r.id).forEach(cid=>rmRow(cat,k[0],cid));});
  cat[table]=cat[table].filter(r=>r.id!==id);
}
function srcNote(id){
  if(SRC_NOTE[id])return SRC_NOTE[id];
  const l=langOf(id);
  return l?{hy:tx(l.name,'hy')+' խոսողների համար',en:'For '+tx(l.name,'en')+' speakers'}:{hy:'',en:''};
}
const unitLocked=u=>{const c=CAT&&CAT.courses.find(x=>x.id===u.course_id);return !!(u.vip||(c&&c.vip))&&!isVip();};

function setCatalog(c){
  const ok=c&&c.courses&&c.courses.length;
  CAT=ok?{languages:c.languages||[],courses:c.courses||[],units:c.units||[],lessons:c.lessons||[],questions:c.questions||[]}:buildSeed();
  QBY={};
  CAT.questions.slice().sort(byPos).forEach(q=>{(QBY[q.lesson_id]=QBY[q.lesson_id]||[]).push(q);});
  applyCourse();
}
const langOf=id=>CAT.languages.find(l=>l.id===id)||null;
/* Round country flags (inline SVG, no network). Only languages without one fall back to their letter code. */
const FLAG_SVG={
 en:'<rect width="60" height="30" fill="#012169"/><path d="M0 0L60 30M60 0L0 30" stroke="#fff" stroke-width="6"/><path d="M0 0L60 30M60 0L0 30" stroke="#C8102E" stroke-width="2"/><path d="M30 0V30M0 15H60" stroke="#fff" stroke-width="10"/><path d="M30 0V30M0 15H60" stroke="#C8102E" stroke-width="6"/>',
 fr:'<rect width="20" height="30" fill="#0055A4"/><rect x="20" width="20" height="30" fill="#fff"/><rect x="40" width="20" height="30" fill="#EF4135"/>',
 de:'<rect width="60" height="10" fill="#000"/><rect y="10" width="60" height="10" fill="#DD0000"/><rect y="20" width="60" height="10" fill="#FFCE00"/>',
 it:'<rect width="20" height="30" fill="#009246"/><rect x="20" width="20" height="30" fill="#fff"/><rect x="40" width="20" height="30" fill="#CE2B37"/>',
 ru:'<rect width="60" height="10" fill="#fff"/><rect y="10" width="60" height="10" fill="#0039A6"/><rect y="20" width="60" height="10" fill="#D52B1E"/>',
 tr:'<rect width="60" height="30" fill="#E30A17"/><circle cx="23" cy="15" r="8" fill="#fff"/><circle cx="26" cy="15" r="6.4" fill="#E30A17"/><path d="M36 15l5.6-1.8-3.5 4.8v-6l3.5 4.8z" fill="#fff"/>',
 az:'<rect width="60" height="10" fill="#00B5E2"/><rect y="10" width="60" height="10" fill="#EF3340"/><rect y="20" width="60" height="10" fill="#509E2F"/><circle cx="28" cy="15" r="4.4" fill="#fff"/><circle cx="29.4" cy="15" r="3.6" fill="#EF3340"/><circle cx="34" cy="15" r="1.4" fill="#fff"/>'
};
const flagHtml=(lid,fallback)=>FLAG_SVG[lid]?`<svg class="flag" viewBox="0 0 60 30" preserveAspectRatio="xMidYMid slice" aria-hidden="true">${FLAG_SVG[lid]}</svg>`:esc(fallback);
/* A course as the views use it: code, name, tts, difficulty, months, note, real */
function courseView(c){
  const L=langOf(c.language_id)||{};
  const code=L.flag||String(c.id).slice(0,2).toUpperCase();
  return {id:c.id,raw:c,code,flag:flagHtml(c.language_id||c.id,code),name:{hy:tx(c.title,'hy')||tx(L.name,'hy'),en:tx(c.title,'en')||tx(L.name,'en')},
    tts:L.tts||'en-US',diff:c.difficulty||L.difficulty||'easy',months:c.months||0,real:!c.sample,draft:!!c.draft,
    note:srcNote(c.source),level:c.level||'',source:c.source,lpos:L.pos||0};
}
function courseCards(){
  return CAT.courses.filter(c=>c.published!==false&&!c.archived&&!c.sample&&(!langOf(c.language_id)||langOf(c.language_id).active!==false))
    .map(courseView).sort((a,b)=>((b.source===S.lang)-(a.source===S.lang))||a.lpos-b.lpos||byPos(a.raw,b.raw));
}
const curCourse=()=>{const l=courseCards();return l.find(c=>c.id===S.course)||l[0]||null;};
const ttsLang=()=>{const c=curCourse();return c?c.tts:'en-US';};

function applyCourse(){
  const c=curCourse();
  UNITS=[];FLAT.length=0;
  if(!c)return;
  const lessonsBy={};
  CAT.lessons.filter(l=>l.published!==false).forEach(l=>{(lessonsBy[l.unit_id]=lessonsBy[l.unit_id]||[]).push(l);});
  CAT.units.filter(u=>u.course_id===c.id&&u.published!==false).sort(byPos).forEach((u,ui)=>{
    const ls=(lessonsBy[u.id]||[]).filter(l=>(QBY[l.id]||[]).length).sort(byPos);
    const locked=unitLocked(u);
    if(!locked&&!ls.length)return;
    const unit={id:u.id,t:u.title||{hy:'',en:''},d:u.descr||{hy:'',en:''},tint:u.tint,vip:!!u.vip||!!c.vip,pos:u.pos,locked,words:[],sents:[],_fi:FLAT.length,_n:0};
    if(!locked){
      ls.forEach((l,j)=>{
        FLAT.push({id:l.id,u:unit,ui,j,lesson:l});
        (QBY[l.id]||[]).forEach(q=>{
          if(q.type==='intro'&&q.data)unit.words.push({en:q.data.en,hy:q.data.hy,ex:q.data.example||'',pron:q.data.pron||'',pos:q.data.pos||'',lid:l.id});
          else if(q.type==='order'&&q.data)unit.sents.push({en:q.data.sentence,hy:q.data.prompt,lid:l.id});
        });
      });
      unit._n=ls.length;
    }
    UNITS.push(unit);
  });
}
/* How complete a course really is, from the rows we hold. Used by the admin and by the learner's course card. */
function courseHealth(cat,id){
  const us=cat.units.filter(u=>u.course_id===id),uid=new Set(us.map(u=>u.id));
  const ls=cat.lessons.filter(l=>uid.has(l.unit_id)),qc={};
  cat.questions.forEach(q=>{qc[q.lesson_id]=(qc[q.lesson_id]||0)+1;});
  const pub=ls.filter(l=>l.published!==false);
  return {units:us.length,lessons:ls.length,published:pub.length,questions:ls.reduce((n,l)=>n+(qc[l.id]||0),0),
    empty:pub.filter(l=>!qc[l.id]).length,thin:pub.filter(l=>qc[l.id]&&qc[l.id]<5).length,verified:pub.filter(l=>l.review==='verified').length};
}
function courseStatus(cat,c){
  if(c.archived)return 'archived';
  if(c.published===false)return 'draft';
  const h=courseHealth(cat,c.id);
  return h.published===0||h.empty>0?'incomplete':'published';
}
function lessonIssues(l,qs){
  const out=[],ok=qs.filter(q=>toStep(q));
  if(!qs.length)out.push(['err','iss_noQ']);
  else if(ok.length<qs.length)out.push(['err','iss_bad']);
  if(qs.length&&!qs.some(q=>q.type!=='intro'))out.push(['err','iss_noEx']);
  if(qs.length&&qs.length<5)out.push(['warn','iss_few']);
  if(!qs.some(q=>q.type==='intro')&&!String(l.grammar||'').trim())out.push(['warn','iss_noVocab']);
  if(!String(l.objectives||'').trim())out.push(['warn','iss_noObj']);
  if(l.review!=='verified')out.push(['info','iss_unverified']);
  return out;
}
function courseStats(id){
  const ls=[];
  CAT.units.filter(u=>u.course_id===id&&u.published!==false&&!unitLocked(u)).forEach(u=>{
    CAT.lessons.filter(l=>l.unit_id===u.id&&l.published!==false&&(QBY[l.id]||[]).length).forEach(l=>ls.push(l));
  });
  const d=ls.filter(l=>S.done[l.id]).length;
  return {total:ls.length,done:d,pct:ls.length?Math.round(d/ls.length*100):0};
}
