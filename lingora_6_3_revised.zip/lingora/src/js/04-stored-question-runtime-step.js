/* ---------- stored question -> runtime step ---------- */
const withAns=d=>shuffle(Array.from(new Set([d.answer].concat(d.options||[]).filter(x=>x!=null&&String(x)!==''))));
const safeUrl=(u,kind)=>typeof u==='string'&&(/^https:\/\//i.test(u)||u.indexOf('data:'+kind+'/')===0);
Object.assign(UI.hy,{qImg:'Ընտրիր ճիշտ նկարը',fixT:'Ուղղենք բաց թողած վարժությունները։'});
Object.assign(UI.en,{qImg:'Select the correct image',fixT:'Let’s correct the exercises you missed!'});
/* word -> {vis, hy} lookup built from the course's "new word" cards; lets an image question be shown the other way round (word -> pick the picture) */
let _VM=null;
function visMap(){
  const n=Object.keys(QBY).length;
  if(_VM&&_VM.q===QBY&&_VM.n===n)return _VM.m;
  const m={};
  Object.keys(QBY).forEach(k=>(QBY[k]||[]).forEach(q=>{const d=q.data||{};if(q.type==='intro'&&d.en&&d.hy&&d.vis&&d.vis[0]==='e'&&d.vis[1])m[d.en]={vis:d.vis,hy:d.hy};}));
  _VM={q:QBY,n,m};return m;
}
const hash0=x=>{let h=0;String(x).split('').forEach(c=>{h=(h*31+c.charCodeAt(0))|0;});return Math.abs(h);};
/* beginners: every picture word question in the first topic of a course is shown as 'hear the word, tap the picture' */
function inFirstUnit(qid){
  for(const lid of Object.keys(QBY)){if((QBY[lid]||[]).some(q=>q.id===qid)){const f=FLAT.find(x=>x.id===lid);return !!f&&f.ui===0;}}
  return false;
}
function imgVariant(s){
  if(s.k!=='pic'||!s.vis||s.vis[0]!=='e'||s.opts.length<4)return;
  if(hash0(s.id)%2&&!inFirstUnit(s.id))return;
  const vm=visMap(),cards=s.opts.map(o=>vm[o]);
  if(cards.some(c=>!c)||new Set(cards.map(c=>c.vis[1])).size<s.opts.length)return;
  s.k='imgsel';s.cards=cards;
}
function toStep(q){
  const s=toStep0(q);
  if(!s)return null;
  imgVariant(s);
  const d=q.data||{};
  if(d.hint)s.hint=String(d.hint);
  if(d.instruction)s.instr=String(d.instruction);
  if(d.wrongMsg)s.wrongMsg=String(d.wrongMsg);
  if(safeUrl(d.image,'image'))s.image=d.image;
  if(safeUrl(d.audio,'audio'))s.audio=d.audio;
  return s;
}
function toStep0(q){
  const d=q.data||{},id=q.id;
  try{
    switch(q.type){
      case 'intro':if(!d.en||!d.hy)return null;return {k:'intro',id,en:d.en,hy:d.hy,vis:d.vis||null,ex:d.example||'',exTr:d.exampleTr||'',pron:d.pron||'',pos:d.pos||'',def:d.definition||''};
      case 'pics':{
        const items=(Array.isArray(d.items)?d.items:[]).filter(x=>x&&x.w&&((x.e&&String(x.e).trim())||safeUrl(x.img,'image')));
        if(items.length<3||!d.answer||!items.some(x=>x.w===d.answer))return null;
        const pickN=shuffle(items.filter(x=>x.w!==d.answer)).slice(0,3).concat(items.filter(x=>x.w===d.answer).slice(0,1)),sh=shuffle(pickN);
        return {k:'imgsel',id,ans:d.answer,opts:sh.map(x=>x.w),cards:sh.map(x=>({vis:x.e?['e',String(x.e)]:null,img:safeUrl(x.img,'image')?x.img:'',hy:x.l||''})),expl:d.explanation||'',key:d.answer};
      }
      case 'mc':if(!d.prompt||!d.answer)return null;return {k:'gmc',id,prompt:d.prompt,speak:d.speak||'',opts:withAns(d),ans:d.answer,expl:d.explanation||'',key:d.answer};
      case 'image':if(!d.vis||!d.answer)return null;return {k:'pic',id,vis:d.vis,opts:withAns(d),ans:d.answer,expl:d.explanation||'',key:d.answer};
      case 'listen':if(!d.text||!d.answer)return null;return {k:'listen',id,text:d.text,opts:withAns(d),ans:d.answer,expl:d.explanation||'',key:d.answer};
      case 'read':if(!d.passage||!d.prompt||!d.answer)return null;return {k:'read',id,passage:d.passage,prompt:d.prompt,opts:withAns(d),ans:d.answer,expl:d.explanation||'',key:d.answer};
      case 'type':if(!d.prompt||!d.answer)return null;return {k:'type',id,prompt:d.prompt,ans:d.answer,accept:d.accept||[],expl:d.explanation||'',key:d.answer};
      case 'listen_type':if(!d.text&&!d.audio)return null;if(!d.text&&!d.answer)return null;return {k:'listen_type',id,text:d.text||d.answer,ans:d.answer||d.text,accept:d.accept||[],expl:d.explanation||'',key:d.answer||d.text};
      case 'write':if(!d.prompt||!(d.answer||(d.keywords&&d.keywords.length)))return null;return {k:'write',id,prompt:d.prompt,ans:d.answer||(d.keywords||[]).join(', '),accept:d.accept||[],keywords:d.keywords||[],expl:d.explanation||'',key:d.answer||d.prompt};
      case 'match':{
        const pairs=(d.pairs||[]).filter(p=>p&&p[0]&&p[1]).map((p,i)=>({id:i,en:p[0],hy:p[1]}));
        if(pairs.length<2)return null;
        return {k:'match',id,pairs,left:shuffle(pairs.map(p=>p.id)),right:shuffle(pairs.map(p=>p.id)),key:pairs[0].en};
      }
      case 'speak':if(!d.text)return null;return {k:'speak',id,text:d.text,hy:d.translation||'',ans:d.text,expl:d.explanation||'',key:d.text};
      case 'tf':if(!d.statement||(d.answer!=='true'&&d.answer!=='false'))return null;return {k:'gmc',id,prompt:d.statement,speak:'',opts:[t('tTrue'),t('tFalse')],vals:['true','false'],ans:d.answer==='true'?t('tTrue'):t('tFalse'),lbl:'qTf',expl:d.explanation||'',key:d.statement};
      case 'fix':if(!d.wrong||!d.answer)return null;return {k:'type',id,prompt:d.wrong,lbl:'qFix',ans:d.answer,accept:d.accept||[],expl:d.explanation||'',key:d.answer};
      case 'order':{
        const words=String(d.sentence||'').replace(/[?.!,։]/g,'').split(' ').filter(Boolean);
        if(!words.length)return null;
        return {k:'build',id,prompt:d.prompt||'',sent:d.sentence,words,tiles:shuffle(words.concat(d.extra||[])),expl:d.explanation||'',key:d.sentence};
      }
      case 'fill':{
        const sn=String(d.sentence||''),at=sn.indexOf('___');
        if(at<0||!d.answer)return null;
        return {k:'fill',id,prompt:d.prompt||'',before:sn.slice(0,at),after:sn.slice(at+3),ans:d.answer,opts:withAns({answer:d.answer,options:d.distractors}),expl:d.explanation||'',key:d.answer};
      }
    }
  }catch(e){}
  return null;
}
const stepsFor=id=>(QBY[id]||[]).filter(q=>q.published!==false).map(toStep).filter(Boolean);
function practiceSteps(){
  const pool=[];
  FLAT.forEach(f=>{if(S.done[f.id])(QBY[f.id]||[]).forEach(q=>{if(q.type!=='intro')pool.push(q);});});
  /* spaced repetition: questions that are due (or never seen) come first, the rest fill up the round */
  const due=pool.filter(q=>{const k=(toStep(q)||{}).key;return k&&typeof srsDue==='function'&&srsDue(k)&&S.srs&&S.srs[k];});
  const first=pick(due,Math.min(10,due.length));
  const rest=pick(pool.filter(q=>first.indexOf(q)<0),Math.max(0,Math.min(10,pool.length)-first.length));
  return first.concat(rest).map(toStep).filter(Boolean);
}
