/* ---------- cache, offline and sync ---------- */
function loadCache(){try{return JSON.parse(localStorage.getItem(CKEY));}catch(e){return null;}}
function saveCache(){
  try{
    if(!A.user){localStorage.removeItem(CKEY);return;}
    localStorage.setItem(CKEY,JSON.stringify({user:A.user,profile:A.profile,cat:A.rawCat,cfg:{game:G,brand:BRAND},content:CONTENT.filter(c=>c.kind!=='mascot'||liveC(c))}));
  }catch(e){}
}
/* Rules, brand and admin-written content come from the database; defaults apply if it has none yet. */
async function refreshConfig(){
  if(!B)return;
  try{const c=await B.getConfig();setGame(c.game);setBrand(c.brand);}catch(e){}
  try{CONTENT=await B.listContent();}catch(e){}
  try{await applyUiOverrides();}catch(e){}
  if(A.user)syncContentNotes();
}
/* A suspended account is signed out on this device. The database also refuses to save its progress. */
async function blockIfSuspended(){
  if(!A.profile||!A.profile.suspended)return false;
  try{await B.signOut();}catch(e){}
  A.user=null;A.profile=null;saveCache();
  throw E('suspended');
}
function syncOffline(){
  if(MODE!=='cloud'||!('serviceWorker' in navigator)||!/^https?:$/.test(location.protocol))return;
  try{
    if(isVip()&&A.user){navigator.serviceWorker.register('sw.js').catch(()=>{});}
    else{
      navigator.serviceWorker.getRegistrations().then(rs=>rs.forEach(r=>r.unregister())).catch(()=>{});
      if(window.caches)caches.keys().then(ks=>ks.forEach(k=>{if(k.indexOf('ee-')===0)caches.delete(k);})).catch(()=>{});
    }
  }catch(e){}
}
/* ---------- progress sync queue ----------
   Progress is always written to this device first (save()). The server copy is a whole snapshot merged with mergeP
   (max / union, keyed by lesson id), so a retry can never award XP or a lesson completion twice.
   One flush runs at a time; changes made while it runs are picked up by the same flush (SYNC.rev).
   A failed flush keeps the "pending" marker in localStorage, retries with exponential backoff (2 s .. 60 s, jitter),
   retries at once when the browser comes back online, and offers a Retry button. After a failure the next attempt
   first merges the server copy, so progress made on another device is not overwritten. */
const SYNC={st:'idle',tries:0,next:0,err:'',rev:0,run:null,timer:null,tick:null,overwrite:false,okAt:0};
function syncReset(){clearTimeout(SYNC.timer);SYNC.timer=null;SYNC.st='idle';SYNC.tries=0;SYNC.err='';SYNC.overwrite=false;syncUi();}
const syncPKey=()=>KEY+'.pend';
function syncMark(on){try{if(on)localStorage.setItem(syncPKey(),JSON.stringify({uid:A.user&&A.user.id,t:Date.now()}));else localStorage.removeItem(syncPKey());}catch(e){}}
function syncWasPending(){try{const j=JSON.parse(localStorage.getItem(syncPKey())||'null');return !!(j&&A.user&&j.uid===A.user.id);}catch(e){return false;}}
/* ---------- pending server-side reset (B-006) ----------
   "Reset progress" must reach the server, otherwise the server copy (XP, finished lessons, streak) comes straight back on the
   next sync. The wish to reset is stored on this device (localStorage) until the server confirms, so a failed request, a reload
   or a closed tab cannot undo it. While it is pending, server progress is NOT merged into the device and the economy state is
   not re-applied. */
const resetKey=()=>KEY+'.reset';
function resetMark(on){try{if(on)localStorage.setItem(resetKey(),JSON.stringify({uid:A.user&&A.user.id,t:Date.now()}));else localStorage.removeItem(resetKey());}catch(e){}}
function resetPending(){try{const j=JSON.parse(localStorage.getItem(resetKey())||'null');return !!(j&&A.user&&j.uid===A.user.id);}catch(e){return false;}}
/* ---------- unsynced progress that must survive a sign-out (P1-01) ----------
   Signing out wipes the progress kept on this device (privacy on shared phones). If the last changes had not reached the server yet,
   that wipe lost them for good. Now sign-out first tries to deliver them; if the server cannot be reached, a snapshot for THIS account is
   kept in localStorage (progress only, no e-mail or password) and merged back the next time the same account signs in (max/union merge, so
   nothing is counted twice). It is dropped after 30 days, when another snapshot replaces it, and when the account is deleted. */
const stashKey=uid=>KEY+'.stash.'+uid;
function stashSave(){
  if(!A.user||resetPending())return false;
  try{localStorage.setItem(stashKey(A.user.id),JSON.stringify({t:Date.now(),p:progOf(S)}));return true;}
  catch(e){console.warn('could not keep unsynced progress for the next sign-in',e);return false;}
}
function stashTake(uid){
  try{
    const k=stashKey(uid),j=JSON.parse(localStorage.getItem(k)||'null');
    if(!j)return null;
    localStorage.removeItem(k);
    return j.p&&Date.now()-(j.t||0)<30*864e5?j.p:null;
  }catch(e){return null;}
}
function stashDrop(uid){try{localStorage.removeItem(stashKey(uid));}catch(e){}}
/* Resolves when nothing is pending (or the server confirmed the reset); throws when it could not be delivered. */
async function resetFlush(){
  if(!B||!A.user||!resetPending())return;
  if(typeof B.resetProgress!=='function'){resetMark(false);return;}
  if(netOff())throw E('net');
  try{await B.resetProgress();}
  catch(e){
    if(/could not find the function|pgrst202|schema cache/i.test(String((e&&e.message)||e))){resetMark(false);console.error('reset_my_progress is missing on the server: apply migrations/013_reset_progress.sql',e);}
    throw e;
  }
  resetMark(false);SYNC.overwrite=true;SYNC.rev++;syncMark(true);
}
/* The Reset button: clear this device, then make the server do the same (retried until it succeeds). */
async function startReset(){
  resetProgress();S.uid=A.user?A.user.id:'';save();
  if(B&&A.user&&typeof B.resetProgress==='function'){
    resetMark(true);SYNC.overwrite=true;
    try{await resetFlush();}catch(e){syncFail(e,netOff());toast(t('resetPend'),'confused');return false;}
    await pushProgress();await econSync();return true;
  }
  SYNC.overwrite=true;await pushProgress();return true;
}
function syncDelay(n){const b=Math.min(60000,2000*Math.pow(2,Math.max(0,n-1)));return Math.round(b*(0.8+Math.random()*0.4));}
function netOff(){return typeof navigator!=='undefined'&&navigator.onLine===false;}
function syncUi(){
  let el=document.getElementById('syncbar');
  const show=SYNC.st==='pending'||SYNC.st==='offline'||SYNC.st==='denied'||SYNC.st==='syncing'&&SYNC.tries>0||SYNC.st==='ok'&&Date.now()-SYNC.okAt<2500;
  if(!show||!A.user){if(el)el.hidden=true;clearInterval(SYNC.tick);SYNC.tick=null;return;}
  if(!el){el=document.createElement('div');el.id='syncbar';el.setAttribute('role','status');el.setAttribute('aria-live','polite');document.body.appendChild(el);
    el.addEventListener('click',e=>{if(e.target.closest('[data-sync="retry"]'))syncNow();});}
  const sec=Math.max(0,Math.ceil((SYNC.next-Date.now())/1000));
  let msg,btn=false,cls='';
  if(SYNC.st==='ok'){msg=t('syncOk');cls='ok';}
  else if(SYNC.st==='syncing'){msg=t('syncBusy');}
  else if(SYNC.st==='offline'){msg=t('syncOff');btn=true;cls='warn';}
  else if(SYNC.st==='denied'){msg=t('syncDenied');cls='err';}
  else{msg=t('syncPend')+(sec?' '+t('syncIn')+' '+sec+' s':'');btn=true;cls='warn';}
  el.className='syncbar '+cls;el.hidden=false;
  el.innerHTML='<span>'+esc(msg)+'</span>'+(btn?'<button type="button" class="btn sm" data-sync="retry">'+esc(t('syncRetry'))+'</button>':'');
  if(SYNC.st==='pending'&&!SYNC.tick)SYNC.tick=setInterval(syncUi,1000);
  if(SYNC.st!=='pending'&&SYNC.tick){clearInterval(SYNC.tick);SYNC.tick=null;}
}
function syncFail(e,offline){
  SYNC.err=mapErr(e);
  const fatal=SYNC.err==='denied'||SYNC.err==='suspended';
  if(fatal){SYNC.st='denied';SYNC.tries=0;syncUi();return;}
  SYNC.tries++;
  if(offline){SYNC.st='offline';syncUi();return;}
  const d=syncDelay(SYNC.tries);SYNC.next=Date.now()+d;SYNC.st='pending';
  clearTimeout(SYNC.timer);SYNC.timer=setTimeout(()=>{SYNC.timer=null;if(!SYNC.run)syncFlush();},d);
  console.warn('progress sync failed, retry in '+Math.round(d/1000)+' s',e);syncUi();
}
function syncFlush(){
  clearTimeout(SYNC.timer);SYNC.timer=null;
  if(SYNC.run)return SYNC.run;
  SYNC.run=(async()=>{
    try{
      if(!B||!A.user)return;
      if(netOff()){syncFail(E('net'),true);return;}
      SYNC.st='syncing';syncUi();
      await resetFlush();
      const uid=A.user.id;let guard=0,clean=false;
      while(guard++<5){
        if(!A.user||A.user.id!==uid)return;
        const rev=SYNC.rev;
        if(SYNC.tries>0&&!SYNC.overwrite&&!resetPending()){
          const remote=await B.loadProgress(uid);
          if(remote&&A.user&&A.user.id===uid){Object.assign(S,mergeP(progOf(S),remote));applyPf();save();}
        }
        await B.saveProgress(uid,progOf(S));
        if(SYNC.rev===rev){clean=true;break;}
      }
      if(!clean)throw E('net');
      SYNC.tries=0;SYNC.err='';SYNC.overwrite=false;SYNC.st='ok';SYNC.okAt=Date.now();syncMark(false);syncUi();
      setTimeout(syncUi,2600);
    }catch(e){syncFail(e,netOff());}
  })().finally(()=>{SYNC.run=null;});
  return SYNC.run;
}
function syncNow(){SYNC.tries=Math.max(SYNC.tries,1);return syncFlush();}
function pushProgress(){
  if(!B||!A.user)return Promise.resolve();
  SYNC.rev++;syncMark(true);
  if(SYNC.run)return SYNC.run;
  if(netOff()){clearTimeout(SYNC.timer);SYNC.timer=null;SYNC.st='offline';syncUi();return Promise.resolve();}
  if(SYNC.timer||SYNC.st==='offline'||SYNC.st==='denied')return Promise.resolve(); /* kept locally, a retry is already scheduled */
  return syncFlush();
}
window.addEventListener('offline',()=>{if(A.user&&(SYNC.st==='pending'||syncWasPending()||resetPending())&&!SYNC.run){clearTimeout(SYNC.timer);SYNC.timer=null;SYNC.st='offline';syncUi();}});
window.addEventListener('online',()=>{if(A.user&&(SYNC.st==='offline'||SYNC.st==='pending'||syncWasPending()||resetPending()))syncNow();});
async function syncProgress(){
  if(!B||!A.user)return;
  if(S.uid&&S.uid!==A.user.id){resetProgress(true);syncMark(false);}
  S.uid=A.user.id;
  if(SYNC.st==='denied')SYNC.st='idle';
  try{await resetFlush();}catch(e){syncMark(true);syncFail(e,netOff());return;}
  let remote=null;
  try{remote=await B.loadProgress(A.user.id);}catch(e){syncMark(true);syncFail(e,netOff());return;}
  Object.assign(S,mergeP(progOf(S),remote));applyPf();save();
  const kept=stashTake(A.user.id);                                  /* P1-01: changes that were still unsynced when this account signed out */
  if(kept){Object.assign(S,mergeP(progOf(S),kept));applyPf();save();syncMark(true);}
  await pushProgress();
}
async function loadBoard(force){
  if(!B||!A.user){A.board=null;return;}
  if(!force&&Date.now()-A.boardAt<30000)return;
  A.boardAt=Date.now();
  try{A.board=await B.leaderboard();}catch(e){A.board=null;}
  if(tab==='home'||tab==='rank')render();
}
async function refreshCatalog(){
  const cat=await B.catalog();
  A.rawCat=cat;A.dbCount=(cat.courses||[]).length;setCatalog(cat);
}
async function afterLogin(u){
  A.user=u;
  try{A.profile=await B.profile(u.id);}
  catch(e){                                                         /* P1-07: password was right but the profile could not be read: stay signed out, say why */
    A.user=null;A.profile=null;console.warn('sign-in: profile could not be loaded',e);
    try{await B.signOut();}catch(e2){console.warn('sign-in: could not close the half-open session',e2);if(B.forgetSession)B.forgetSession();}
    throw e;
  }
  await blockIfSuspended();
  await syncProgress();
  await econSync();
  p4Sync();
  await refreshConfig();
  leagueTick();
  if(!sessionStorage.getItem('lg.hi')){try{sessionStorage.setItem('lg.hi','1');}catch(e){}toast(mmsg('login',true),'wave',3200);}
  try{await refreshCatalog();}catch(e){setCatalog(A.rawCat);}
  saveCache();netOff();loadBoard(true);loadFriends(true);
}
/* Coming back from Stripe (?paid=1 / ?paid=0). VIP is granted by the webhook, which can arrive a few seconds later: poll briefly. */
async function payReturn(){
  let p='';try{p=new URLSearchParams(location.search).get('paid')||'';}catch(e){}
  if(p!=='1'&&p!=='0')return;
  try{history.replaceState(null,'',location.pathname);}catch(e){}
  if(p==='0'){toast(t('payCancel'),'confused');return;}
  toast(t('payWait'),'happy');
  for(let i=0;i<8&&A.user&&B;i++){
    await new Promise(r=>setTimeout(r,4000));
    try{A.profile=await B.profile(A.user.id);if(isVip()){render();toast(t('payOk'),'happy');return;}}catch(e){}
  }
}
async function boot(){
  const c=MODE==='local'?null:loadCache();
  if(c&&c.user){A.user=c.user;A.profile=c.profile;if(c.cat&&c.cat.courses&&c.cat.courses.length){A.rawCat=c.cat;A.dbCount=c.cat.courses.length;}if(c.cfg){setGame(c.cfg.game);setBrand(c.cfg.brand);}CONTENT=c.content||[];}
  setCatalog(A.rawCat);
  A.booting=MODE==='cloud'&&!A.rawCat;
  render();
  if(!B){A.ready=true;tab=guardRoute(tab);render();return;}
  try{
    B.onRecovery(()=>{A.recovery=true;tab='me';render();});
    const u=await B.init();
    if(u){
      A.user=u;A.profile=await B.profile(u.id);
      try{await blockIfSuspended();}catch(e){A.err='suspended';flow='login';S.onb=false;}
      if(A.user){await syncProgress();await econSync();}
    }else{A.user=null;A.profile=null;}
    await refreshCatalog();
    await refreshConfig();
    A.net=true;
  }catch(e){A.net=false;}
  A.booting=false;
  saveCache();netOff();loadBoard(true);
  leagueTick();reminderTick();setInterval(reminderTick,60000);
  A.ready=true;
  payReturn();
  tab=guardRoute(tab);
  render();
  if(A.user)enterTab(tab);
}
