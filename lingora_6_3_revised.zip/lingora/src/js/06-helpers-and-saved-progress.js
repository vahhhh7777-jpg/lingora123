/* ---------- helpers and saved progress ---------- */
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const pick=(a,n)=>shuffle(a).slice(0,n);
const norm=s=>String(s==null?'':s).toLowerCase().replace(/[.,!?։՞՜]/g,'').replace(/\s+/g,' ').trim();
/* Typed answers: accents are forgiven in Latin scripts (so 'ecrire' passes for 'écrire'), never in Cyrillic or Armenian. */
const fold=s=>{s=norm(s);return /[\u0400-\u058f]/.test(s)?s:s.normalize('NFD').replace(/[\u0300-\u036f]/g,'');};
const p2=n=>(n<10?'0':'')+n;
const dstr=d=>d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate());
const today=()=>dstr(new Date());
const yesterday=()=>dstr(new Date(Date.now()-864e5));
const KEY='lingora.v1',CKEY='lingora.cache.v1';
const PROG=['xp','streak','best','last','day','dayXp','done','miss','log','ach','qc','onb','course','level','name','srs','fav','resume','why','freeze','boost','ms','wc','league','notifs','seenC','lw','pf','rv'];
const KEEP=['lang','sound','goal','theme','name','onb','course','level','why','rem','accent','dense','fs','diff','nset','avatar','hc','noanim','pfT'];
function fresh(){return {accent:'brand',dense:false,fs:100,diff:'normal',nset:{},avatar:'',hc:false,pfT:0,v:1,lang:'hy',sound:true,goal:20,theme:'dark',uid:'',name:'',onb:false,course:'en',level:'beginner',xp:0,streak:0,best:0,last:'',day:'',dayXp:0,done:{},miss:{},log:[],ach:{},qc:{day:'',ids:[]},srs:{},fav:{},resume:null,why:'',freeze:0,boost:null,ms:{},wc:{w:'',ok:false},league:{tier:0,w:''},notifs:[],seenC:{},lw:{},rv:{d:'',n:0,ok:0,t:0,o:0,last:null},rem:{on:false,time:'19:00',day:'',risk:''},dis:{}};}
function load(){
  try{const j=JSON.parse(localStorage.getItem(KEY)||localStorage.getItem('easyenglish.v1'));if(j&&j.v===1){if(!j.onb&&(j.xp>0||Object.keys(j.done||{}).length))j.onb=true;return Object.assign(fresh(),j);}}catch(e){}
  return fresh();
}
let S=load();
function save(){try{localStorage.setItem(KEY,JSON.stringify(S));}catch(e){}}
const progOf=s=>{const o={};PROG.forEach(k=>{o[k]=s[k];});o.pf=prefSnap(s);return o;};
function resetProgress(full){const keep=full?['lang','sound','theme']:KEEP;const k={};keep.forEach(x=>{k[x]=S[x];});S=Object.assign(fresh(),k);applyCourse();}
function mergeP(a,b){
  b=Object.assign({xp:0,streak:0,best:0,last:'',day:'',dayXp:0,done:{},miss:{},log:[],ach:{},qc:{day:'',ids:[]},srs:{},fav:{},resume:null,why:'',freeze:0,boost:null,ms:{},wc:{w:'',ok:false},league:{tier:0,w:''},notifs:[],seenC:{}},b||{});
  const r={};
  r.xp=Math.max(a.xp||0,b.xp||0);
  r.done=Object.assign({},b.done);Object.keys(a.done||{}).forEach(k=>{r.done[k]=Math.max(a.done[k],b.done[k]||0);});
  const lt=(a.last||'')>=(b.last||'')?a:b;r.streak=lt.streak||0;r.last=lt.last||'';
  r.best=Math.max(a.best||0,b.best||0,r.streak);
  const dl=(a.day||'')>=(b.day||'')?a:b;r.day=dl.day||'';r.dayXp=dl.dayXp||0;
  r.miss=Object.assign({},b.miss);Object.keys(a.miss||{}).forEach(k=>{r.miss[k]=Math.max(a.miss[k],b.miss[k]||0);});
  const seen={};r.log=(a.log||[]).concat(b.log||[]).filter(e=>e&&!seen[e.t]&&(seen[e.t]=1)).sort((x,y)=>x.t-y.t).slice(-150);
  r.ach=Object.assign({},b.ach);Object.keys(a.ach||{}).forEach(k=>{r.ach[k]=Math.min(a.ach[k],b.ach[k]||a.ach[k]);});
  const qa=a.qc||{day:'',ids:[]},qb=b.qc||{day:'',ids:[]};
  r.qc=qa.day===qb.day?{day:qa.day,ids:Array.from(new Set((qa.ids||[]).concat(qb.ids||[])))}:(qa.day>qb.day?qa:qb);
  r.srs=Object.assign({},b.srs);Object.keys(a.srs||{}).forEach(k=>{const x=a.srs[k],y=b.srs&&b.srs[k];r.srs[k]=!y||(x.t||0)>=(y.t||0)?x:y;});
  r.fav=Object.assign({},b.fav,a.fav);
  r.lw=Object.assign({},b.lw,a.lw);
  r.resume=((a.resume&&a.resume.t)||0)>=((b.resume&&b.resume.t)||0)?(a.resume||null):(b.resume||null);
  const pa=a.onb?a:(b.onb?b:a);
  r.onb=!!(a.onb||b.onb);r.course=pa.course||'en';r.level=pa.level||'beginner';r.name=pa.name||a.name||b.name||'';
  r.why=pa.why||a.why||b.why||'';
  r.freeze=Math.max(0,Number(lt.freeze)||0);
  const ba=a.boost&&a.boost.until||0,bb=b.boost&&b.boost.until||0;r.boost=ba>=bb?(a.boost||null):(b.boost||null);
  r.ms=Object.assign({},b.ms,a.ms);
  const wa=a.wc||{w:'',ok:false},wb=b.wc||{w:'',ok:false};r.wc=wa.w>wb.w?wa:wb.w>wa.w?wb:{w:wa.w,ok:!!(wa.ok||wb.ok)};
  const la=a.league||{tier:0,w:''},lb=b.league||{tier:0,w:''};r.league=la.w>=lb.w?la:lb;
  const nseen={};r.notifs=(a.notifs||[]).concat(b.notifs||[]).filter(e=>e&&e.id&&!nseen[e.id]&&(nseen[e.id]=1)).map(e=>{const o=(a.notifs||[]).find(x=>x.id===e.id),q=(b.notifs||[]).find(x=>x.id===e.id);return Object.assign({},e,{read:!!((o&&o.read)||(q&&q.read))});}).sort((x,y)=>y.t-x.t).slice(0,40);
  r.seenC=Object.assign({},b.seenC,a.seenC);
  const ra=a.rv||{},rb=b.rv||{},rl=(ra.d||'')>=(rb.d||'')?ra:rb,sd=ra.d===rb.d;
  r.rv={d:rl.d||'',n:sd?Math.max(ra.n||0,rb.n||0):(rl.n||0),ok:sd?Math.max(ra.ok||0,rb.ok||0):(rl.ok||0),t:Math.max(ra.t||0,rb.t||0),o:Math.max(ra.o||0,rb.o||0),last:((ra.last&&ra.last.t)||0)>=((rb.last&&rb.last.t)||0)?(ra.last||null):(rb.last||null)};
  r.pf=((a.pf&&a.pf.t)||0)>=((b.pf&&b.pf.t)||0)?a.pf:b.pf;
  return r;
}
const t=k=>(UI[S.lang]||UI.hy)[k];
const dayDiff=(a,b)=>Math.round((new Date(b+'T12:00:00')-new Date(a+'T12:00:00'))/864e5);
const missedDays=()=>S.last?Math.max(0,dayDiff(S.last,today())-1):0;
/* The streak survives as many missed days as the learner has streak freezes */
const streakAlive=()=>!!S.last&&(S.last===today()||missedDays()<=Math.max(0,S.freeze||0));
const streakNow=()=>streakAlive()?S.streak:0;
const streakRisk=()=>streakNow()>0&&S.last!==today();
const dayXp=()=>S.day===today()?S.dayXp:0;
/* Returns what happened today so the lesson screen can celebrate it: {froze, ms} */
function touchDay(){
  const ev={froze:0,ms:null};
  if(S.last!==today()){
    const miss=missedDays();
    if(!S.last)S.streak=1;
    else if(miss===0)S.streak++;
    else if(miss<=(S.freeze||0)){S.freeze-=miss;S.streak++;ev.froze=miss;notify('freeze',t('n_freezeT'),t('n_freezeB').replace('{n}',miss),'happy');}
    else S.streak=1;
    S.last=today();
    const m=(G.streak.milestones||[]).find(x=>x.d===S.streak&&!(S.ms&&S.ms[x.d]));
    if(m){
      if(!S.ms)S.ms={};S.ms[m.d]=Date.now();ev.ms=m;
      if(m.xp)addXp(m.xp);
      if(m.freeze)S.freeze=Math.min(G.streak.maxFreeze||2,(S.freeze||0)+m.freeze);
      if(m.boost)S.boost={until:Date.now()+m.boost*60000,mult:2};
      notify('streak',t('n_streakT').replace('{n}',m.d),mmsg('streak'),'celebrating');
    }
  }
  S.best=Math.max(S.best||0,S.streak);
  return ev;
}
function addXp(n){
  if(S.day!==today()){S.day=today();S.dayXp=0;}
  S.xp+=n;S.dayXp+=n;
}
/* XP multiplier: an admin-run event (for example double XP weekend) or a boost earned from a streak reward */
function xpMult(){
  let m=1;const g=G.multiplier||{};
  if(g.value>1&&(!g.until||new Date(g.until)>new Date()))m=g.value;
  if(S.boost&&S.boost.until>Date.now())m=Math.max(m,S.boost.mult||2);
  return m;
}
const boostLeft=()=>S.boost&&S.boost.until>Date.now()?Math.ceil((S.boost.until-Date.now())/60000):0;
function levelInfo(xp){let L=1,need=60;while(xp>=need){xp-=need;L++;need+=40;}return {level:L,cur:xp,need};}
let QUESTS=[{id:'xp',n:30,r:10},{id:'lessons',n:2,r:15},{id:'perfect',n:1,r:20}];
const todayLog=()=>{const k=today();return (S.log||[]).filter(e=>dstr(new Date(e.t))===k);};
function questProg(q){
  const L=todayLog(),ty=q.type||q.id;
  if(ty==='xp')return Math.min(q.n,L.reduce((n,e)=>n+e.xp,0));
  if(ty==='practice')return Math.min(q.n,L.filter(e=>e.id==='practice').length);
  const ls=L.filter(e=>e.id!=='practice');
  if(ty==='lessons')return Math.min(q.n,ls.length);
  return Math.min(q.n,ls.filter(e=>e.acc===100).length);
}
const qClaimed=id=>!!(S.qc&&S.qc.day===today()&&S.qc.ids.indexOf(id)>=0);
function claimQuest(id){
  const q=QUESTS.find(x=>x.id===id);
  if(!q||qClaimed(id)||questProg(q)<q.n)return false;
  if(!S.qc||S.qc.day!==today())S.qc={day:today(),ids:[]};
  S.qc.ids.push(id);addXp(q.r);save();pushProgress();return true;
}
const doneCount=s=>Object.keys(s.done).length;
const unitFinished=()=>UNITS.some(u=>u._n&&FLAT.filter(f=>f.u===u).every(f=>S.done[f.id]));
const ACH=[
{id:'first',ic:'star',t:{hy:'Առաջին քայլը',en:'First step'},d:{hy:'Ավարտիր առաջին դասը',en:'Finish your first lesson'},ok:s=>doneCount(s)>=1},
{id:'five',ic:'book',t:{hy:'Հինգ դաս',en:'Five lessons'},d:{hy:'Ավարտիր 5 դաս',en:'Finish 5 lessons'},ok:s=>doneCount(s)>=5},
{id:'ten',ic:'book',t:{hy:'Տասը դաս',en:'Ten lessons'},d:{hy:'Ավարտիր 10 դաս',en:'Finish 10 lessons'},ok:s=>doneCount(s)>=10},
{id:'streak3',ic:'flame',t:{hy:'Երեք օր անընդմեջ',en:'Three-day streak'},d:{hy:'Սովորիր 3 օր անընդմեջ',en:'Learn 3 days in a row'},ok:s=>(s.best||0)>=3},
{id:'streak7',ic:'flame',t:{hy:'Մեկ շաբաթ',en:'One full week'},d:{hy:'Սովորիր 7 օր անընդմեջ',en:'Learn 7 days in a row'},ok:s=>(s.best||0)>=7},
{id:'xp100',ic:'bolt',t:{hy:'100 XP',en:'100 XP'},d:{hy:'Հավաքիր 100 XP',en:'Earn 100 XP'},ok:s=>s.xp>=100},
{id:'xp500',ic:'bolt',t:{hy:'500 XP',en:'500 XP'},d:{hy:'Հավաքիր 500 XP',en:'Earn 500 XP'},ok:s=>s.xp>=500},
{id:'perfect',ic:'check',t:{hy:'Անթերի դաս',en:'Flawless lesson'},d:{hy:'Ստացիր 3 աստղ դասում',en:'Get 3 stars in a lesson'},ok:s=>Object.keys(s.done).some(k=>s.done[k]>=3)},
{id:'unit',ic:'shield',t:{hy:'Թեման ավարտված է',en:'Topic complete'},d:{hy:'Ավարտիր մի ամբողջ թեմա',en:'Finish a whole topic'},ok:()=>unitFinished()},
{id:'level3',ic:'crown',t:{hy:'3-րդ մակարդակ',en:'Level 3'},d:{hy:'Հասիր 3-րդ մակարդակին',en:'Reach level 3'},ok:s=>levelInfo(s.xp).level>=3},
{id:'practice',ic:'heart',t:{hy:'Կրկնող',en:'Reviewer'},d:{hy:'Ավարտիր 3 կրկնություն',en:'Finish 3 practice sessions'},ok:s=>(s.log||[]).filter(e=>e.id==='practice').length>=3}
];
const ACH_TYPES=['lessons','xp','streak','level','perfect'];
const ACH_ICONS=['star','book','flame','bolt','check','shield','crown','heart','trophy'];
function customAch(){
  return ((G.achievements||[])).filter(a=>a&&a.id&&a.n>0).map(a=>({id:a.id,ic:a.ic||'star',custom:1,r:a.r||0,t:a.t||{hy:a.id,en:a.id},d:a.d||{hy:'',en:''},
    ok:s=>a.type==='xp'?s.xp>=a.n:a.type==='streak'?(s.best||0)>=a.n:a.type==='level'?levelInfo(s.xp).level>=a.n:a.type==='perfect'?Object.keys(s.done).filter(k=>s.done[k]>=3).length>=a.n:doneCount(s)>=a.n}));
}
const allAch=()=>ACH.concat(customAch());
function evalAch(){
  const out=[];
  if(!S.ach)S.ach={};
  allAch().forEach(a=>{if(!S.ach[a.id]&&a.ok(S)){S.ach[a.id]=Date.now();out.push(a);if(a.r)addXp(a.r);notify('ach',t('achNew')+': '+tx(a.t),tx(a.d),'proud');}});
  return out;
}
