# AI Coach: activation guide (Lingora 4.0)

The coach is the Supabase Edge Function `ai-coach` (`supabase/functions/ai-coach/index.ts`, logic in `supabase/functions/_shared/coach.js`).
The model key lives only in Supabase secrets. The browser never sees it. Without the key the app shows a clear "not configured" message and no learner loses a daily call.

## Why it was missing
The 4.0 ZIP contained the database side (`ai_reserve`, `ai_record`, `coach_context`, `my_ai_usage` in SETUP.sql) and the browser side (`B.askCoach`), but **no `supabase/functions/ai-coach` source and no `_shared/coach.js`** (only `tts` was packaged). The earlier README listed them, so they were lost when the project was repackaged. They could not be recovered from the ZIP, so the function was re-implemented against the existing database contract.

## Activate (once)
1. Run `SETUP.sql` in the Supabase SQL editor. It is idempotent and keeps data. **Existing projects:** run `migrations/012_ai_coach_release.sql` instead (additive, safe to repeat).
2. Install the Supabase CLI, then:
   ```
   supabase login && supabase link --project-ref <ref>
   supabase secrets set ANTHROPIC_API_KEY=sk-ant-... AI_MODEL=claude-haiku-4-5 ALLOWED_ORIGIN=https://your-site.example
   supabase functions deploy ai-coach        # keep JWT verification ON (default)
   ```
   `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` are injected by Supabase. Optional: `AI_PRICE_IN_PER_MTOK` / `AI_PRICE_OUT_PER_MTOK` (USD per million tokens, defaults 1 / 5) for the cost counter, `AI_TIMEOUT_MS` (default 25000).
   Check the model name in your Anthropic console. It is only a default, the code does not depend on it.
3. Admin -> AI: daily free limit, VIP limit, monthly budget, on/off switch (stored in `settings.ai`).

## Modes
| mode | purpose |
|---|---|
| `tutor` | multi-turn conversation in the learner's course language at the chosen CEFR level (A1-C2). Returns `reply`, `reply_translation`, `corrections[{original, corrected, type, explanation}]`, `new_words`, `assessment`. Explanations are written in the interface language (Armenian or English). Optional `scenario` (restaurant, airport, hotel, shop, doctor, directions). |
| `plan`, `explain`, `exercises` | study plan from the learner's real progress, explanation of a mistake, practice exercises |
| `chat` | legacy single-turn alias of `tutor` |

Conversation context: the browser sends the last 12 turns with every request (kept in `sessionStorage`, wiped on sign-out). The server is stateless and stores nothing the learner writes. Only token and cost counters are stored.

Languages: en, fr, de, it, tr, az, ru, es, pt, ja, ko, zh, ar, hy.

## Safety and honesty rules implemented in the function
- Caller identity is verified with the auth server; daily limit, monthly budget, on/off switch and hourly rate limit are enforced in the database by `ai_reserve`.
- Missing key / missing service key is detected **before** a call is counted. A provider failure, timeout or unusable answer gives the call back (`ai_release`).
- Learner text is only ever sent as a `user` message. Roles other than user/assistant are rejected; the system prompt tells the model to treat learner text as data.
- Model output is validated: a correction must quote text the learner really wrote, must change something, and exercises must contain their correct answer among the options. Anything else is dropped.
- Error codes returned to the app: `ai_not_configured`, `limit`, `budget`, `disabled`, `rate_limited`, `denied`, `unauthorized`, `bad_request`, `timeout`, `provider_error`, `bad_output`.

## Testing against your real project
```
SUPABASE_URL=https://<ref>.supabase.co SUPABASE_ANON_KEY=<anon key> EXPECT_AI=1 \
ADMIN_EMAIL=<admin> ADMIN_PASSWORD=<pw> node tests/live/smoke.mjs
```
Requirements: e-mail confirmation off for the run (or pass `SMOKE_EMAIL`/`SMOKE_PASSWORD` of a confirmed learner), at least one published lesson (Admin -> Content -> import the built-in course), the function deployed with its secret. Exit code 0 = all passed, 1 = failure, 2 = blocked by missing setup. The script prints BLOCKED lines naming exactly what is missing and never reports those as passed.
