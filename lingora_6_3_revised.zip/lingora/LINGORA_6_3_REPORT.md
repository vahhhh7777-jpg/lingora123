# LINGORA 6.3 — Stabilization & verification report

**Bottom line.** 6.3 is a verified stabilization release for everything that could be executed in the sandbox. **It is not declared production-ready**: the live smoke test, real screen-reader/device checks and a real installed-PWA update were NOT run (no deployment, no devices). See "Not executed" and "Remaining risks". No app source (`src/`), business logic, XP/gems/economy, course content or DB schema was changed.

Test environment: Linux sandbox, Chromium (Playwright), PostgreSQL 16, Node 22, the repo's PostgreSQL-backed Supabase stand-in. This is **not** a real Supabase project and not a deployed site.

## 1. Results (PASS / FAIL / BLOCKED / NOT RUN)

Source: `tests/results/6.3/summary.tsv` and the `.log` files next to it (one full `bash tests/run_all.sh` run, fresh DB).

| Suite | Result | Exact output |
|---|---|---|
| Build check (`build.mjs --check`) | PASS | exit 0 |
| Static actions | PASS | 194 actions, 299 handlers, none unhandled |
| SQL | PASS | 144 PASS, 0 FAIL |
| UI layout | PASS | 182 screens, no layout problems |
| UI audit 6.2 | PASS | 572 screen states, no problems |
| Accessibility 6.2 | PASS | 48 passed, 0 failed |
| Accessibility 6.3 (new) | PASS | 5 passed (reduced motion, heading hierarchy) |
| Contrast | PASS | 28 screens, 0 low-contrast text elements |
| Media | PASS | 26 passed, 0 failed |
| Sync | PASS | 21 passed |
| Reset | PASS | 17 passed |
| Payment | PASS | 7 passed |
| Admin | PASS | 8 passed |
| Phase 1 | PASS | 22 passed |
| Completion | PASS | 34 passed |
| Review | PASS | 18 passed |
| Service worker / cache (new) | PASS | 36 checks incl. 6.2→6.3 upgrade; exit 0 |
| AI | PASS | 26/26 |
| Stripe | PASS | 19/19 |
| E2E (`e2e.mjs`) | PASS | 43 passed, 0 failed |
| E2E Phase 2 (`phase2.mjs`) | PASS | 62 PASS, 0 FAIL (was: failing H3, H4, R1 + timeout) |
| Monkey crawl (deterministic) | PASS | 10 PASS (learner phone/desktop, admin) |
| Monkey random (new, seeded) learner | PASS | seeds 1–6 × 150 actions |
| Monkey random (new, seeded) admin | PASS | seeds 1–6 × 150 actions |
| **Live smoke – API (`smoke.mjs`)** | **BLOCKED** | exit 2: no `SUPABASE_URL`; `site/config.js` ships empty; no deployment given |
| **Live smoke – browser (`smoke_browser.mjs`, new)** | **BLOCKED** | exit 2: no `SITE_URL` |
| Real NVDA / VoiceOver / TalkBack / physical devices | **NOT RUN** | none available |
| Real installed-PWA update on a phone, real CDN | **NOT RUN** | none available |

Executed, but **not live** (labelled so, never counted as live):
- `smoke.mjs` against the local stand-in + a local static server: 57 PASS, 0 FAIL (`live-smoke-api-AGAINST-STANDIN-not-live.log`). This proves the script works; it proves nothing about your deployment.
- `smoke_browser.mjs` against a local static server in local mode: 5 PASS, 0 FAIL, 1 BLOCKED (signed-in part needs a cloud site).

Stability: the Phase-2 flow passed on several fresh-DB runs during development (one full run: e2e 43/43 + phase2 62/62; final regression: same).

## 2. Modified / new files
Modified: `site/sw.js`, `site/styles.css`, `package.json` (6.2.0→6.3.0), `tests/e2e/phase2.mjs`, `tests/e2e/monkey.mjs`, `tests/e2e/run.sh`, `tests/live/smoke.mjs`.
New: `tests/e2e/monkey_random.mjs`, `tests/e2e/_bridge_up.sh`, `tests/live/smoke_browser.mjs`, `tests/ui/sw.mjs`, `tests/ui/a11y63.mjs`, `tests/css/analyze.mjs`, `tests/css/equiv.mjs`, `tests/run_all.sh`, `ACCESSIBILITY_CHECKLIST_6_3.md`, `LINGORA_6_3_REPORT.md`, `tests/results/6.3/*`.
Unchanged: everything under `src/`, `site/app.js`, SQL, edge functions, course data (verified by `diff -rq` against 6.2).

## 3. Issues found and fixes

**I-1 Legacy E2E `phase2.mjs` (H3, H4, R1, timeout).** Cause: the test targeted UI removed in 6.0 on purpose (coin chip `.hm-mini`, Daily-review card `.hm-rv`, the Repetition tab with `.rv-hero` / `button.rv-go` / summary / difficult-words list). Same failure on 6.1/6.2. Not an app bug.
Fix, intent preserved, no assertion dropped:
- H3 → coins shown in the `.hm-kp.gem` tile **and equal to the server balance**.
- H4 → Home "Recommended practice" flashcards card shows a real due count.
- R1/R2 → review plan comes from real history; Learn flashcards badge.
- R3–R11 → the same review behaviours exercised through the real in-lesson review of a server-backed lesson: review steps mixed in (≤4), a review item answered wrongly on purpose, summary shown, miss/SRS recorded, counters updated, attempt completed in DB, history synced, item queued again, coin cap.
- R12/R13 → a brand-new learner has no review plan, no review steps in the first lesson, no due-cards card.
- R12 changed meaning: flashcards deliberately *preview the first 12 course words* for a learner who has met none, so the old "empty flashcards screen" no longer exists.
**I-2 Vacuous checks in the old test.** `tab()` silently did nothing for a missing tab, so L1/L2 re-screenshotted the previous page for the removed `practice` tab. `tab()` now FAILS on a missing target; the row uses `learn`.
**I-3 (real defect, fixed) Service worker could keep stale CSS/JS.** `sw.js` install used `cache.add(url)`, which honours the browser HTTP cache. On hosts that send `max-age` for static files (GitHub Pages 10 min, Cloudflare Pages default), a new SW version re-cached the OLD `app.js`/`styles.css` and the app kept running the old build for up to the max-age. Reproduced in a real browser (S3). Also, with an unchanged cache name and long max-age the background revalidation never reached the network (S3b).
Fix (`site/sw.js`): cache name `ee-v27`→`ee-v28`; install fetches use `{cache:'reload'}`; same-origin background revalidation uses `{cache:'no-cache'}` (conditional request). Verified: S3 and S3b pass with 6.3 `sw.js`; S3b fails with the 6.2 `sw.js` (`SHOW_OLD_SW=1`).
**I-4 Observation (not changed):** flashcards show 12 "to review" cards for a learner with no history (by design in `pxDueCards`; business logic untouched). Check that this is intended.
**I-5 Observation (not changed):** the shop logs `shop load failed: net` and retries quietly right after a page reload; it recovers (tests pass). Designed retry path.
**I-6 Harness defects found in my own new tests (fixed, none were app bugs):** wrong quit-confirm selector (`quitYes`), route order shadowing the stand-in, the random monkey typing "undefined" into admin fields and then flagging it, history navigation leaving the app, wallet-fixture drift, `no-cache` revalidation needing ETags in the test server, Playwright `page.reload()` hiding SW traffic (now uses a new page = a real "next visit"). The crawl treated the AI daily-quota 429 as an error; now 429 is accepted and any other 4xx fails with its URL.
**I-7 Playwright note:** `button[data-a="continue"]` can't be clicked normally because of its intentional infinite pulse; tests use `force:true`. Pulse stops under reduced motion (verified).

Monkey testing: **no application defect was found** by the crawl or by 12 seeded random runs (JS exceptions, blank screens, overflow, stacked dialogs, orphan overlays over the nav, stuck loaders after 12 s, junk text, corrupt state, gem-ledger drift, duplicate unlock charges, 5xx, UI-vs-server XP after reload). Not exhaustive: 6 seeds × 150 actions per role.

## 4. Service worker / cache (`tests/ui/sw.mjs`, uses the real 6.2 `site/` as the previous release)
Verified in Chromium: cache created and complete; offline reload and Learn screen work; 6.2→6.3 upgrade replaces `ee-v27` with `ee-v28`, deletes the old cache, every cached file is byte-identical to the new deployment (revalidating host and long-max-age host); new JS+CSS run after the next visit; an update arriving **mid-lesson** leaves the lesson open and finishable, XP saved; `_headers` keep `sw.js`/`config.js`/`theme-boot.js` out of caches.
Behaviour to know: cache-first means an installed app runs the previous build for one visit after a deployment ("one visit behind"); the open page is never force-reloaded. The SW exists only for VIP/admin by design.
Limits: the mid-lesson test ran in local mode, not a cloud lesson attempt; no real installed PWA / iOS Safari. An end-to-end "who gets the SW" gating test was attempted and **removed** (the stand-in/CDN interplay made it unreliable); only the registration code was read, not tested end-to-end.

## 5. CSS maintenance
Analysis (`tests/css/analyze.mjs`, results in `tests/results/6.3/css-analysis.txt`): 2,044 style rules + 61 at-rules, 175 KB; `!important`: 34 rules / 178 declarations (36 lines; the "55" in the brief could not be reproduced — counting method unknown); about 25 of them are reduced-motion/`no-anim` resets or `[hidden]`, which are legitimate; 22 selectors with an id or ≥4 classes; heavy features: 4 `backdrop-filter`, 8 blur filters, 47 `infinite` animation declarations (all stopped by reduced motion), 0 `transition:all`, 0 `will-change`; 0 obsolete media queries (nothing below 320 px or above 3840 px); 24 `-webkit-` prefixes.
The unused-rule scan reported 1,236 "candidates" (1,178 not state-only). **I do not trust this number**: the sweep cannot reach dialogs, lesson step types, admin sub-screens or hover/focus states, so most are false positives. **None were removed.**
Changed (only what is provably neutral): removed `html{-webkit-text-size-adjust:100%}` (subset of the later `html{…text-size-adjust…}` rule) and the second identical `.wrap.wide{max-width:1120px}`; −65 bytes. Proof: `tests/css/equiv.mjs`, pristine 6.2 vs 6.3 stylesheet, 9 sizes × 2 themes × 15 screens (270 cells): 268 byte-identical on the first pass; the 2 differing cells (`@notif` at 820×1180 light and 768×1024 dark) were identical on 3 of 3 re-runs, and are timing flakiness of the notification-panel animation (new-vs-new also identical 3 of 3). The checker is deterministic on same-site runs and detects a 0.01 px letter-spacing change (sensitivity test). The computed-style hash mode is opt-in (`--computed`) because it was timing-sensitive here and is not used as evidence.
Practical conclusion: a larger cleanup needs a per-component review with hover/focus/dialog states in the equivalence sweep. Not done in a stabilization release.

## 6. Accessibility
See `ACCESSIBILITY_CHECKLIST_6_3.md`. Automated-verified: skip link, headings (one h1, no skipped level), notification-dialog focus trap/restore, accessible names/labels/alt, text contrast, reduced motion, layout. **NOT VERIFIED (no tools/devices): NVDA, VoiceOver iOS/macOS, TalkBack, physical devices, forced-colours, 200 % zoom, focus behaviour of dialogs other than notifications, non-text contrast.**

## 7. Live smoke — what is ready and what you must run
`tests/live/smoke.mjs` now also covers startup assets/headers/config/SW (`SITE_URL`), course data, shop, friends, rank, error handling (garbage token, unknown function, bad ids → 4xx never 5xx) and more admin restrictions. `smoke_browser.mjs` covers navigation, shop/friends/rank screens, course + lesson loading, persistence after reload, admin gating, offline behaviour. Caveat: checks 12–17 were validated only against the stand-in; if the real schema differs in a column/function name, the first live run may report a FAIL that is a script mismatch — read it before blaming the app.
Run: `SUPABASE_URL=… SUPABASE_ANON_KEY=… SITE_URL=… ADMIN_EMAIL=… ADMIN_PASSWORD=… node tests/live/smoke.mjs` then `SITE_URL=… SMOKE_EMAIL=… SMOKE_PASSWORD=… [ADMIN_EMAIL=… ADMIN_PASSWORD=…] node tests/live/smoke_browser.mjs`. It creates and deletes a throw-away account.

## 8. Remaining risks
1. No live run yet (BLOCKED). Real Supabase RLS, rate limits, email confirmation, Stripe webhooks and CDN behaviour are unproven here.
2. Screen readers and real devices unverified.
3. SW: one-visit-behind by design; a mixed old-index/new-app moment is theoretically possible during activation (not observed); installed-PWA/iOS behaviour untested; hosts without `_headers` support (e.g. GitHub Pages) won't send `no-cache` for `sw.js`/`config.js`.
4. Random monkey is bounded (12 runs); not a proof of absence of defects.
5. CSS remains large (≈2,000 rules); unused/duplicate cleanup beyond the two rules was deliberately not attempted.
6. Open product question I-4 (flashcard preview for new learners).

## 9. Deployment recommendation
Deploy 6.3 to a **staging** environment first. Then: (1) run both live smoke scripts; (2) do the manual accessibility checklist at least with NVDA and VoiceOver; (3) confirm the host serves `site/_headers` (or equivalent) so `sw.js` is `no-cache`; (4) after deploying, open the app twice on one installed device and confirm the new build; (5) roll out gradually. Only after steps 1–2 pass should anyone call it production-ready.
