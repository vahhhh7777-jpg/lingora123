// Lingora build: concatenates src/js/*.js (sorted by file name) into site/app.js.
// Usage: node build.mjs [--check]   (--check fails if site/app.js differs from the sources)
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const root = path.dirname(new URL(import.meta.url).pathname);
const dir = path.join(root, 'src/js');
const files = fs.readdirSync(dir).filter(f => f.endsWith('.js')).sort();
const header = fs.readFileSync(path.join(root, 'src/header.txt'), 'utf8');
const body = files.map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('');
const out = header + body + '})();\n';
try { new vm.Script(out, { filename: 'app.js' }); } catch (e) { console.error('SYNTAX ERROR in build:', e.message); process.exit(1); }
const target = path.join(root, 'site/app.js');
if (process.argv.includes('--check')) {
  const cur = fs.existsSync(target) ? fs.readFileSync(target, 'utf8') : '';
  if (cur !== out) { console.error('site/app.js is out of date: run node build.mjs'); process.exit(1); }
  console.log('OK: site/app.js matches src/ (' + files.length + ' files, ' + out.length + ' bytes)');
} else {
  fs.writeFileSync(target, out);
  console.log('Built site/app.js from ' + files.length + ' files (' + out.length + ' bytes)');
}
