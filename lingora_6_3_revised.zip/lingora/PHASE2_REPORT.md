# Lingora — Phase 2 հաշվետվություն (UI/UX + խելացի ուսուցում)

## Ինչ է արված
1. **Repetition (Practice) էջ** — խելացի անհատականացված կրկնություն (`src/js/36b-phase2-review-engine.js`).
   - Նյութը վերցվում է միայն իրական պատմությունից՝ ավարտած դասերի բառեր/հարցեր, S.srs (տուփ 0–5, հաջորդ ամսաթիվ), S.miss (սխալներ). Կեղծ պատմություն չկա։
   - Դասակարգում՝ difficult > forgotten > due > new > strong։ Օրական նպատակ 10 տարր, մինչև 40% հարցեր դասերից (քերականություն/դաս), «Extra practice»՝ երբ օրվա պլանն ավարտված է։
   - Ժամանակացույց՝ SRS_DAYS = 0,1,2,4,8,16 օր։ Սխալ → տուփը 0, ճիշտ → +1։
   - Նիստի ավարտին՝ ամփոփում՝ քանի տարր, քանի ճիշտ, %, դժվար, ինչը կրկնել կրկին։ Հաշվիչները (rv) սինքրվում են DB-ի հետ։
   - Դատարկ վիճակ՝ նոր սովորողի համար՝ հստակ բացատրություն և «սկսել դաս» կոճակ, առանց կեղծ կոճակի։
2. **Home** — Continue learning, Daily goal (streak/coins/level), Daily review (միայն երբ կա ինչ կրկնել), Learning progress, AI coach տող, quests։ Հեռացված են ավելորդ/դատարկ քարտերը։
3. **Shop** — իրական խանութ։ «VIP lessons» (անհատական դասեր մետաղադրամով) և «Boosts & items» ներդիրներ, հաստատման պատուհան (գին / մնացորդ / մնացորդ գնումից հետո), անբավարարության դեպքում կոճակն անջատված է և ասում է, թե որքան է պակասում, գնումից հետո՝ «Start lesson»։ Stripe/VIP գնումը անփոփոխ է (բացված է, երբ ONLINE_PAYMENTS միացված է)։
4. **Profile** — նոր վերնագիր (avatar, անուն, @username, VIP/Free, լեզու+մակարդակ, XP-ի շերտ) և 5 բաժին՝ Overview / Stats / Badges / Mistakes / Settings։ Ձեռքբերումները ցուցադրվում են միայն ստացվածները։ Sign out՝ Overview-ում և Settings-ում։
5. **Դիզայն համակարգ** — `site/styles.css` վերջում «Phase 2» բլոկ (p2-card/list/row/tabs/sheet, rv-*, hm-*, shop-*), focus-visible օղակներ, մուգ/բաց թեմա նույն token-ներով, ներքևի նավիգացիայի համար տեղ (`.wrap` padding), reduced-motion։

## Տնտեսություն (migration 015, նաև SETUP.sql-ում)
- `lessons.unlock_price`, աղյուսակ `lesson_unlocks` (RLS՝ միայն սեփականը/admin-ը կարդում է, գրել չի կարելի browser-ից), `owns_lesson()`, `shop_lessons()`, `unlock_lesson(lesson, idem)`։
- Գինը միշտ DB-ից (unlock_price կամ cfg shop.lesson_unlock կամ 80); մնացորդը՝ սերվերից; player_state տողը կողպվում է (`for update`) → կրկնակի/զուգահեռ գնում չի գանձվում երկու անգամ; բացասական մնացորդ հնարավոր չէ (check gems>=0 + ստուգում); idempotency key; rate limit 60/ժամ; suspended/VIP/չգնվող դաս՝ մերժվում է։
- Գնված դասը մնում է reset-ից հետո։ Ոչ բոլոր դասերն են VIP — գնվում են միայն lesson-level VIP դասերը ոչ-VIP unit/course-ում։
- Մետաղադրամների վաստակ ունեն բոլորը (free_earn=true) սահմանափակ աղբյուրներից՝ դասի առաջին ավարտ, օրական նպատակ (օրը մեկ), streak milestone, quests/achievements, practice՝ օրական cap 5/24ժ (anti-farming, ledger unique (user, reason, ref))։

## Փոփոխված ֆայլեր
src/js: 06, 12, 14, 17, 20, 22, 25, 31, 35, 36b (նոր), 37, 41, 43, 45; site/styles.css, site/app.js (վերակառուցված), site/sw.js (cache ee-v24); migrations/015_phase2_economy.sql (նոր) + SETUP.sql; tests/sql/50_phase2.sql (նոր), tests/sql/run.sh, tests/e2e/phase2.mjs (նոր), tests/e2e/run.sh, tests/e2e/lib.mjs։

## Փաստացի կատարված թեստեր (վերջնական build)
| Փաթեթ | Արդյունք |
|---|---|
| SQL (PostgreSQL 16, Phase 1 + Phase 2) | 144 PASS / 0 FAIL |
| E2E իրական բրաուզեր + DB (e2e.mjs) | 43 / 0 |
| E2E Phase 2 (phase2.mjs՝ Home, Repetition, Shop, Profile, թեմաներ, overflow) | 60 / 0 |
| UI sync / mediacopy / reset / pay / admin / phase1 | 21 / 26 / 17 / 7 / 8 / 22 — բոլորը անցան |
| Contrast audit (32 էկրան, light+dark, 390/1200) | 0 ցածր-կոնտրաստ տարր |
| AI coach / Stripe node թեստեր | 26 / 19 |
| `node build.mjs --check`, `node --check site/app.js` | OK |

Թեստերի ընթացքում հայտնաբերված և շտկված իրական խնդիրներ՝ Shop-ը էջի reload-ից անմիջապես հետո բեռնվում էր նախքան backend-ի պատրաստ լինելը (հիմա լուռ կրկնում է մինչև 4 անգամ); Home-ը հեռախոսում ցուցադրվում էր կես լայնությամբ (grid սխալ); Stripe կոճակը թաքնված էր փակ բաժնում (բացվում է երբ առցանց վճարումը միացված է); Sign out-ը բացակայում էր Settings-ում; երկու ցածր կոնտրաստ։

## Հայտնի սահմանափակումներ (անկեղծ)
- Իրական Supabase / Stripe / Edge Functions չեն փորձարկվել — թեստերը՝ տեղային PostgreSQL + bridge + memstub։
- Կրկնության նիստի բառերի պատասխանները գնահատվում են բրաուզերում (սերվերում չկան այդ հարցերի id-ները), ուստի գործնական coin-ը սահմանափակված է (cap 5/օր) և հիմնված է հաշվետու քանակի վրա; դա սերվերով ստուգվող չէ։
- Նիստերի պատմությունը պահվում է հաշվիչներով (օր/ընդհանուր/վերջին), ոչ թե նիստ առ նիստ։
- SRS «մոռացված/դժվար/ժամկետանց» վիճակները թեստերում ստացվել են պահված ամսաթվերը հետ տեղափոխելով (ժամանակի ճանապարհորդություն), քանի որ իրական օրերը սպասել հնարավոր չէր։
- Listening/Speaking practice-ի սինթետիկ քայլերը cloud ռեժիմում չեն ստուգվել առանձին (չեմ պնդում, որ աշխատում են)։
- Monkey (պատահական սեղմումներ) թեստը այս build-ի վրա չի գործարկվել։
- Ավելի ուշ հիմնվելով տեսողական ստուգման վրա՝ նկարները նկարվել են 390 և 1280 px-ով, այլ սարքերում/Safari-ում չեմ ստուգել։
