# Lingora 6.2: UI/UX quality and responsive polish

A refinement release on top of 6.1. No business logic, course content, XP/reward maths or database schema was changed.

## Files modified
- `site/styles.css`: 6.1 layer tidied (blur effect and one `!important` removed), 4 exact duplicate rules removed, new "6.2 quality layer" appended (no `!important`).
- `src/js/46-lingora-6-2-keyboard-and-screen-reader-layer.js` (new, built into `site/app.js`): skip link, page headings, `document.title`, announcements, dialog focus handling.
- `src/js/17-views-learning-path-words-report-profile.js`: action button in the Words and Rank empty states.
- `src/js/20-shop-gems-hearts-boosts.js`: action button in the Shop empty state.
- `src/js/27-admin-dashboard-content-builder-users.js`: admin loading state is a skeleton (`role=status`, `aria-busy`) instead of a bare "…".
- `site/sw.js`: cache `ee-v26` -> `ee-v27` so installed apps pick up the new CSS/JS. `package.json`: version 6.2.0, new tests added to `test:ui`.
- New tests: `tests/ui/audit62.mjs` (responsive + safe-area + accessibility sweep), `tests/ui/a11y62.mjs` (keyboard/screen-reader behaviour).

## Issues discovered -> fixed
| Issue | Fix |
|---|---|
| Home, Learn and Words pages had no `<h1>` | a heading is added when a page has none (visually hidden) |
| No skip link; page title never changed on navigation | skip link; `document.title` = page name; polite live-region announcement |
| Dialogs (notifications, shop confirm, level-up, admin): focus stayed behind them, Tab left them, focus was lost on close | focus moves in, Tab/Shift+Tab are trapped, focus returns to the button that opened it |
| Empty states were plain text, some with no next step | one consistent card (mascot, sentence, action): Shop -> Continue learning, Words -> Start learning, Rank -> Friends |
| Admin loading showed "…" (layout jump) | skeleton blocks with reserved height |
| Focus ring not defined for `summary`/`[tabindex]` | one shared 3px ring on every keyboard-reachable control, both themes |
| Disabled inputs/ghost buttons looked like enabled ones | muted colours + dashed border + `not-allowed` cursor (not colour alone) |
| Admin overlay and sheet backdrops ignored notches | safe-area padding on all four edges |
| Landscape phones: rail could cut items off | compact, scrollable rail under 480px height |
| 6.1 sticky tabs used `backdrop-filter` (repaint cost) | removed |

## Tests actually executed (this session)
- `tests/ui/audit62.mjs`: 572 screen states (9 widths 320-1280 + landscape 844x390 and 667x375, light and dark, top and bottom scroll, notification overlay): **0 problems** after the fixes. Before: 54 missing headings (real) plus 6 "content under nav" reports that were a test artefact (children of a closed `<details>`), which I fixed in the test.
- `tests/ui/a11y62.mjs`: **48 passed, 0 failed** (at 390, 820, 1280px).
- `tests/ui/layout.mjs`: 182 screens, no layout problems. `sync` 21, `mediacopy` 26, `reset` 17, `pay` 7, `admin` 8, `phase1` 22, `complete` 34, `review` 18: all passed. `contrast`: 28 screens, 0 low-contrast text.
- `tests/static/actions.mjs`: no action without a handler. `build.mjs --check`: OK.
- SQL (`tests/sql/run.sh`, PostgreSQL 16): 144 PASS, 0 FAIL/ERROR.
- AI coach tests: 26/26. Stripe tests: 19/19. E2E `e2e.mjs`: 43/43.

## Remaining issues (honest list)
- `tests/e2e/phase2.mjs` **fails** (H3, H4, R1, then a timeout on `button.rv-go`). I ran the same test on the unchanged 6.1 archive and it fails the same way, so it is not caused by 6.2: it still looks for the old Home markup (`.hm-mini`, `.hm-rv`). It needs updating to the 6.0 Home design.
- Not run: `tests/live/smoke.mjs` (needs a deployed site) and the optional monkey test.
- No real screen reader (NVDA/VoiceOver) and no real device were used. Safe-area `env()` values are 0 in desktop Chromium, so notch handling is by CSS review, not measured.
- The stylesheet is still layered over many releases (about 2,100 rules, 55 older `!important`). Only exact duplicates were removed; merging the rest safely needs a visual-diff pass per page.
- The visually hidden headings are added by script, not in the original markup.
- Armenian long-label truncation (for example the Words filter chips) scrolls horizontally by design and was not changed.
