// Payment tests. The REAL handlers (supabase/functions/_shared/stripe.js) run against the PostgreSQL-backed stand-in (real
// apply_payment, real RLS/GRANTs); only api.stripe.com is mocked. They prove signature checking, idempotency, amount checks,
// failure handling, refunds and checkout hardening. They do NOT prove anything about the real Stripe service or a live account.
// Run:  node tests/bridge/server.mjs &  then  node --test tests/stripe/
import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { verifyStripeSignature, hmacHex, interpretEvent, handleWebhook, handleCheckout, validSiteUrl } from '../../supabase/functions/_shared/stripe.js';

const BASE = process.env.BRIDGE_URL || 'http://127.0.0.1:54321', DB = process.env.PGDB || 'lingora_e2e';
const keys = await (await fetch(BASE + '/__test/keys')).json();
const psql = (sql) => spawnSync('runuser', ['-u', 'postgres', '--', 'psql', '-X', '-q', '-A', '-t', '-d', DB, '-c', sql], { encoding: 'utf8' }).stdout.trim();
const SECRET = 'whsec_test_secret';
const baseEnv = { STRIPE_WEBHOOK_SECRET: SECRET, STRIPE_SECRET_KEY: 'sk_test_x', SUPABASE_URL: BASE, SUPABASE_SERVICE_ROLE_KEY: keys.service, SUPABASE_ANON_KEY: keys.anon, SITE_URL: 'https://lingora.example' };
const envOf = (o = {}) => (k) => ({ ...baseEnv, ...o })[k];
const quiet = { log: () => {} };
let n = 0;
async function newUser() {
  const email = `pay-${Date.now()}-${n++}@lingora.test`;
  const r = await fetch(BASE + '/auth/v1/signup', { method: 'POST', headers: { apikey: keys.anon, 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: 'secret123' }) });
  const j = await r.json(); return { id: j.user.id, tok: j.access_token, email };
}
const vipUntil = (id) => psql(`select coalesce(vip_until::text,'') from profiles where id='${id}'`);
const payRows = (ref) => Number(psql(`select count(*) from payments where provider_ref='${ref}'`));
const status = (ref) => psql(`select status from payments where provider_ref='${ref}'`);
async function signed(ev, { secret = SECRET, t = Math.floor(Date.now() / 1000), body } = {}) {
  const raw = body ?? JSON.stringify(ev);
  return new Request('http://x/stripe-webhook', { method: 'POST', headers: { 'stripe-signature': `t=${t},v1=${await hmacHex(secret, `${t}.${raw}`)}` }, body: raw });
}
const hook = async (ev, opts, env) => { const r = await handleWebhook(await signed(ev, opts), envOf(env), quiet); return { status: r.status, body: await r.json() }; };
const session = (u, o = {}) => ({ id: 'evt_' + Math.random().toString(36).slice(2), type: 'checkout.session.completed', data: { object: { id: 'cs_' + Math.random().toString(36).slice(2), mode: 'payment', payment_status: 'paid', client_reference_id: u, metadata: { user_id: u, plan: 'month' }, payment_intent: 'pi_' + Math.random().toString(36).slice(2), amount_total: 499, amount_subtotal: 499, currency: 'usd', ...o } } });

test.before(() => psql(`update vip_plans set price_cents=499, currency='usd', provider_price='price_test1' where id='month'`));
test.after(() => psql(`update vip_plans set price_cents=null, provider_price=null where id='month'`));

/* ---------- signature ---------- */
test('signature: valid, tampered body, wrong secret, stale, malformed, missing', async () => {
  const raw = '{"a":1}', t = 1_700_000_000, v1 = await hmacHex(SECRET, `${t}.${raw}`);
  assert.equal((await verifyStripeSignature(raw, `t=${t},v1=${v1}`, SECRET, t + 10)).ok, true);
  assert.equal((await verifyStripeSignature(raw + ' ', `t=${t},v1=${v1}`, SECRET, t + 10)).reason, 'mismatch');
  assert.equal((await verifyStripeSignature(raw, `t=${t},v1=${v1}`, 'other', t + 10)).reason, 'mismatch');
  assert.equal((await verifyStripeSignature(raw, `t=${t},v1=${v1}`, SECRET, t + 301)).reason, 'stale');
  assert.equal((await verifyStripeSignature(raw, `t=${t},v1=${v1}`, SECRET, t - 301)).reason, 'stale');
  assert.equal((await verifyStripeSignature(raw, 'garbage', SECRET, t)).reason, 'malformed');
  assert.equal((await verifyStripeSignature(raw, '', SECRET, t)).reason, 'no_header');
  assert.equal((await verifyStripeSignature(raw, `t=${t},v1=${v1}`, '', t)).reason, 'no_secret');
  assert.equal((await verifyStripeSignature(raw, `t=${t},v1=deadbeef,v1=${v1}`, SECRET, t)).ok, true, 'any one of several v1 values may match (secret rotation)');
});

/* ---------- interpretation ---------- */
test('interpretEvent: only paid money grants; subscriptions use invoice.paid; partial refunds ignored', () => {
  assert.equal(interpretEvent(session('u')).action, 'grant');
  assert.equal(interpretEvent(session('u', { payment_status: 'unpaid' })).action, 'ignore');
  assert.equal(interpretEvent(session('u', { mode: 'subscription' })).action, 'ignore');
  assert.equal(interpretEvent({ type: 'invoice.paid', data: { object: { id: 'in_1', amount_paid: 0 } } }).action, 'ignore');
  assert.equal(interpretEvent({ type: 'charge.refunded', data: { object: { refunded: false, payment_intent: 'pi' } } }).action, 'ignore');
  assert.equal(interpretEvent({ type: 'charge.refunded', data: { object: { refunded: true, payment_intent: 'pi_1' } } }).ref, 'pi_1');
  assert.equal(interpretEvent({ type: 'customer.subscription.deleted', data: { object: {} } }).action, 'ignore');
  assert.equal(interpretEvent(null).action, 'ignore');
});

/* ---------- webhook against the real database ---------- */
test('webhook without secrets configured does nothing (503)', async () => {
  const r = await handleWebhook(await signed(session('x')), envOf({ STRIPE_WEBHOOK_SECRET: '' }), quiet);
  assert.equal(r.status, 503);
});
test('webhook rejects a bad signature and writes nothing', async () => {
  const u = await newUser(), ev = session(u.id);
  const r = await hook(ev, { secret: 'wrong' });
  assert.equal(r.status, 400); assert.equal(payRows(ev.data.object.payment_intent), 0); assert.equal(vipUntil(u.id), '');
});
test('webhook rejects a replayed (stale) but validly signed request', async () => {
  const u = await newUser(), ev = session(u.id);
  const r = await hook(ev, { t: Math.floor(Date.now() / 1000) - 3600 });
  assert.equal(r.status, 400); assert.equal(vipUntil(u.id), '');
});
test('valid payment grants VIP once; the same event replayed does not extend it again', async () => {
  const u = await newUser(), ev = session(u.id), ref = ev.data.object.payment_intent;
  const a = await hook(ev); assert.equal(a.status, 200); assert.equal(a.body.status, 'succeeded');
  const first = vipUntil(u.id); assert.ok(first, 'vip_until set');
  assert.ok(new Date(first) > new Date(Date.now() + 29 * 864e5), '30 days granted');
  const b = await hook(ev); assert.equal(b.status, 200); assert.equal(b.body.duplicate, true);
  assert.equal(vipUntil(u.id), first, 'no double extension'); assert.equal(payRows(ref), 1);
  // a differently-id'd event for the same payment (Stripe re-sends under a new event id) is also a no-op
  const c = await hook({ ...ev, id: 'evt_other' }); assert.equal(c.body.duplicate, true); assert.equal(vipUntil(u.id), first);
});
test('wrong amount is rejected (no VIP, no payment row)', async () => {
  const u = await newUser(), ev = session(u.id, { amount_total: 1, amount_subtotal: 1 });
  const r = await hook(ev); assert.equal(r.status, 200); assert.equal(r.body.rejected, 'amount_mismatch');
  assert.equal(vipUntil(u.id), ''); assert.equal(payRows(ev.data.object.payment_intent), 0);
});
test('wrong currency, unknown plan, unknown user and missing metadata are rejected', async () => {
  const u = await newUser();
  assert.equal((await hook(session(u.id, { currency: 'eur' }))).body.rejected, 'amount_mismatch');
  assert.equal((await hook(session(u.id, { metadata: { user_id: u.id, plan: 'lifetime' } }))).body.rejected, 'unknown_plan');
  assert.equal((await hook(session(u.id, { metadata: {}, client_reference_id: null }))).body.rejected, 'missing_metadata');
  const ghost = '00000000-0000-0000-0000-00000000dead'; const g = await hook(session(ghost));
  assert.equal(g.status, 200); assert.ok(g.body.rejected, 'unknown user refused, not retried forever'); assert.equal(vipUntil(u.id), '');
});
test('unpaid / pending checkout sessions grant nothing', async () => {
  const u = await newUser(); const r = await hook(session(u.id, { payment_status: 'unpaid' }));
  assert.equal(r.body.ignored, 'not_paid_yet'); assert.equal(vipUntil(u.id), '');
});
test('subscription: invoice.paid grants, failure then successful retry still grants, renewal extends', async () => {
  const u = await newUser(), meta = { user_id: u.id, plan: 'month' }, RUN = Date.now().toString(36);
  const inv = (id, type, extra = {}) => ({ id: 'evt_' + id + type, type, data: { object: { id, amount_paid: 499, subtotal: 499, currency: 'usd', subscription_details: { metadata: meta }, attempt_count: 1, ...extra } } });
  const f = await hook(inv('in_A' + RUN, 'invoice.payment_failed', { amount_paid: 0 })); assert.equal(f.body.status, 'failed'); assert.equal(vipUntil(u.id), '', 'a failed payment grants nothing');
  const ok = await hook(inv('in_A' + RUN, 'invoice.paid')); assert.equal(ok.body.status, 'succeeded', 'the retry of the same invoice is not blocked by the earlier failure');
  const v1 = vipUntil(u.id); assert.ok(v1);
  const again = await hook(inv('in_A' + RUN, 'invoice.paid')); assert.equal(again.body.duplicate, true); assert.equal(vipUntil(u.id), v1);
  const renew = await hook(inv('in_B' + RUN, 'invoice.paid')); assert.equal(renew.body.status, 'succeeded');
  assert.ok(new Date(vipUntil(u.id)) > new Date(v1), 'a renewal extends from the current end');
  const first = await hook({ id: 'evt_cs' + RUN, type: 'checkout.session.completed', data: { object: { id: 'cs_s', mode: 'subscription', payment_status: 'paid', client_reference_id: u.id, metadata: meta, amount_total: 499 } } });
  assert.equal(first.body.ignored, 'subscription_uses_invoice_paid');
});
test('full refund marks the payment refunded and ends the VIP that payment bought; partial refund does nothing', async () => {
  const u = await newUser(), ev = session(u.id), ref = ev.data.object.payment_intent;
  await hook(ev); assert.ok(vipUntil(u.id));
  const part = await hook({ id: 'evt_p', type: 'charge.refunded', data: { object: { refunded: false, payment_intent: ref } } }); assert.equal(part.body.ignored, 'partial_refund'); assert.ok(vipUntil(u.id));
  const full = await hook({ id: 'evt_r', type: 'charge.refunded', data: { object: { refunded: true, payment_intent: ref } } });
  assert.equal(full.status, 200); assert.equal(status(ref), 'refunded');
  assert.ok(!vipUntil(u.id) || new Date(vipUntil(u.id)) <= new Date(Date.now() + 1000), 'VIP from the refunded payment is gone');
  const unknown = await hook({ id: 'evt_u', type: 'charge.refunded', data: { object: { refunded: true, payment_intent: 'pi_unknown' } } }); assert.equal(unknown.body.ignored, 'unknown_payment');
});
test('transient database failure returns 500 so Stripe retries', async () => {
  const u = await newUser();
  const r = await handleWebhook(await signed(session(u.id)), envOf(), { ...quiet, fetch: async () => { throw new Error('boom'); } });
  assert.equal(r.status, 500);
});
test('only POST is accepted', async () => { assert.equal((await handleWebhook(new Request('http://x', { method: 'GET' }), envOf(), quiet)).status, 405); });

/* ---------- create-checkout ---------- */
function stripeMock(over = {}) {
  const seen = [];
  const f = async (url, init = {}) => {
    if (String(url).startsWith('https://api.stripe.com/v1/prices/')) { seen.push('price'); return Response.json({ id: 'price_test1', active: true, unit_amount: 499, currency: 'usd', type: 'one_time', ...over.price }); }
    if (String(url) === 'https://api.stripe.com/v1/checkout/sessions') { seen.push(init.body); return Response.json({ url: 'https://checkout.stripe.com/c/pay/cs_x', ...over.session }); }
    return fetch(url, init);
  };
  return { f, seen };
}
const checkout = async (tok, body, env, deps) => { const r = await handleCheckout(new Request('http://x/create-checkout', { method: 'POST', headers: tok ? { Authorization: 'Bearer ' + tok } : {}, body: typeof body === 'string' ? body : JSON.stringify(body) }), envOf(env), { ...quiet, ...deps }); return { status: r.status, body: await r.json() }; };

test('checkout: needs configuration, a valid body and a signed-in user', async () => {
  const u = await newUser(), m = stripeMock();
  assert.equal((await checkout(u.tok, { plan: 'month' }, { STRIPE_SECRET_KEY: '' }, { fetch: m.f })).status, 503);
  assert.equal((await checkout(u.tok, { plan: 'month' }, { SITE_URL: 'javascript:alert(1)' }, { fetch: m.f })).status, 503);
  assert.equal((await checkout(null, { plan: 'month' }, {}, { fetch: m.f })).status, 401);
  assert.equal((await checkout('not-a-jwt', { plan: 'month' }, {}, { fetch: m.f })).status, 401);
  assert.equal((await checkout(u.tok, '{bad', {}, { fetch: m.f })).status, 400);
  assert.equal((await checkout(u.tok, { plan: "x'; drop table" }, {}, { fetch: m.f })).status, 400);
  assert.equal((await checkout(u.tok, { plan: 'year' }, {}, { fetch: m.f })).status, 404, 'a plan with no online price cannot be bought');
  assert.deepEqual(m.seen, [], 'Stripe was never called for any rejected request');
});
test('checkout: session is bound to the VERIFIED user and ignores identity/price sent by the browser', async () => {
  const u = await newUser(), m = stripeMock();
  const r = await checkout(u.tok, { plan: 'month', user: '00000000-0000-0000-0000-000000000001', price: 'price_cheap', amount: 1 }, {}, { fetch: m.f });
  assert.equal(r.status, 200); assert.match(r.body.url, /^https:\/\/checkout\.stripe\.com\//);
  const sent = new URLSearchParams(m.seen.filter((x) => x !== 'price').pop());
  assert.equal(sent.get('client_reference_id'), u.id); assert.equal(sent.get('metadata[user_id]'), u.id); assert.equal(sent.get('line_items[0][price]'), 'price_test1');
  assert.equal(sent.get('mode'), 'payment'); assert.equal(sent.get('success_url'), 'https://lingora.example/?paid=1');
});
test('checkout: recurring prices use subscription mode and tag the subscription', async () => {
  const u = await newUser(), m = stripeMock({ price: { type: 'recurring' } });
  await checkout(u.tok, { plan: 'month' }, {}, { fetch: m.f });
  const sent = new URLSearchParams(m.seen.filter((x) => x !== 'price').pop());
  assert.equal(sent.get('mode'), 'subscription'); assert.equal(sent.get('subscription_data[metadata][user_id]'), u.id);
});
test('checkout: refuses when Stripe price and database price disagree, or Stripe fails', async () => {
  const u = await newUser();
  assert.equal((await checkout(u.tok, { plan: 'month' }, {}, { fetch: stripeMock({ price: { unit_amount: 100 } }).f })).status, 409);
  assert.equal((await checkout(u.tok, { plan: 'month' }, {}, { fetch: stripeMock({ price: { active: false } }).f })).status, 409);
  assert.equal((await checkout(u.tok, { plan: 'month' }, {}, { fetch: stripeMock({ session: { url: 'https://evil.example/' } }).f })).status, 502, 'never redirects to a non-Stripe URL');
});
test('checkout: a suspended account cannot start one', async () => {
  const u = await newUser(), m = stripeMock();
  psql(`select set_config('lingora.priv','1',false); update profiles set suspended=true where id='${u.id}'`);
  assert.equal((await checkout(u.tok, { plan: 'month' }, {}, { fetch: m.f })).status, 403);
});
test('validSiteUrl', () => {
  assert.ok(validSiteUrl('https://a.example')); assert.ok(validSiteUrl('http://localhost:8080'));
  assert.ok(!validSiteUrl('http://a.example')); assert.ok(!validSiteUrl('javascript:alert(1)')); assert.ok(!validSiteUrl(''));
});
