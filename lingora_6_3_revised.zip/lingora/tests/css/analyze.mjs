// LINGORA 6.3: read-only CSS analysis. It NEVER edits anything. It opens every audit screen at the audit viewports in both themes and reports:
//   unused-rule CANDIDATES (no element ever matched, ignoring :hover/:focus/::before etc.; dynamic states the sweep cannot reach are false positives, so these are leads, not verdicts),
//   exact duplicate rules, duplicate declarations inside one rule, selectors redefined many times, !important declarations, high-specificity selectors,
//   media queries that can never apply to a supported viewport, and costly properties.
// Usage: node tests/css/analyze.mjs [siteDir] [--json out.json]
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : new URL('../../site', import.meta.url).pathname);
const JSON_OUT = process.argv.includes('--json') ? process.argv[process.argv.indexOf('--json') + 1] : '';
const STUB = fs.readFileSync(new URL('../ui/supabase-memstub.js', import.meta.url), 'utf8');
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined, args: ['--no-sandbox'] });
const WIDTHS = [[320, 640], [390, 844], [768, 1024], [1024, 768], [1280, 800], [844, 390]];
const SCREENS = ['home', 'learn', 'stories', 'ai', 'me', 'courses', 'words', 'world', 'friends', 'rank', 'shop', '@admin', '@notif', '@lesson', '@profile-tabs'];

// ---- 1. dump the CSSOM once (rules with their media context), and the set of selectors that matched anywhere ----
const matched = new Set(); let rules = [];
for (const theme of ['light', 'dark']) for (const [w, h] of WIDTHS) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, hasTouch: w < 800, isMobile: w < 800 }); const page = await ctx.newPage();
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon"};' }));
  await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (r) => r.abort());
  await page.addInitScript((t) => { sessionStorage.setItem('__admin', '1'); localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 120, lang: 'en', course: 'en', level: 'beginner', theme: t, done: {} })); }, theme);
  await page.goto(`http://127.0.0.1:${port}/index.html`); await page.waitForTimeout(1000);
  const collect = async () => {
    const r = await page.evaluate(() => {
      const out = [], hit = [];
      const strip = (s) => s.replace(/::?[a-zA-Z-]+(\([^)]*\))?/g, (m) => /^:(not|is|where|has)\(/.test(m) ? m : '').replace(/\s*[>+~]\s*$/, '').trim() || '*';
      const walk = (list, media, idx0) => { for (const r of list) {
        if (r.type === 1) { const parts = r.selectorText.split(','); out.push({ sel: r.selectorText, media, css: r.style.cssText, n: r.style.length, imp: [...r.style].filter((p) => r.style.getPropertyPriority(p) === 'important') });
          for (const p of parts) { try { if (document.querySelector(strip(p.trim()))) hit.push(media + '||' + p.trim()); } catch (e) { hit.push(media + '||' + p.trim()); } } }
        else if (r.type === 4) walk(r.cssRules, media + '@media ' + r.conditionText + ' ', 0);
        else if (r.type === 12) walk(r.cssRules, media + '@supports ' + r.conditionText + ' ', 0);
        else if (r.type === 7 || r.type === 5) out.push({ at: r.cssText.slice(0, 60) }); } };
      for (const ss of document.styleSheets) { try { if (ss.href && !ss.href.includes('styles.css')) continue; walk(ss.cssRules, '', 0); } catch (e) {} }
      return { out, hit };
    });
    if (!rules.length) rules = r.out; r.hit.forEach((x) => matched.add(x));
  };
  for (const s of SCREENS) {
    try {
      if (s === '@admin') await page.evaluate(() => document.querySelector('[data-a="tab"][data-v="admin"]').click());
      else if (s === '@notif') { await page.evaluate(() => document.querySelector('[data-a="tab"][data-v="home"]').click()); await page.waitForTimeout(250); await page.evaluate(() => { const b = document.querySelector('[data-a="bell"]'); if (b) b.click(); }); }
      else if (s === '@lesson') { await page.evaluate(() => document.querySelector('.nav [data-a="tab"][data-v="learn"]').click()); await page.waitForTimeout(300); await page.evaluate(() => document.querySelector('[data-a="node"]').click()); }
      else if (s === '@profile-tabs') { await page.evaluate(() => document.querySelector('.nav [data-a="tab"][data-v="me"]').click()); await page.waitForTimeout(300); for (const t of ['stats', 'badges', 'mist', 'set']) { await page.evaluate((t) => { const b = document.querySelector(`[data-a="ptab"][data-v="${t}"]`); if (b) b.click(); }, t); await page.waitForTimeout(250); await collect(); } }
      else await page.evaluate((v) => { const t = document.querySelector(`.nav [data-a="tab"][data-v="${v}"]`); if (t) t.click(); else location.hash = '#/' + v; }, s);
    } catch (e) {}
    await page.waitForTimeout(350); await collect();
    if (s === '@lesson') await page.evaluate(() => { const q = document.querySelector('[data-a="quit"]'); if (q) q.click(); }).catch(() => {});
    if (s === '@lesson') { await page.waitForTimeout(250); await page.evaluate(() => { const q = document.querySelector('[data-a="quitYes"]'); if (q) q.click(); }).catch(() => {}); }
  }
  await ctx.close();
}
await browser.close(); srv.close();

// ---- 2. analysis ----
const styled = rules.filter((r) => r.sel);
const key = (r) => r.media + '||' + r.sel;
const normDecl = (css) => css.split(';').map((x) => x.trim()).filter(Boolean).sort().join(';');
const report = { totals: {}, unused: [], dupRules: [], dupDecl: [], redefined: [], important: [], specific: [], obsoleteMedia: [], heavy: [] };
report.totals = { rules: styled.length, atRules: rules.length - styled.length, importantDecl: styled.reduce((a, r) => a + r.imp.length, 0), bytes: fs.statSync(path.join(ROOT, 'styles.css')).size };
const stateRe = /:(hover|focus|focus-visible|focus-within|active|checked|disabled|target|visited|placeholder-shown|invalid|valid|empty|first-child|last-child|nth)|::(before|after|placeholder|selection|backdrop|-webkit|marker)/;
for (const r of styled) {
  const parts = r.sel.split(',').map((x) => x.trim());
  const dead = parts.filter((p) => !matched.has(r.media + '||' + p));
  if (dead.length === parts.length) report.unused.push({ sel: r.sel.slice(0, 110), media: r.media.trim(), pseudo: parts.some((p) => stateRe.test(p)) });
}
const seen = new Map();
for (const r of styled) { const k = key(r) + '=>' + normDecl(r.css); seen.set(k, (seen.get(k) || 0) + 1); }
for (const [k, n] of seen) if (n > 1) report.dupRules.push({ rule: k.slice(0, 140), times: n });
for (const r of styled) { const props = r.css.split(';').map((x) => x.trim().split(':')[0]).filter(Boolean); const d = props.filter((p, i) => props.indexOf(p) !== i); if (d.length) report.dupDecl.push({ sel: r.sel.slice(0, 80), props: [...new Set(d)] }); }
const by = new Map(); for (const r of styled) by.set(key(r), (by.get(key(r)) || 0) + 1);
for (const [k, n] of by) if (n >= 4) report.redefined.push({ selector: k.slice(0, 120), times: n });
for (const r of styled) if (r.imp.length) report.important.push({ sel: r.sel.slice(0, 90), media: r.media.trim().slice(0, 50), props: r.imp });
const spec = (s) => { const a = (s.match(/#[\w-]+/g) || []).length, b = (s.match(/\.[\w-]+|\[[^\]]+\]|:(?!:)(?!not|is|where)[\w-]+/g) || []).length, c = (s.match(/(^|[\s>+~])[a-z][\w-]*/gi) || []).length; return [a, b, c]; };
for (const r of styled) for (const p of r.sel.split(',')) { const [a, b, c] = spec(p.trim()); if (a >= 1 || b >= 4) report.specific.push({ sel: p.trim().slice(0, 100), spec: `${a},${b},${c}` }); }
const supportedMin = 320, supportedMax = 3840;
for (const r of styled.concat(rules.filter((x) => x.at))) { const m = r.media || ''; const max = [...m.matchAll(/max-width:\s*(\d+)px/g)].map((x) => +x[1]); const min = [...m.matchAll(/min-width:\s*(\d+)px/g)].map((x) => +x[1]); if (max.some((v) => v < supportedMin) || min.some((v) => v > supportedMax)) report.obsoleteMedia.push({ media: m.trim(), sel: (r.sel || '').slice(0, 60) }); }
const css = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');
const count = (re) => (css.match(re) || []).length;
report.heavy = { backdropFilter: count(/backdrop-filter/g), filterBlur: count(/filter:[^;]*blur/g), transitionAll: count(/transition:\s*all/g), willChange: count(/will-change/g), infiniteAnimations: count(/infinite/g), universalSelector: count(/(^|[,{}\s])\*\s*[{,]/g), boxShadowLarge: count(/box-shadow:[^;]*\d{2,}px[^;]*\d{2,}px/g), webkitPrefixed: count(/-webkit-/g), mozPrefixed: count(/-moz-/g) };
const out = { totals: report.totals, unusedCandidates: report.unused.length, unusedNoPseudo: report.unused.filter((u) => !u.pseudo).length, dupRules: report.dupRules.length, dupDecl: report.dupDecl.length, redefinedSelectors: report.redefined.length, important: report.important.length, highSpecificity: report.specific.length, obsoleteMedia: report.obsoleteMedia.length, heavy: report.heavy };
console.log(JSON.stringify(out, null, 1));
console.log('\n-- exact duplicate rules --'); report.dupRules.forEach((x) => console.log(' ', x.times + '×', x.rule));
console.log('\n-- duplicate declarations inside one rule --'); report.dupDecl.forEach((x) => console.log(' ', x.sel, '->', x.props.join(',')));
console.log('\n-- !important --'); report.important.forEach((x) => console.log(' ', x.sel, '|', x.media, '|', x.props.join(',')));
console.log('\n-- obsolete media queries --'); report.obsoleteMedia.forEach((x) => console.log(' ', x.media, x.sel));
console.log('\n-- unused candidates (selector never matched an element in any audit screen/size/theme; state/pseudo-only ones marked *) --'); report.unused.forEach((x) => console.log(' ', x.pseudo ? '*' : ' ', (x.media ? x.media + ' ' : '') + x.sel));
console.log('\n-- selectors defined 4+ times --'); report.redefined.forEach((x) => console.log(' ', x.times + '×', x.selector));
if (JSON_OUT) fs.writeFileSync(JSON_OUT, JSON.stringify(report, null, 1));
