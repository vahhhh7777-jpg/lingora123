// LINGORA 6.3: visual-equivalence proof for a CSS change.   node tests/css/equiv.mjs <beforeSiteDir> <afterSiteDir> [--quick]
// For every audit screen x viewport x theme (+ the open lesson and the quit sheet) it renders BOTH sites in the same Chromium and compares
//   (a) the screenshot bytes (animations frozen) and (b) a hash of EVERY computed style property of EVERY element.
// Identical hashes everywhere = the change is visually and computationally equivalent for everything the sweep can reach. Exit 1 on any difference.
import { createRequire } from 'node:module'; import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/'); const { chromium } = require('playwright');
const [A, B] = [process.argv[2], process.argv[3]].map((p) => path.resolve(p)); const QUICK = process.argv.includes('--quick'), COMPUTED = process.argv.includes('--computed');   // computed-style hashing is opt-in: it proved timing-sensitive in this sandbox
const STUB = fs.readFileSync(new URL('../ui/supabase-memstub.js', import.meta.url), 'utf8');
const mk = (root) => { const s = http.createServer((q, r) => { const f = path.join(root, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.setHeader('cache-control', 'no-store'); r.end(fs.readFileSync(f)); }).listen(0); return s; };
const sa = mk(A), sb = mk(B), browser = await chromium.launch({ executablePath: process.env.CHROME || undefined, args: ['--no-sandbox'] });
const ONLY = (process.env.EQ_SCREENS || '').split(',').filter(Boolean), ONLYW = (process.env.EQ_WIDTHS || '').split(',').filter(Boolean).map((x) => x.split('x').map(Number));   // narrow a re-run to some cells
const WIDTHS = ONLYW.length ? ONLYW : QUICK ? [[390, 844], [1280, 800]] : [[320, 640], [360, 740], [390, 844], [430, 932], [768, 1024], [820, 1180], [1024, 768], [1280, 800], [844, 390]];
const SCREENS = ONLY.length ? ONLY : ['home', 'learn', 'stories', 'ai', 'me', 'courses', 'words', 'world', 'friends', 'rank', 'shop', '@admin', '@notif', '@lesson', '@quit'];
const sha = (b) => crypto.createHash('sha1').update(b).digest('hex');
async function render(port, theme, [w, h]) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, hasTouch: w < 800, isMobile: w < 800, reducedMotion: 'reduce' }); const page = await ctx.newPage(); const out = {};
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon"};' }));
  await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (r) => r.abort());
  await page.addInitScript((t) => { sessionStorage.setItem('__admin', '1'); localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 120, lang: 'en', course: 'en', level: 'beginner', theme: t, done: {} })); Math.random = () => 0.5; }, theme);
  await page.goto(`http://127.0.0.1:${port}/index.html`); await page.addStyleTag({ content: '*,::before,::after{animation:none!important;transition:none!important;caret-color:transparent!important}' }); await page.waitForTimeout(1200);   // frozen identically on both sides: only static style differences remain
  for (const s of SCREENS) {
    await page.evaluate((s) => { const c = (q) => { const e = document.querySelector(q); if (e) e.click(); };
      if (s === '@admin') c('[data-a="tab"][data-v="admin"]'); else if (s === '@notif') { c('.nav [data-a="tab"][data-v="home"]'); setTimeout(() => c('[data-a="bell"]'), 150); }
      else if (s === '@lesson') { c('.nav [data-a="tab"][data-v="learn"]'); setTimeout(() => c('[data-a="node"]'), 150); } else if (s === '@quit') c('[data-a="quit"]');
      else { const t = document.querySelector(`.nav [data-a="tab"][data-v="${s}"]`); if (t) t.click(); else location.hash = '#/' + s; } }, s);
    await page.waitForTimeout(700);
    const shot = sha(await page.screenshot({ animations: 'disabled', caret: 'hide' }));
    const cs = !COMPUTED ? '-' : await page.evaluate(() => { let h = 2166136261 >>> 0, n = 0; const mix = (str) => { for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } };
      for (const el of document.querySelectorAll('body *, html, body')) { const c = getComputedStyle(el); mix(el.tagName); for (let i = 0; i < c.length; i++) { const p = c[i]; if (/^(animation|transition)/.test(p)) continue; mix(p + c.getPropertyValue(p) + ';'); } n++; } return h + ':' + n; });
    out[s] = { shot, cs };
    if (s === '@quit') await page.evaluate(() => { const y = document.querySelector('[data-a="quitYes"]'); if (y) y.click(); });
  }
  await ctx.close(); return out;
}
let diffs = 0, cells = 0;
for (const theme of ['light', 'dark']) for (const wh of WIDTHS) {
  const [ra, rb] = [await render(sa.address().port, theme, wh), await render(sb.address().port, theme, wh)];
  for (const s of SCREENS) { cells++; if (ra[s].shot !== rb[s].shot) { diffs++; console.log('DIFF screenshot', theme, wh.join('x'), s); } if (ra[s].cs !== rb[s].cs) { diffs++; console.log('DIFF computed-style', theme, wh.join('x'), s, ra[s].cs, rb[s].cs); } }
}
await browser.close(); sa.close(); sb.close();
console.log(diffs ? `\nNOT EQUIVALENT: ${diffs} differences in ${cells} screen/size/theme cells` : `\nEQUIVALENT: ${cells} screen/size/theme cells, screenshots byte-identical${COMPUTED ? " and computed styles identical" : ""}`);
process.exit(diffs ? 1 : 0);
