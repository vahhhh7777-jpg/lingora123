// Dead-button guard: every data-a="..." action used in the markup must have a handler in the dispatcher.
import fs from 'node:fs'; import path from 'node:path';
const dir = new URL('../../src/js/', import.meta.url).pathname;
const src = fs.readdirSync(dir).filter(f => f.endsWith('.js')).sort().map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('\n');
const used = new Set([...src.matchAll(/data-a=\\?"([A-Za-z0-9_-]+)\\?"/g)].map(m => m[1]));
const handled = new Set([...src.matchAll(/case\s*'([A-Za-z0-9_-]+)'/g)].map(m => m[1]));
for (const m of src.matchAll(/\ba===?'([A-Za-z0-9_-]+)'/g)) handled.add(m[1]);
const dead = [...used].filter(u => !handled.has(u));
console.log(`${used.size} distinct actions in markup, ${handled.size} handlers`);
if (dead.length) { console.log('DEAD (no handler): ' + dead.join(', ')); process.exit(1); }
console.log('PASS no action without a handler');
