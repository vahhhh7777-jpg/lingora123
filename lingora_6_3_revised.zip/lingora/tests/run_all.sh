#!/usr/bin/env bash
# LINGORA 6.3: run EVERY suite and print one PASS / FAIL / BLOCKED line each (BLOCKED = exit code 2 or an environment that is not there).
# Needs PostgreSQL 16, Node 22, Playwright + Chromium. Live checks need SUPABASE_URL / SUPABASE_ANON_KEY (+ SITE_URL, SMOKE_EMAIL ...); without them they are BLOCKED, never PASS.
#   OLD_SITE=/path/to/previous/site bash tests/run_all.sh      (enables the service-worker upgrade scenarios)   OUT=/dir  where the logs go
cd "$(dirname "$0")/.."; OUT="${OUT:-/tmp/lingora-regression}"; mkdir -p "$OUT"; : > "$OUT/summary.tsv"
run() { local name="$1"; shift; "$@" > "$OUT/$name.log" 2>&1; local c=$?; local st=FAIL; [ $c = 0 ] && st=PASS; [ $c = 2 ] && st=BLOCKED
  echo -e "$st\t$name\texit=$c\t$(grep -E 'passed|FAILED|EQUIVALENT|audited|no problems|no layout|# pass|# fail|all passed|problems|stages|0 distinct' "$OUT/$name.log" | tail -1 | cut -c1-120)" | tee -a "$OUT/summary.tsv"; }
fresh() { bash tests/e2e/_bridge_up.sh >/dev/null 2>&1; }
run build-check node build.mjs --check
run static-actions node tests/static/actions.mjs
run sql bash tests/sql/run.sh
for t in layout audit62 a11y62 a11y63 contrast mediacopy sync reset pay admin phase1 complete review; do run ui-$t node tests/ui/$t.mjs; done
run ui-service-worker node tests/ui/sw.mjs
# ---- everything below needs the stand-in bridge on a FRESH database ----
fresh
run ai node --test tests/ai/coach.test.mjs
run stripe node --test tests/stripe/stripe.test.mjs
run e2e node tests/e2e/e2e.mjs
run e2e-phase2 node tests/e2e/phase2.mjs
run monkey-crawl node tests/e2e/monkey.mjs
for r in learner admin; do run monkey-random-$r env ROLES=$r SEEDS=1,2,3,4,5,6 STEPS=150 node tests/e2e/monkey_random.mjs; done
# live smoke: protocol level. Without SUPABASE_URL this is BLOCKED (exit 2). Against the local stand-in it is NOT a live test (see the report).
run live-smoke-api node tests/live/smoke.mjs
run live-smoke-browser node tests/live/smoke_browser.mjs
echo; echo "---- summary ----"; cut -f1 "$OUT/summary.tsv" | sort | uniq -c
