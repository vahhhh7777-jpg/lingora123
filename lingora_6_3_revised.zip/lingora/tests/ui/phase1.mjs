// Phase 1 browser regression tests (real Chromium, real site/app.js, in-memory Supabase stand-in).
// P1-01 sign-out must not throw away progress that has not reached the server yet
// P1-03 sign-out whose server call fails must still end the session on this device and tell the user
// P1-04 a VIP that starts in the future is not shown / treated as active
// P1-06 "e-mail not confirmed" gets its own clear message
// P1-07 a failed profile load after sign-in does not leave a half signed-in state
// P1-08 a learner opening #/admin never sees the admin screen
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL(process.env.SITE || '../../site', import.meta.url).pathname);
const STUB = fs.readFileSync(new URL('./supabase-memstub.js', import.meta.url), 'utf8');
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome', args: ['--no-sandbox'] });
let pass = 0, fail = 0; const check = (n, c, x = '') => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : '  ' + x)); };
async function fresh(opts = {}) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } }); const page = await ctx.newPage(); const errs = [], warns = [];
  page.on('pageerror', (e) => errs.push(e.message)); page.on('console', (m) => { if (m.type() === 'warning') warns.push(m.text()); });
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon"};' }));
  await page.addInitScript((o) => { if (o.vip) sessionStorage.setItem('__vip', JSON.stringify(o.vip)); if (o.admin) sessionStorage.setItem('__admin', '1');
    if (!localStorage.getItem('lingora.v1')) localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 0, lang: 'en', course: 'en', level: 'beginner', theme: 'light', done: {} })); }, opts);
  await page.goto(`http://127.0.0.1:${port}/index.html${opts.hash || ''}`); await page.waitForTimeout(1500);
  return { ctx, page, errs, warns };
}
const tabTo = async (page, v) => { await page.evaluate((v) => { const t = document.querySelector(`[data-a="tab"][data-v="${v}"]`); if (t) t.click(); }, v); await page.waitForTimeout(200); };
const setLevel = async (page, v) => { await tabTo(page, 'me'); await page.evaluate(() => { const t = document.querySelector('[data-a="ptab"][data-v="set"]'); if (t) t.click(); }); await page.waitForTimeout(150);
  const ok = await page.evaluate((v) => { const b = document.querySelector(`[data-a="sset"][data-k="diff"][data-v="${v}"]`); if (b) { b.click(); return true; } return false; }, v); if (!ok) throw new Error('difficulty control not found'); };
const local = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('lingora.v1')));
const signOut = async (page) => { await tabTo(page, 'me'); await page.evaluate(() => { const b = document.querySelector('[data-a="signout"]'); if (b) b.click(); }); await page.waitForTimeout(500); };

/* ---- P1-01: unsynced progress survives sign-out + sign-in ---- */
{ const { ctx, page, errs } = await fresh();
  await page.evaluate(() => { window.__sb.failProgress = -1; });
  await setLevel(page, 'hard'); await page.waitForTimeout(600);
  check('P1-01 setup: change is only on this device (server still failing)', (await local(page)).diff === 'hard' && (await page.evaluate(() => window.__sb.progress && window.__sb.progress.pf && window.__sb.progress.pf.diff)) !== 'hard');
  await signOut(page);
  await page.evaluate(() => { window.__sb.failProgress = 0; });
  await page.evaluate(() => { const b = document.querySelector('[data-a="authgo"][data-v="signin"]'); if (b) b.click(); }); await page.waitForTimeout(200);
  await page.fill('#em', 't@example.com'); await page.fill('#pw', 'secret1'); await page.click('#authform button[type=submit]'); await page.waitForTimeout(2500);
  const srv = await page.evaluate(() => window.__sb.progress);
  check('P1-01 unsynced progress was not lost by sign-out: after signing in again it reaches the server', !!srv && srv.pf && srv.pf.diff === 'hard', JSON.stringify(srv && srv.pf));
  check('P1-01 ...and is back on the device', (await local(page)).diff === 'hard');
  check('P1-01 no JavaScript errors', errs.length === 0, errs.join('|')); await ctx.close(); }

/* ---- P1-03: failed server sign-out still ends the local session ---- */
{ const { ctx, page, errs } = await fresh();
  await page.evaluate(() => { localStorage.setItem('sb-stub-auth-token', '{"access_token":"tok"}'); window.__sb.signOutError = 'Failed to fetch'; });
  await signOut(page);
  const left = await page.evaluate(() => localStorage.getItem('sb-stub-auth-token'));
  check('P1-03 the stored session token is removed from this device even though the server call failed', left === null, String(left));
  const shown = await page.evaluate(() => !!document.querySelector('[data-a="authgo"]'));
  check('P1-03 the app shows the signed-out screen', shown);
  check('P1-03 the user is told (toast) that the server session could not be ended', /could not|no connection|server/i.test(await page.evaluate(() => (document.getElementById('toast') || {}).innerText || '')), await page.evaluate(() => (document.getElementById('toast') || {}).innerText));
  check('P1-03 no JavaScript errors', errs.length === 0, errs.join('|')); await ctx.close(); }

/* ---- P1-04: scheduled VIP is not active ---- */
{ const soon = new Date(Date.now() + 5 * 864e5).toISOString(), later = new Date(Date.now() + 35 * 864e5).toISOString();
  const { ctx, page } = await fresh({ vip: { from: soon, until: later } });
  await tabTo(page, 'me'); await page.evaluate(() => { const t = document.querySelector('[data-a="ptab"][data-v="set"]'); if (t) t.click(); }); await page.waitForTimeout(300);
  const st = await page.evaluate(() => ({ on: !!document.querySelector('.vipst.on'), box: !!document.querySelector('.vipst') }));
  check('P1-04 a VIP that starts in 5 days is not shown as active VIP today', st.box && !st.on, JSON.stringify(st));
  await ctx.close();
  const a = await fresh({ vip: { from: new Date(Date.now() - 864e5).toISOString(), until: later } });
  await tabTo(a.page, 'me'); await a.page.evaluate(() => { const t = document.querySelector('[data-a="ptab"][data-v="set"]'); if (t) t.click(); }); await a.page.waitForTimeout(300);
  check('P1-04 control: a VIP that already started IS shown as active', await a.page.evaluate(() => !!document.querySelector('.vipst.on')));
  await a.ctx.close(); }

/* ---- P1-06: e-mail not confirmed ---- */
{ const { ctx, page, errs } = await fresh();
  await signOut(page);
  await page.evaluate(() => { window.__sb.signInError = 'Email not confirmed'; const b = document.querySelector('[data-a="authgo"][data-v="signin"]'); if (b) b.click(); }); await page.waitForTimeout(200);
  await page.fill('#em', 't@example.com'); await page.fill('#pw', 'secret1'); await page.click('#authform button[type=submit]'); await page.waitForTimeout(800);
  const m = await page.evaluate(() => (document.querySelector('.msg.err') || {}).innerText || '');
  check('P1-06 unconfirmed e-mail: message tells the user to confirm the e-mail', /confirm/i.test(m) && !/could not save|something went wrong/i.test(m), m);
  check('P1-06 no JavaScript errors', errs.length === 0, errs.join('|')); await ctx.close(); }

/* ---- P1-07: profile load fails right after a successful password check ---- */
{ const { ctx, page, errs } = await fresh();
  await signOut(page);
  await page.evaluate(() => { window.__sb.profileFail = true; const b = document.querySelector('[data-a="authgo"][data-v="signin"]'); if (b) b.click(); }); await page.waitForTimeout(200);
  await page.fill('#em', 't@example.com'); await page.fill('#pw', 'secret1'); await page.click('#authform button[type=submit]'); await page.waitForTimeout(1500);
  const state = await page.evaluate(() => ({ form: !!document.querySelector('#authform'), err: (document.querySelector('.msg.err') || {}).innerText || '', onboarding: /What should we call you/i.test(document.body.innerText) }));
  check('P1-07 profile fetch fails after a successful password check: the sign-in form stays with an error message (no half signed-in / onboarding screen)', state.form && !!state.err && !state.onboarding, JSON.stringify(state));
  await page.evaluate(() => { window.__sb.profileFail = false; }); await page.fill('#pw', 'secret1'); await page.click('#authform button[type=submit]'); await page.waitForTimeout(2000);
  check('P1-07 retry after the failure signs in normally', await page.evaluate(() => !document.querySelector('#authform') && !!document.querySelector('[data-a="tab"]')));
  check('P1-07 no JavaScript errors', errs.length === 0, errs.join('|')); await ctx.close(); }

/* ---- P1-08: route guard ---- */
{ const { ctx, page, errs } = await fresh({ hash: '#/admin' });
  const st = await page.evaluate(() => ({ hash: location.hash, admin: !!document.querySelector('[data-a="asub"],[data-a="admtab"],.adm,#adm,[data-adm]') }));
  check('P1-08 a learner opening #/admin is sent away from the admin route', st.hash !== '#/admin' && !st.admin, JSON.stringify(st));
  check('P1-08 no JavaScript errors', errs.length === 0, errs.join('|')); await ctx.close(); }

/* ---- P1-09: a failing background call is logged and the user is told (not silent) ---- */
{ const { ctx, page, warns, errs } = await fresh();
  await page.evaluate(() => { window.__sb.econ = { xp: 0, level: 1, gems: 0, hearts: 5, max_hearts: 5, streak: 0, goal: 20, day_xp: 0 }; });
  await page.reload(); await page.waitForTimeout(1500);
  await page.evaluate(() => { window.__sb.failRpc = 'set_my_goal'; });
  await tabTo(page, 'me'); await page.evaluate(() => { const t = document.querySelector('[data-a="ptab"][data-v="set"]'); if (t) t.click(); }); await page.waitForTimeout(200);
  await page.selectOption('select[data-sel="goal"]', '30'); await page.waitForTimeout(600);
  check('P1-09 a failed goal save on the server is logged to the console', warns.some((w) => /daily goal not saved/.test(w)), warns.join('|'));
  check('P1-09 no uncaught JavaScript errors', errs.length === 0, errs.join('|'));
  await ctx.close(); }

/* ---- P1-10 / P1-11: intro screen is visible, flags are drawn (visual regressions the other suites skipped because automation hides the intro) ---- */
{ const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true }); const page = await ctx.newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"",SUPABASE_ANON_KEY:""};' }));
  await page.goto(`http://127.0.0.1:${port}/index.html#splash`); await page.waitForTimeout(2400);
  const sp = await page.evaluate(() => { const e = document.querySelector('.sp-hi'), l = document.querySelector('.sp-logo'); if (!e || !l) return null; const a = e.getBoundingClientRect(), b = l.getBoundingClientRect(); return { hiY: a.y, hiB: a.bottom, logoY: b.y, vh: innerHeight }; });
  check('P1-10 intro screen: logo and greeting are inside the visible screen (not pushed below the fold)', !!sp && sp.hiY >= 0 && sp.hiB <= sp.vh && sp.logoY >= 0, JSON.stringify(sp));
  await page.evaluate(() => { const b = document.querySelector('[data-a="splashgo"]'); if (b) b.click(); }); await page.waitForTimeout(800);
  await page.evaluate(() => { const b = document.querySelector('[data-a="start"]'); if (b) b.click(); }); await page.waitForTimeout(800);
  const fl = await page.evaluate(() => ({ svg: document.querySelectorAll('.opts.courses svg.flag').length, rawText: /<svg|viewBox=/.test(document.body.innerText) }));
  check('P1-11 onboarding language cards show drawn flags, not SVG source text', fl.svg >= 7 && !fl.rawText, JSON.stringify(fl));
  check('P1-10/11 no JavaScript errors', errs.length === 0, errs.join('|')); await ctx.close(); }

await browser.close(); srv.close();
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
