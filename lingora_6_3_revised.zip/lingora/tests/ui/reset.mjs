// B-006 in a real browser: "Reset progress" must reach the server, survive a failed request + reload, and the old server
// progress / XP must never come back. Uses the in-memory Supabase stand-in (tests/ui/supabase-memstub.js).
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname);
const STUB = fs.readFileSync(new URL('./supabase-memstub.js', import.meta.url), 'utf8');
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined, args: ['--no-sandbox'] });
let pass = 0, fail = 0; const check = (n, c, x = '') => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : '  ' + x)); };
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } }); const page = await ctx.newPage(); const errs = [];
page.on('pageerror', (e) => errs.push(e.message));
await page.route(/fonts\.(googleapis|gstatic)/, (r) => r.abort());
await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon"};' }));
// the "server" keeps its state across reloads of the page (the stub is re-created on every load, so we mirror it in sessionStorage)
await page.addInitScript(() => {
  if (!localStorage.getItem('lingora.v1')) localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 0, lang: 'en', course: 'en', level: 'beginner', theme: 'light', done: {} }));
});
await page.goto(`http://127.0.0.1:${port}/index.html`); await page.waitForTimeout(1200);
const local = () => page.evaluate(() => JSON.parse(localStorage.getItem('lingora.v1')));
const marker = () => page.evaluate(() => localStorage.getItem('lingora.v1.reset'));
const click = (sel) => page.evaluate((s) => { const b = document.querySelector(s); if (b) { b.click(); return true; } return false; }, sel);
async function pressReset() {
  await click('[data-a="tab"][data-v="me"]'); await page.waitForTimeout(150);
  await click('[data-a="ptab"][data-v="set"]'); await page.waitForTimeout(150);
  const ok = await click('[data-a="sreset"]'); await page.waitForTimeout(200);
  const ok2 = await click('#dlgok'); await page.waitForTimeout(700); return ok && ok2;
}
// give the account progress on "server" and device
await page.evaluate(() => { const sb = window.__sb; sb.progress = { xp: 500, done: { lessonX: 1 }, pf: {} }; sb.econ = { xp: 500, gems: 7, streak: 3, best_streak: 3, done: { lessonX: 1 } }; });
await page.evaluate(() => { const j = JSON.parse(localStorage.getItem('lingora.v1')); j.xp = 500; j.done = { lessonX: 1 }; localStorage.setItem('lingora.v1', JSON.stringify(j)); });

// 1. reset while the server is DOWN
await page.evaluate(() => { window.__sb.failReset = true; });
check('reset button + confirm dialog work', await pressReset());
let l = await local();
check('device progress is cleared at once', l.xp === 0 && Object.keys(l.done || {}).length === 0, JSON.stringify({ xp: l.xp, done: l.done }));
check('a pending-reset marker is persisted (survives reload)', (await marker()) !== null);
check('the server was asked to reset', (await page.evaluate(() => window.__sb.rpcs.filter((x) => x === 'reset_my_progress').length)) >= 1);
const toastTxt = await page.evaluate(() => (document.getElementById('toast') || {}).innerText || '');
check('user is told honestly that the server has not been reset yet', /not reached the server|server/i.test(toastTxt) && !/progress cleared/i.test(toastTxt), toastTxt);
const serverXpStill = await page.evaluate(() => window.__sb.econ && window.__sb.econ.xp);
check('(sanity) the stand-in server still holds the old XP', serverXpStill === 500);

// 2. reload while the server is still down: the old progress must NOT come back
await page.evaluate(() => { sessionStorage.setItem('__failreset', '1'); sessionStorage.setItem('__srv', JSON.stringify({ p: window.__sb.progress, e: window.__sb.econ })); });
await page.reload(); await page.waitForTimeout(1500);
l = await local();
check('after reload (server down) the old XP did not come back', l.xp === 0, 'xp=' + l.xp);
check('after reload the old finished lessons did not come back', !l.done || !l.done.lessonX, JSON.stringify(l.done));
check('marker still there (reset still owed to the server)', (await marker()) !== null);

// 3. server back: the retry delivers the reset, marker cleared, server really reset
await page.evaluate(() => { sessionStorage.removeItem('__failreset'); window.__sb.failReset = false; });
await page.evaluate(() => window.dispatchEvent(new Event('online'))); await page.waitForTimeout(1500);
check('server received reset_my_progress and applied it', (await page.evaluate(() => window.__sb.serverResets)) >= 1);
check('marker cleared after the server confirmed', (await marker()) === null);
l = await local();
check('device still at zero after delivery', l.xp === 0 && !(l.done && l.done.lessonX), JSON.stringify({ xp: l.xp, done: l.done }));
check('server progress blob is empty (nothing old left to restore)', await page.evaluate(() => JSON.stringify(window.__sb.progress) === '{}' || (window.__sb.progress && !window.__sb.progress.xp)));

// 4. a normal reset with the server up goes through immediately and is not marked pending
await page.evaluate(() => { const sb = window.__sb; sb.progress = { xp: 80, done: { lessonY: 1 } }; sb.econ = { xp: 80, gems: 1, streak: 1, best_streak: 1, done: { lessonY: 1 } }; sb.serverResets = 0; });
await pressReset();
check('online reset: server reset called once', (await page.evaluate(() => window.__sb.serverResets)) === 1);
check('online reset: no pending marker left', (await marker()) === null);
l = await local();
check('online reset: device cleared', l.xp === 0 && !(l.done && l.done.lessonY), JSON.stringify(l));
check('no JavaScript errors during the whole run', errs.length === 0, errs.join('|'));
console.log(`\n${pass} passed, ${fail} failed`); await browser.close(); srv.close(); process.exit(fail ? 1 : 0);
