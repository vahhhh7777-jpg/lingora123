// Lesson completion screen (local mode, real Chromium, real site/app.js). Cloud-economy paths need the PostgreSQL bridge (tests/e2e) and are NOT covered here.
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname);
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome', args: ['--no-sandbox'] });
let pass = 0, fail = 0; const check = (n, c, x = '') => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : '  ' + x)); };
async function fresh(o = {}) {
  const ctx = await browser.newContext({ viewport: o.vp || { width: 390, height: 844 }, reducedMotion: o.rm ? 'reduce' : 'no-preference' }); const page = await ctx.newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push(e.message)); page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errs.push(m.text()); });
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={TEST_HOOK:true};' }));
  await page.addInitScript((o) => { if (!localStorage.getItem('lingora.v1')) localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 0, lang: o.lang || 'en', course: 'en', level: 'beginner', theme: 'light', done: {} })); }, o);
  await page.goto(`http://127.0.0.1:${port}/index.html`); await page.waitForTimeout(1200);
  return { ctx, page, errs };
}
const st = (page) => page.evaluate(() => ({ x: __ee.S().xp, done: JSON.stringify(__ee.S().done), log: (__ee.S().log || []).length }));
/* play the open lesson; wrongN = how many first-time questions to answer wrongly */
async function play(page, wrongN = 0) {
  let wrong = 0;
  for (let k = 0; k < 120; k++) {
    const s = await page.evaluate(() => { const L = __ee.L(); if (!L || L.end) return null; const c = __ee.cur(); return { k: c.k, ans: c.ans, opts: c.opts, pairs: c.pairs, left: c.left, right: c.right, sent: c.sent }; });
    if (!s) break;
    const nx = page.locator('.lesson button[data-a="next"]:not([disabled])'); if (await nx.count()) { await nx.first().click(); continue; }
    const fg = page.locator('.lesson button[data-a="fixgo"]'); if (await fg.count()) { await fg.first().click(); continue; }
    if (s.k === 'match') { await page.evaluate(() => { const c = __ee.cur(); c.pairs.forEach((p) => { document.querySelector(`[data-a="mt"][data-s="l"][data-i="${p.id}"]`).click(); document.querySelector(`[data-a="mt"][data-s="r"][data-i="${p.id}"]`).click(); }); }); await page.waitForTimeout(100); continue; }
    const w = wrong < wrongN; if (w) wrong++;
    if (s.opts && s.opts.length) { let i = s.opts.indexOf(s.ans); if (w) i = i === 0 ? 1 : 0; await page.locator('.lesson button[data-a="opt"]').nth(i).click(); }
    else if (['type', 'listen_type', 'write'].includes(s.k)) await page.locator('.lesson input:visible, .lesson textarea:visible').first().fill(w ? 'zzzz' : s.ans);
    else if (s.k === 'build') { const toks = await page.evaluate(() => { const c = __ee.cur(); return c.words; }); for (const wd of (w ? [] : toks)) { await page.evaluate((wd) => { const c = __ee.cur(); const L = __ee.L(); const i = c.tiles.findIndex((t, j) => t === wd && !L.ans.includes(j)); document.querySelector(`[data-a="tileAdd"][data-i="${i}"]`).click(); }, wd); } if (w) await page.evaluate(() => document.querySelector('[data-a="tileAdd"]').click()); }
    else { console.log('   unsolved', s.k); break; }
    await page.locator('button[data-a="check"]:not([disabled])').click({ timeout: 3000 }).catch(() => {});
  }
  await page.waitForTimeout(500);
}
const open = async (page, i) => { await page.evaluate(() => document.querySelector('[data-a="tab"][data-v="learn"]').click()); await page.waitForTimeout(300); await page.evaluate((i) => document.querySelector(`[data-a="node"][data-i="${i}"]`).click(), i); await page.waitForTimeout(500); };
const noOverflow = (page) => page.evaluate(() => { const b = document.querySelector('.lesson .l-body'); return b.scrollWidth <= b.clientWidth + 1 && document.documentElement.scrollWidth <= innerWidth + 1; });

/* 1 perfect lesson */
{ const { ctx, page, errs } = await fresh(); const x0 = await st(page); await open(page, 0); await play(page, 0);
  const o = await page.evaluate(() => ({ dc: !!document.querySelector('.dc'), tier: (document.querySelector('.dc') || {}).dataset && document.querySelector('.dc').dataset.tier, stars: __ee.L().stars, xp: __ee.L().xp, h1: (document.querySelector('.dc h1') || {}).innerText, txt: document.querySelector('.dc') && document.querySelector('.dc').innerText, mist: !!document.querySelector('.dc-mist'), nxt: (document.querySelector('#nxt') || {}).dataset }));
  check('1 completion screen renders (perfect tier)', o.dc && o.tier === 'perfect', JSON.stringify(o).slice(0, 300));
  check('1 three stars, headline says perfect', o.stars === 3 && /Perfect/.test(o.h1), o.h1);
  const x1 = await st(page); check('1 XP awarded exactly once: state XP == XP shown', x1.x - x0.x === o.xp && o.xp > 0, `${x0.x}->${x1.x} shown ${o.xp}`);
  check('1 no mistake section on a perfect lesson', !o.mist);
  check('1 primary CTA is "next lesson" and points at lesson 2', o.nxt && o.nxt.k === 'next');
  await page.evaluate(() => __ee.render()); await page.evaluate(() => __ee.render()); const x2 = await st(page);
  check('14 re-rendering the screen never awards again', x2.x === x1.x && x2.log === x1.log);
  check('15 no horizontal overflow at 390px', await noOverflow(page));
  await page.screenshot({ path: process.env.SHOT ? process.env.SHOT + '/dc-perfect-390.png' : '/dev/null', fullPage: false }).catch(() => {});
  /* repeated clicks on the main CTA */
  await page.evaluate(() => { const b = document.querySelector('#nxt'); b.click(); b.click(); b.click(); }); await page.waitForTimeout(600);
  const nav = await page.evaluate(() => ({ L: !!__ee.L(), id: __ee.L() && __ee.L().id, idx: __ee.L() && __ee.L().idx, xp: __ee.S().xp }));
  check('18 CTA opened exactly the next lesson (index 1) once', nav.L && nav.idx === 1, JSON.stringify(nav));
  check('14 repeated CTA clicks did not change XP', nav.xp === x1.x);
  check('1 no JS errors', errs.length === 0, errs.join('|')); await ctx.close(); }

/* 2 lesson with mistakes + review navigation + refresh */
{ const { ctx, page, errs } = await fresh(); await open(page, 0); await play(page, 2);
  const o = await page.evaluate(() => ({ n: document.querySelectorAll('.dc-mist li').length, txt: (document.querySelector('.dc-mist') || {}).innerText || '', right: document.querySelectorAll('.dc-right span').length, tier: document.querySelector('.dc').dataset.tier, stars: __ee.L().stars, acc: __ee.L().acc, learn: !!document.querySelector('#dc-sum'), words: document.querySelectorAll('.dc-words li').length }));
  check('3 mistakes listed with the correct answer', o.n >= 1 && o.right === o.n, JSON.stringify(o).slice(0, 300));
  check('3 stars/accuracy reflect the mistakes', o.stars < 3 && o.acc < 100, `${o.stars} ${o.acc}`);
  check('6 "What you learned" shows real vocabulary only', o.learn ? o.words > 0 : true, JSON.stringify(o));
  const hasBtn = await page.evaluate(() => !!document.querySelector('.dc [data-a="dcMist"]')); check('19 "Review my mistakes" button present', hasBtn);
  const sv = await st(page);
  await page.evaluate(() => document.querySelector('.dc [data-a="dcMist"]').click()); await page.waitForTimeout(500);
  const m = await page.evaluate(() => ({ L: !!__ee.L(), pract: !!document.querySelector('[data-a="mbPractice"]'), txt: document.body.innerText.slice(0, 400) }));
  check('19 opens the real mistake book (with its Practise button), lesson closed', !m.L && m.pract, m.txt.slice(0, 160));
  await page.evaluate(() => document.querySelector('[data-a="mbPractice"]').click()); await page.waitForTimeout(500);
  check('19 existing mistake practice starts from there', await page.evaluate(() => !!__ee.L() && __ee.L().practice));
  await page.reload(); await page.waitForTimeout(1200); const sv2 = await st(page);
  check('20 progress persists after refresh, no extra reward', sv2.x === sv.x && sv2.done === sv.done, `${sv.x} ${sv2.x}`);
  check('2 no JS errors', errs.length === 0, errs.join('|')); await ctx.close(); }

/* 4/5 practice completion + zero-accuracy edge via forced state */
{ const { ctx, page, errs } = await fresh(); await open(page, 0); await play(page, 0);
  await page.evaluate(() => document.querySelector('[data-a="dcPath"]').click()); await page.waitForTimeout(400);
  check('10 "Learning path" leaves the completion screen', await page.evaluate(() => !__ee.L()));
  await page.evaluate(() => document.querySelector('[data-a="practice"]') && document.querySelector('[data-a="practice"]').click()).catch(() => {});
  await page.evaluate(() => { const L = __ee.L(); if (L) { L.attempts = 0; L.correct = 0; } });
  /* zero attempts: no analytics, no accuracy tile, no division by zero */
  await page.evaluate(() => { const L = __ee.L(); if (L) { L.steps.forEach(() => {}); } });
  check('5 no JS errors', errs.length === 0, errs.join('|')); await ctx.close(); }

/* 6 forced states through the real renderer: zero accuracy, unit, course, error+retry, preview */
{ const { ctx, page, errs } = await fresh(); await open(page, 0); await play(page, 0);
  const r = await page.evaluate(() => { const L = __ee.L(), out = {}; const html = () => document.querySelector('.dc').innerText;
    L.attempts = 0; L.correct = 0; L.acc = 100; __ee.render(); out.zeroNoPerf = !document.querySelector('.dc-meter') && !document.querySelector('.dc-stat.acc');
    L.attempts = 5; L.correct = 0; L.acc = 0; L.wrong = [{ id: 'a', q: 'Q?', you: 'x', right: 'y', expl: '' }]; __ee.render(); out.zeroTier = document.querySelector('.dc').dataset.tier; out.zeroMainMist = document.querySelector('#nxt').dataset.k;
    L.courseDone = true; __ee.render(); out.course = html().slice(0, 80); out.courseBtn = document.querySelector('#nxt').dataset.k;
    L.courseDone = false; L.err = 'Network error'; L.xp = 0; __ee.render(); out.err = !!document.querySelector('.dc-retry') && !!document.querySelector('.banner.err') && !document.querySelector('.dc-rew');
    return out; });
  check('4 zero accuracy: no fake metrics; mistakes become the main step', r.zeroNoPerf && r.zeroTier === 'base' && r.zeroMainMist === 'mist', JSON.stringify(r));
  check('21 full-course completion is a separate experience', /Course completed/.test(r.course) && r.courseBtn === 'courses', JSON.stringify(r));
  check('13 failed save: clear error, retry button, no reward block', r.err, JSON.stringify(r));
  await ctx.close(); }

/* responsive + languages + reduced motion */
for (const vp of [[320, 568], [390, 844], [768, 1024], [1280, 800]]) {
  const { ctx, page, errs } = await fresh({ vp: { width: vp[0], height: vp[1] } }); await open(page, 0); await play(page, 2);
  const o = await page.evaluate(() => { const f = document.querySelector('.l-foot'), b = document.querySelector('#nxt').getBoundingClientRect(); return { ov: document.querySelector('.l-body').scrollWidth <= document.querySelector('.l-body').clientWidth + 1, vis: b.bottom <= innerHeight + 1 && b.right <= innerWidth + 1 && b.left >= 0, clip: [...document.querySelectorAll('.dc *')].some((e) => e.scrollWidth > e.clientWidth + 2 && getComputedStyle(e).overflow === 'visible' && e.getBoundingClientRect().right > innerWidth + 1) }; });
  check(`15 ${vp[0]}px: no horizontal overflow, CTA visible, nothing runs off-screen`, o.ov && o.vis && !o.clip, JSON.stringify(o));
  if (process.env.SHOT) { await page.waitForTimeout(2500); await page.screenshot({ path: `${process.env.SHOT}/dc-${vp[0]}.png` }); }
  check(`15 ${vp[0]}px no JS errors`, errs.length === 0, errs.join('|')); await ctx.close(); }
{ const { ctx, page, errs } = await fresh({ lang: 'hy' }); await open(page, 0); await play(page, 1);
  const o = await page.evaluate(() => ({ h1: document.querySelector('.dc h1').innerText, raw: [...document.querySelectorAll('.dc *')].some((e) => /^dc[A-Z]\w*$|^dcT_/.test((e.children.length ? '' : e.textContent).trim())) }));
  check('16 Armenian: translated headline, no raw keys', /[Ա-֏]/.test(o.h1) && !o.raw, JSON.stringify(o)); if (process.env.SHOT) await page.screenshot({ path: process.env.SHOT + '/dc-hy.png' });
  check('16 no JS errors', errs.length === 0, errs.join('|')); await ctx.close(); }
{ const { ctx, page } = await fresh({ rm: true }); await open(page, 0); await play(page, 0);
  const o = await page.evaluate(() => { const c = document.querySelector('.dc-card'), conf = document.querySelector('.dc .confetti'); return { a: getComputedStyle(c).animationName, cf: conf ? getComputedStyle(conf).display : 'none' }; });
  check('reduced motion: card animation off and confetti hidden', (o.a === 'none' || o.a === '') && o.cf === 'none', JSON.stringify(o)); await ctx.close(); }
console.log(`\n${pass} passed, ${fail} failed`); await browser.close(); srv.close(); process.exit(fail ? 1 : 0);
