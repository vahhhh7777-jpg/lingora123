// Lingora 6.2 behaviour checks: skip link, headings + document.title per page, dialog focus (move in, trap, restore), empty-state actions.
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname);
const STUB = fs.readFileSync(new URL('./supabase-memstub.js', import.meta.url), 'utf8');
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome', args: ['--no-sandbox'] });
let pass = 0, fail = 0; const ok = (c, m) => { if (c) { pass++; console.log('PASS ' + m); } else { fail++; console.log('FAIL ' + m); } };
for (const [w, h] of [[390, 844], [820, 1180], [1280, 800]]) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, hasTouch: w < 800, isMobile: w < 800 });
  const page = await ctx.newPage(); const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon"};' }));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await page.addInitScript(() => { sessionStorage.setItem('__admin', '1'); localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 120, lang: 'en', course: 'en', level: 'beginner', theme: 'light', done: {} })); });
  await page.goto(`http://127.0.0.1:${srv.address().port}/index.html`); await page.waitForTimeout(1200);
  const T = `${w}px`;
  // skip link
  await page.keyboard.press('Tab');
  ok(await page.evaluate(() => document.activeElement && document.activeElement.className === 'skip'), `${T}: first Tab stops on the skip link`);
  await page.keyboard.press('Enter');
  ok(await page.evaluate(() => document.activeElement && document.activeElement.tagName === 'MAIN'), `${T}: skip link moves focus to <main>`);
  // every tab has exactly one h1 and a matching document.title
  for (const v of ['home', 'learn', 'stories', 'ai', 'me']) {
    await page.evaluate((v) => document.querySelector(`.nav [data-a="tab"][data-v="${v}"]`).click(), v); await page.waitForTimeout(350);
    const r = await page.evaluate(() => ({ h1: document.querySelectorAll('main h1').length, title: document.title, live: document.querySelector('[aria-live=polite]').textContent, h: (document.querySelector('main h1') || {}).textContent }));
    ok(r.h1 >= 1 && r.title.endsWith('· Lingora') && r.title.startsWith((r.h || '').replace(/\s+/g, ' ').trim()), `${T}: ${v} has a heading ("${(r.h || '').trim().slice(0, 24)}") and title "${r.title.slice(0, 30)}"`);
  }
  // dialog: focus moves in, Tab is trapped, Escape restores focus to the bell
  await page.evaluate(() => document.querySelector('.nav [data-a="tab"][data-v="home"]').click()); await page.waitForTimeout(300);
  await page.focus('[data-a="bell"]'); await page.keyboard.press('Enter'); await page.waitForTimeout(400);
  ok(await page.evaluate(() => { const d = document.querySelector('[role=dialog]'); return !!d && d.contains(document.activeElement); }), `${T}: opening notifications moves focus into the dialog`);
  let inside = true; for (let i = 0; i < 8; i++) { await page.keyboard.press('Tab'); inside = inside && await page.evaluate(() => { const d = document.querySelector('[role=dialog]'); return !!d && d.contains(document.activeElement); }); }
  ok(inside, `${T}: Tab stays inside the dialog (8 presses)`);
  await page.keyboard.press('Shift+Tab'); ok(await page.evaluate(() => document.querySelector('[role=dialog]').contains(document.activeElement)), `${T}: Shift+Tab stays inside the dialog`);
  await page.keyboard.press('Escape'); await page.waitForTimeout(400);
  ok(await page.evaluate(() => !document.querySelector('[role=dialog]') && document.activeElement && document.activeElement.dataset.a === 'bell'), `${T}: Escape closes it and focus returns to the bell`);
  // empty states with a real action
  await page.evaluate(() => { location.hash = '#/shop'; }); await page.waitForTimeout(500);
  const shop = await page.evaluate(() => { const e = document.querySelector('.empty .btn[data-a="tab"][data-v="learn"]'); return !!e; });
  ok(shop, `${T}: shop empty state offers "continue learning"`);
  if (shop) { await page.click('.empty .btn[data-a="tab"][data-v="learn"]'); await page.waitForTimeout(400); ok(await page.evaluate(() => document.querySelector('.nav [aria-current=page]').dataset.v === 'learn'), `${T}: that button opens Learn`); }
  await page.evaluate(() => { location.hash = '#/words'; }); await page.waitForTimeout(500);
  ok(await page.evaluate(() => !!document.querySelector('.empty .btn[data-a="tab"][data-v="learn"]')), `${T}: words empty state offers "start learning"`);
  await page.evaluate(() => { location.hash = '#/rank'; }); await page.waitForTimeout(500);
  ok(await page.evaluate(() => !!document.querySelector('.rk-act[data-v="friends"]')), `${T}: rank empty state offers Friends`);
  ok(errs.length === 0, `${T}: no JS errors ${errs.slice(0, 2)}`);
  await ctx.close();
}
console.log(`\n${pass} passed, ${fail} failed`); await browser.close(); srv.close(); process.exit(fail ? 1 : 0);
