// B-004 regression: opening the Admin tab must never freeze or crash the browser, even when admin_stats returns nothing or an error.
// (It used to refetch + re-render forever, which hung and finally crashed Chromium.)
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname);
const STUB = fs.readFileSync(new URL('./supabase-memstub.js', import.meta.url), 'utf8');
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined, args: ['--no-sandbox'] });
let pass = 0, fail = 0; const check = (n, c, x = '') => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : '  ' + x)); };
async function open(mode) {
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 800 } }); const page = await ctx.newPage(); const errs = []; let crashed = false;
  page.on('pageerror', (e) => errs.push(e.message)); page.on('crash', () => { crashed = true; });
  await page.route(/fonts\.(googleapis|gstatic)/, (r) => r.abort());
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon"};' }));
  await page.addInitScript((m) => { sessionStorage.setItem('__admin', '1'); if (m === 'error') { const iv = setInterval(() => { if (window.__sb) { window.__sb.statsMode = 'error'; clearInterval(iv); } }, 1); }
    if (!localStorage.getItem('lingora.v1')) localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 0, lang: 'en', course: 'en', level: 'beginner', theme: 'light', done: {} })); }, mode);
  await page.goto(`http://127.0.0.1:${port}/index.html`); await page.waitForTimeout(1200);
  page.evaluate(() => document.querySelector('[data-a="tab"][data-v="admin"]').click()).catch(() => {});
  await page.waitForTimeout(2500);
  const alive = await Promise.race([page.evaluate(() => document.title.length >= 0).catch(() => false), new Promise((r) => setTimeout(() => r(false), 4000))]);
  const n = await page.evaluate(() => window.__sb.rpcs.filter((x) => x === 'admin_stats').length).catch(() => -1);
  return { page, errs, crashed, alive, n };
}
for (const mode of ['empty', 'error']) {
  const r = await open(mode);
  check(`admin tab, admin_stats = ${mode}: page stays alive`, r.alive && !r.crashed);
  check(`admin tab, admin_stats = ${mode}: loaded a bounded number of times (got ${r.n})`, r.n >= 1 && r.n <= 2, String(r.n));
  check(`admin tab, admin_stats = ${mode}: no JavaScript errors`, r.errs.length === 0, r.errs.join('|'));
  if (mode === 'error') {
    const txt = await r.page.evaluate(() => document.body.innerText);
    check('failed load shows an error with a retry button', /Could not load/i.test(txt) && /Try again/i.test(txt), txt.slice(0, 120));
    await r.page.evaluate(() => document.querySelector('[data-a="p3reload"][data-k="s"]').click()); await r.page.waitForTimeout(800);
    const n2 = await r.page.evaluate(() => window.__sb.rpcs.filter((x) => x === 'admin_stats').length);
    check('Retry makes exactly one new attempt', n2 === r.n + 1, `${r.n} -> ${n2}`);
  }
  await r.page.context().close();
}
console.log(`\n${pass} passed, ${fail} failed`); await browser.close(); srv.close(); process.exit(fail ? 1 : 0);
