// LINGORA 6.3: two accessibility facts that had no automated proof before: (1) prefers-reduced-motion really stops the looping animations, (2) heading levels never skip (h1 -> h3).
// Automated only: this does NOT replace a screen reader or a physical device (see ACCESSIBILITY_CHECKLIST_6_3.md).
import { createRequire } from 'node:module'; import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/'); const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname), STUB = fs.readFileSync(new URL('./supabase-memstub.js', import.meta.url), 'utf8');
const srv = http.createServer((q, r) => { const f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); } r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'x'); r.end(fs.readFileSync(f)); }).listen(0);
const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined, args: ['--no-sandbox'] }); let bad = 0;
const ok = (c, n, why) => { console.log(c ? 'PASS' : 'FAIL', n, c ? '' : '- ' + (why || '')); if (!c) bad++; };
const SCREENS = ['home', 'learn', 'stories', 'ai', 'me', 'courses', 'words', 'world', 'friends', 'rank', 'shop', '@admin'];
async function open(reduced, w) { const ctx = await browser.newContext({ viewport: { width: w, height: 844 }, reducedMotion: reduced ? 'reduce' : 'no-preference' }); const page = await ctx.newPage();
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon"};' }));
  await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, (r) => r.abort());
  await page.addInitScript(() => { sessionStorage.setItem('__admin', '1'); localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 120, lang: 'en', course: 'en', level: 'beginner', theme: 'light', done: {} })); });
  await page.goto(`http://127.0.0.1:${srv.address().port}/index.html`); await page.waitForTimeout(2200); return { ctx, page }; }
const go = async (page, s) => { await page.evaluate((s) => { if (s === '@admin') { const a = document.querySelector('[data-a="tab"][data-v="admin"]'); if (a) a.click(); } else { const t = document.querySelector(`.nav [data-a="tab"][data-v="${s}"]`); if (t) t.click(); else location.hash = '#/' + s; } }, s); await page.waitForTimeout(500); };
// (1) reduced motion: count visible elements whose animation loops forever, with and without the preference
const loops = (page) => page.evaluate(() => [...document.querySelectorAll('body *')].filter((e) => { const c = getComputedStyle(e); return c.display !== 'none' && c.animationName !== 'none' && (c.animationIterationCount === 'infinite') && parseFloat(c.animationDuration) > 0.01; }).map((e) => e.tagName + '.' + String(e.className).slice(0, 24)));
let off = 0, on = 0, offList = [];
for (const reduced of [false, true]) { const { ctx, page } = await open(reduced, 390); for (const s of SCREENS) { await go(page, s); const l = await loops(page); if (reduced) { on += l.length; if (l.length) offList.push(s + ':' + l.slice(0, 3)); } else off += l.length; } await ctx.close(); }
ok(off > 0, `A1 sanity: without the preference the app does have looping animations (${off} element-screens)`);
ok(on === 0, 'A2 with prefers-reduced-motion: reduce NO element keeps a looping animation', JSON.stringify(offList));
{ const { ctx, page } = await open(true, 390); await go(page, 'home'); const t = await page.evaluate(() => { const b = document.querySelector('.cont-play'); const c = b && getComputedStyle(b); return c ? { an: c.animationName, dur: c.animationDuration } : null; }); ok(t && (t.an === 'none' || parseFloat(t.dur) < 0.01), 'A3 the Continue button pulse (contPulse) stops under reduced motion', JSON.stringify(t)); await ctx.close(); }
// (2) heading hierarchy, per screen, at phone and desktop width
for (const w of [390, 1280]) { const { ctx, page } = await open(false, w); const bads = [];
  for (const s of SCREENS) { await go(page, s); const lv = await page.evaluate(() => [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')].filter((h) => { const c = getComputedStyle(h); return c.display !== 'none' && c.visibility !== 'hidden' && h.getBoundingClientRect().height > 0; }).map((h) => +h.tagName[1]));
    const h1s = lv.filter((x) => x === 1).length; let skip = false; for (let i = 1; i < lv.length; i++) if (lv[i] - lv[i - 1] > 1) skip = true; if (h1s !== 1 || skip) bads.push(`${s}: ${lv.join('')}`); }
  ok(!bads.length, `A4 ${w}px: every screen has exactly one h1 and no skipped heading level`, bads.join(' | ')); await ctx.close(); }
await browser.close(); srv.close(); console.log(bad ? `\n${bad} FAILED` : '\nall passed'); process.exit(bad ? 1 : 0);
