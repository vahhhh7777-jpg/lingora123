// Real-browser test of the progress sync queue (failure, backoff, retry button, offline/online, no duplicates, local preservation).
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname);
const STUB = fs.readFileSync(new URL('./supabase-memstub.js', import.meta.url), 'utf8');
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome', args: ['--no-sandbox'] });
let pass = 0, fail = 0; const check = (n, c, x = '') => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : '  ' + x)); };
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } }); const page = await ctx.newPage(); const errs = [];
page.on('pageerror', (e) => errs.push(e.message));
await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon"};' }));
await page.addInitScript(() => { if (!localStorage.getItem('lingora.v1')) localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 0, lang: 'en', course: 'en', level: 'beginner', theme: 'light', done: {} })); });
await page.goto(`http://127.0.0.1:${port}/index.html`); await page.waitForTimeout(1500);
const sbq = (f) => page.evaluate(f);
const bar = () => page.evaluate(() => { const e = document.getElementById('syncbar'); return e && !e.hidden ? e.innerText : ''; });
const act = async (a, v) => { await page.evaluate(([a, v]) => { const b = document.querySelector(`[data-a="${a}"]${v ? `[data-v="${v}"]` : ''}`); if (b) b.click(); }, [a, v]); };
const setLevel = async (v) => { await page.evaluate(() => { const t = document.querySelector('[data-a="tab"][data-v="me"]'); if (t) t.click(); }); await page.waitForTimeout(150);
  await page.evaluate(() => { const t = document.querySelector('[data-a="ptab"][data-v="set"]'); if (t) t.click(); }); await page.waitForTimeout(150);
  const ok = await page.evaluate((v) => { const b = document.querySelector(`[data-a="sset"][data-k="diff"][data-v="${v}"]`); if (b) { b.click(); return true; } return false; }, v); if (!ok) throw new Error('difficulty control not found'); };
const local = () => page.evaluate(() => JSON.parse(localStorage.getItem('lingora.v1')));
const pend = () => page.evaluate(() => localStorage.getItem('lingora.v1.pend'));
check('app booted in cloud mode, no page errors', (await page.evaluate(() => !!window.__sb)) && errs.length === 0, errs.join('|'));
// 1. successful sync
await setLevel('easy'); await page.waitForTimeout(800);
let s = await sbq(() => window.__sb);
check('successful change reaches the server', s.progress && s.progress.pf && s.progress.pf.diff === 'easy', JSON.stringify(s.progress && s.progress.pf));
check('no pending marker after success', (await pend()) === null);
// 2. failing server: local copy kept, pending marker, banner with Retry
await page.evaluate(() => { window.__sb.failProgress = -1; window.__sb.saves.length = 0; });
await setLevel('hard'); await page.waitForTimeout(800);
check('failed sync keeps progress on this device', (await local()).diff === 'hard');
check('pending marker is stored', (await pend()) !== null);
let b = await bar();
check('user sees a clear status with a Retry button', /not saved on the server/i.test(b) && /retry/i.test(b), b);
const n1 = (await sbq(() => window.__sb.saves.length));
// 3. manual retry while still failing -> another failed attempt, no spurious success
await page.evaluate(() => document.querySelector('[data-sync="retry"]').click()); await page.waitForTimeout(600);
check('Retry button makes a new attempt', (await sbq(() => window.__sb.saves.length)) > n1);
check('still pending (nothing falsely reported as saved)', (await pend()) !== null && /not saved/i.test(await bar()));
// 4. backoff: automatic retry happens later, not in a tight loop
const n2 = await sbq(() => window.__sb.saves.length); await page.waitForTimeout(1200);
check('controlled backoff (no hammering)', (await sbq(() => window.__sb.saves.length)) - n2 <= 1);
// 5. other device progressed meanwhile; recovery merges instead of overwriting; XP not duplicated
await page.evaluate(() => { const p = JSON.parse(JSON.stringify(window.__sb.progress)); p.xp = 500; p.done = { 'lessonX': 1 }; window.__sb.progress = p; window.__sb.failProgress = 0; });
await page.evaluate(() => document.querySelector('[data-sync="retry"]').click()); await page.waitForTimeout(900);
s = await sbq(() => window.__sb.progress);
check('recovery succeeded and cleared pending', (await pend()) === null);
check("other device's XP and lesson kept (merge, not overwrite)", s.xp === 500 && s.done && s.done.lessonX === 1 && s.pf.diff === 'hard', JSON.stringify({ xp: s.xp, done: s.done, diff: s.pf && s.pf.diff }));
check('XP not duplicated locally (max-merge, not sum)', (await local()).xp === 500);
check('lesson completion not duplicated', Object.keys((await local()).done).filter((k) => k === 'lessonX').length === 1);
// 6. thrown network error (fetch rejects) is handled the same way
await page.evaluate(() => { window.__sb.failProgress = -1; window.__sb.failMode = 'throw'; });
await setLevel('normal'); await page.waitForTimeout(700);
check('thrown fetch error: still pending, local kept, no page error', (await pend()) !== null && (await local()).diff === 'normal' && errs.length === 0, errs.join('|'));
// 7. offline -> online recovery
await page.evaluate(() => { window.__sb.failProgress = 0; window.__sb.failMode = 'error'; });
await ctx.setOffline(true); await page.evaluate(() => window.dispatchEvent(new Event('offline')));
await setLevel('easy'); await page.waitForTimeout(500);
b = await bar(); check('offline status shown', /no connection/i.test(b), b);
await ctx.setOffline(false); await page.waitForTimeout(300); await page.evaluate(() => window.dispatchEvent(new Event('online'))); await page.waitForTimeout(1200);
s = await sbq(() => window.__sb.progress);
check('connectivity back: saved automatically', s.pf.diff === 'easy' && (await pend()) === null, JSON.stringify(s.pf));
// 8. unsynced progress survives a reload (server still failing) and is pushed once the server is back
await page.evaluate(() => { window.__sb.failProgress = -1; sessionStorage.setItem('__fail', '1'); }); await setLevel('hard'); await page.waitForTimeout(500);
await page.reload(); await page.waitForTimeout(1200);
check('reload keeps local progress and pending marker', (await local()).diff === 'hard' && (await pend()) !== null, JSON.stringify({ d: (await local()).diff, p: await pend() }));
check('after reload the server has not received it yet (still failing)', (await sbq(() => window.__sb.progress)) === null);
await page.evaluate(() => { sessionStorage.removeItem('__fail'); window.__sb.failProgress = 0; });
await page.evaluate(() => { const b = document.querySelector('[data-sync="retry"]'); if (b) b.click(); }); await page.waitForTimeout(1000);
check('after the server is back the pending progress is pushed', (await sbq(() => window.__sb.progress && window.__sb.progress.pf.diff)) === 'hard' && (await pend()) === null);
// 9. permission denied is not retried forever
await page.evaluate(() => { window.__sb.failProgress = -1; window.__sb.failMode = 'denied'; window.__sb.saves.length = 0; });
await setLevel('normal'); await page.waitForTimeout(700); const d1 = await sbq(() => window.__sb.saves.length); await page.waitForTimeout(2500);
check('denied: no retry storm and clear message', (await sbq(() => window.__sb.saves.length)) === d1 && /refused/i.test(await bar()), await bar());
check('no JavaScript errors during the whole run', errs.length === 0, errs.join('|'));
console.log(`\n${pass} passed, ${fail} failed`); await browser.close(); srv.close(); process.exit(fail ? 1 : 0);
