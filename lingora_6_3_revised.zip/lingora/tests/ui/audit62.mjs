// Lingora 6.2 audit: responsive + safe-area + accessibility sweep.
// Every main screen x viewport x theme x scroll state (top / bottom) plus the notification overlay.
// Fails on: horizontal scroll, elements outside the viewport, last content hidden behind the fixed nav,
// toast covering nav, controls with no accessible name, images without alt, inputs without a label,
// clickable non-buttons without role/tabindex, missing <main>/<h1>, focus ring missing on keyboard focus.
// Usage: PW_MODULE=/opt/npm-tools/node_modules/ SHOTS=/dir node tests/ui/audit62.mjs [--quick]
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname);
const STUB = fs.readFileSync(new URL('./supabase-memstub.js', import.meta.url), 'utf8');
const SHOTS = process.env.SHOTS || '';
const QUICK = process.argv.includes('--quick');
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome', args: ['--no-sandbox'] });
const widths = QUICK ? [[360, 740], [820, 1180], [1280, 800]] : [[320, 640], [360, 740], [390, 844], [430, 932], [768, 1024], [820, 1180], [900, 1000], [1024, 768], [1280, 800], [844, 390], [667, 375]];
const screens = ['home', 'learn', 'stories', 'ai', 'me', 'courses', 'words', 'world', 'friends', 'rank', 'shop', '@admin', '@notif'];
const problems = new Map(); let n = 0;
const add = (k, v) => { if (!problems.has(k)) problems.set(k, new Set()); problems.get(k).add(v); };
for (const theme of ['light', 'dark']) for (const [w, h] of widths) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, hasTouch: w < 800, isMobile: w < 800 });
  const page = await ctx.newPage(); const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon"};' }));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await page.addInitScript((t) => { sessionStorage.setItem('__admin', '1'); localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 120, lang: 'en', course: 'en', level: 'beginner', theme: t, done: {} })); }, theme);
  await page.goto(`http://127.0.0.1:${port}/index.html`); await page.waitForTimeout(1200);
  for (const s of screens) {
    if (s === '@admin') await page.evaluate(() => { document.querySelector('[data-a="tab"][data-v="admin"]').click(); });
    else if (s === '@notif') await page.evaluate(() => { document.querySelector('[data-a="tab"][data-v="home"]').click(); });
    else await page.evaluate((v) => { const t = document.querySelector(`.nav [data-a="tab"][data-v="${v}"]`); if (t) t.click(); else location.hash = '#/' + v; }, s);
    await page.waitForTimeout(350);
    if (s === '@notif') { await page.evaluate(() => { const b = document.querySelector('[data-a="bell"]'); if (b) b.click(); }); await page.waitForTimeout(350); }
    for (const state of ['top', 'bottom']) {
      if (state === 'bottom') { await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight)); await page.waitForTimeout(200); }
      n++;
      const r = await page.evaluate(({ state, s }) => {
        const out = { hs: document.documentElement.scrollWidth - innerWidth, over: [], hidden: null, toast: null, names: [], alts: 0, labels: [], clk: [], main: !!document.querySelector('main'), h1: !!document.querySelector('main h1, [role=dialog] h1, [role=dialog] h2, .p2-sheet h2, .p2-sheet h3'), navPos: '', dlgFit: null };
        const vis = (el) => { const dt = el.closest('details:not([open])'); if (dt && !(el.tagName === 'SUMMARY' && el.parentElement === dt)) return false; const cs = getComputedStyle(el); if (cs.display === 'none' || cs.visibility === 'hidden') return false; const b = el.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
        const nav = document.querySelector('nav.nav'); const nb = nav && vis(nav) ? nav.getBoundingClientRect() : null;
        out.navPos = nb ? (nb.width > innerWidth * .6 ? 'bottom' : 'side:' + Math.round(nb.width)) : 'none';
        for (const el of document.querySelectorAll('body *')) {
          if (!vis(el)) continue; const cs = getComputedStyle(el); const b = el.getBoundingClientRect();
          let sc = false; for (let p = el.parentElement; p; p = p.parentElement) { const o = getComputedStyle(p).overflowX; if ((o === 'auto' || o === 'scroll' || o === 'hidden') && p.scrollWidth > p.clientWidth + 1 && p !== document.body && p !== document.documentElement) { sc = true; break; } }
          if (!sc && cs.position !== 'fixed' && (b.right > innerWidth + 1 || b.left < -1)) out.over.push(el.tagName + '.' + String(el.className).slice(0, 28));
          const tag = el.tagName;
          if ((tag === 'BUTTON' || tag === 'A' || el.getAttribute('role') === 'button' || el.getAttribute('role') === 'tab') && !el.closest('[aria-hidden=true]')) {
            const name = (el.getAttribute('aria-label') || el.getAttribute('title') || el.innerText || el.textContent || '').trim();
            const lb = el.getAttribute('aria-labelledby'); if (!name && !lb) out.names.push(tag + '.' + String(el.className).slice(0, 28) + '[' + (el.dataset.a || '') + ']');
          }
          if (tag === 'IMG' && !el.hasAttribute('alt')) out.alts++;
          if ((tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') && el.type !== 'hidden') {
            const ok = el.getAttribute('aria-label') || el.getAttribute('aria-labelledby') || el.closest('label') || (el.id && document.querySelector(`label[for="${el.id}"]`)) || el.title;
            if (!ok) out.labels.push(tag + '#' + (el.id || el.className || el.name).toString().slice(0, 24));
          }
          if (el.dataset && el.dataset.a && !/^(BUTTON|A|INPUT|SELECT|TEXTAREA|SUMMARY|LABEL)$/.test(tag) && !el.getAttribute('role') && el.getAttribute('tabindex') === null && !/popclose|splashgo/.test(el.dataset.a)) out.clk.push(tag + '.' + String(el.className).slice(0, 24) + '[' + el.dataset.a + ']');
        }
        // last content must clear the fixed bottom bar
        if (state === 'bottom' && nb && nb.width > innerWidth * .6 && !document.querySelector('[role=dialog]')) {
          const m = document.querySelector('main'); if (m) { let last = null; for (const el of m.querySelectorAll('*')) { if (!vis(el)) continue; const b = el.getBoundingClientRect(); if (!last || b.bottom > last.bottom) last = b; } if (last && last.bottom > nb.top + 1) out.hidden = Math.round(last.bottom - nb.top); }
        }
        const t = document.getElementById('toast'); if (t && vis(t) && nb && nb.width > innerWidth * .6 && getComputedStyle(t).opacity > 0.05) { const tb = t.getBoundingClientRect(); if (tb.bottom > nb.top + 1) out.toast = Math.round(tb.bottom - nb.top); }
        const d = document.querySelector('[role=dialog]'); if (d && vis(d)) { const b = d.getBoundingClientRect(); if (b.bottom > innerHeight + 1 || b.top < -1) out.dlgFit = Math.round(b.top) + '..' + Math.round(b.bottom); }
        return out; }, { state, s });
      const tag = `${theme} ${w}x${h} ${s} ${state}`;
      if (r.hs > 1) add('horizontal scroll', `${tag} +${r.hs}`);
      for (const o of new Set(r.over)) add('outside viewport', `${tag} ${o}`);
      if (r.hidden) add('last content under nav', `${tag} ${r.hidden}px`);
      if (r.toast) add('toast over nav', `${tag} ${r.toast}px`);
      if (r.dlgFit) add('dialog taller than viewport', `${tag} ${r.dlgFit}`);
      for (const o of new Set(r.names)) add('control without accessible name', `${tag} ${o}`);
      if (r.alts) add('img without alt', `${tag} x${r.alts}`);
      for (const o of new Set(r.labels)) add('input without label', `${tag} ${o}`);
      for (const o of new Set(r.clk)) add('clickable non-button', `${tag} ${o}`);
      if (state === 'top' && !r.main && s !== '@notif') add('no <main>', tag);
      if (state === 'top' && !r.h1 && s !== '@notif') add('no heading', tag);
      if (SHOTS && theme === 'light' && state === 'top') await page.screenshot({ path: `${SHOTS}/${w}-${s}.png` });
      if (SHOTS && theme === 'dark' && state === 'top' && w === 390) await page.screenshot({ path: `${SHOTS}/dark-${w}-${s}.png` });
    }
    if (s === '@notif') { await page.keyboard.press('Escape'); await page.evaluate(() => { const b = document.querySelector('[data-a="popclose"],[data-a="notifclose"],.pop-bg'); if (b) b.click(); }); await page.waitForTimeout(150); }
    await page.evaluate(() => window.scrollTo(0, 0));
  }
  // keyboard focus ring check on the first interactive elements of Home
  await page.evaluate(() => { const t = document.querySelector('.nav [data-a="tab"][data-v="home"]'); if (t) t.click(); }); await page.waitForTimeout(300);
  await page.evaluate(() => { document.activeElement && document.activeElement.blur(); }); await page.mouse.click(1, 1).catch(() => {});
  for (let i = 0; i < 14; i++) {
    await page.keyboard.press('Tab');
    const f = await page.evaluate(() => { const e = document.activeElement; if (!e || e === document.body) return null; const cs = getComputedStyle(e); const ring = (cs.outlineStyle !== 'none' && parseFloat(cs.outlineWidth) >= 2) || (cs.boxShadow && cs.boxShadow !== 'none'); const b = e.getBoundingClientRect(); return { ring, d: e.tagName + '.' + String(e.className).slice(0, 24) + '[' + (e.dataset.a || '') + ']', vis: b.width > 0 && b.height > 0 }; });
    if (f && f.vis && !f.ring) add('no visible focus ring', `${theme} ${w} ${f.d}`);
  }
  if (errs.length) add('JS errors', `${theme} ${w}: ${errs.slice(0, 2)}`);
  await ctx.close();
}
console.log(`audited ${n} screen states`);
let total = 0;
for (const [k, set] of problems) { console.log(`\nPROBLEM ${k}: ${set.size}`); total += set.size; for (const v of [...set].slice(0, 8)) console.log('   ' + v); }
console.log(total ? `\n${total} problems in ${problems.size} categories` : '\nno problems');
await browser.close(); srv.close(); process.exit(total ? 1 : 0);
