// Layout audit: every main screen x viewport x theme. Fails on horizontal scroll, elements sticking out of the viewport, and tiny touch targets.
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname);
const STUB = fs.readFileSync(new URL('./supabase-memstub.js', import.meta.url), 'utf8');
const SHOTS = process.env.SHOTS || '';
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome', args: ['--no-sandbox'] });
const widths = [[320, 640], [360, 740], [375, 812], [390, 844], [414, 896], [768, 1024], [1280, 800]];
const screens = ['home', 'learn', 'stories', '@lesson', '@admin', 'courses', 'words', 'world', 'friends', 'rank', 'shop', 'ai', 'me'];
const problems = []; let n = 0;
for (const theme of ['light', 'dark']) for (const [w, h] of widths) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, hasTouch: w < 800, isMobile: w < 800 });
  const page = await ctx.newPage(); const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon"};' }));
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.abort());
  await page.addInitScript((t) => { sessionStorage.setItem('__admin', '1'); localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 120, lang: 'en', course: 'en', level: 'beginner', theme: t, done: {} })); }, theme);
  await page.goto(`http://127.0.0.1:${port}/index.html`); await page.waitForTimeout(1200);
  for (const s of screens) {
    if (s === '@lesson') { await page.evaluate(() => { document.querySelector('[data-a="tab"][data-v="learn"]').click(); }); await page.waitForTimeout(250); await page.evaluate(() => { const n = document.querySelector('[data-a="node"][data-i="0"]'); if (n) n.click(); }); await page.waitForTimeout(500); }
    else if (s === '@admin') { await page.evaluate(() => { const l = document.getElementById('lesson'); const x = l && l.querySelector('[data-a="lessonx"],[data-a="close"],[data-a="quit"]'); if (x) x.click(); document.querySelector('[data-a="tab"][data-v="admin"]').click(); }); await page.waitForTimeout(500); }
    else await page.evaluate((v) => { const l = document.getElementById('lesson'); if (l) l.hidden = true; const t = document.querySelector(`.nav [data-a="tab"][data-v="${v}"]`); if (t) t.click(); else location.hash = '#/' + v; }, s);
    await page.waitForTimeout(350);
    n++;
    const r = await page.evaluate((w) => {
      const out = { hscroll: document.documentElement.scrollWidth - innerWidth, over: [], small: [] };
      for (const el of document.querySelectorAll('body *')) {
        const cs = getComputedStyle(el); if (cs.display === 'none' || cs.visibility === 'hidden') continue;
        const b = el.getBoundingClientRect(); if (!b.width || !b.height) continue;
        // ignore content inside horizontal scrollers
        let sc = false; for (let p = el.parentElement; p; p = p.parentElement) { const o = getComputedStyle(p).overflowX; if ((o === 'auto' || o === 'scroll' || o === 'hidden') && p.scrollWidth > p.clientWidth + 1 && p !== document.body && p !== document.documentElement) { sc = true; break; } }
        if (!sc && (b.right > innerWidth + 1 || b.left < -1) && cs.position !== 'fixed') out.over.push(el.tagName + '.' + String(el.className).slice(0, 30) + ' ' + Math.round(b.left) + '..' + Math.round(b.right));
        if (innerWidth < 800 && /^(BUTTON|A|INPUT|SELECT)$/.test(el.tagName) && (b.height < 36 || b.width < 36) && b.top < innerHeight && b.bottom > 0 && !(b.height >= 28 && document.elementFromPoint(b.left + b.width / 2, b.top - 5) === el) && el.type !== 'hidden' && el.type !== 'checkbox' && el.type !== 'radio') out.small.push(el.tagName + '.' + String(el.className).slice(0, 25) + '[' + (el.dataset.a || '') + '] ' + Math.round(b.width) + 'x' + Math.round(b.height));
      }
      return out; }, w);
    const tag = `${theme} ${w}x${h} ${s}`;
    if (r.hscroll > 1) problems.push(`${tag}: horizontal scroll +${r.hscroll}px`);
    for (const o of [...new Set(r.over)].slice(0, 4)) problems.push(`${tag}: outside viewport ${o}`);
    for (const o of [...new Set(r.small)].slice(0, 4)) problems.push(`${tag}: small target ${o}`);
    if (SHOTS && theme === 'light') await page.screenshot({ path: `${SHOTS}/${w}-${s}.png` });
  }
  if (errs.length) problems.push(`${theme} ${w}: JS errors ${errs.slice(0, 2)}`);
  await ctx.close();
}
console.log(`audited ${n} screens`); for (const p of problems) console.log('PROBLEM ' + p);
console.log(problems.length ? `${problems.length} problems` : 'no layout problems');
await browser.close(); srv.close(); process.exit(problems.length ? 1 : 0);
