// LINGORA 6.3: service worker + cache verification, in a real Chromium, against a small static server whose "deployment" can be swapped while the page is open.
//   node tests/ui/sw.mjs                       (OLD = the release given by OLD_SITE, default: none -> the upgrade scenarios are reported BLOCKED)
//   OLD_SITE=/path/to/previous/site node tests/ui/sw.mjs
// Scenarios:  S1 install + offline   S2 upgrade (host revalidates: Netlify-like)   S3 upgrade (host sends a long max-age: GitHub Pages / Cloudflare default)
//             S4 an update arrives while a lesson is running   S5 the shipped _headers keep sw.js / config.js out of every cache
// What this does NOT prove: behaviour on iOS Safari / installed PWAs on a phone (not available here) and a real CDN in front of the site.
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import os from 'node:os'; import crypto from 'node:crypto';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const NEW_SITE = path.resolve(new URL('../../site', import.meta.url).pathname), OLD_SITE = process.env.OLD_SITE ? path.resolve(process.env.OLD_SITE) : '';
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ee-sw-')); let bad = 0, blocked = 0;
const ok = (c, n, why) => { console.log(c ? 'PASS' : 'FAIL', n, c ? '' : '- ' + (why || '')); if (!c) bad++; };
const SHELL = ['index.html', 'config.js', 'app.js', 'theme-boot.js', 'styles.css', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'icon-maskable-512.png'];
const sha = (b) => crypto.createHash('sha1').update(b).digest('hex');

// "deploy": copy a site folder and make it testable: local mode (empty config) with the test hook, and a visible build marker in the JS and the CSS.
function deploy(name, src, mark) {
  const d = path.join(TMP, name); fs.cpSync(src, d, { recursive: true });
  fs.writeFileSync(path.join(d, 'config.js'), 'window.EE_CONFIG={TEST_HOOK:true,SUPABASE_URL:"",SUPABASE_ANON_KEY:""};');
  fs.appendFileSync(path.join(d, 'app.js'), `\n;window.__BUILD=${JSON.stringify(mark)};\n`);
  fs.appendFileSync(path.join(d, 'styles.css'), `\n/* build ${mark} */\n:root{--build-mark:"${mark}"}\n`);
  return d;
}
let ROOT = '', MODE = 'revalidate'; const hits = [];
const MIME = { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const srv = http.createServer((q, r) => {
  let u = q.url.split('?')[0]; if (u === '/') u = '/index.html'; hits.push(u);
  const f = path.join(ROOT, u); if (!f.startsWith(ROOT) || !fs.existsSync(f)) { r.statusCode = 404; return r.end('nf'); }
  const always = ['/sw.js', '/config.js', '/theme-boot.js'].includes(u);   // exactly what site/_headers says
  r.setHeader('content-type', MIME[path.extname(f)] || 'application/octet-stream');
  r.setHeader('cache-control', always ? 'no-cache' : MODE === 'longcache' ? 'public, max-age=3600' : 'public, max-age=0, must-revalidate');
  // like every real static host: an ETag, and 304 for a conditional request
  const body = fs.readFileSync(f), tag = '"' + sha(body) + '"'; r.setHeader('etag', tag);
  if (q.headers['if-none-match'] === tag) { hits.push('(304) ' + u); r.statusCode = 304; return r.end(); }
  r.end(body);
}).listen(0); const PORT = srv.address().port, URL_ = `http://127.0.0.1:${PORT}/`;
const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined, args: ['--no-sandbox'] });
const poll = async (fn, ms = 10000) => { const t0 = Date.now(); for (;;) { const v = await fn(); if (v) return v; if (Date.now() - t0 > ms) return v; await new Promise((r) => setTimeout(r, 150)); } };
const cacheState = (page) => page.evaluate(async (shell) => {
  const out = { keys: await caches.keys(), files: {} };
  for (const k of out.keys) { const c = await caches.open(k); for (const u of shell) { const r = await c.match(u); if (!r) continue; const b = await r.arrayBuffer(); const h = await crypto.subtle.digest('SHA-1', b); out.files[k + '|' + u] = [...new Uint8Array(h)].map((x) => x.toString(16).padStart(2, '0')).join(''); } }
  return out; }, SHELL);
const ctrl = (page) => page.evaluate(() => !!navigator.serviceWorker.controller);
const swVer = (txt) => (txt.match(/const CACHE = '([^']+)'/) || [])[1];
async function install(ctx, page) {
  await page.goto(URL_); await page.evaluate(() => navigator.serviceWorker.register('sw.js')); await page.evaluate(() => navigator.serviceWorker.ready);
  await page.reload(); await poll(() => ctrl(page), 5000);
}
const newPage = async () => { const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: 'allow' }); const page = await ctx.newPage(); const errs = []; page.on('pageerror', (e) => errs.push(e.message)); return { ctx, page, errs }; };

const NEW_VER = swVer(fs.readFileSync(path.join(NEW_SITE, 'sw.js'), 'utf8'));
const OLD_VER = OLD_SITE ? swVer(fs.readFileSync(path.join(OLD_SITE, 'sw.js'), 'utf8')) : '';
console.log(`INFO new release cache name: ${NEW_VER}; previous release: ${OLD_VER || '(not given)'}`);
ok(!!NEW_VER && /^ee-v\d+$/.test(NEW_VER), 'S0 sw.js declares a versioned cache name (' + NEW_VER + ')');
if (OLD_SITE) ok(OLD_VER !== NEW_VER, `S0b the cache name changed between the previous release (${OLD_VER}) and this one (${NEW_VER}); without that, installed apps never receive the new files`);

// ---------------- S1: install + offline (new release alone) ----------------
{
  ROOT = deploy('new1', NEW_SITE, 'N'); MODE = 'revalidate'; const { ctx, page, errs } = await newPage();
  await page.goto(URL_); await page.evaluate(() => { localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 0, lang: 'en', course: 'en', level: 'beginner', theme: 'light', done: {} })); });
  await install(ctx, page);
  const st = await cacheState(page);
  ok(st.keys.length === 1 && st.keys[0] === NEW_VER, `S1 one cache is created and it is ${NEW_VER}`, JSON.stringify(st.keys));
  const missing = SHELL.filter((u) => !st.files[NEW_VER + '|' + u]); ok(!missing.length, 'S1b every app-shell file is in the cache', 'missing: ' + missing.join(', '));
  ok(await ctrl(page), 'S1c the page is controlled by the service worker after the first reload');
  await ctx.setOffline(true); await page.reload().catch(() => {}); await page.waitForTimeout(1500);
  const off = await page.evaluate(() => ({ app: (document.getElementById('app') || {}).childElementCount, build: window.__BUILD, text: document.body.innerText.length }));
  ok(off.app > 0 && off.build === 'N' && off.text > 50, 'S1d OFFLINE: the app opens and works from the cache', JSON.stringify(off));
  await page.evaluate(() => { const b = document.querySelector('[data-a="tab"][data-v="learn"]'); if (b) b.click(); }); await page.waitForTimeout(600);
  ok(await page.evaluate(() => !!document.querySelector('[data-a="node"]')) && errs.length === 0, 'S1e OFFLINE: the Learn screen with its lessons still renders, no JS errors', errs.join('|'));
  const r = await page.evaluate(async () => { try { const x = await fetch('/does-not-exist.js'); return x.status; } catch (e) { return 'network-error'; } });
  ok(r === 404 || r === 'network-error' || r === 200, 'S1f OFFLINE: a missing file fails cleanly (no hang): ' + r);
  await ctx.close();
}

// ---------------- S2 / S3: upgrade OLD -> NEW ----------------
async function upgrade(label, mode) {
  ROOT = deploy('old-' + label, OLD_SITE, 'O'); MODE = mode; const { ctx, page, errs } = await newPage();
  await install(ctx, page); const before = await cacheState(page);
  ok(before.keys.length === 1 && before.keys[0] === OLD_VER && (await page.evaluate(() => window.__BUILD)) === 'O', `${label} previous release installed (cache ${before.keys}), page runs build O`);
  // ---- the site owner deploys the new release ----
  ROOT = deploy('new-' + label, NEW_SITE, 'N'); hits.length = 0;
  await page.reload(); await page.waitForTimeout(500);
  const first = await page.evaluate(() => window.__BUILD);
  console.log(`INFO ${label}: first reload after the deployment runs build ${first} (O = previous release served from the cache while the update installs in the background)`);
  const switched = await poll(async () => { const k = (await cacheState(page)).keys; return k.length === 1 && k[0] === NEW_VER; }, 12000);
  ok(!!switched, `${label} the browser found the new service worker by itself and replaced cache ${OLD_VER} with ${NEW_VER}`, JSON.stringify((await cacheState(page)).keys));
  const after = await cacheState(page);
  ok(!after.keys.includes(OLD_VER), `${label}b the old cache ${OLD_VER} was deleted`, JSON.stringify(after.keys));
  const stale = SHELL.filter((u) => after.files[NEW_VER + '|' + u] !== sha(fs.readFileSync(path.join(ROOT, u))));
  ok(!stale.length, `${label}c every cached file is byte-identical to the NEW deployment (no stale CSS/JS)`, 'STALE in cache: ' + stale.join(', '));
  await page.reload(); await page.waitForTimeout(800);
  const run = await page.evaluate(() => ({ build: window.__BUILD, css: getComputedStyle(document.documentElement).getPropertyValue('--build-mark').trim().replace(/"/g, '') }));
  ok(run.build === 'N' && run.css === 'N', `${label}d after one more reload the page runs the new JS and the new CSS`, JSON.stringify(run));
  await ctx.setOffline(true); await page.reload().catch(() => {}); await page.waitForTimeout(1200);
  ok(await page.evaluate(() => window.__BUILD === 'N' && document.getElementById('app').childElementCount > 0), `${label}e offline after the upgrade still works, with the new build`);
  ok(errs.length === 0, `${label}f no JS errors during the upgrade`, errs.join('|'));
  await ctx.close();
}
if (!OLD_SITE) { blocked++; console.log('BLOCKED S2/S3 upgrade scenarios - give OLD_SITE=<previous release site folder>'); }
else { await upgrade('S2', 'revalidate'); await upgrade('S3', 'longcache'); }

// ---------------- S3b: a release that FORGETS to bump the cache name, on a host with a long max-age ----------------
// (same sw.js bytes, so the browser installs nothing; the files must still be refreshed by the service worker's own revalidation)
async function forgot(label, srcSite) {
  ROOT = deploy('f-old-' + label, srcSite, 'O'); MODE = 'longcache'; const { ctx, page, errs } = await newPage();
  await install(ctx, page);
  ok((await page.evaluate(() => window.__BUILD)) === 'O', `${label} release O installed`);
  ROOT = deploy('f-new-' + label, srcSite, 'N');
  // a "visit" = the person closes the app and opens it again: a NEW page in the same browser profile (same service worker, same HTTP cache, but no in-renderer memory cache)
  const visit = async (old) => { await old.close(); const p = await ctx.newPage(); p.on('pageerror', (e) => errs.push(e.message)); hits.length = 0; await p.goto(URL_); await p.waitForTimeout(1500); return p; };
  let pg = await visit(page);
  if (process.env.V) console.log('   requests seen by the server on visit 1:', hits.join(' '));
  const v1 = await pg.evaluate(() => window.__BUILD);
  pg = await visit(pg);
  const run = await pg.evaluate(() => ({ build: window.__BUILD, css: getComputedStyle(document.documentElement).getPropertyValue('--build-mark').trim().replace(/"/g, ''), visit1: undefined }));
  run.visit1 = v1;
  ok(run.build === 'N' && run.css === 'N', `${label} without a cache-name bump, on a long-max-age host, the new JS and CSS arrive by the second visit (visit 1 ran build ${v1})`, JSON.stringify(run));
  ok(errs.length === 0, `${label}b no JS errors`, errs.join('|')); await ctx.close();
}
await forgot('S3b', NEW_SITE);
if (OLD_SITE && process.env.SHOW_OLD_SW) await forgot('S3b-with-the-old-sw.js (expected to FAIL: demonstrates the 6.2 behaviour)', OLD_SITE);

// ---------------- S4: an update lands while a lesson is running ----------------
if (OLD_SITE) {
  ROOT = deploy('old-s4', OLD_SITE, 'O'); MODE = 'revalidate'; const { ctx, page, errs } = await newPage();
  await install(ctx, page);
  await page.evaluate(() => { localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 0, lang: 'en', course: 'en', level: 'beginner', theme: 'light', done: {} })); });
  await page.reload(); await page.waitForTimeout(1200);
  await page.evaluate(() => document.querySelector('[data-a="tab"][data-v="learn"]').click()); await page.waitForTimeout(300);
  await page.evaluate(() => document.querySelector('[data-a="node"]').click()); await page.waitForTimeout(800);
  const lessonId = await page.evaluate(() => __ee.L() && __ee.L().steps.length);
  ok(lessonId > 0 && await page.locator('button[data-a="quit"]').count() === 1, `S4 a lesson is running (${lessonId} steps) on the previous release`);
  const solve = async (n) => { for (let i = 0; i < n; i++) {
    const st = await page.evaluate(() => (__ee.L() && !__ee.L().end) ? { k: __ee.cur().k, ans: __ee.cur().ans, opts: __ee.cur().opts, words: __ee.cur().words, tiles: __ee.cur().tiles, pairs: (__ee.cur().pairs || []).length } : null); if (!st) return;
    const nx = page.locator('.lesson button[data-a="next"]:not([disabled])'); if (await nx.count()) { await nx.first().click(); await page.waitForTimeout(250); continue; }
    const fg = page.locator('.lesson button[data-a="fixgo"]'); if (await fg.count()) { await fg.first().click(); await page.waitForTimeout(250); continue; }
    if (st.k === 'match') { for (let j = 0; j < st.pairs; j++) { await page.locator(`button[data-a="mt"][data-i="${j}"]`).nth(0).click(); await page.locator(`button[data-a="mt"][data-i="${j}"]`).nth(1).click(); } await page.waitForTimeout(500); continue; }
    if (st.k === 'build') { const used = new Set(); for (const w of st.words) { const j = st.tiles.findIndex((x, q) => x === w && !used.has(q)); used.add(j); await page.locator(`button[data-a="tileAdd"][data-i="${j}"]`).click(); } }
    else if (st.opts && st.opts.length) await page.locator('.lesson button[data-a="opt"]').nth(st.opts.indexOf(st.ans)).click();
    else if (st.ans !== undefined) await page.locator('.lesson input:visible').first().fill(st.ans);
    else break;
    await page.locator('button[data-a="check"]:not([disabled])').click({ timeout: 2500 }).catch(() => {}); await page.waitForTimeout(450); } };
  await solve(6);
  const mid = await page.evaluate(() => ({ i: __ee.L().i, hearts: __ee.L().hearts, n: __ee.L().steps.length }));
  // the new release is deployed and the browser installs + ACTIVATES it (skipWaiting) while the lesson stays open
  ROOT = deploy('new-s4', NEW_SITE, 'N');
  await page.evaluate(async () => { const r = await navigator.serviceWorker.getRegistration(); await r.update(); });
  const sw = await poll(async () => { const k = (await cacheState(page)).keys; return k.length === 1 && k[0] === NEW_VER; }, 12000);
  ok(!!sw, 'S4b the new service worker installed and activated while the lesson was open (cache ' + NEW_VER + ')');
  const kept = await page.evaluate(() => ({ open: !!document.querySelector('.lesson [data-a="quit"]'), i: __ee.L() && __ee.L().i, build: window.__BUILD, steps: __ee.L() && __ee.L().steps.length }));
  ok(kept.open && kept.i === mid.i && kept.steps === mid.n, `S4c the running lesson is untouched by the activation (still open, still on step ${mid.i}, ${kept.steps} steps)`, JSON.stringify([mid, kept]));
  ok(kept.build === 'O', 'S4d the open page keeps running the code it started with (no forced reload in the middle of a lesson)', kept.build);
  await solve(80); await page.waitForTimeout(1200);
  const end = await page.evaluate(() => ({ end: !!(__ee.L() && __ee.L().end), xp: __ee.S().xp, done: Object.keys(__ee.S().done).length }));
  ok(end.end && end.xp > 0 && end.done === 1, 'S4e the lesson can be finished after the update and its XP / completion are saved', JSON.stringify(end));
  ok(errs.length === 0, 'S4f no JavaScript errors while the update arrived mid-lesson', errs.join('|'));
  await page.evaluate(() => { const b = document.querySelector('[data-a="exitLesson"]'); if (b) b.click(); }); await page.waitForTimeout(500);
  await page.reload(); await page.waitForTimeout(1000);
  ok(await page.evaluate(() => window.__BUILD === 'N' && Object.keys(__ee.S().done).length === 1), 'S4g after the lesson, the next reload runs the new build and the progress is still there');
  await ctx.close();
} else { blocked++; console.log('BLOCKED S4 update during a lesson - give OLD_SITE'); }

// ---------------- S5: headers shipped with the site ----------------
{
  const h = fs.readFileSync(path.join(NEW_SITE, '_headers'), 'utf8');
  const sec = (name) => { const m = h.match(new RegExp('^' + name.replace('/', '\\/') + '\\s*\\n((?:[ \\t]+.*\\n?)+)', 'm')); return m ? m[1] : ''; };
  for (const f of ['/sw.js', '/config.js', '/theme-boot.js']) ok(/no-cache/.test(sec(f)), `S5 _headers: ${f} is served with Cache-Control: no-cache`, 'section: ' + JSON.stringify(sec(f)));
  ok(!/\/app\.js|\/styles\.css/.test(h), 'S5b _headers: app.js / styles.css are NOT given a long max-age (the host default or the service worker revalidation decides)');
}
await browser.close(); srv.close(); fs.rmSync(TMP, { recursive: true, force: true });
console.log(bad ? `\n${bad} FAILED` : blocked ? `\nall executed checks passed, ${blocked} scenario group(s) BLOCKED` : '\nall passed'); process.exit(bad ? 1 : blocked ? 2 : 0);
