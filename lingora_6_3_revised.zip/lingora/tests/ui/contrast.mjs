// Contrast audit in a real Chromium: every visible text element, light + dark theme, phone + desktop, local (no-backend) mode.
// Usage: node tests/ui/contrast.mjs   (needs playwright + chromium; PW_MODULE / CHROME env override paths)
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname);
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome', args: ['--no-sandbox'] });
const probe = () => {
  const parse = (c) => { const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(/[ ,\/]+/).filter(Boolean).map(Number); return { r: p[0], g: p[1], b: p[2], a: p[3] == null ? 1 : p[3] }; };
  const lum = ({ r, g, b }) => { const f = (v) => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(r) + .7152 * f(g) + .0722 * f(b); };
  const over = (top, bot) => { const a = top.a + bot.a * (1 - top.a); return a === 0 ? { r: 0, g: 0, b: 0, a: 0 } : { r: (top.r * top.a + bot.r * bot.a * (1 - top.a)) / a, g: (top.g * top.a + bot.g * bot.a * (1 - top.a)) / a, b: (top.b * top.a + bot.b * bot.a * (1 - top.a)) / a, a }; };
  const out = []; let skipped = 0;
  for (const el of document.querySelectorAll('body *')) {
    if (!el.offsetParent && getComputedStyle(el).position !== 'fixed') continue;
    const own = [...el.childNodes].filter((n) => n.nodeType === 3 && n.textContent.trim()).map((n) => n.textContent.trim()).join(' ');
    if (!own) continue;
    const rect = el.getBoundingClientRect(); if (rect.width < 2 || rect.height < 2) continue;
    if (el.closest(':disabled,[aria-disabled="true"]')) continue; /* disabled controls are exempt (WCAG 1.4.3) */
    const cs = getComputedStyle(el); if (cs.visibility === 'hidden' || +cs.opacity === 0) continue;
    let bg = { r: 0, g: 0, b: 0, a: 0 }, unknown = false, chain = [];
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) { const s = getComputedStyle(n); if (s.backgroundImage !== 'none') { unknown = true; } const c = parse(s.backgroundColor); if (c && c.a > 0 && !unknown) { bg = over(bg, c); chain.push(c); } }
    if (unknown) { skipped++; continue; } /* text over a gradient/image: cannot be computed, checked by eye */
    if (bg.a < .999) bg = over(bg, { r: 255, g: 255, b: 255, a: 1 });
    let fg = parse(cs.color); fg = over({ ...fg, a: fg.a * (+cs.opacity || 1) }, bg);
    const L1 = lum(fg), L2 = lum(bg), ratio = (Math.max(L1, L2) + .05) / (Math.min(L1, L2) + .05);
    const size = parseFloat(cs.fontSize), bold = +cs.fontWeight >= 700, large = size >= 24 || (size >= 18.66 && bold);
    if (ratio < (large ? 3 : 4.5)) out.push({ sel: (el.parentElement ? el.parentElement.tagName.toLowerCase() + (typeof el.parentElement.className === 'string' && el.parentElement.className ? '.' + el.parentElement.className.trim().split(/\s+/)[0] : '') + ' > ' : '') + el.tagName.toLowerCase() + (el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).join('.') : ''), text: own.slice(0, 30), ratio: +ratio.toFixed(2), unknown, fg: cs.color, bg: `rgb(${bg.r | 0},${bg.g | 0},${bg.b | 0})` });
  }
  return out;
};
const all = new Map(); let pages = 0;
for (const theme of ['light', 'dark']) for (const vp of [{ width: 390, height: 844 }, { width: 1200, height: 800 }]) {
  const ctx = await browser.newContext({ viewport: vp }); const page = await ctx.newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  await page.addInitScript((th) => { try { localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 120, streak: 3, theme: th, lang: 'en', course: 'en', level: 'beginner', done: {}, uid: '' })); localStorage.setItem('lingora.theme', th); } catch (e) {} }, theme);
  await page.goto(`http://127.0.0.1:${port}/index.html`); await page.waitForTimeout(1200);
  await page.evaluate((th) => { document.documentElement.dataset.theme = th; }, theme);
  const tabs = await page.$$eval('[data-a="tab"]', (b) => [...new Set(b.map((x) => x.dataset.v))]);
  for (const t of ['home', ...tabs]) {
    await page.evaluate((v) => { const b = document.querySelector(`[data-a="tab"][data-v="${v}"]`); if (b) b.click(); }, t); await page.waitForTimeout(500);
    await page.evaluate((th) => { document.documentElement.dataset.theme = th; }, theme);
    for (const r of await page.evaluate(probe)) { const k = `${r.sel}|${r.text}`; const v = all.get(k) || { ...r, where: new Set() }; v.where.add(`${theme}/${vp.width}/${t}`); all.set(k, v); }
    pages++;
  }
  if (errs.length) console.log('PAGE ERRORS', theme, vp.width, errs.slice(0, 3));
  await ctx.close();
}
await browser.close(); srv.close();
const rows = [...all.values()].sort((a, b) => a.ratio - b.ratio);
console.log(`audited ${pages} screens; ${rows.length} distinct low-contrast text elements`);
for (const r of rows.slice(0, 60)) console.log(r.ratio, r.sel.slice(0, 50), JSON.stringify(r.text), r.fg, 'on', r.bg, r.unknown ? '(gradient)' : '', [...r.where].slice(0, 3).join(','));
process.exit(rows.some((r) => !r.unknown) ? 1 : 0);
