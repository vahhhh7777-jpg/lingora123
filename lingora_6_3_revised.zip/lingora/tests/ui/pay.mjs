// Online-payment UI: hidden unless ONLINE_PAYMENTS is true; buttons come from vip_plans; only a plan id is sent; the redirect
// target must be a checkout.stripe.com URL; failures are shown. Uses the in-memory Supabase stand-in. Real Stripe is NOT contacted.
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname);
const STUB = fs.readFileSync(new URL('./supabase-memstub.js', import.meta.url), 'utf8');
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined, args: ['--no-sandbox'] });
let pass = 0, fail = 0; const check = (n, c, x = '') => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : '  ' + x)); };
async function run(online, checkout) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } }); const page = await ctx.newPage(); const errs = []; page.on('pageerror', (e) => errs.push(e.message)); page.invoked = []; page.on('console', (m) => { if (m.text().startsWith('INVOKE ')) page.invoked.push(JSON.parse(m.text().slice(7))); });
  await page.route(/fonts\.(googleapis|gstatic)/, (r) => r.abort());
  await page.route('**/checkout.stripe.com/**', (r) => r.fulfill({ contentType: 'text/html', body: 'stripe' }));
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: `window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon",ONLINE_PAYMENTS:${online},PRICE_TEXT:{en:"Message us"}};` }));
  await page.addInitScript((c) => { sessionStorage.setItem('__plans', JSON.stringify([{ id: 'month', title: { en: '1 month' }, days: 30, price_cents: 499, currency: 'usd', provider_price: 'price_1' }]));
    if (!localStorage.getItem('lingora.v1')) localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 0, lang: 'en', course: 'en', level: 'beginner', theme: 'light', done: {} }));
    const iv = setInterval(() => { if (window.__sb) { window.__sb.checkout = c; clearInterval(iv); } }, 1); }, checkout);
  await page.goto(`http://127.0.0.1:${port}/index.html`); await page.waitForTimeout(1200);
  await page.evaluate(() => { const b = document.querySelector('[data-a="tab"][data-v="shop"]'); if (b) b.click(); }); await page.waitForTimeout(1200);
  return { page, errs };
}
let { page, errs } = await run(false, null);
check('flag off: no online buy buttons (manual payment text only)', (await page.$$('[data-a="buyvip"]')).length === 0);
await page.context().close();
({ page, errs } = await run(true, { data: { url: 'https://checkout.stripe.com/c/pay/cs_test' }, error: null }));
check('flag on: plan button rendered from vip_plans with the price', /1 month · 4\.99 USD/.test(await page.evaluate(() => (document.querySelector('[data-a="buyvip"]') || {}).innerText || '')));
await page.evaluate(() => document.querySelector('[data-a="buyvip"]').click()); await page.waitForTimeout(900);
const inv = page.invoked;
check('only the plan id is sent to create-checkout', inv && inv.length === 1 && inv[0].name === 'create-checkout' && JSON.stringify(inv[0].body) === '{"plan":"month"}', JSON.stringify(inv));
check('browser is redirected to the Stripe checkout URL', /checkout\.stripe\.com/.test(page.url()), page.url());
await page.context().close();
({ page, errs } = await run(true, { data: { url: 'https://evil.example/x' }, error: null }));
await page.evaluate(() => document.querySelector('[data-a="buyvip"]').click()); await page.waitForTimeout(900);
check('a non-Stripe URL from the server is never followed', /127\.0\.0\.1/.test(page.url()));
check('the failure is shown to the user and the button is usable again', /Could not start the payment/.test(await page.evaluate(() => document.body.innerText)) && await page.evaluate(() => !document.querySelector('[data-a="buyvip"]').disabled));
await page.context().close();
({ page, errs } = await run(true, { data: null, error: { message: 'not deployed' } }));
await page.evaluate(() => document.querySelector('[data-a="buyvip"]').click()); await page.waitForTimeout(900);
check('function not deployed: clear error, no crash', /Could not start the payment/.test(await page.evaluate(() => document.body.innerText)) && errs.length === 0, errs.join('|'));
console.log(`\n${pass} passed, ${fail} failed`); await browser.close(); srv.close(); process.exit(fail ? 1 : 0);
