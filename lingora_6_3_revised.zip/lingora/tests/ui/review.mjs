// Lingora 6.0: no Review section; review mixed into lessons; nav.  (was: Lesson completion screen) (local mode, real Chromium, real site/app.js). Cloud-economy paths need the PostgreSQL bridge (tests/e2e) and are NOT covered here.
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname);
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome', args: ['--no-sandbox'] });
let pass = 0, fail = 0; const check = (n, c, x = '') => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : '  ' + x)); };
async function fresh(o = {}) {
  const ctx = await browser.newContext({ viewport: o.vp || { width: 390, height: 844 }, reducedMotion: o.rm ? 'reduce' : 'no-preference' }); const page = await ctx.newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push(e.message)); page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource|ERR_/.test(m.text())) errs.push(m.text()); });
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={TEST_HOOK:true};' }));
  await page.addInitScript((o) => { if (!localStorage.getItem('lingora.v1')) localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 0, lang: o.lang || 'en', course: 'en', level: 'beginner', theme: 'light', done: {} })); }, o);
  await page.goto(`http://127.0.0.1:${port}/index.html`); await page.waitForTimeout(1200);
  return { ctx, page, errs };
}
const st = (page) => page.evaluate(() => ({ x: __ee.S().xp, done: JSON.stringify(__ee.S().done), log: (__ee.S().log || []).length }));
/* play the open lesson; wrongN = how many first-time questions to answer wrongly */
async function play(page, wrongN = 0) {
  let wrong = 0;
  for (let k = 0; k < 120; k++) {
    const s = await page.evaluate(() => { const L = __ee.L(); if (!L || L.end) return null; const c = __ee.cur(); return { k: c.k, ans: c.ans, opts: c.opts, pairs: c.pairs, left: c.left, right: c.right, sent: c.sent }; });
    if (!s) break;
    const nx = page.locator('.lesson button[data-a="next"]:not([disabled])'); if (await nx.count()) { await nx.first().click(); continue; }
    const fg = page.locator('.lesson button[data-a="fixgo"]'); if (await fg.count()) { await fg.first().click(); continue; }
    if (s.k === 'match') { await page.evaluate(() => { const c = __ee.cur(); c.pairs.forEach((p) => { document.querySelector(`[data-a="mt"][data-s="l"][data-i="${p.id}"]`).click(); document.querySelector(`[data-a="mt"][data-s="r"][data-i="${p.id}"]`).click(); }); }); await page.waitForTimeout(100); continue; }
    const w = wrong < wrongN; if (w) wrong++;
    if (s.opts && s.opts.length) { let i = s.opts.indexOf(s.ans); if (w) i = i === 0 ? 1 : 0; await page.locator('.lesson button[data-a="opt"]').nth(i).click(); }
    else if (['type', 'listen_type', 'write'].includes(s.k)) await page.locator('.lesson input:visible, .lesson textarea:visible').first().fill(w ? 'zzzz' : s.ans);
    else if (s.k === 'build') { const toks = await page.evaluate(() => { const c = __ee.cur(); return c.words; }); for (const wd of (w ? [] : toks)) { await page.evaluate((wd) => { const c = __ee.cur(); const L = __ee.L(); const i = c.tiles.findIndex((t, j) => t === wd && !L.ans.includes(j)); document.querySelector(`[data-a="tileAdd"][data-i="${i}"]`).click(); }, wd); } if (w) await page.evaluate(() => document.querySelector('[data-a="tileAdd"]').click()); }
    else { console.log('   unsolved', s.k); break; }
    await page.locator('button[data-a="check"]:not([disabled])').click({ timeout: 3000 }).catch(() => {});
  }
  await page.waitForTimeout(500);
}
const open = async (page, i) => { await page.evaluate(() => document.querySelector('[data-a="tab"][data-v="learn"]').click()); await page.waitForTimeout(300); await page.evaluate((i) => document.querySelector(`[data-a="node"][data-i="${i}"]`).click(), i); await page.waitForTimeout(500); };
const noOverflow = (page) => page.evaluate(() => { const b = document.querySelector('.lesson .l-body'); return b.scrollWidth <= b.clientWidth + 1 && document.documentElement.scrollWidth <= innerWidth + 1; });

/* ---- navigation ---- */
{
  const { ctx, page, errs } = await fresh();
  const nav = await page.evaluate(() => [...document.querySelectorAll('.nav [data-nav]')].map((b) => b.dataset.nav));
  check('R1 bottom nav = home, learn, stories, ai, me', JSON.stringify(nav) === JSON.stringify(['home', 'learn', 'stories', 'ai', 'me']), JSON.stringify(nav));
  check('R2 no Review / Repetition entry anywhere in the shell', await page.evaluate(() => !document.querySelector('[data-v="practice"],[data-px="rvgo"],.hm-rv,.rv-hero')));
  for (const v of nav) { await page.evaluate((v) => document.querySelector(`.nav [data-nav="${v}"]`).click(), v); await page.waitForTimeout(250);
    check('R3 nav ' + v + ' renders', await page.evaluate((v) => location.hash === '#/' + v && !!document.querySelector('main') && !document.querySelector('.card[role=alert]'), v)); }
  await page.evaluate(() => { location.hash = '#/practice'; }); await page.waitForTimeout(300);
  check('R4 old #/practice link lands on Learn', await page.evaluate(() => location.hash === '#/learn' && !!document.querySelector('.lt')));
  await page.evaluate(() => document.querySelector('.nav [data-nav="learn"]').click()); await page.waitForTimeout(200);
  await page.evaluate(() => document.querySelector('[data-px="place"]').click()); await page.waitForTimeout(300);
  check('R5 placement test opens inside Learn, back returns', await page.evaluate(() => { const b = document.querySelector('.px-back'); if (!b) return false; b.click(); return true; }));
  await page.waitForTimeout(300);
  check('R5b back shows Learn path again', await page.evaluate(() => !!document.querySelector('.lt') && !!document.querySelector('.path')));
  check('R6 no JS errors (nav)', errs.length === 0, errs.join('|'));
  await ctx.close();
}
/* ---- review inside lessons ---- */
{
  const { ctx, page, errs } = await fresh();
  await open(page, 0);
  check('R7 first lesson has no review steps (nothing learned yet)', await page.evaluate(() => !__ee.L().steps.some((s) => s.review)));
  await play(page, 0);
  await page.evaluate(() => document.querySelector('[data-a="exitLesson"],[data-a="dcPath"]').click()).catch(() => {}); await page.waitForTimeout(300);
  await page.evaluate(() => { const l = document.getElementById('lesson'); if (l && !l.hidden) { document.querySelector('[data-a="exitLesson"]') && document.querySelector('[data-a="exitLesson"]').click(); } });
  await page.waitForTimeout(300);
  await open(page, 1);
  const info = await page.evaluate(() => { const L = __ee.L(); const r = L.steps.filter((s) => s.review); return { n: r.length, total: L.steps.length, base: L.base, loc: r.every((s) => s.loc), first: L.steps.findIndex((s) => s.review), intro: L.steps.filter((s) => s.k === 'intro').length }; });
  check('R8 lesson 2 mixes in 1-4 review steps from lesson 1', info.n >= 1 && info.n <= 4, JSON.stringify(info));
  check('R9 review steps are judged locally and sit after the intro steps', info.loc && info.first >= info.intro, JSON.stringify(info));
  const before = await page.evaluate(() => ({ keys: Object.keys(__ee.S().srs).length }));
  /* answer every review step WRONG, everything else right: stars must stay 3 and hearts untouched */
  let guard = 0;
  while (guard++ < 150) {
    const s = await page.evaluate(() => { const L = __ee.L(); if (!L || L.end) return null; const c = __ee.cur(); return { k: c.k, ans: c.ans, opts: c.opts, review: !!c.review }; });
    if (!s) break;
    const nx = page.locator('.lesson button[data-a="next"]:not([disabled])'); if (await nx.count()) { await nx.first().click(); continue; }
    if (s.opts && s.opts.length) { let i = s.opts.indexOf(s.ans); if (s.review) i = i === 0 ? 1 : 0; await page.locator('.lesson button[data-a="opt"]').nth(i).click(); }
    else if (['type', 'listen_type', 'write'].includes(s.k)) await page.locator('.lesson input:visible, .lesson textarea:visible').first().fill(s.review ? 'zzzz' : s.ans);
    else if (s.k === 'match') { await page.evaluate(() => { const c = __ee.cur(); c.pairs.forEach((p) => { document.querySelector(`[data-a="mt"][data-s="l"][data-i="${p.id}"]`).click(); document.querySelector(`[data-a="mt"][data-s="r"][data-i="${p.id}"]`).click(); }); }); await page.waitForTimeout(100); continue; }
    else break;
    await page.locator('button[data-a="check"]:not([disabled])').click({ timeout: 3000 }).catch(() => {});
  }
  await page.waitForTimeout(500);
  const end = await page.evaluate(() => { const L = __ee.L(); return L ? { end: L.end, stars: L.stars, hearts: L.hearts, acc: L.acc, rvm: L.rvm ? L.rvm.log.length : 0, bad: L.rvm ? L.rvm.log.filter((x) => !x.ok).length : 0, sum: !!document.querySelector('.rm-sum') } : null; });
  check('R10 wrong review answers do not cost hearts / stars', end && end.end === 'done' && end.stars === 3 && end.hearts === 5 && end.acc === 100, JSON.stringify(end));
  check('R11 summary section lists the reinforced items', end && end.sum && end.rvm === info.n && end.bad === info.n, JSON.stringify(end));
  check('R12 spaced repetition boxes were updated by review answers', await page.evaluate((b) => Object.keys(__ee.S().srs).length >= b, before.keys));
  check('R13 no JS errors (lessons)', errs.length === 0, errs.join('|'));
  await ctx.close();
}
console.log(`\n${pass} passed, ${fail} failed`); await browser.close(); srv.close(); process.exit(fail ? 1 : 0);
