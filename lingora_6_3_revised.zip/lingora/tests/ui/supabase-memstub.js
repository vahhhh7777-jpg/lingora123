// TEST-ONLY in-memory stand-in for @supabase/supabase-js (no network, no PostgreSQL). Controlled through window.__sb.
(function () {
  const sb = window.__sb = { failProgress: sessionStorage.getItem('__fail') ? -1 : 0, failMode: 'error', progress: null, saves: [], loads: 0, user: { id: 'u1', email: 't@example.com', user_metadata: {} } };
  sb.rpcs = []; sb.failReset = !!sessionStorage.getItem('__failreset'); sb.econ = null; sb.serverResets = 0;
  try { const srv = JSON.parse(sessionStorage.getItem('__srv') || 'null'); if (srv) { sb.progress = srv.p; sb.econ = srv.e; } } catch (e) {}
  const admin = !!sessionStorage.getItem('__admin');
  const vipx = JSON.parse(sessionStorage.getItem('__vip') || '{}');
  const profile = { id: 'u1', name: 'Tester', username: 'tester', is_admin: admin, role: admin ? 'super_admin' : 'user', vip_until: vipx.until || null, vip_from: vipx.from || null, suspended: false, avatar: null };
  const ok = (data) => ({ data, error: null });
  function builder(table) {
    const st = { op: 'select', body: null, single: false };
    const run = async () => {
      if (table === 'progress') {
        if (st.op === 'upsert') {
          if (sb.failProgress !== 0) { if (sb.failProgress > 0) sb.failProgress--; sb.saves.push({ ok: false }); if (sb.failMode === 'throw') throw new TypeError('Failed to fetch'); return { data: null, error: { message: sb.failMode === 'denied' ? 'permission denied for table progress' : 'Failed to fetch', code: sb.failMode === 'denied' ? '42501' : undefined, status: sb.failMode === 'denied' ? 403 : 0 } }; }
          sb.progress = JSON.parse(JSON.stringify(st.body.data)); sb.saves.push({ ok: true, xp: sb.progress.xp }); return ok(null);
        }
        sb.loads++; if (st.single) return ok(sb.progress ? { data: sb.progress } : null); return ok(sb.progress ? [{ user_id: 'u1', data: sb.progress }] : []);
      }
      if (table === 'profiles') { if (sb.profileFail) return { data: null, error: { message: 'Failed to fetch' } }; return ok(st.single ? profile : [profile]); }
      if (table === 'vip_plans') return ok(JSON.parse(sessionStorage.getItem('__plans') || '[]'));
      if (table === 'media_assets' && st.op === 'select') return ok([{ id: 'm1', kind: 'image', url: 'https://cdn.example.invalid/media/a-test.png', path: 'image/a-test.png', mime: 'image/png', bytes: 100, created_at: new Date().toISOString() }]);
      if (table === 'media_assets' && st.op === 'insert') return ok(null);
      return ok(st.single ? null : []);
    };
    const b = new Proxy({}, { get(_, k) {
      if (k === 'then') return (res, rej) => run().then(res, rej);
      if (k === 'upsert' || k === 'insert' || k === 'update') return (body) => { st.op = k; st.body = body; return b; };
      if (k === 'delete') return () => { st.op = 'delete'; return b; };
      if (k === 'single' || k === 'maybeSingle') return () => { st.single = true; return b; };
      return () => b;
    } });
    return b;
  }
  const session = () => ({ access_token: 'tok', refresh_token: 'r', expires_at: Math.floor(Date.now() / 1000) + 3600, user: sb.user });
  const listeners = [];
  window.supabase = { createClient() { return {
    auth: {
      async getSession() { return ok({ session: sb.signedOut ? null : session() }); },
      async getUser() { return ok({ user: sb.user }); },
      onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
      async signInWithPassword() { if (sb.signInError) return { data: { user: null, session: null }, error: { message: sb.signInError } }; sb.signedOut = false; return ok({ user: sb.user, session: session() }); },
      async signOut() { if (sb.signOutError) return { error: { message: sb.signOutError } }; sb.signedOut = true; return { error: null }; },
    },
    from: builder,
    rpc: async (name) => {
      sb.rpcs.push(name);
      if (name === 'reset_my_progress') { if (sb.failReset) { if (sb.failMode === 'throw') throw new TypeError('Failed to fetch'); return { data: null, error: { message: 'Failed to fetch' } }; } sb.progress = {}; sb.econ = null; sb.serverResets++; return ok(null); }
      if (sb.failRpc && sb.failRpc === name) return { data: null, error: { message: 'Failed to fetch' } };
      if (name === 'get_my_state') return ok(sb.econ);
      if (name === 'admin_stats' && sb.statsMode === 'error') return { data: null, error: { message: 'permission denied' } };
      return ok(null);
    },
    functions: { invoke: async (name, o) => { sb.invoked = sb.invoked || []; sb.invoked.push({ name, body: o && o.body }); console.log('INVOKE ' + JSON.stringify({ name, body: o && o.body })); return sb.checkout || { data: null, error: { message: 'not deployed' } }; } },
    storage: { from: () => ({ upload: async () => ok({ path: 'p' }), getPublicUrl: (p) => ({ data: { publicUrl: 'https://cdn.example.invalid/media/' + p } }), remove: async () => ok(null) }) },
  }; } };
})();
