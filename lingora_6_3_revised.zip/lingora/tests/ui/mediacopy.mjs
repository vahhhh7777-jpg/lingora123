// Real-browser test of the two admin "copy media URL" buttons: Clipboard API granted, refused (fallback + feedback), phone viewport.
import { createRequire } from 'node:module';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const ROOT = path.resolve(new URL('../../site', import.meta.url).pathname);
const STUB = fs.readFileSync(new URL('./supabase-memstub.js', import.meta.url), 'utf8');
const srv = http.createServer((q, r) => { let f = path.join(ROOT, q.url.split('?')[0].replace(/\/$/, '/index.html')); if (!fs.existsSync(f)) { r.statusCode = 404; return r.end(); }
  r.setHeader('content-type', { '.js': 'text/javascript', '.css': 'text/css', '.html': 'text/html' }[path.extname(f)] || 'application/octet-stream'); r.end(fs.readFileSync(f)); }).listen(0);
const port = srv.address().port;
const browser = await chromium.launch({ executablePath: process.env.CHROME || '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome', args: ['--no-sandbox'] });
let pass = 0, fail = 0; const check = (n, c, x = '') => { c ? pass++ : fail++; console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : '  ' + x)); };
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
async function session(grant, viewport, touch) {
  const ctx = await browser.newContext({ viewport, hasTouch: touch, isMobile: touch, permissions: grant ? ['clipboard-read', 'clipboard-write'] : [] });
  const page = await ctx.newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: STUB }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: 'window.EE_CONFIG={SUPABASE_URL:"http://stub.invalid",SUPABASE_ANON_KEY:"anon"};' }));
  await page.addInitScript(() => { sessionStorage.setItem('__admin', '1'); if (!localStorage.getItem('lingora.v1')) localStorage.setItem('lingora.v1', JSON.stringify({ v: 1, onb: true, xp: 0, lang: 'en', course: 'en', level: 'beginner', theme: 'light', done: {} })); });
  await page.goto(`http://127.0.0.1:${port}/index.html`); await page.waitForTimeout(1500);
  await page.evaluate(() => document.querySelector('[data-a="tab"][data-v="admin"]').click()); await page.waitForTimeout(500);
  await page.evaluate(() => { const b = document.querySelector('[data-a="asub"][data-v="content"]'); if (b) b.click(); }); await page.waitForTimeout(300);
  const sec = await page.evaluate(() => [...document.querySelectorAll('[data-a]')].filter((b) => /sec|nav/.test(b.dataset.a)).map((b) => b.dataset.a + ':' + b.dataset.v).join(' '));
  return { ctx, page, errs, sec };
}
const toast = (page) => page.evaluate(() => document.getElementById('toast').innerText.trim());
async function openMedia(page) {
  // find the control that opens the media section
  const ok = await page.evaluate(() => { const c = [...document.querySelectorAll('[data-a]')].find((b) => b.dataset.v === 'media' || b.dataset.k === 'media' || b.dataset.id === 'media'); if (c) { c.click(); return c.dataset.a; } return ''; });
  await page.waitForTimeout(700); return ok;
}
for (const [label, vp, touch] of [['desktop', { width: 1200, height: 800 }, false], ['phone', { width: 390, height: 844 }, true]]) {
  // --- A. clipboard permitted
  let s = await session(true, vp, touch); const p = s.page;
  const via = await openMedia(p);
  check(`${label}: admin Media section opens (via ${via || 'none'})`, !!via, s.sec);
  const has = await p.evaluate(() => !!document.querySelector('[data-a="mediacopy"]'));
  check(`${label}: library item has a Copy URL button`, has);
  if (has) {
    const box = await p.evaluate(() => { const r = document.querySelector('[data-a="mediacopy"]').getBoundingClientRect(); return { w: r.width, h: r.height }; });
    check(`${label}: button is a usable tap target (>=32px)`, box.h >= 32 && box.w >= 32, JSON.stringify(box));
    await p.evaluate(() => document.querySelector('[data-a="mediacopy"]').click()); await p.waitForTimeout(400);
    const clip = await p.evaluate(() => navigator.clipboard.readText());
    check(`${label}: exact URL is in the clipboard`, clip === 'https://cdn.example.invalid/media/a-test.png', clip);
    check(`${label}: success feedback shown`, /copied/i.test(await toast(p)), await toast(p));
  }
  // upload path (mcopy)
  const inp = await p.$('#mup');
  if (inp) {
    await inp.setInputFiles({ name: 't.png', mimeType: 'image/png', buffer: PNG }); await p.waitForTimeout(1200);
    const mc = await p.evaluate(() => !!document.querySelector('[data-a="mcopy"]'));
    check(`${label}: uploaded image shows its URL with a Copy button`, mc);
    if (mc) { await p.evaluate(() => document.querySelector('[data-a="mcopy"]').click()); await p.waitForTimeout(400);
      const clip = await p.evaluate(() => navigator.clipboard.readText());
      check(`${label}: uploaded URL copied exactly`, /^https:\/\/cdn\.example\.invalid\/media\/image\/.+\.(png|jpg|webp)$/.test(clip), clip);
      check(`${label}: upload copy feedback`, /copied/i.test(await toast(p)), await toast(p)); }
  } else check(`${label}: upload field present`, false);
  check(`${label}: no JS errors (clipboard granted)`, s.errs.length === 0, s.errs.join('|')); await s.ctx.close();
  // --- B. clipboard refused everywhere: must say so, must not claim success, must select the text
  s = await session(false, vp, touch); const q = s.page;
  await openMedia(q);
  await q.evaluate(() => { Object.defineProperty(navigator, 'clipboard', { value: { writeText: () => Promise.reject(new DOMException('denied', 'NotAllowedError')) }, configurable: true }); document.execCommand = () => false; });
  const u2 = await q.$('#mup');
  if (u2) { await u2.setInputFiles({ name: 't.png', mimeType: 'image/png', buffer: PNG }); await q.waitForTimeout(1200); }
  for (const sel of ['[data-a="mediacopy"]', '[data-a="mcopy"]']) {
    const e = await q.evaluate((x) => !!document.querySelector(x), sel); if (!e) { check(`${label}: ${sel} present for refusal test`, false); continue; }
    await q.evaluate((x) => document.querySelector(x).click(), sel); await q.waitForTimeout(400);
    const tt = await toast(q);
    check(`${label}: ${sel} refused clipboard -> failure message, not success`, /could not copy/i.test(tt) && !/URL copied/i.test(tt), tt);
  }
  const selTxt = await q.evaluate(() => { const i = document.activeElement; return i && i.tagName === 'INPUT' ? i.value.slice(i.selectionStart, i.selectionEnd) : ''; });
  check(`${label}: URL field is selected so it can be copied by hand`, /^https:\/\/cdn\.example\.invalid\//.test(selTxt) || selTxt.length > 10, selTxt);
  check(`${label}: no unhandled errors when clipboard is refused`, s.errs.length === 0, s.errs.join('|')); await s.ctx.close();
}
console.log(`\n${pass} passed, ${fail} failed`); await browser.close(); srv.close(); process.exit(fail ? 1 : 0);
