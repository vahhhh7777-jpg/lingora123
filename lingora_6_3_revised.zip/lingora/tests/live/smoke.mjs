// Lingora protocol-level integration test. Uses ONLY fetch, so it can run against a REAL Supabase project or the local stand-in.
//   SUPABASE_URL=https://xxxx.supabase.co SUPABASE_ANON_KEY=eyJ... node tests/live/smoke.mjs
// Optional:  ADMIN_EMAIL / ADMIN_PASSWORD   an existing admin account (enables the admin checks)
//            SMOKE_EMAIL / SMOKE_PASSWORD   an existing CONFIRMED learner (use when the project requires e-mail confirmation)
//            LESSON_ID                      a published lesson to play (default: first published lesson found)
//            EXPECT_AI=1                    require the ai-coach function to answer (needs ANTHROPIC_API_KEY set in Supabase secrets)
//            SMOKE_KEEP=1                   do not delete the test account at the end
//            SITE_URL=https://your-site    the deployed STATIC site: enables the startup checks (assets, content types, security headers, config.js, service worker)
//            (6.3) checks 12-17 cover course data, shop, friends, rank, error handling and extra admin restrictions; the browser walk-through is tests/live/smoke_browser.mjs
// Exit code 0 = every check passed, 1 = a check failed, 2 = blocked by missing setup (nothing was claimed as tested).
const URL_ = (process.env.SUPABASE_URL || '').replace(/\/$/, ''), ANON = process.env.SUPABASE_ANON_KEY || '';
if (!URL_ || !ANON) { console.error('BLOCKED: set SUPABASE_URL and SUPABASE_ANON_KEY'); process.exit(2); }
let failed = 0, blocked = 0; const results = [];
const pass = (n) => { results.push(['PASS', n]); console.log('PASS', n); };
const fail = (n, why) => { failed++; results.push(['FAIL', n, why]); console.log('FAIL', n, '-', why); };
const block = (n, why) => { blocked++; results.push(['BLOCKED', n, why]); console.log('BLOCKED', n, '-', why); };
const check = (c, n, why) => (c ? pass(n) : fail(n, why || 'condition false'));
const hdr = (tok) => ({ apikey: ANON, Authorization: 'Bearer ' + (tok || ANON), 'Content-Type': 'application/json' });
async function call(method, p, tok, body, extra) {
  const r = await fetch(URL_ + p, { method, headers: { ...hdr(tok), ...(extra || {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
  const t = await r.text(); let j = null; try { j = t ? JSON.parse(t) : null; } catch { j = t; }
  return { status: r.status, ok: r.ok, j };
}
const rpc = (fn, args, tok) => call('POST', '/rest/v1/rpc/' + fn, tok, args || {});
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const login = async (email, pw) => { const r = await call('POST', '/auth/v1/token?grant_type=password', null, { email, password: pw }); return r.ok ? r.j : null; };

function answerFor(q) {            // builds the answer a learner would give, from the question the server will check against
  const d = q.data || {};
  switch (q.type) {
    case 'mc': case 'image': case 'listen': case 'read': case 'fill': case 'pics': case 'tf': return { choice: d.answer };
    case 'type': case 'fix': case 'listen_type': case 'write': return { text: d.answer || d.text || (d.keywords || []).join(' ') };
    case 'order': return { tokens: String(d.sentence || '').replace(/[?.!,։]/g, '').split(' ').filter(Boolean) };
    case 'match': return { pairs: d.pairs };
    default: return null;            // intro / speak: nothing to submit
  }
}

(async () => {
  const stamp = Date.now(), email = process.env.SMOKE_EMAIL || `lingora-smoke+${stamp}@example.com`, pw = process.env.SMOKE_PASSWORD || 'Smoke-' + stamp + '-pw';

  // 0. startup: the deployed static site (only when SITE_URL is given; otherwise this is reported BLOCKED, never assumed)
  if (!process.env.SITE_URL) block('0 startup', 'set SITE_URL to the deployed site (for example https://your-site.netlify.app) to check the assets, headers, config.js and service worker');
  else {
    const SITE = process.env.SITE_URL.replace(/\/$/, ''); const get = async (p) => { try { const r = await fetch(SITE + p, { redirect: 'follow' }); return { status: r.status, h: r.headers, t: await r.text() }; } catch (e) { return { status: 0, h: new Headers(), t: String(e.message) }; } };
    const idx = await get('/'); check(idx.status === 200 && /<title>/i.test(idx.t), '0 startup: the home page loads (HTTP ' + idx.status + ')', idx.t.slice(0, 100));
    for (const [pth, ct] of [['/app.js', /javascript/], ['/styles.css', /css/], ['/config.js', /javascript/], ['/sw.js', /javascript/], ['/manifest.webmanifest', /json|manifest/], ['/icon-192.png', /png/]]) {
      const r = await get(pth); check(r.status === 200 && ct.test(r.h.get('content-type') || ''), `0b startup: ${pth} is served (HTTP ${r.status}, ${r.h.get('content-type')})`);
    }
    const sw = await get('/sw.js'); check(/no-cache|no-store|max-age=0/i.test(sw.h.get('cache-control') || ''), '0c sw.js is not cached by the browser/CDN (otherwise installed apps never update)', 'cache-control: ' + sw.h.get('cache-control'));
    const cf = await get('/config.js'); check(cf.status === 200 && cf.t.includes(URL_), '0d the deployed config.js points to the SAME Supabase project this test used', 'config.js does not contain ' + URL_);
    check(/no-cache|no-store|max-age=0/i.test(cf.h.get('cache-control') || ''), '0e config.js is not cached', 'cache-control: ' + cf.h.get('cache-control'));
    const hh = idx.h; check(/nosniff/i.test(hh.get('x-content-type-options') || ''), '0f header X-Content-Type-Options: nosniff', String(hh.get('x-content-type-options')));
    check(!!hh.get('content-security-policy'), '0g Content-Security-Policy header present', 'missing (site/_headers is only honoured by Netlify / Cloudflare Pages)');
    check(/deny|sameorigin/i.test(hh.get('x-frame-options') || '') || /frame-ancestors/i.test(hh.get('content-security-policy') || ''), '0h clickjacking protection (X-Frame-Options or frame-ancestors)', 'missing');
    const swv = (sw.t.match(/const\s+(?:CACHE|VERSION|CACHE_NAME|V)\s*=\s*['"]([^'"]+)['"]/) || [])[1] || (sw.t.match(/ee-v\d+/) || [])[0]; console.log('INFO deployed service-worker cache name:', swv || '(not found)');
  }
  // 1. registration
  let tok = null, uid = null;
  if (process.env.SMOKE_EMAIL) { const s = await login(email, pw); if (!s) { block('1 register', 'SMOKE_EMAIL could not log in'); process.exit(2); } tok = s.access_token; uid = s.user.id; pass('1 registration skipped: using SMOKE_EMAIL account'); }
  else {
    const r = await call('POST', '/auth/v1/signup', null, { email, password: pw, data: { name: 'Smoke' } });
    if (!r.ok) fail('1 registration', `HTTP ${r.status} ${JSON.stringify(r.j).slice(0, 160)}`);
    else if (!r.j.access_token) { block('1 registration', 'account created but NO session: e-mail confirmation is ON in this project. Confirm the user (or turn confirmation off for the test) or pass SMOKE_EMAIL/SMOKE_PASSWORD of a confirmed learner'); console.log('\nBLOCKED: cannot continue'); process.exit(2); }
    else { pass('1 registration returns a session'); tok = r.j.access_token; uid = r.j.user.id; }
  }
  // 2. login
  const s2 = await login(email, pw);
  check(s2 && s2.access_token && s2.user.id === uid, '2 login with e-mail + password', 'login failed');
  const bad = await login(email, pw + 'x'); check(!bad, '2b wrong password is refused');
  const me = await call('GET', '/auth/v1/user', s2 && s2.access_token); check(me.ok && me.j.id === uid, '2c token identifies the user');
  tok = s2 ? s2.access_token : tok;
  const prof = await call('GET', `/rest/v1/profiles?id=eq.${uid}&select=id,name`, tok);
  check(prof.ok && prof.j.length === 1, '3 profile row created by the sign-up trigger');
  // 3. lesson
  let lessonId = process.env.LESSON_ID;
  if (!lessonId) { const l = await call('GET', '/rest/v1/lessons?published=eq.true&select=id&order=position&limit=1', tok); lessonId = l.ok && l.j[0] && l.j[0].id; }
  if (!lessonId) { block('4-7 lesson / XP', 'no published lesson in the database. Admin -> Content -> import the built-in course (or add a lesson) and publish it, or set LESSON_ID'); }
  else {
    const qs = await call('GET', `/rest/v1/questions?lesson_id=eq.${encodeURIComponent(lessonId)}&published=neq.false&select=id,type,data&order=position`, tok);
    const st = await rpc('start_lesson', { p_lesson: lessonId, p_kind: 'lesson' }, tok);
    check(st.ok && st.j.attempt_id, '4 start a lesson', `HTTP ${st.status} ${JSON.stringify(st.j).slice(0, 160)}`);
    if (st.ok) {
      let seq = 0, okAll = true;
      for (const q of (qs.j || [])) { const a = answerFor(q); if (!a) continue; const r = await rpc('submit_answer', { p_attempt: st.j.attempt_id, p_question: q.id, p_seq: seq++, p_answer: a, p_client_ok: true, p_lenient: false, p_ms: 1500 }, tok); if (!r.ok || r.j.correct !== true) { okAll = false; console.log('   answer refused', q.type, q.id, JSON.stringify(r.j).slice(0, 120)); } }
      check(okAll, '4b every question is answered correctly and the SERVER agrees', 'a correct answer was judged wrong or refused (see lines above)');
      let done = null;
      for (let i = 0; i < 60; i++) { const r = await rpc('complete_lesson', { p_attempt: st.j.attempt_id, p_mistakes: 0 }, tok); if (r.ok) { done = r.j; break; } if (!/too_fast/.test(JSON.stringify(r.j))) { fail('5 complete the lesson', JSON.stringify(r.j).slice(0, 200)); break; } await sleep(2000); }
      if (done) {
        pass('5 complete the lesson');
        check(done.xp > 0, '6 XP awarded by the server (' + done.xp + ')');
        const ev = await call('GET', '/rest/v1/xp_events?select=amount,kind', tok);
        check(ev.ok && ev.j.some((e) => e.kind === 'lesson' && e.amount === done.xp), '6b XP event stored in the database');
        const again = await rpc('complete_lesson', { p_attempt: st.j.attempt_id, p_mistakes: 0 }, tok);
        check(again.ok && again.j.xp === done.xp, '6c completing twice gives no second reward');
        // 7. "refresh": a brand-new session reads everything back from the database
        const s3 = await login(email, pw); const state = await rpc('get_my_state', { p_tz: 0 }, s3.access_token);
        check(state.ok && state.j.xp === done.xp && state.j.done && state.j.done[lessonId] >= 1, '7 after a new login the XP and the finished lesson are still there', JSON.stringify(state.j).slice(0, 200));
      }
    }
  }
  // legacy progress blob
  const up = await call('POST', '/rest/v1/progress', tok, { user_id: uid, data: { xp: 1, probe: stamp } }, { Prefer: 'resolution=merge-duplicates,return=minimal' });
  const rd = await call('GET', `/rest/v1/progress?user_id=eq.${uid}&select=data`, tok);
  check(up.ok && rd.ok && rd.j[0] && rd.j[0].data.probe === stamp, '7b progress row saved and read back');
  const other = await call('GET', `/rest/v1/progress?user_id=neq.${uid}&select=user_id`, tok); check(other.ok && other.j.length === 0, '7c other learners\' progress is invisible (RLS)');
  // 8. AI coach
  const ai = await call('POST', '/functions/v1/ai-coach', tok, { mode: 'tutor', language: 'en', level: 'A2', ui: 'en', messages: [{ role: 'user', content: 'I goes to school every day.' }] });
  if (ai.status === 404) { (process.env.EXPECT_AI ? fail : block)('8 AI coach', 'Edge Function ai-coach is not deployed (supabase functions deploy ai-coach)'); }
  else if (ai.status === 503 && ai.j && ai.j.error === 'ai_not_configured') { (process.env.EXPECT_AI ? fail : block)('8 AI coach', 'deployed but not configured: missing ' + (ai.j.missing || 'secret') + ' (supabase secrets set ANTHROPIC_API_KEY=...)'); }
  else if (ai.ok) {
    check(typeof ai.j.reply === 'string' && ai.j.reply.length > 0 && Array.isArray(ai.j.corrections), '8 AI coach answers with a reply and a corrections list');
    const ai2 = await call('POST', '/functions/v1/ai-coach', tok, { mode: 'tutor', language: 'en', level: 'A2', ui: 'en', messages: [{ role: 'user', content: 'I goes to school every day.' }, { role: 'assistant', content: ai.j.reply }, { role: 'user', content: 'Yesterday I go to the park.' }] });
    check(ai2.ok && ai2.j.reply, '8b second turn with history');
    check(ai2.ok && ai2.j.usage && ai2.j.usage.limit >= ai2.j.usage.used, '8c usage counter returned');
  } else fail('8 AI coach', `HTTP ${ai.status} ${JSON.stringify(ai.j).slice(0, 200)}`);
  const noAuth = await call('POST', '/functions/v1/ai-coach', null, { mode: 'tutor', language: 'en', messages: [{ role: 'user', content: 'hi' }] });
  check(noAuth.status === 401 || noAuth.status === 404, '9 AI coach refuses the anonymous key', 'HTTP ' + noAuth.status);
  const badReq = await call('POST', '/functions/v1/ai-coach', tok, { mode: 'tutor', language: 'xx', messages: [] });
  if (badReq.status !== 404) check(badReq.status === 400, '9b malformed AI request -> 400', 'HTTP ' + badReq.status);
  // 10. admin
  const denied = await rpc('admin_list_users', { p_q: '', p_filter: 'all', p_sort: 'created', p_dir: 'desc', p_limit: 5, p_offset: 0 }, tok);
  check(!denied.ok, '10 a normal learner cannot call admin_list_users', 'HTTP ' + denied.status);
  const selfAdmin = await call('PATCH', `/rest/v1/profiles?id=eq.${uid}`, tok, { is_admin: true, role: 'admin' }, { Prefer: 'return=representation' });
  const after = await call('GET', `/rest/v1/profiles?id=eq.${uid}&select=is_admin,role`, tok); check(after.ok && after.j[0] && !after.j[0].is_admin && after.j[0].role !== 'admin', '10b a learner cannot make themselves admin');
  if (process.env.ADMIN_EMAIL) {
    const a = await login(process.env.ADMIN_EMAIL, process.env.ADMIN_PASSWORD || ''); if (!a) fail('10c admin login', 'could not log in');
    else { const l = await rpc('admin_list_users', { p_q: '', p_filter: 'all', p_sort: 'created', p_dir: 'desc', p_limit: 5, p_offset: 0 }, a.access_token); check(l.ok, '10c admin can list users', JSON.stringify(l.j).slice(0, 160)); const sx = await rpc('admin_stats', {}, a.access_token); check(sx.ok, '10d admin can read statistics'); }
  } else block('10c admin access', 'set ADMIN_EMAIL / ADMIN_PASSWORD of an existing admin account to test the admin side');

  const state0 = (await rpc('get_my_state', { p_tz: 0 }, tok)).j;
  // 12. course data is readable by a signed-in learner (the app's Learn screen is built from these three tables)
  for (const tb of ['courses', 'units', 'lessons']) { const r = await call('GET', `/rest/v1/${tb}?select=id&limit=1`, tok); check(r.ok && Array.isArray(r.j), `12 course data: ${tb} readable (HTTP ${r.status})`, JSON.stringify(r.j).slice(0, 120)); }
  const pubL = await call('GET', '/rest/v1/lessons?published=eq.true&select=id&limit=1', tok); check(pubL.ok && pubL.j.length === 1, '12b at least one published lesson is visible to a learner', JSON.stringify(pubL.j).slice(0, 120));
  const anonL = await call('GET', '/rest/v1/lessons?published=eq.false&select=id&limit=1', tok); check(anonL.ok && anonL.j.length === 0, '12c unpublished lessons are hidden from a learner', JSON.stringify(anonL.j).slice(0, 120));
  // 13. shop
  const si = await call('GET', '/rest/v1/shop_items?select=id,price_gems&active=eq.true&limit=5', tok); check(si.ok && Array.isArray(si.j), `13 shop items load (${si.ok ? si.j.length + ' active' : 'HTTP ' + si.status})`, JSON.stringify(si.j).slice(0, 120));
  const sl = await rpc('shop_lessons', {}, tok); check(sl.ok && Array.isArray(sl.j), `13b shop VIP-lesson list loads (${sl.ok ? sl.j.length : 'HTTP ' + sl.status})`, JSON.stringify(sl.j).slice(0, 120));
  // 14. friends
  const fr = await rpc('friends_overview', {}, tok); check(fr.ok && fr.j && typeof fr.j === 'object', '14 friends overview loads', 'HTTP ' + fr.status + ' ' + JSON.stringify(fr.j).slice(0, 120));
  // 15. rank
  const lb = await rpc('leaderboard', {}, tok); check(lb.ok && Array.isArray(lb.j), `15 leaderboard loads (${lb.ok ? lb.j.length + ' rows' : 'HTTP ' + lb.status})`, JSON.stringify(lb.j).slice(0, 120));
  // 16. error handling: bad input must produce a clean 4xx, never a 5xx; no token must not read state
  const eh = [];
  const e1 = await rpc('get_my_state', { p_tz: 0 }, 'not.a.jwt'); eh.push(['a garbage token is refused', e1.status >= 400 && e1.status < 500, e1.status]);
  const e2 = await rpc('get_my_state', { p_tz: 0 }); eh.push(['the anonymous key cannot read player state', !e2.ok, e2.status]);
  const e3 = await rpc('this_function_does_not_exist', {}, tok); eh.push(['an unknown function answers 404, not 5xx', e3.status === 404, e3.status]);
  const e4 = await rpc('start_lesson', { p_lesson: 'no-such-lesson', p_kind: 'lesson' }, tok); eh.push(['starting a lesson that does not exist is refused (4xx)', !e4.ok && e4.status < 500, e4.status]);
  const e5 = await rpc('submit_answer', { p_attempt: '00000000-0000-0000-0000-000000000000', p_question: 'x', p_seq: 0, p_answer: {} }, tok); eh.push(['an answer for an unknown attempt is refused (4xx)', !e5.ok && e5.status < 500, e5.status]);
  const e6 = await rpc('complete_lesson', { p_attempt: 'not-a-uuid', p_mistakes: 0 }, tok); eh.push(['a malformed attempt id is refused (4xx)', !e6.ok && e6.status < 500, e6.status]);
  const e7 = await rpc('unlock_lesson', { p_lesson: 'no-such-lesson', p_idem: 'smoke-idem-0001' }, tok); eh.push(['unlocking an unknown lesson is refused (4xx) and charges nothing', !e7.ok && e7.status < 500, e7.status]);
  for (const [n, c, st] of eh) check(c, '16 error handling: ' + n + ' (HTTP ' + st + ')');
  // 17. admin restrictions (beyond 10): learner and anonymous callers
  const a1 = await rpc('admin_stats', {}, tok); check(!a1.ok, '17 a learner cannot read admin_stats', 'HTTP ' + a1.status);
  const a2 = await rpc('admin_list_users', { p_q: '', p_filter: 'all', p_sort: 'created', p_dir: 'desc', p_limit: 5, p_offset: 0 }); check(!a2.ok, '17b the anonymous key cannot call admin_list_users', 'HTTP ' + a2.status);
  const a3 = await rpc('admin_grant_gems', { p_user: uid, p_amount: 999 }, tok); check(!a3.ok, '17c a learner cannot grant themselves gems', 'HTTP ' + a3.status);
  const st2 = await rpc('get_my_state', { p_tz: 0 }, tok); check(st2.ok && st2.j && st2.j.gems === (state0 ? state0.gems : st2.j.gems), '17d the refused calls changed nothing: the gem balance is unchanged', 'HTTP ' + st2.status + ' ' + JSON.stringify(st2.j).slice(0, 100));
  if (!process.env.SMOKE_KEEP && !process.env.SMOKE_EMAIL) { const d = await rpc('delete_my_account', {}, tok); check(d.ok, '11 cleanup: test account deleted', JSON.stringify(d.j).slice(0, 120)); }
  console.log(`\n${results.filter((r) => r[0] === 'PASS').length} passed, ${failed} failed, ${blocked} blocked`);
  process.exit(failed ? 1 : blocked ? 2 : 0);
})().catch((e) => { console.error('ERROR', e); process.exit(1); });
