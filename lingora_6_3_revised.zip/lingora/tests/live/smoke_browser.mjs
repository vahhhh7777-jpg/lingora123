// LINGORA 6.3: browser walk-through of a DEPLOYED site (companion of smoke.mjs, which talks to the API only).
//   SITE_URL=https://your-site.example SMOKE_EMAIL=learner@example.com SMOKE_PASSWORD=... node tests/live/smoke_browser.mjs
// Optional: ADMIN_EMAIL / ADMIN_PASSWORD (an admin: checks that the Admin tab appears for them and NOT for the learner)
//           SHOTS=/dir   save a screenshot per screen        PW_MODULE / CHROME   where Playwright / Chromium live
// Exit code 0 = everything that could run passed, 1 = a check failed, 2 = parts were BLOCKED (never counted as passed).
// Without SMOKE_EMAIL the signed-out parts (startup, landing, offline, service worker) still run; everything that needs a login is reported BLOCKED.
import { createRequire } from 'node:module';
import fs from 'node:fs';
const require = createRequire(process.env.PW_MODULE || '/home/claude/.npm-global/lib/node_modules/');
const { chromium } = require('playwright');
const SITE = (process.env.SITE_URL || '').replace(/\/$/, '');
if (!SITE) { console.error('BLOCKED: set SITE_URL to the deployed site'); process.exit(2); }
const SHOTS = process.env.SHOTS || ''; if (SHOTS) fs.mkdirSync(SHOTS, { recursive: true });
let failed = 0, blocked = 0, passed = 0;
const pass = (n) => { passed++; console.log('PASS', n); };
const fail = (n, why) => { failed++; console.log('FAIL', n, '-', why || ''); };
const block = (n, why) => { blocked++; console.log('BLOCKED', n, '-', why); };
const check = (c, n, why) => (c ? pass(n) : fail(n, why));
const browser = await chromium.launch({ executablePath: process.env.CHROME || undefined, args: ['--no-sandbox'] });

async function open(viewport) {
  const ctx = await browser.newContext({ viewport, serviceWorkers: 'allow' }); const page = await ctx.newPage(); const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push('console: ' + m.text().slice(0, 160)); });
  // failed loads are judged by URL: only the site's own files (and its backend) count, a blocked third-party font host does not
  page.on('response', (r) => { if (r.url().startsWith(SITE) && r.status() >= 400) errors.push('http ' + r.status() + ' ' + r.url().slice(SITE.length, SITE.length + 60)); });
  page.on('requestfailed', (r) => { if (r.url().startsWith(SITE)) errors.push('request failed ' + r.url().slice(SITE.length, SITE.length + 60)); });
  return { ctx, page, errors };
}
const shot = (page, n) => SHOTS ? page.screenshot({ path: `${SHOTS}/${n}.png` }) : null;
const tabTo = async (page, v) => { const ok = await page.evaluate((v) => { const e = [...document.querySelectorAll('button[data-a="tab"]')].find((b) => b.offsetParent && b.dataset.v === v); if (e) e.click(); return !!e; }, v); await page.waitForTimeout(700); return ok; };
const settled = async (page, ms = 12000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { const busy = await page.evaluate(() => document.querySelectorAll('.gl-load,[aria-busy="true"]').length); if (!busy) return true; await page.waitForTimeout(400); } return false; };
const text = (page) => page.evaluate(() => document.body.innerText);

// 1. startup + signed-out
const a = await open({ width: 390, height: 844 });
const resp = await a.page.goto(SITE + '/', { waitUntil: 'load' }); await a.page.waitForTimeout(2500);
check(resp && resp.ok(), '1 startup: the site answers (HTTP ' + (resp && resp.status()) + ')');
check(await a.page.evaluate(() => (document.getElementById('app') || {}).childElementCount > 0), '1b startup: the app rendered something (no blank page)');
check(a.errors.length === 0, '1c startup: no JavaScript or console errors on first load', a.errors.slice(0, 3).join(' | '));
check((await a.page.title()).length > 2, '1d the page has a title: "' + (await a.page.title()) + '"');
const swOk = await a.page.evaluate(async () => { if (!('serviceWorker' in navigator)) return 'unsupported'; const r = await navigator.serviceWorker.getRegistration(); return r ? (r.active ? 'active' : 'installing') : 'none'; });
// by design the offline service worker is only registered for VIP members and admins (see syncOffline), so a signed-out visitor must NOT have one
console.log('INFO service worker for a signed-out visitor:', swOk, '(expected: none)');
check(swOk === 'none' || swOk === 'unsupported', '1e a signed-out visitor has no service worker (it is VIP/admin only)', swOk);
const mode = await a.page.evaluate(() => (window.EE_CONFIG && window.EE_CONFIG.SUPABASE_URL) ? 'cloud' : 'local');
console.log('INFO site mode:', mode, mode === 'local' ? '(config.js has no SUPABASE_URL: sign-in, shop, friends and rank are not available)' : '');
await shot(a.page, 'startup');
// offline: only meaningful when a service worker exists. By design that is VIP / admin only, so for a signed-out visitor the offline reload is expected to fail and is not judged.
if (swOk === 'active') { await a.ctx.setOffline(true); await a.page.reload().catch(() => {}); await a.page.waitForTimeout(2500);
  check(await a.page.evaluate(() => (document.getElementById('app') || {}).childElementCount > 0), '2 offline: the cached app still opens after a reload'); await a.ctx.setOffline(false); }
else console.log('INFO 2 offline reload not judged: no service worker for a signed-out visitor (VIP/admin only). Offline behaviour is verified by tests/ui/sw.mjs');
await a.ctx.close();

// 2. signed-in learner
const email = process.env.SMOKE_EMAIL, pw = process.env.SMOKE_PASSWORD;
if (mode !== 'cloud') block('3-9 signed-in checks', 'the site runs in local mode (no SUPABASE_URL in config.js), so there is no sign-in to test');
else if (!email || !pw) block('3-9 signed-in checks', 'set SMOKE_EMAIL and SMOKE_PASSWORD (a CONFIRMED learner account) to test sign-in, navigation, shop, friends, rank and persistence');
else {
  const L = await open({ width: 390, height: 844 }); const p = L.page;
  await p.goto(SITE + '/'); await p.waitForTimeout(2000);
  await p.click('button[data-a="lang"][data-v="en"]').catch(() => {});
  await p.click('button[data-a="authgo"][data-v="signin"]:visible').catch(() => {}); await p.fill('#em', email); await p.fill('#pw', pw);
  await p.click('#authform button[type=submit]'); await p.waitForTimeout(4000);
  check(await p.locator('button[data-a="tab"][data-v="learn"]:visible').count() === 1, '3 authentication: the learner signs in and sees the app');
  await shot(p, 'home');
  for (const [v, name] of [['home', 'Home'], ['learn', 'Learn'], ['stories', 'Stories'], ['ai', 'AI coach'], ['me', 'Profile'], ['shop', 'Shop'], ['friends', 'Friends'], ['rank', 'Rank']]) {
    const found = await tabTo(p, v);
    if (!found) { fail('4 navigation: ' + name, 'no visible control leads to "' + v + '"'); continue; }
    const done = await settled(p); const t = await text(p);
    check(done && t.length > 40 && !/\bundefined\b|\bNaN\b|\[object Object\]/.test(t), `4 navigation + loading: ${name} opens and finishes loading`, done ? 'text: ' + t.slice(0, 80).replace(/\n/g, ' ') : 'still loading after 12 s');
    await shot(p, 'tab-' + v);
  }
  // course + lesson
  await tabTo(p, 'learn'); await settled(p);
  const nodes = await p.locator('button[data-a="node"]').count(); check(nodes > 0, `5 course loading: the Learn path shows ${nodes} lesson nodes`);
  if (nodes) {
    await p.evaluate(() => document.querySelector('button[data-a="node"]:not([disabled])').click()); await p.waitForTimeout(2500);
    const open_ = await p.locator('button[data-a="quit"]').count() === 1; check(open_, '5b lesson loading: a lesson opens (no error screen)', (await text(p)).slice(0, 120).replace(/\n/g, ' '));
    await shot(p, 'lesson');
    await p.locator('button[data-a="quit"]').click().catch(() => {}); await p.waitForTimeout(400); await p.locator('button[data-a="quitYes"]').first().click().catch(() => {}); await p.waitForTimeout(800);
  }
  // persistence: reload keeps the session and XP
  const xp1 = await p.evaluate(() => document.body.innerText.match(/(\d[\d,]*)\s*XP/i)); await p.reload(); await p.waitForTimeout(3500);
  check(await p.locator('button[data-a="tab"][data-v="learn"]:visible').count() === 1, '6 persistence: after a reload the learner is still signed in');
  const xp2 = await p.evaluate(() => document.body.innerText.match(/(\d[\d,]*)\s*XP/i)); check(!xp1 || !xp2 || xp1[1] === xp2[1], '6b persistence: the XP shown is the same after a reload', JSON.stringify([xp1 && xp1[1], xp2 && xp2[1]]));
  // admin restriction
  check(await p.locator('.nav-admin, button[data-a="tab"][data-v="admin"]').count() === 0, '7 admin restriction: a normal learner has no Admin tab');
  await p.evaluate(() => { location.hash = '#/admin'; }); await p.waitForTimeout(1500);
  check(!(await p.evaluate(() => !!document.querySelector('[data-a="asub"],[data-a="p3sub"]'))), '7b admin restriction: opening #/admin as a learner does not show the admin screens');
  // offline error handling while signed in
  await L.ctx.setOffline(true); await tabTo(p, 'home'); await p.waitForTimeout(1500);
  check(await p.evaluate(() => (document.getElementById('app') || {}).childElementCount > 0) && L.errors.filter((e) => /pageerror/.test(e)).length === 0, '8 error handling: going offline while signed in does not crash the app', L.errors.slice(0, 2).join(' | '));
  await shot(p, 'offline'); await L.ctx.setOffline(false);
  check(L.errors.filter((e) => /pageerror/.test(e)).length === 0, '9 no uncaught JavaScript exceptions during the whole signed-in walk-through', L.errors.slice(0, 3).join(' | '));
  await L.ctx.close();
  if (process.env.ADMIN_EMAIL) {
    const A = await open({ width: 1280, height: 800 }); const q = A.page; await q.goto(SITE + '/'); await q.waitForTimeout(2000);
    await q.click('button[data-a="lang"][data-v="en"]').catch(() => {}); await q.click('button[data-a="authgo"][data-v="signin"]:visible').catch(() => {});
    await q.fill('#em', process.env.ADMIN_EMAIL); await q.fill('#pw', process.env.ADMIN_PASSWORD || ''); await q.click('#authform button[type=submit]'); await q.waitForTimeout(4000);
    check(await q.locator('button[data-a="tab"][data-v="admin"]:visible').count() === 1, '10 admin access: the admin account sees the Admin tab');
    await tabTo(q, 'admin'); check(await settled(q), '10b admin access: the Admin screen finishes loading'); await shot(q, 'admin');
    await A.ctx.close();
  } else block('10 admin access', 'set ADMIN_EMAIL / ADMIN_PASSWORD to test the admin side in the browser');
}
await browser.close();
console.log(`\n${passed} passed, ${failed} failed, ${blocked} blocked`);
process.exit(failed ? 1 : blocked ? 2 : 0);
