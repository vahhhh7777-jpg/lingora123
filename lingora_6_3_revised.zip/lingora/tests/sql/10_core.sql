-- Lingora SQL tests. Run by tests/sql/run.sh against a database that already holds SETUP.sql (+ the test shim).
-- Every check prints PASS or aborts the script with FAIL. Identity is set the way current PostgREST does it:
-- only the JSON setting request.jwt.claims plus SET ROLE (no legacy request.jwt.claim.* settings).
\set ON_ERROR_STOP on
\set QUIET on
set client_min_messages = notice;
create schema if not exists t;
create or replace function t.as_user(uid uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, false); execute 'set role authenticated'; end $$;
create or replace function t.as_service() returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claims', json_build_object('role', 'service_role')::text, false); execute 'set role service_role'; end $$;
create or replace function t.as_anon() returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claims', '', false); execute 'set role anon'; end $$;
create or replace function t.as_root() returns void language plpgsql as $$ begin
  execute 'reset role'; perform set_config('request.jwt.claims', '', false); end $$;
create or replace function t.ok(c boolean, msg text) returns void language plpgsql as $$ begin
  if c is not true then raise exception 'FAIL: %', msg; end if; raise notice 'PASS: %', msg; end $$;
-- runs sql, expects an error whose message contains pat
create or replace function t.err(q text, pat text, msg text) returns void language plpgsql as $$
declare m text; begin
  begin execute q; exception when others then m := sqlerrm; end;
  if m is null then raise exception 'FAIL: % (no error raised)', msg; end if;
  if position(lower(pat) in lower(m)) = 0 then raise exception 'FAIL: % (got: %)', msg, m; end if;
  raise notice 'PASS: % [%]', msg, m; end $$;
-- a write is "blocked" when it raises an error OR (for UPDATE/DELETE under RLS) touches zero rows
create or replace function t.blocked(q text, msg text) returns void language plpgsql as $$
declare m text; n bigint; begin
  begin execute q; get diagnostics n = row_count; exception when others then m := sqlerrm; end;
  if m is null and coalesce(n,0) > 0 then raise exception 'FAIL: % (% row(s) changed)', msg, n; end if;
  raise notice 'PASS: % [%]', msg, coalesce(m, 'no row affected'); end $$;
grant usage on schema t to anon, authenticated, service_role;
grant execute on all functions in schema t to anon, authenticated, service_role;

-- clean slate for the test fixtures only (fixtures use fixed ids; real data is never touched)
select t.as_root();
delete from auth.users where email like '%@lingora.test';
delete from public.languages where id = 'tl';

-- ===== A. registration =====
insert into auth.users (id, email, raw_user_meta_data) values
 ('00000000-0000-0000-0000-0000000000a1', 'alice@lingora.test', '{"name":"Alice"}'),
 ('00000000-0000-0000-0000-0000000000b2', 'bob@lingora.test',   '{"name":"Bob"}'),
 ('00000000-0000-0000-0000-0000000000c3', 'carol@lingora.test', '{"name":"Carol"}');
select t.ok((select count(*) from public.profiles where id in ('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000b2')) = 2, 'A1 sign-up trigger creates a profile for each new account');
select t.ok((select name from public.profiles where id = '00000000-0000-0000-0000-0000000000a1') = 'Alice', 'A2 profile name comes from sign-up metadata');
select t.ok(not (select coalesce(is_admin,false) from public.profiles where id = '00000000-0000-0000-0000-0000000000a1'), 'A3 new accounts are not admins');

-- ===== fixtures: one course with 2 lessons =====
insert into public.languages (id, code, name, tts) values ('tl', 'tl', '{"en":"Testish","hy":"Թեստ"}', 'en-US');
insert into public.courses (id, language_id, source, title, published) values ('tc', 'tl', 'hy', '{"en":"Test course"}', true);
insert into public.units (id, course_id, title, published) values ('tu', 'tc', '{"en":"Unit"}', true), ('tu_draft', 'tc', '{"en":"Draft unit"}', false);
insert into public.lessons (id, unit_id, title, xp, published) values ('tl1', 'tu', '{"en":"L1"}', 10, true), ('tl2', 'tu', '{"en":"L2"}', 10, true), ('tl_d', 'tu_draft', '{"en":"D"}', 10, true);
insert into public.questions (id, lesson_id, type, data, position) values
 ('tq1', 'tl1', 'mc',   '{"prompt":"cat?","options":["cat","dog"],"answer":"cat"}', 1),
 ('tq2', 'tl1', 'type', '{"prompt":"say dog","answer":"dog"}', 2),
 ('tq3', 'tl1', 'mc',   '{"prompt":"sun?","options":["sun","moon"],"answer":"sun"}', 3),
 ('tq4', 'tl2', 'mc',   '{"prompt":"x?","options":["x","y"],"answer":"x"}', 1),
 ('tq5', 'tl_d','mc',   '{"prompt":"d?","options":["d","e"],"answer":"d"}', 1);

-- ===== B. catalog visibility + progress persistence + RLS =====
select t.as_anon();
select t.ok((select count(*) from public.courses where id = 'tc') = 1, 'B1 signed-out visitors can read the published catalog');
select t.err($q$select public.start_lesson('tl1','lesson',null)$q$, 'permission denied', 'B2 signed-out visitors cannot call start_lesson');
select t.err($q$insert into public.progress (user_id, data) values ('00000000-0000-0000-0000-0000000000a1','{}')$q$, 'row-level security', 'B3 signed-out visitors cannot write progress');
select t.as_user('00000000-0000-0000-0000-0000000000a1');
insert into public.progress (user_id, data) values ('00000000-0000-0000-0000-0000000000a1', '{"xp":5,"done":{"tl1":2}}');
select t.ok((select data->>'xp' from public.progress where user_id = '00000000-0000-0000-0000-0000000000a1') = '5', 'B4 a learner can save and read back their own progress');
insert into public.progress (user_id, data) values ('00000000-0000-0000-0000-0000000000a1', '{"xp":9}') on conflict (user_id) do update set data = excluded.data;
select t.ok((select data->>'xp' from public.progress where user_id = '00000000-0000-0000-0000-0000000000a1') = '9', 'B5 progress upsert overwrites the same row (no duplicates)');
select t.err($q$insert into public.progress (user_id, data) values ('00000000-0000-0000-0000-0000000000b2','{"xp":999}')$q$, 'row-level security', 'B6 a learner cannot write another learner''s progress');
select t.as_user('00000000-0000-0000-0000-0000000000b2');
select t.ok((select count(*) from public.progress where user_id = '00000000-0000-0000-0000-0000000000a1') = 0, 'B7 a learner cannot read another learner''s progress');
select t.ok((select count(*) from public.units where id = 'tu_draft') = 0, 'B8 unpublished units are hidden from learners');
select t.blocked($q$update public.profiles set role = 'admin' where id = '00000000-0000-0000-0000-0000000000b2'$q$, 'B9 a learner cannot promote themselves to admin');
select t.blocked($q$update public.profiles set is_admin = true where id = '00000000-0000-0000-0000-0000000000b2'$q$, 'B10 a learner cannot set is_admin on themselves');
select t.blocked($q$insert into public.xp_events (user_id, amount, kind, day) values ('00000000-0000-0000-0000-0000000000b2', 500, 'lesson', current_date)$q$, 'B11 a learner cannot write XP directly');
select t.blocked($q$update public.player_state set xp = 99999 where user_id = '00000000-0000-0000-0000-0000000000b2'$q$, 'B12 a learner cannot edit player_state directly');
select t.as_root();
select t.ok((select is_admin is not true from public.profiles where id='00000000-0000-0000-0000-0000000000b2'), 'B13 failed escalation attempts left the profile unchanged');

-- ===== C. lesson flow: start, answer, complete, XP persisted =====
select t.as_user('00000000-0000-0000-0000-0000000000a1');
select t.err($q$select public.start_lesson('tl_d','lesson',null)$q$, 'denied', 'C1 a lesson in an unpublished unit cannot be started');
select t.err($q$select public.start_lesson('nope','lesson',null)$q$, 'not_found', 'C2 an unknown lesson id is refused');
create temp table ctx as select (public.start_lesson('tl1','lesson',null)->>'attempt_id')::uuid as att;
grant all on ctx to authenticated;
select t.ok((select att from ctx) is not null, 'C3 start_lesson returns an attempt id');
select t.ok((public.submit_answer((select att from ctx), 'tq1', 0, '{"choice":"dog"}', true, false, 900)->>'correct')::boolean = false, 'C4 server marks a wrong answer wrong even if the client claims it is right');
select t.ok((public.submit_answer((select att from ctx), 'tq1', 1, '{"choice":"cat"}', false, false, 900)->>'correct')::boolean = true, 'C5 server marks a right answer right even if the client claims it is wrong');
select public.lesson_miss((select att from ctx));
select t.ok((public.submit_answer((select att from ctx), 'tq1', 1, '{"choice":"dog"}', true, false, 900)->>'duplicate')::boolean, 'C6 a repeated submit returns the stored verdict');
select t.err($q$select public.submit_answer((select att from ctx), 'tq4', 5, '{"choice":"x"}', true, false, 1)$q$, 'invalid', 'C7 an answer for a question of another lesson is refused');
select t.err($q$select public.complete_lesson((select att from ctx), 0)$q$, 'too_fast', 'C8 completing a lesson instantly gives no XP (too_fast)');
select t.as_root();
update public.lesson_attempts set started_at = now() - interval '1 hour' where id = (select att from ctx);
select t.as_user('00000000-0000-0000-0000-0000000000a1');
select t.err($q$select public.complete_lesson((select att from ctx), 0)$q$, 'incomplete', 'C9 completion is refused while exercises are unanswered');
select public.submit_answer((select att from ctx), 'tq2', 2, '{"text":"dog"}', true, false, 900);
select public.submit_answer((select att from ctx), 'tq3', 3, '{"choice":"sun"}', true, false, 900);
select t.as_user('00000000-0000-0000-0000-0000000000a1');
create temp table res as select public.complete_lesson((select att from ctx), 0) as r;
grant all on res to authenticated;
select t.ok((select (r->>'xp')::int from res) > 0, 'C10 completing the lesson awards XP (' || (select r->>'xp' from res) || ')');
select t.ok((select r->>'first' from res)::boolean, 'C11 first completion is flagged as first');
select t.as_root();
select t.ok((select xp from public.player_state where user_id='00000000-0000-0000-0000-0000000000a1') = (select (r->>'xp')::int from res), 'C12 player_state.xp equals the awarded XP (persisted in the table)');
select t.ok((select count(*) from public.xp_events where user_id='00000000-0000-0000-0000-0000000000a1' and kind='lesson') = 1, 'C13 exactly one xp_events row written');
select t.ok((select count(*) from public.lesson_completions where user_id='00000000-0000-0000-0000-0000000000a1' and lesson_id='tl1') = 1, 'C14 lesson_completions row written');
select t.ok((select count(*) from public.mistake_book where user_id='00000000-0000-0000-0000-0000000000a1' and question_id='tq1') = 1, 'C15 the wrong answer went into the mistake book');
select t.as_user('00000000-0000-0000-0000-0000000000a1');
select t.ok((public.complete_lesson((select att from ctx), 0)) = (select r from res), 'C16 calling complete again returns the same result');
select t.as_root();
select t.ok((select xp from public.player_state where user_id='00000000-0000-0000-0000-0000000000a1') = (select (r->>'xp')::int from res), 'C17 ...and gives no second XP reward');
select t.as_user('00000000-0000-0000-0000-0000000000b2');
select t.err($q$select public.complete_lesson((select att from ctx), 0)$q$, 'not_found', 'C18 another learner cannot complete someone else''s attempt');
select t.as_user('00000000-0000-0000-0000-0000000000a1');
select t.ok(((public.get_my_state(0))->'done'->>'tl1')::int >= 1, 'C19 get_my_state (what the app loads after a refresh) reports the lesson as done');
select t.ok(((public.get_my_state(0))->>'xp')::int = (select (r->>'xp')::int from res), 'C20 get_my_state reports the saved XP');
select t.as_root();

-- ===== D. admin permissions =====
select t.as_user('00000000-0000-0000-0000-0000000000b2');
select t.err($q$select public.admin_list_users('', 'all', 'created', 'desc', 10, 0)$q$, 'denied', 'D1 a learner cannot list users');
select t.err($q$select public.admin_grant_vip('00000000-0000-0000-0000-0000000000b2', 30, '', null)$q$, 'denied', 'D2 a learner cannot grant themselves VIP');
select t.err($q$select public.admin_grant_gems('00000000-0000-0000-0000-0000000000b2', 100, '')$q$, 'denied', 'D3 a learner cannot grant themselves gems');
select t.err($q$select public.admin_set_role('00000000-0000-0000-0000-0000000000b2', 'admin')$q$, '', 'D4 a learner cannot call admin_set_role');
select t.err($q$select public.admin_stats()$q$, 'denied', 'D5 a learner cannot read admin statistics');
select t.err($q$insert into public.courses (id, language_id, title) values ('hack','tl','{"en":"x"}')$q$, 'row-level security', 'D6 a learner cannot create courses');
select t.ok((select count(*) from public.profiles) = 1, 'D7 a learner sees only their own profile');
select t.as_root();
update public.profiles set is_admin = true, role = 'admin' where id = '00000000-0000-0000-0000-0000000000c3';
select t.as_user('00000000-0000-0000-0000-0000000000c3');
select t.ok((public.admin_list_users('', 'all', 'created', 'desc', 50, 0)) is not null, 'D8 an admin can list users');
select t.ok((select count(*) from public.profiles) >= 3, 'D9 an admin can read all profiles');
select t.ok((public.admin_grant_vip('00000000-0000-0000-0000-0000000000b2', 30, 'test', null)) is not null, 'D10 an admin can grant VIP');
insert into public.courses (id, language_id, source, title, published) values ('tc2','tl','hy','{"en":"Admin course"}', false);
select t.ok((select count(*) from public.courses where id='tc2') = 1, 'D11 an admin can create courses');
select t.ok((select count(*) from public.audit_log) >= 1, 'D12 admin actions are written to the audit log');
select t.as_root();
select t.ok((select vip_until > now() from public.profiles where id='00000000-0000-0000-0000-0000000000b2'), 'D13 VIP grant persisted on the learner profile');
select t.as_user('00000000-0000-0000-0000-0000000000b2');
select t.ok((select count(*) from public.audit_log) = 0, 'D14 a learner cannot read the audit log');
select t.as_root();
delete from public.courses where id = 'tc2';

-- ===== E. AI coach quota, cost accounting, privileges (modern claims only) =====
select t.as_user('00000000-0000-0000-0000-0000000000a1');
select t.ok((public.my_ai_usage()->>'limit')::int = 3, 'E1 free learners get 3 AI calls per day');
select t.ok((public.ai_reserve()->>'used')::int = 1, 'E2 ai_reserve counts call 1');
select public.ai_reserve(); select public.ai_reserve();
select t.err($q$select public.ai_reserve()$q$, 'ai_limit', 'E3 the 4th free call is refused with ai_limit');
select t.err($q$select public.ai_record('00000000-0000-0000-0000-0000000000a1', 1, 1, 1)$q$, 'denied', 'E4 a learner cannot call ai_record (cannot forge cost data)');
select t.err($q$select public.ai_release('00000000-0000-0000-0000-0000000000a1')$q$, '', 'E5 a learner cannot call ai_release (cannot refund themselves)');
select t.err($q$select public.coach_context('00000000-0000-0000-0000-0000000000a1')$q$, '', 'E6 a learner cannot call coach_context');
select t.as_service();
select public.ai_release('00000000-0000-0000-0000-0000000000a1');
select t.ok((select calls from public.ai_usage where user_id='00000000-0000-0000-0000-0000000000a1' and day=current_date) = 2, 'E7 the server can give back one call');
select public.ai_record('00000000-0000-0000-0000-0000000000a1', 100, 50, 350);
select t.ok((select cost_micro from public.ai_usage where user_id='00000000-0000-0000-0000-0000000000a1' and day=current_date) = 350, 'E8 service role can record tokens and cost (works with request.jwt.claims only)');
select t.ok((public.coach_context('00000000-0000-0000-0000-0000000000a1')->>'lessons_done')::int = 1, 'E9 coach_context returns the learner''s real progress for the model');
select t.as_user('00000000-0000-0000-0000-0000000000a1');
select t.ok((public.ai_reserve()->>'used')::int = 3, 'E10 a released call can be used again');
select t.as_root();
update public.settings set value = '{"enabled":false}'::jsonb where key = 'ai';
insert into public.settings (key, value) select 'ai', '{"enabled":false}'::jsonb where not exists (select 1 from public.settings where key='ai');
select t.as_user('00000000-0000-0000-0000-0000000000b2');
select t.err($q$select public.ai_reserve()$q$, 'ai_disabled', 'E11 the admin switch disables the coach');
select t.as_root();
update public.settings set value = '{"monthly_budget_micro":100}'::jsonb where key = 'ai';
select t.as_user('00000000-0000-0000-0000-0000000000b2');
select t.err($q$select public.ai_reserve()$q$, 'ai_budget', 'E12 the monthly budget stops the coach (spent 350 > 100)');
select t.as_root();
delete from public.settings where key = 'ai';

-- ===== F. cleanup of fixtures =====
delete from auth.users where email like '%@lingora.test';
delete from public.languages where id = 'tl';
select t.ok((select count(*) from public.profiles where id in ('00000000-0000-0000-0000-0000000000a1','00000000-0000-0000-0000-0000000000b2')) = 0, 'F1 deleting an account removes its profile (cascade)');
drop schema t cascade;
