#!/usr/bin/env bash
# Usage: tests/sql/run.sh [db]   (needs a local PostgreSQL server and the postgres OS user; creates/overwrites the test DB)
set -euo pipefail
DB=${1:-lingora_test}; HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$HERE/../.."
P() { su postgres -c "psql -X -q -v ON_ERROR_STOP=1 $*"; }
su postgres -c "psql -X -q -c 'drop database if exists $DB' -c 'create database $DB'" 2>/dev/null
P -d $DB -f "$HERE/00_supabase_shim.sql"
echo "== SETUP.sql (first run)";  P -d $DB -f "$ROOT/SETUP.sql" 2>&1 | grep -v NOTICE || true
echo "== SETUP.sql (second run: idempotency)"; P -d $DB -f "$ROOT/SETUP.sql" 2>&1 | grep -v NOTICE || true
echo "== migrations 011 + 012 + 013 + 014 + 015 on top (013 and 014 are also inside SETUP.sql: running them again proves they are idempotent)"; for m in 011_stories_placement 012_ai_coach_release 013_reset_progress 014_phase1_stability 015_phase2_economy; do P -d $DB -f "$ROOT/migrations/$m.sql" 2>&1 | grep -v NOTICE || true; done
echo "== tests"; for f in 10_core 20_service_role_as_authenticator 30_reset_progress 40_phase1 50_phase2; do su postgres -c "psql -X -d $DB -v ON_ERROR_STOP=1 -f $HERE/$f.sql" 2>&1 | grep -E "PASS|FAIL|ERROR" | sed 's/^psql:[^ ]* //;s/^NOTICE:  //'; done
