-- Phase 2 checks: coin earning for every learner, practice-coin cap, individual VIP-lesson unlocks (price, ownership, idempotency, RLS, no negative balance).
\set ON_ERROR_STOP on
\set QUIET on
set client_min_messages = notice;
create schema if not exists t;
create or replace function t.as_user(uid uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, false); execute 'set role authenticated'; end $$;
create or replace function t.as_anon() returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claims', json_build_object('role', 'anon')::text, false); execute 'set role anon'; end $$;
create or replace function t.as_root() returns void language plpgsql as $$ begin
  execute 'reset role'; perform set_config('request.jwt.claims', '', false); end $$;
create or replace function t.ok(c boolean, msg text) returns void language plpgsql as $$ begin
  if c is not true then raise exception 'FAIL: %', msg; end if; raise notice 'PASS: %', msg; end $$;
create or replace function t.err(q text, pat text, msg text) returns void language plpgsql as $$
declare m text; begin
  begin execute q; exception when others then m := sqlerrm; end;
  if m is null then raise exception 'FAIL: % (no error raised)', msg; end if;
  if position(lower(pat) in lower(m)) = 0 then raise exception 'FAIL: % (got: %)', msg, m; end if;
  raise notice 'PASS: % [%]', msg, m; end $$;
grant usage on schema t to anon, authenticated, service_role;
grant execute on all functions in schema t to anon, authenticated, service_role;
select t.as_root();
delete from auth.users where email like '%@p2.test';
delete from public.languages where id = 'p2l';
insert into auth.users (id, email, raw_user_meta_data) values
 ('00000000-0000-0000-0000-0000000002a1', 'earn@p2.test', '{"name":"Earn"}'),
 ('00000000-0000-0000-0000-0000000002b2', 'buyer@p2.test', '{"name":"Buyer"}'),
 ('00000000-0000-0000-0000-0000000002c3', 'other@p2.test', '{"name":"Other"}'),
 ('00000000-0000-0000-0000-0000000002d4', 'vip@p2.test', '{"name":"Vip"}'),
 ('00000000-0000-0000-0000-0000000002e5', 'prac@p2.test', '{"name":"Prac"}');
insert into public.languages (id, code, name, tts) values ('p2l', 'p2', '{"en":"P2ish"}', 'en-US');
insert into public.courses (id, language_id, source, title, published) values ('p2c', 'p2l', 'hy', '{"en":"P2 course"}', true);
insert into public.units (id, course_id, title, published, vip) values ('p2u', 'p2c', '{"en":"Free unit"}', true, false), ('p2uv', 'p2c', '{"en":"VIP unit"}', true, true);
insert into public.lessons (id, unit_id, title, xp, published, vip, position) values
 ('p2free', 'p2u', '{"en":"Free"}', 10, true, false, 1),
 ('p2vip',  'p2u', '{"en":"VIP lesson"}', 10, true, true, 2),
 ('p2vip2', 'p2u', '{"en":"VIP cheap"}', 10, true, true, 3),
 ('p2inv',  'p2uv', '{"en":"In VIP unit"}', 10, true, true, 1);
update public.lessons set unlock_price = 5 where id = 'p2vip2';
insert into public.questions (id, lesson_id, type, data, position) values
 ('p2q1', 'p2free', 'mc', '{"prompt":"cat?","options":["cat","dog"],"answer":"cat"}', 1),
 ('p2q2', 'p2vip',  'mc', '{"prompt":"dog?","options":["cat","dog"],"answer":"dog"}', 1),
 ('p2q3', 'p2vip2', 'mc', '{"prompt":"sun?","options":["sun","moon"],"answer":"sun"}', 1),
 ('p2q4', 'p2inv',  'mc', '{"prompt":"sea?","options":["sea","sky"],"answer":"sea"}', 1);
select set_config('lingora.priv', '1', false);
update public.profiles set vip_until = now() + interval '30 days' where id = '00000000-0000-0000-0000-0000000002d4';
select set_config('lingora.priv', '', false);

create or replace function t.play2(uid uuid, lid text, qid text, ans text) returns jsonb language plpgsql as $$
declare att uuid; r jsonb; begin
  perform t.as_user(uid); perform public.get_my_state(0);
  att := (public.start_lesson(lid,'lesson',null)->>'attempt_id')::uuid;
  perform public.submit_answer(att, qid, 0, jsonb_build_object('choice', ans), true, false, 900);
  perform t.as_root(); update public.lesson_attempts set started_at = now() - interval '1 hour' where id = att;
  perform t.as_user(uid); r := public.complete_lesson(att, 0); perform t.as_root(); return r; end $$;
grant execute on function t.play2(uuid, text, text, text) to authenticated;
create or replace function t.practice(uid uuid) returns int language plpgsql as $$
declare att uuid; r jsonb; begin
  perform t.as_user(uid);
  att := (public.start_lesson(null,'practice',5)->>'attempt_id')::uuid;
  perform t.as_root(); update public.lesson_attempts set started_at = now() - interval '1 hour' where id = att;
  perform t.as_user(uid); r := public.complete_practice(att, 5); perform t.as_root(); return (r->>'gems')::int; end $$;
grant execute on function t.practice(uuid) to authenticated;

/* ---- E: a FREE learner earns coins; replaying does not pay again ---- */
select t.ok(not private.is_vip('00000000-0000-0000-0000-0000000002a1'), 'E0 the learner is a free account');
select t.play2('00000000-0000-0000-0000-0000000002a1', 'p2free', 'p2q1', 'cat');
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000002a1') >= 8, 'E1 a free learner earns coins for the first completion of a lesson');
create temp table e_g as select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000002a1';
select t.play2('00000000-0000-0000-0000-0000000002a1', 'p2free', 'p2q1', 'cat');
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000002a1') = (select gems from e_g), 'E2 replaying a completed lesson pays no coins (no farming)');
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000002a1') = coalesce((select sum(delta) from public.gem_transactions where user_id = '00000000-0000-0000-0000-0000000002a1'), 0), 'E3 balance equals the sum of the ledger');

/* ---- P: practice coins are capped per rolling 24 h ---- */
select t.practice('00000000-0000-0000-0000-0000000002e5');
select t.practice('00000000-0000-0000-0000-0000000002e5');
select t.practice('00000000-0000-0000-0000-0000000002e5');
select t.practice('00000000-0000-0000-0000-0000000002e5');
select t.practice('00000000-0000-0000-0000-0000000002e5');
select t.practice('00000000-0000-0000-0000-0000000002e5');
select t.practice('00000000-0000-0000-0000-0000000002e5');
select t.ok((select coalesce(sum(delta),0) from public.gem_transactions where user_id = '00000000-0000-0000-0000-0000000002e5' and reason = 'practice') = 5, 'P1 seven practice sessions in a row pay at most the daily cap (5 coins)');
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000002e5') = coalesce((select sum(delta) from public.gem_transactions where user_id = '00000000-0000-0000-0000-0000000002e5'), 0), 'P2 practice balance equals the ledger');

/* ---- U: unlocking one VIP lesson with coins ---- */
select t.as_user('00000000-0000-0000-0000-0000000002b2'); select public.get_my_state(0);
select t.err($$select public.unlock_lesson('p2vip','idem-buyer-0001')$$, 'not_enough_gems', 'U1 unlock with too few coins is refused');
select t.as_root();
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000002b2') = 10 and not exists (select 1 from public.lesson_unlocks where user_id = '00000000-0000-0000-0000-0000000002b2'), 'U2 a refused unlock changes nothing (welcome coins untouched, no unlock row)');
select t.as_user('00000000-0000-0000-0000-0000000002c3');
select t.ok((select count(*) from public.questions where lesson_id = 'p2vip') = 0, 'U3 a VIP lesson is hidden from a free learner who does not own it');
select t.err($$select public.start_lesson('p2vip','lesson',null)$$, 'denied', 'U4 a free learner cannot start a lesson they do not own');
select t.ok(public.locked_lessons() @> '[{"id":"p2vip"}]'::jsonb, 'U5 the lesson is listed as locked');
select t.as_root();
select private.gem_add('00000000-0000-0000-0000-0000000002b2', 69, 'admin', 'p2-grant-1', '{}'::jsonb);
select t.as_user('00000000-0000-0000-0000-0000000002b2');
select t.err($$select public.unlock_lesson('p2vip','idem-buyer-0002')$$, 'not_enough_gems', 'U6 with price-1 coins (79) the unlock is still refused');
select t.as_root();
select private.gem_add('00000000-0000-0000-0000-0000000002b2', 121, 'admin', 'p2-grant-2', '{}'::jsonb);
select t.as_user('00000000-0000-0000-0000-0000000002b2');
select public.unlock_lesson('p2vip','idem-buyer-0003');
select t.as_root();
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000002b2') = 120 and exists (select 1 from public.lesson_unlocks where user_id = '00000000-0000-0000-0000-0000000002b2' and lesson_id = 'p2vip' and price = 80), 'U7 unlock charges exactly 80 coins once and records the unlock');
select t.as_user('00000000-0000-0000-0000-0000000002b2');
select t.ok((public.unlock_lesson('p2vip','idem-buyer-0003')->>'duplicate')::boolean and (public.unlock_lesson('p2vip','idem-buyer-0004')->>'duplicate')::boolean, 'U8 repeating the same or a new key for an owned lesson is a no-op (no double charge)');
select t.as_root();
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000002b2') = 120 and (select count(*) from public.gem_transactions where user_id = '00000000-0000-0000-0000-0000000002b2' and reason = 'unlock') = 1, 'U9 still 120 coins, exactly one unlock ledger row');
select t.as_user('00000000-0000-0000-0000-0000000002b2');
select t.ok((select count(*) from public.questions where lesson_id = 'p2vip') = 1, 'U10 the owner can read the lesson content (RLS)');
select t.ok(public.start_lesson('p2vip','lesson',null) ? 'attempt_id', 'U11 the owner can start the lesson');
select t.ok(not (public.locked_lessons() @> '[{"id":"p2vip"}]'::jsonb), 'U12 an owned lesson is no longer listed as locked');
select t.ok((public.get_my_state(0)->'unlocked') @> '["p2vip"]'::jsonb, 'U13 the account state carries the unlocked lesson id');
select t.ok((select (x->>'owned')::boolean from jsonb_array_elements(public.shop_lessons()) x where x->>'id' = 'p2vip'), 'U14 the shop lists it as owned');
select t.as_user('00000000-0000-0000-0000-0000000002c3');
select t.ok((select count(*) from public.questions where lesson_id = 'p2vip') = 0, 'U15 another account still cannot read it');
select t.as_user('00000000-0000-0000-0000-0000000002b2');
select t.err($$select public.unlock_lesson('p2free','idem-buyer-0005')$$, 'not_unlockable', 'U16 a normal (free) lesson cannot be bought');
select t.err($$select public.unlock_lesson('p2inv','idem-buyer-0006')$$, 'not_unlockable', 'U17 a lesson inside a VIP unit cannot be bought one by one');
select t.err($$select public.unlock_lesson('nope','idem-buyer-0007')$$, 'not_found', 'U18 an unknown lesson is refused');
select t.err($$select public.unlock_lesson('p2vip2','x')$$, 'invalid', 'U19 a malformed idempotency key is refused');
select t.err($$insert into public.lesson_unlocks (user_id, lesson_id, price) values ('00000000-0000-0000-0000-0000000002b2','p2vip2',0)$$, 'permission denied', 'U20 a browser cannot write an unlock row directly');
select t.err($$update public.player_state set gems = 99999 where user_id = '00000000-0000-0000-0000-0000000002b2'$$, 'permission denied', 'U21 a browser cannot edit its own coin balance');
select public.unlock_lesson('p2vip2','idem-buyer-0008');
select t.as_root();
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000002b2') = 115, 'U22 a lesson with its own unlock_price (5) costs 5');
select t.as_user('00000000-0000-0000-0000-0000000002b2');
select t.as_root(); update public.player_state set gems = 79 where user_id = '00000000-0000-0000-0000-0000000002b2'; delete from public.gem_transactions where user_id = '00000000-0000-0000-0000-0000000002b2';
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000002b2') >= 0, 'U23 balance is never negative');
select t.err($$update public.player_state set gems = -1 where user_id = '00000000-0000-0000-0000-0000000002b2'$$, 'gems', 'U24 the database itself rejects a negative balance');
select t.as_user('00000000-0000-0000-0000-0000000002d4');
select t.err($$select public.unlock_lesson('p2vip','idem-vip-00001')$$, 'already_vip', 'U25 a VIP member does not pay for lessons VIP already includes');
select t.as_anon();
select t.err($$select public.unlock_lesson('p2vip','idem-anon-0001')$$, 'permission denied', 'U26 a signed-out visitor cannot call unlock_lesson');
select t.err($$select public.shop_lessons()$$, 'permission denied', 'U27 nor shop_lessons');
select t.as_root();

/* ---- exact price boundary: price coins buys it and leaves 0 ---- */
select private.ps_get('00000000-0000-0000-0000-0000000002c3');
select private.gem_add('00000000-0000-0000-0000-0000000002c3', 70, 'admin', 'p2-grant-3', '{}'::jsonb);
select t.as_user('00000000-0000-0000-0000-0000000002c3'); select public.unlock_lesson('p2vip','idem-other-001'); select t.as_root();
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000002c3') = 0, 'U28 exactly 80 coins buys the lesson and leaves 0 (never below)');

/* ---- reset keeps what was bought ---- */
select t.as_user('00000000-0000-0000-0000-0000000002c3');
select public.reset_my_progress();
select t.as_root();
select t.ok(exists (select 1 from public.lesson_unlocks where user_id = '00000000-0000-0000-0000-0000000002c3' and lesson_id = 'p2vip'), 'U29 resetting learning progress does not take away a purchased lesson');
