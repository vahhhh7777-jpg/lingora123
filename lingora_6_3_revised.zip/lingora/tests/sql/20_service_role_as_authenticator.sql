-- Real Supabase connects as the login role `authenticator` and then switches to service_role; session_user is NOT postgres.
-- This test reproduces that, so the "is this the server?" checks cannot pass by accident.
\set ON_ERROR_STOP on
do $$ begin if not exists (select 1 from pg_roles where rolname='authenticator') then create role authenticator noinherit login; end if; end $$;
grant anon, authenticated, service_role to authenticator;
insert into auth.users(id,email) values ('00000000-0000-0000-0000-0000000000d4','d@lingora.test') on conflict do nothing;
set session authorization authenticator;
set role service_role;
select set_config('request.jwt.claims','{"role":"service_role"}',false);
do $$ begin
  perform public.ai_record('00000000-0000-0000-0000-0000000000d4', 1, 1, 1);  raise notice 'PASS: G1 ai_record works for service_role (session_user=authenticator, JSON claims only)';
  perform public.coach_context('00000000-0000-0000-0000-0000000000d4');      raise notice 'PASS: G2 coach_context works for service_role (session_user=authenticator)';
  perform public.ai_release('00000000-0000-0000-0000-0000000000d4');         raise notice 'PASS: G3 ai_release works for service_role (session_user=authenticator)';
end $$;
reset role;
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000d4","role":"authenticated"}', false);
set role authenticated;
do $$ declare m text; begin
  begin perform public.ai_record('00000000-0000-0000-0000-0000000000d4', 1, 1, 1); exception when others then m := sqlerrm; end;
  if m is null then raise exception 'FAIL: G4 learner could call ai_record'; end if; raise notice 'PASS: G4 a signed-in learner is refused by ai_record [%]', m;
end $$;
reset role; reset session authorization;
delete from auth.users where email = 'd@lingora.test';
