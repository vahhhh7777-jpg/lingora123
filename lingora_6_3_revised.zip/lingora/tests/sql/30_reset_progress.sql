-- B-006 + gem-farming guard (migration 013). Run by tests/sql/run.sh after 10_core / 20_*. Self-contained fixtures (ids prefixed r*).
\set ON_ERROR_STOP on
\set QUIET on
set client_min_messages = notice;
create schema if not exists t;
create or replace function t.as_user(uid uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, false); execute 'set role authenticated'; end $$;
create or replace function t.as_service() returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claims', json_build_object('role', 'service_role')::text, false); execute 'set role service_role'; end $$;
create or replace function t.as_anon() returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claims', '', false); execute 'set role anon'; end $$;
create or replace function t.as_root() returns void language plpgsql as $$ begin
  execute 'reset role'; perform set_config('request.jwt.claims', '', false); end $$;
create or replace function t.ok(c boolean, msg text) returns void language plpgsql as $$ begin
  if c is not true then raise exception 'FAIL: %', msg; end if; raise notice 'PASS: %', msg; end $$;
-- runs sql, expects an error whose message contains pat
create or replace function t.err(q text, pat text, msg text) returns void language plpgsql as $$
declare m text; begin
  begin execute q; exception when others then m := sqlerrm; end;
  if m is null then raise exception 'FAIL: % (no error raised)', msg; end if;
  if position(lower(pat) in lower(m)) = 0 then raise exception 'FAIL: % (got: %)', msg, m; end if;
  raise notice 'PASS: % [%]', msg, m; end $$;
-- a write is "blocked" when it raises an error OR (for UPDATE/DELETE under RLS) touches zero rows
create or replace function t.blocked(q text, msg text) returns void language plpgsql as $$
declare m text; n bigint; begin
  begin execute q; get diagnostics n = row_count; exception when others then m := sqlerrm; end;
  if m is null and coalesce(n,0) > 0 then raise exception 'FAIL: % (% row(s) changed)', msg, n; end if;
  raise notice 'PASS: % [%]', msg, coalesce(m, 'no row affected'); end $$;
grant usage on schema t to anon, authenticated, service_role;
grant execute on all functions in schema t to anon, authenticated, service_role;
select t.as_root();
delete from auth.users where email like '%@reset.test';
delete from public.languages where id = 'rl';
insert into auth.users (id, email, raw_user_meta_data) values
 ('00000000-0000-0000-0000-0000000000e5', 'eve@reset.test', '{"name":"Eve"}'),
 ('00000000-0000-0000-0000-0000000000f6', 'finn@reset.test', '{"name":"Finn"}'),
 ('00000000-0000-0000-0000-0000000000a7', 'gus@reset.test', '{"name":"Gus"}');
insert into public.languages (id, code, name, tts) values ('rl', 'rl', '{"en":"Resetish"}', 'en-US');
insert into public.courses (id, language_id, source, title, published) values ('rc', 'rl', 'hy', '{"en":"Reset course"}', true);
insert into public.units (id, course_id, title, published) values ('ru', 'rc', '{"en":"Unit"}', true);
insert into public.lessons (id, unit_id, title, xp, published) values ('rl1', 'ru', '{"en":"R1"}', 10, true);
insert into public.questions (id, lesson_id, type, data, position) values ('rq1', 'rl1', 'mc', '{"prompt":"cat?","options":["cat","dog"],"answer":"cat"}', 1);
-- Eve is VIP (VIP earns gems), Finn is a bystander with progress of his own, Gus is suspended
select set_config('lingora.priv', '1', false);
update public.profiles set vip_until = now() + interval '30 days' where id in ('00000000-0000-0000-0000-0000000000e5','00000000-0000-0000-0000-0000000000f6');
update public.profiles set suspended = true where id = '00000000-0000-0000-0000-0000000000a7';
select set_config('lingora.priv', '', false);

-- helper: play lesson rl1 once as the given user (backdates the attempt so the anti-speed rule passes, like a human-paced run)
create or replace function t.play(uid uuid) returns jsonb language plpgsql as $$
declare att uuid; r jsonb; begin
  perform t.as_user(uid);
  att := (public.start_lesson('rl1','lesson',null)->>'attempt_id')::uuid;
  perform public.submit_answer(att, 'rq1', 0, '{"choice":"cat"}', true, false, 900);
  perform t.as_root(); update public.lesson_attempts set started_at = now() - interval '1 hour' where id = att;
  perform t.as_user(uid); r := public.complete_lesson(att, 0); perform t.as_root(); return r; end $$;
grant execute on function t.play(uuid) to authenticated;

create temp table r1 as select t.play('00000000-0000-0000-0000-0000000000e5') as r;
create temp table f1 as select t.play('00000000-0000-0000-0000-0000000000f6') as r;
select t.ok((select (r->>'xp')::int from r1) > 0, 'R1 Eve earned XP');
select t.ok((select gems from public.player_state where user_id='00000000-0000-0000-0000-0000000000e5') > 0, 'R2 a VIP earned gems for the first completion (' || (select gems from public.player_state where user_id='00000000-0000-0000-0000-0000000000e5') || ')');
create temp table before as select gems, hearts from public.player_state where user_id='00000000-0000-0000-0000-0000000000e5';

select t.as_anon();
select t.err($q$select public.reset_my_progress()$q$, 'permission denied', 'R3 signed-out visitors cannot reset');
select t.as_user('00000000-0000-0000-0000-0000000000a7');
select t.err($q$select public.reset_my_progress()$q$, 'suspended', 'R4 a suspended account cannot reset');
select t.as_user('00000000-0000-0000-0000-0000000000e5');
select t.err($q$select public.reset_my_progress('00000000-0000-0000-0000-0000000000f6')$q$, 'does not exist', 'R5 there is no way to name another user (no argument accepted)');
create temp table rs as select public.reset_my_progress() as r;
select t.as_root();
select t.ok((select xp from public.player_state where user_id='00000000-0000-0000-0000-0000000000e5') = 0, 'R6 XP is 0 after reset (server side)');
select t.ok((select count(*) from public.lesson_completions where user_id='00000000-0000-0000-0000-0000000000e5') = 0, 'R7 lesson completions are gone');
select t.ok((select count(*) from public.xp_events where user_id='00000000-0000-0000-0000-0000000000e5' and day >= private.week_start('00000000-0000-0000-0000-0000000000e5')) = 0, 'R8 this week''s XP events are gone (weekly leaderboard consistent)');
select t.ok((select (r->>'xp')::int = 0 and (r->>'streak')::int = 0 from rs), 'R9 reset returns the fresh state (xp 0, streak 0)');
select t.ok((select p.gems = b.gems and p.hearts = b.hearts from public.player_state p, before b where p.user_id='00000000-0000-0000-0000-0000000000e5'), 'R10 gems and hearts are NOT touched by a reset');
select t.ok((select count(*) from public.lesson_completions where user_id='00000000-0000-0000-0000-0000000000f6') = 1 and (select xp from public.player_state where user_id='00000000-0000-0000-0000-0000000000f6') > 0, 'R11 another learner''s progress is untouched');
select t.ok((select count(*) from public.audit_log where action='progress_reset' and entity_id='00000000-0000-0000-0000-0000000000e5') = 1, 'R12 the reset is written to the audit log');
select t.ok((select data = '{}'::jsonb from public.progress where user_id='00000000-0000-0000-0000-0000000000e5'), 'R13 the progress blob was cleared too (nothing old can be restored from it)');

-- replay after reset: XP is earned again (it was reset) but the first-completion gems are NOT paid a second time
create temp table r2 as select t.play('00000000-0000-0000-0000-0000000000e5') as r;
select t.ok((select (r->>'xp')::int from r2) > 0, 'R14 replaying after a reset earns XP again');
select t.ok((select (r->>'first')::boolean from r2), 'R15 the replay counts as a first completion (progress really was reset)');
select t.ok((select (r->>'gems')::int from r2) = 0, 'R16 ...but pays 0 gems (reported honestly)');
select t.ok((select gems from public.player_state where user_id='00000000-0000-0000-0000-0000000000e5') = (select gems from before), 'R17 reset + replay cannot farm gems (balance unchanged)');
select t.ok((select count(*) from public.gem_transactions where user_id='00000000-0000-0000-0000-0000000000e5' and reason='lesson_first' and ref='rl1') = 1, 'R18 exactly one lesson_first reward exists for the lesson');
-- a second reset right after is harmless
select t.as_user('00000000-0000-0000-0000-0000000000e5'); select public.reset_my_progress(); select t.as_root();
select t.ok((select xp from public.player_state where user_id='00000000-0000-0000-0000-0000000000e5') = 0, 'R19 reset is repeatable');

delete from auth.users where email like '%@reset.test';
delete from public.languages where id = 'rl';
