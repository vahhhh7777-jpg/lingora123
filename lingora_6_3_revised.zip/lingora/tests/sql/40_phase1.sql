-- Phase 1 stability checks: streak / hearts / gems / XP arithmetic and admin list filters. Self-contained fixtures (ids prefixed p1*).
-- Run by tests/sql/run.sh after the older files.
\set ON_ERROR_STOP on
\set QUIET on
set client_min_messages = notice;
create schema if not exists t;
create or replace function t.as_user(uid uuid) returns void language plpgsql as $$ begin
  perform set_config('request.jwt.claims', json_build_object('sub', uid, 'role', 'authenticated')::text, false); execute 'set role authenticated'; end $$;
create or replace function t.as_root() returns void language plpgsql as $$ begin
  execute 'reset role'; perform set_config('request.jwt.claims', '', false); end $$;
create or replace function t.ok(c boolean, msg text) returns void language plpgsql as $$ begin
  if c is not true then raise exception 'FAIL: %', msg; end if; raise notice 'PASS: %', msg; end $$;
create or replace function t.err(q text, pat text, msg text) returns void language plpgsql as $$
declare m text; begin
  begin execute q; exception when others then m := sqlerrm; end;
  if m is null then raise exception 'FAIL: % (no error raised)', msg; end if;
  if position(lower(pat) in lower(m)) = 0 then raise exception 'FAIL: % (got: %)', msg, m; end if;
  raise notice 'PASS: % [%]', msg, m; end $$;
grant usage on schema t to anon, authenticated, service_role;
grant execute on all functions in schema t to anon, authenticated, service_role;
select t.as_root();
delete from auth.users where email like '%@p1.test';
delete from public.languages where id = 'p1l';
insert into auth.users (id, email, raw_user_meta_data) values
 ('00000000-0000-0000-0000-0000000001a1', 'tz@p1.test', '{"name":"Tz"}'),
 ('00000000-0000-0000-0000-0000000001b2', 'fr@p1.test', '{"name":"Freeze"}'),
 ('00000000-0000-0000-0000-0000000001c3', 'hp@p1.test', '{"name":"Hearts"}'),
 ('00000000-0000-0000-0000-0000000001d4', 'sc@p1.test', '{"name":"Scheduled"}'),
 ('00000000-0000-0000-0000-0000000001e5', 'ad@p1.test', '{"name":"Admin"}'),
 ('00000000-0000-0000-0000-0000000001f6', 'dr@p1.test', '{"name":"Daily"}');
insert into public.languages (id, code, name, tts) values ('p1l', 'p1', '{"en":"P1ish"}', 'en-US');
insert into public.courses (id, language_id, source, title, published) values ('p1c', 'p1l', 'hy', '{"en":"P1 course"}', true);
insert into public.units (id, course_id, title, published) values ('p1u', 'p1c', '{"en":"Unit"}', true);
insert into public.lessons (id, unit_id, title, xp, published) values ('p1a', 'p1u', '{"en":"A"}', 10, true), ('p1b', 'p1u', '{"en":"B"}', 10, true);
insert into public.questions (id, lesson_id, type, data, position) values
 ('p1qa', 'p1a', 'mc', '{"prompt":"cat?","options":["cat","dog"],"answer":"cat"}', 1),
 ('p1qb', 'p1b', 'mc', '{"prompt":"dog?","options":["cat","dog"],"answer":"dog"}', 1);
select set_config('lingora.priv', '1', false);
update public.profiles set is_admin = true, role = 'super_admin' where id = '00000000-0000-0000-0000-0000000001e5';
update public.profiles set vip_from = now() + interval '5 days', vip_until = now() + interval '35 days' where id = '00000000-0000-0000-0000-0000000001d4';
update public.profiles set vip_until = now() + interval '30 days' where id = '00000000-0000-0000-0000-0000000001f6';   -- only VIPs earn gems (005_gem_policy)
select set_config('lingora.priv', '', false);

-- play one lesson as uid (backdates the attempt so the anti-speed rule passes), optionally at a given tz offset
create or replace function t.play(uid uuid, lid text, qid text, ans text, tz int default null) returns jsonb language plpgsql as $$
declare att uuid; r jsonb; begin
  perform t.as_user(uid);
  perform public.get_my_state(tz);
  att := (public.start_lesson(lid,'lesson',null)->>'attempt_id')::uuid;
  perform public.submit_answer(att, qid, 0, jsonb_build_object('choice', ans), true, false, 900);
  perform t.as_root(); update public.lesson_attempts set started_at = now() - interval '1 hour' where id = att;
  perform t.as_user(uid); r := public.complete_lesson(att, 0); perform t.as_root(); return r; end $$;
grant execute on function t.play(uuid, text, text, text, int) to authenticated;

/* ---- S: streak cannot be pushed forward several times a day by changing the reported time zone ---- */
select t.play('00000000-0000-0000-0000-0000000001a1', 'p1a', 'p1qa', 'cat', 840);
select t.ok((select streak from public.player_state where user_id = '00000000-0000-0000-0000-0000000001a1') = 1, 'S1 first lesson starts the streak at 1');
select t.play('00000000-0000-0000-0000-0000000001a1', 'p1b', 'p1qb', 'dog', -720);
select t.ok((select streak from public.player_state where user_id = '00000000-0000-0000-0000-0000000001a1') = 1, 'S2 reporting an earlier time zone does not extend the streak');
select t.play('00000000-0000-0000-0000-0000000001a1', 'p1a', 'p1qa', 'cat', 840);
select t.ok((select streak from public.player_state where user_id = '00000000-0000-0000-0000-0000000001a1') = 1, 'S3 flipping the time zone back and forth never extends the streak within the same real day');
select t.ok((select last_day from public.player_state where user_id = '00000000-0000-0000-0000-0000000001a1') >= (select (now() at time zone 'UTC' + interval '14 hours')::date - 1), 'S4 last_day never moves backwards');

/* ---- F: freezes are spent for missed days, streak resets when there are not enough ---- */
select t.as_root();
select t.play('00000000-0000-0000-0000-0000000001b2', 'p1a', 'p1qa', 'cat', 0);
update public.player_state set last_day = private.local_day('00000000-0000-0000-0000-0000000001b2') - 3, streak = 5, freezes = 2
 where user_id = '00000000-0000-0000-0000-0000000001b2';
select t.play('00000000-0000-0000-0000-0000000001b2', 'p1b', 'p1qb', 'dog', 0);
select t.ok((select streak from public.player_state where user_id = '00000000-0000-0000-0000-0000000001b2') = 6 and (select freezes from public.player_state where user_id = '00000000-0000-0000-0000-0000000001b2') = 0, 'F1 two missed days with two freezes: streak continues (6), both freezes spent');
update public.player_state set last_day = private.local_day('00000000-0000-0000-0000-0000000001b2') - 3, streak = 9, freezes = 1
 where user_id = '00000000-0000-0000-0000-0000000001b2';
select t.play('00000000-0000-0000-0000-0000000001b2', 'p1a', 'p1qa', 'cat', 0);
select t.ok((select streak from public.player_state where user_id = '00000000-0000-0000-0000-0000000001b2') = 1, 'F2 two missed days with one freeze: streak resets to 1');
select t.ok((select best_streak from public.player_state where user_id = '00000000-0000-0000-0000-0000000001b2') >= 6, 'F3 best streak is kept after a reset');

/* ---- H: hearts ---- */
select t.as_user('00000000-0000-0000-0000-0000000001c3');
select public.get_my_state(0);
select t.as_root();
select t.ok((select hearts from public.player_state where user_id = '00000000-0000-0000-0000-0000000001c3') = 5, 'H1 a new account starts with 5 hearts');
select t.as_user('00000000-0000-0000-0000-0000000001c3');
create temp table h_att as select (public.start_lesson('p1a','lesson',null)->>'attempt_id')::uuid as id;
select public.lesson_miss((select id from h_att));
select public.lesson_miss((select id from h_att));
select t.as_root();
select t.ok((select hearts from public.player_state where user_id = '00000000-0000-0000-0000-0000000001c3') = 3, 'H2 each miss costs exactly one heart');
update public.player_state set hearts = 4, hearts_at = now() - interval '130 minutes' where user_id = '00000000-0000-0000-0000-0000000001c3';
select t.as_user('00000000-0000-0000-0000-0000000001c3');
select t.ok((public.get_my_state(0)->>'hearts')::int = 5, 'H3 hearts regenerate with time and never exceed the maximum');
select t.as_root();
update public.player_state set hearts = 0, gems = 10 where user_id = '00000000-0000-0000-0000-0000000001c3';
select t.as_user('00000000-0000-0000-0000-0000000001c3');
select t.err($$select public.start_lesson('p1a','lesson',null)$$, 'no_hearts', 'H4 a lesson cannot be started with 0 hearts');
select t.err($$select public.refill_hearts('idem-not-enough-1')$$, 'not_enough_gems', 'H5 refill with too few gems is refused');
select t.as_root();
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000001c3') = 10 and (select hearts from public.player_state where user_id = '00000000-0000-0000-0000-0000000001c3') = 0, 'H6 a refused purchase changes nothing');
update public.player_state set gems = 120 where user_id = '00000000-0000-0000-0000-0000000001c3';
select t.as_user('00000000-0000-0000-0000-0000000001c3');
select public.refill_hearts('idem-refill-ok-1');
select public.refill_hearts('idem-refill-ok-1');
select t.as_root();
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000001c3') = 70 and (select hearts from public.player_state where user_id = '00000000-0000-0000-0000-0000000001c3') = 5, 'H7 refill costs 50 gems once; the same idempotency key is not charged twice');
select t.as_user('00000000-0000-0000-0000-0000000001c3');
select t.err($$select public.refill_hearts('idem-refill-ok-2')$$, 'already_full', 'H8 refill at full hearts is refused (no gems wasted)');

/* ---- G: gems and XP stay consistent with their ledgers ---- */
select t.as_root();
select t.ok(not exists (select 1 from public.player_state ps where ps.gems <> coalesce((select sum(delta) from public.gem_transactions g where g.user_id = ps.user_id), 0)
                          and ps.user_id in ('00000000-0000-0000-0000-0000000001a1','00000000-0000-0000-0000-0000000001b2')), 'G1 player_state.gems equals the sum of the gem ledger (accounts that only played)');
select t.ok(not exists (select 1 from public.player_state ps where ps.xp <> coalesce((select sum(amount) from public.xp_events x where x.user_id = ps.user_id), 0)
                          and ps.user_id::text like '00000000-0000-0000-0000-0000000001%'), 'G2 player_state.xp equals the sum of the XP events for every test account');

/* ---- D: daily reward cannot be claimed twice by flipping the time zone ---- */
select t.as_user('00000000-0000-0000-0000-0000000001f6');
select public.get_my_state(840);
select public.claim_daily_reward();
select t.ok((select gems from public.player_state where user_id = '00000000-0000-0000-0000-0000000001f6') >= 5, 'D0 a VIP can claim the daily reward once');
select public.get_my_state(-720);
select t.err($$select public.claim_daily_reward()$$, 'already_claimed', 'D1 a second daily-reward claim with a different reported time zone is refused');
select t.as_root();

/* ---- A: admin user list filters ---- */
select t.as_user('00000000-0000-0000-0000-0000000001e5');
select t.ok((public.admin_list_users('sc@p1.test','free','created','desc',25,0)->>'total')::int = 1
          and (public.admin_list_users('sc@p1.test','vip','created','desc',25,0)->>'total')::int = 0,
  'A1 a VIP that only starts in the future is listed as free today (not active), not as VIP, and not lost');
select t.ok((public.admin_list_users('','all','created','desc',100,0)->>'total')::int
          = (public.admin_list_users('','free','created','desc',100,0)->>'total')::int + (public.admin_list_users('','vip','created','desc',100,0)->>'total')::int,
  'A2 vip + free add up to all users (no account is hidden from the filters)');
select t.ok((public.admin_list_users('%','all','name;drop','asc',5,0)->>'total')::int >= 0, 'A4 odd sort / search values are handled safely');
select t.as_root();
select t.ok(to_regclass('public.profiles') is not null, 'A5 nothing was dropped by the odd sort value');
