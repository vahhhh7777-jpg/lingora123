#!/usr/bin/env bash
# Browser end-to-end run against the PostgreSQL-backed stand-in. Needs: PostgreSQL 16 server, Node 22, Playwright + Chromium.
# e2e.mjs (Phase 0/1 flows) -> phase2.mjs (repetition, shop, profile, themes) on the same database.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
su postgres -c "psql -X -q -c 'drop database if exists lingora_e2e' -c 'create database lingora_e2e'"
su postgres -c "psql -X -q -v ON_ERROR_STOP=1 -d lingora_e2e -f $ROOT/tests/sql/00_supabase_shim.sql -f $ROOT/SETUP.sql" 2>&1 | grep -v NOTICE || true
pkill -f tests/bridge/server.mjs 2>/dev/null || true; sleep 0.5
PGDB=lingora_e2e node tests/bridge/server.mjs > /tmp/bridge.log 2>&1 & sleep 1.5
node tests/e2e/e2e.mjs; c1=$?
node tests/e2e/phase2.mjs; c2=$?
if [ "${MONKEY:-0}" = "1" ]; then node tests/e2e/monkey.mjs; c3=$?; node tests/e2e/monkey_random.mjs; c3=$(( c3 || $? )); else c3=0; fi   # 6.3: + seeded random monkey (SEEDS=, STEPS=, ROLES=)
pkill -f tests/bridge/server.mjs || true
exit $(( c1 || c2 || c3 ))
