// "Click everything" runtime test (Phase 1). Logs in as the admin and as a learner (accounts created by e2e.mjs, or created here),
// visits every tab / sub-tab, clicks every non-destructive control once, and fails on any JavaScript error, console error,
// failed same-origin request (4xx/5xx other than expected) or unhandled rejection. Then cycles the tabs many times and fails if
// intervals, document-level listeners or DOM nodes keep growing (leak check).
// Needs the bridge running on an e2e database:  node tests/bridge/server.mjs   (see tests/e2e/run.sh)
import { chromium, psql, keys, BASE } from './lib.mjs';
import fs from 'node:fs';
const SA = fs.readFileSync(new URL('../bridge/supabase-standin.js', import.meta.url), 'utf8');
const PW = 'Secret-pass-1';
let bad = 0;
const ok = (c, n, why) => { console.log(c ? 'PASS' : 'FAIL', n, c ? '' : '- ' + (why || '')); if (!c) bad++; };
const browser = await chromium.launch();
const DESTRUCTIVE = /^(lang|langsel|signout|so|logout|delacct|delete|del|rm|remove|reset|rst|wipe|clear|purge|revoke|suspend|ban|unban|import|buy|pay|checkout|refill|grant|setrole|role|signoutall|unitimport|uimport)/i;

async function open(viewport) {
  const ctx = await browser.newContext({ viewport }); const page = await ctx.newPage(); const errors = [];
  await page.addInitScript(() => {
    window.__iv = new Set(); const si = window.setInterval, ci = window.clearInterval;
    window.setInterval = function (...a) { const id = si.apply(this, a); window.__iv.add(id); return id; };
    window.clearInterval = function (id) { window.__iv.delete(id); return ci.call(this, id); };
    window.__ls = {}; const ae = EventTarget.prototype.addEventListener, re = EventTarget.prototype.removeEventListener;
    EventTarget.prototype.addEventListener = function (t, f, o) { if (this === document || this === window) { const k = (this === window ? 'w:' : 'd:') + t; window.__ls[k] = (window.__ls[k] || 0) + 1; } return ae.call(this, t, f, o); };
    EventTarget.prototype.removeEventListener = function (t, f, o) { if (this === document || this === window) { const k = (this === window ? 'w:' : 'd:') + t; window.__ls[k] = (window.__ls[k] || 0) - 1; } return re.call(this, t, f, o); };
  });
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: SA }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: `window.EE_CONFIG={SUPABASE_URL:${JSON.stringify(keys.url)},SUPABASE_ANON_KEY:${JSON.stringify(keys.anon)},PRICE_TEXT:{hy:'',en:''},GEM_PACKS:[],GEM_TEXT:{hy:'',en:''},NEURAL_TTS:false};` }));
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/ERR_TUNNEL|Failed to load resource/.test(m.text()))   // 6.3: the browser's own line for any non-2xx answer; real HTTP problems are judged (with their URL) by the response handler below
    errors.push('console: ' + m.text().slice(0, 200)); });
  page.on('response', (r) => { const u = r.url(); if (!u.startsWith(BASE)) return; const st = r.status();
    if (st >= 500) errors.push('http ' + st + ' ' + u.slice(BASE.length, BASE.length + 80));
    else if (st >= 400 && st !== 429) errors.push('unexpected http ' + st + ' ' + r.request().method() + ' ' + u.slice(BASE.length, BASE.length + 80));   // 429 = the daily AI quota / rate limit answering as designed
  });
  await page.goto(keys.url + '/site/index.html'); await page.waitForTimeout(1200);
  return { ctx, page, errors };
}
async function login(page, email) {
  await page.click('button[data-a="lang"][data-v="en"]').catch(() => {});
  await page.click('button[data-a="authgo"][data-v="signin"]:visible'); await page.fill('#em', email); await page.fill('#pw', PW);
  await page.click('#authform button[type=submit]'); await page.waitForTimeout(2500);
}
const tabClick = (page, t) => page.evaluate((t) => { const e = [...document.querySelectorAll('button[data-a="tab"]')].find((b) => b.offsetParent && b.dataset.v === t); if (e) e.click(); return !!e; }, t);
const controls = (page) => page.evaluate(() => [...document.querySelectorAll('[data-a]')].filter((b) => b.offsetParent && !b.disabled).map((b, i) => ({ i, a: b.dataset.a, v: b.dataset.v || b.dataset.id || '' })));
async function walk(page, errors, label) {
  const tabs = await page.evaluate(() => [...new Set([...document.querySelectorAll('button[data-a="tab"]')].filter((b) => b.offsetParent).map((b) => b.dataset.v))]);
  let clicks = 0;
  for (const t of tabs) {
    if (process.env.V) console.log(label, 'tab', t, Date.now() % 100000);
    await tabClick(page, t); await page.waitForTimeout(500);
    const list = await controls(page); const seen = new Set();
    for (const c of list.slice(0, 60)) {
      const key = c.a + ':' + c.v; if (seen.has(key) || DESTRUCTIVE.test(c.a) || c.a === 'tab' && c.v === t) continue; seen.add(key);
      const clicked = await page.evaluate(({ a, v }) => { const e = [...document.querySelectorAll('[data-a]')].find((x) => x.offsetParent && !x.disabled && x.dataset.a === a && (x.dataset.v || x.dataset.id || '') === v); if (!e) return false; e.click(); return true; }, c);
      if (process.env.V) console.log('  click', key, clicked, Date.now() % 100000); if (clicked) clicks++; await page.waitForTimeout(120);
      await page.evaluate(() => { const m = document.querySelector('.modal [data-a="close"], [data-a="mclose"], [data-a="close"]'); if (m) m.click(); });
      await tabClick(page, t); await page.waitForTimeout(80);
    }
  }
  ok(errors.length === 0, `${label}: ${tabs.length} tabs, ${clicks} controls clicked, no JS/console/5xx errors`, errors.slice(0, 5).join(' || '));
  return tabs;
}
async function leak(page, tabs, label) {
  const snap = () => page.evaluate(() => ({ iv: window.__iv.size, ls: JSON.stringify(window.__ls), dom: document.getElementsByTagName('*').length, ls_total: Object.values(window.__ls).reduce((a, b) => a + b, 0) }));
  const cycle = async (n) => { for (let k = 0; k < n; k++) for (const t of tabs) { await tabClick(page, t); await page.waitForTimeout(60); } };
  await cycle(2); const a = await snap(); await cycle(8); const b = await snap();
  ok(b.iv <= a.iv, `${label}: no interval growth over 8 tab cycles (${a.iv} -> ${b.iv})`);
  ok(b.ls_total <= a.ls_total, `${label}: no document/window listener growth (${a.ls_total} -> ${b.ls_total})`, a.ls + ' -> ' + b.ls);
  ok(b.dom <= a.dom * 1.15 + 50, `${label}: DOM size stable (${a.dom} -> ${b.dom})`);
}

const admin = await open({ width: 1200, height: 900 });
await login(admin.page, 'ann@lingora.test');
ok(await admin.page.locator('button[data-a="tab"][data-v="admin"]:visible').count() === 1, 'M0 admin signed in');
const at = await walk(admin.page, admin.errors, 'admin');
await leak(admin.page, at, 'admin');
// admin sub-sections
const subs = await admin.page.evaluate(() => { const t = document.querySelector('button[data-a="tab"][data-v="admin"]'); t && t.click(); return [...new Set([...document.querySelectorAll('[data-a="asub"],[data-a="p3sub"]')].map((b) => b.dataset.a + ':' + b.dataset.v))]; });
let sc = 0; for (const s of subs) { const [a, v] = s.split(':'); await admin.page.evaluate(([a, v]) => { document.querySelector('button[data-a="tab"][data-v="admin"]').click(); const e = document.querySelector(`[data-a="${a}"][data-v="${v}"]`); if (e) e.click(); }, [a, v]); await admin.page.waitForTimeout(500); sc++; }
ok(admin.errors.length === 0, `admin: ${sc} admin sections opened, no errors`, admin.errors.slice(0, 5).join(' || '));
await admin.ctx.close();

const email = psql("select email from auth.users where email like 'bob%' limit 1");
const phone = await open({ width: 390, height: 844 });
await login(phone.page, email);
const lt = await walk(phone.page, phone.errors, 'learner phone');
await leak(phone.page, lt, 'learner');
await phone.ctx.close(); await browser.close();
console.log(bad ? `\n${bad} FAILED` : '\nall passed'); process.exit(bad ? 1 : 0);
