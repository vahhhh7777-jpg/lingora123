import { createRequire } from 'node:module';
import fs from 'node:fs';
import { spawnSync } from 'node:child_process';
const require = createRequire('/opt/npm-tools/');
export const { chromium } = require('playwright');
export const BASE = process.env.BRIDGE_URL || 'http://127.0.0.1:54321', DB = process.env.PGDB || 'lingora_e2e';
export const psql = (sql) => spawnSync('runuser', ['-u', 'postgres', '--', 'psql', '-X', '-q', '-A', '-t', '-d', DB, '-c', sql], { encoding: 'utf8' }).stdout.trim();
export const keys = await (await fetch(BASE + '/__test/keys')).json();
export const cfg = (o) => fetch(BASE + '/__test/config', { method: 'POST', body: JSON.stringify(o) });
const SA = fs.readFileSync(new URL('../bridge/supabase-standin.js', import.meta.url), 'utf8');
export async function openApp(browser, viewport = { width: 390, height: 844 }, storage) {
  const ctx = await browser.newContext({ viewport, storageState: storage });
  const page = await ctx.newPage(); const errors = [];
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: SA }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: `window.EE_CONFIG={TEST_HOOK:true,SUPABASE_URL:${JSON.stringify(keys.url)},SUPABASE_ANON_KEY:${JSON.stringify(keys.anon)},PRICE_TEXT:{hy:'',en:''},GEM_PACKS:[],GEM_TEXT:{hy:'',en:''},NEURAL_TTS:false};` }));
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => { if (m.type() === 'error' && !/ERR_TUNNEL|Failed to load resource/.test(m.text())) errors.push(m.text()); });
  await page.goto(keys.url + '/site/index.html'); await page.waitForTimeout(1200);
  return { ctx, page, errors };
}
export const btns = (page) => page.evaluate(() => [...document.querySelectorAll('button:not([disabled])')].filter((b) => b.offsetParent).map((b) => (b.dataset.a || '') + ':' + (b.dataset.v || b.dataset.id || b.dataset.i || '') + ':' + b.textContent.trim().slice(0, 22)).join(' | '));
