#!/usr/bin/env bash
# fresh e2e database + bridge (what run.sh does, but leaves the bridge running for the other suites)
cd "$(dirname "$0")/../.."; pkill -f tests/bridge/server.mjs 2>/dev/null; sleep 0.5
su postgres -c "psql -X -q -c 'drop database if exists lingora_e2e' -c 'create database lingora_e2e'"
su postgres -c "psql -X -q -v ON_ERROR_STOP=1 -d lingora_e2e -f $PWD/tests/sql/00_supabase_shim.sql -f $PWD/SETUP.sql" 2>&1 | grep -v NOTICE
PGDB=lingora_e2e nohup node tests/bridge/server.mjs > /tmp/bridge.log 2>&1 &
sleep 2
