// LINGORA 6.3: SEEDED RANDOM monkey test (complements the deterministic click-everything crawl in monkey.mjs).
// A pseudo-random "user" works the real app against the PostgreSQL-backed stand-in: real mouse clicks at element centres (so an overlay that covers a
// control swallows the click, as it would for a person), double clicks, keyboard keys, typing hostile strings, back/forward, reloads, viewport changes.
// After EVERY action it checks invariants; at the end of every run it checks the server data. A failure prints the seed and the last actions, so it replays:
//     SEED=7 ROLE=learner node tests/e2e/monkey_random.mjs
// Env: SEEDS="1,2,3"  STEPS=150  ROLES="learner,admin"  V=1 (verbose trail)
// Needs the bridge on an e2e database with the accounts made by e2e.mjs (ann = admin, bob = learner). See tests/e2e/run.sh (MONKEY=1).
import { chromium, psql, keys, BASE } from './lib.mjs';
import fs from 'node:fs';
const SA = fs.readFileSync(new URL('../bridge/supabase-standin.js', import.meta.url), 'utf8');
const PW = 'Secret-pass-1';
const SEEDS = (process.env.SEEDS || process.env.SEED || '1,2,3').split(',').map(Number);
const STEPS = Number(process.env.STEPS || 150);
const ROLES = (process.env.ROLES || process.env.ROLE || 'learner,admin').split(',');
let bad = 0;
const ok = (c, n, why) => { console.log(c ? 'PASS' : 'FAIL', n, c ? '' : '- ' + (why || '')); if (!c) bad++; };
const rng = (a) => () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
// never click: leaving the session, deleting data, wiping progress, real payments, importing, role changes
const NO = /(^|[:\s])(signout|so|logout|delacct|delete|del|rm|remove|reset|resetgo|rst|wipe|clear|purge|revoke|suspend|ban|unban|import|uimport|unitimport|checkout|pay|buy|setrole|role|grant|signoutall|resetprogress)/i;
const NOTXT = /sign out|log out|delete|reset|erase|wipe|remove|import|checkout|pay\b|buy\b/i;
const SIZES = [[320, 640], [390, 844], [768, 1024], [1280, 800], [844, 390]];
const WORDS = ['', ' ', 'a', 'Hello', 'Բարեւ', 'שלום', '😀🔥', '<script>window.__xss=1</script>', "'; drop table users;--", '{{7*7}}', '${7*7}', 'x'.repeat(600), '0', '-1', '1e309', 'nil', 'void'];
const KEYS = ['Escape', 'Tab', 'Shift+Tab', 'Enter', 'Space', 'ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight', 'Home', 'End', 'PageDown'];
const browser = await chromium.launch();

async function openRole(role, size) {
  const ctx = await browser.newContext({ viewport: { width: size[0], height: size[1] }, hasTouch: size[0] < 800 });
  const page = await ctx.newPage(); const errors = [], calls = [];
  await page.route(/^https?:\/\/(?!127\.0\.0\.1|localhost)/, (r) => r.abort());   // nothing may leave the machine (registered FIRST: Playwright tries the newest route first)
  await page.route('**/cdn.jsdelivr.net/npm/@supabase/**', (r) => r.fulfill({ contentType: 'text/javascript', body: SA }));
  await page.route('**/config.js*', (r) => r.fulfill({ contentType: 'text/javascript', body: `window.EE_CONFIG={TEST_HOOK:true,SUPABASE_URL:${JSON.stringify(keys.url)},SUPABASE_ANON_KEY:${JSON.stringify(keys.anon)},PRICE_TEXT:{hy:'',en:''},GEM_PACKS:[],GEM_TEXT:{hy:'',en:''},NEURAL_TTS:false};` }));
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('crash', () => errors.push('PAGE CRASHED'));
  page.on('console', (m) => { if (m.type() === 'error' && !/ERR_TUNNEL|Failed to load resource|ERR_FAILED/.test(m.text())) errors.push('console: ' + m.text().slice(0, 200)); });
  page.on('response', (r) => { const u = r.url(); if (u.startsWith(BASE)) { const m = u.match(/rpc\/([a-z_0-9]+)/); if (m) calls.push(m[1] + ':' + r.status()); if (r.status() >= 500) errors.push('http ' + r.status() + ' ' + u.slice(BASE.length, BASE.length + 80)); } });
  await page.goto(keys.url + '/site/index.html'); await page.waitForTimeout(1200);
  const email = role === 'admin' ? 'ann@lingora.test' : psql("select email from auth.users where email like 'bob%' order by created_at limit 1");
  await page.click('button[data-a="lang"][data-v="en"]').catch(() => {});
  await page.click('button[data-a="authgo"][data-v="signin"]:visible'); await page.fill('#em', email); await page.fill('#pw', PW);
  await page.click('#authform button[type=submit]'); await page.waitForTimeout(2500);
  return { ctx, page, errors, calls, email };
}

// ---- invariants ----
const inspect = (page) => page.evaluate(() => {
  const vis = (e) => { const b = e.getBoundingClientRect(), cs = getComputedStyle(e); return b.width > 0 && b.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
  const txt = document.body.innerText || '';
  const dlgs = [...document.querySelectorAll('[role="dialog"],[role="alertdialog"],.p2-sheet,.modal')].filter(vis);
  const S = window.__ee && window.__ee.S ? window.__ee.S() : null;
  const badState = S ? ['xp', 'gems', 'streak'].filter((k) => k in S && (typeof S[k] !== 'number' || !isFinite(S[k]) || S[k] < 0)) : [];
  if (S && (typeof S.done !== 'object' || S.done === null)) badState.push('done');
  if (S && (typeof S.srs !== 'object' || S.srs === null)) badState.push('srs');
  if (S && (typeof S.miss !== 'object' || S.miss === null)) badState.push('miss');
  return { hscroll: document.documentElement.scrollWidth - innerWidth, app: (document.getElementById('app') || {}).childElementCount || 0, textLen: txt.length,
    junk: (txt.match(/\bundefined\b|\bNaN\b|\[object Object\]|\bnull\b/g) || []).slice(0, 3), dlgs: dlgs.length, badState, xss: !!window.__xss,
    lessonOpen: !!document.querySelector('#lesson:not([hidden]) [data-a="quit"]'), busy: document.querySelectorAll('[aria-busy="true"]').length + document.querySelectorAll('.gl-load').length };
});

async function act(page, R, trail) {
  const r = R(); const pick = (a) => a[Math.floor(R() * a.length)];
  if (r < 0.62) {   // click a real control with the mouse
    const list = await page.evaluate((src) => {
      const NO = new RegExp(src.no, 'i'), NOTXT = new RegExp(src.notxt, 'i');
      const out = [];
      for (const e of document.querySelectorAll('[data-a],[data-px],[data-hm],button,a[href],[role=tab],summary,input[type=checkbox],input[type=radio],select')) {
        const b = e.getBoundingClientRect(); if (!b.width || !b.height || e.disabled || getComputedStyle(e).visibility === 'hidden') continue;
        const id = (e.dataset.a || e.dataset.px || e.dataset.hm || e.tagName.toLowerCase()) + ':' + (e.dataset.v || e.dataset.id || e.dataset.i || '');
        if (NO.test(id) || NOTXT.test(e.textContent || '') && !/^(tab|node|opt)/.test(e.dataset.a || '')) continue;
        if (e.tagName === 'A' && e.href && !e.href.startsWith(location.origin)) continue;
        out.push({ id, x: b.left + b.width / 2, y: b.top + b.height / 2, in: b.bottom > 0 && b.top < innerHeight });
      }
      return out;
    }, { no: NO.source, notxt: NOTXT.source });
    if (!list.length) return 'noop';
    const c = pick(list); if (!c.in) { await page.mouse.wheel(0, c.y < 0 ? -400 : 400); return 'scroll'; }
    const dbl = R() < 0.15; trail.push((dbl ? 'dblclick ' : 'click ') + c.id);
    if (dbl) await page.mouse.dblclick(c.x, c.y); else await page.mouse.click(c.x, c.y);
    return 'ok';
  }
  if (r < 0.74) { const k = pick(KEYS); trail.push('key ' + k); await page.keyboard.press(k).catch(() => {}); return 'ok'; }
  if (r < 0.84) { const w = pick(WORDS); trail.push('type ' + JSON.stringify(w.slice(0, 20))); const f = page.locator('input:visible:not([type=checkbox]):not([type=radio]):not([type=hidden]), textarea:visible').first(); if (await f.count()) { await f.fill(w).catch(() => {}); if (R() < 0.5) await page.keyboard.press('Enter').catch(() => {}); } return 'ok'; }
  if (r < 0.90) { trail.push('scroll'); await page.mouse.wheel(0, Math.round((R() - 0.4) * 900)); return 'ok'; }
  if (r < 0.94) { trail.push('back/forward'); await (R() < 0.7 ? page.goBack() : page.goForward()).catch(() => {}); await page.waitForTimeout(300);
    if (!page.url().startsWith(keys.url)) { trail.push('(history left the app: returning)'); await page.goto(keys.url + '/site/index.html'); await page.waitForTimeout(1500); } return 'ok'; }
  if (r < 0.97) { const s = pick(SIZES); trail.push('resize ' + s.join('x')); await page.setViewportSize({ width: s[0], height: s[1] }); return 'ok'; }
  trail.push('reload'); await page.reload().catch(() => {}); await page.waitForTimeout(1500); return 'ok';
}

async function settle(page, label) {   // the person gives up: close everything, then the app must be usable again
  const problems = [];
  for (let i = 0; i < 3; i++) { await page.keyboard.press('Escape').catch(() => {}); await page.waitForTimeout(150); }
  for (let i = 0; i < 4; i++) {   // leave a lesson the normal way (quit -> confirm)
    if (!(await page.locator('#lesson:not([hidden]) [data-a="quit"]').count())) break;
    await page.locator('#lesson [data-a="quit"]').first().click({ timeout: 2000 }).catch(() => {}); await page.waitForTimeout(300);
    await page.locator('button[data-a="quitYes"], button[data-a="exitLesson"]').first().click({ timeout: 1500 }).catch(() => {}); await page.waitForTimeout(500);
  }
  await page.setViewportSize({ width: 390, height: 844 });
  await page.evaluate(() => { const e = [...document.querySelectorAll('button[data-a="tab"]')].find((b) => b.offsetParent && b.dataset.v === 'home'); if (e) e.click(); }); await page.waitForTimeout(800);
  const s = await inspect(page);
  if (s.dlgs) problems.push(`${s.dlgs} dialog(s) still open after Escape x3 and leaving the lesson`);
  if (s.lessonOpen) problems.push('lesson still open after quit');
  // nothing may cover the navigation: the centre of every nav button must hit that button
  const covered = await page.evaluate(() => [...document.querySelectorAll('.nav button[data-a="tab"]')].filter((b) => b.offsetParent).map((b) => { const r = b.getBoundingClientRect(), e = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return e && b.contains(e) ? null : b.dataset.v + ' covered by ' + (e ? e.tagName + '.' + String(e.className).slice(0, 25) : 'nothing'); }).filter(Boolean));
  if (covered.length) problems.push('navigation covered: ' + covered.join(', '));
  // every tab still renders content and finishes loading (no endless spinner / skeleton)
  const tabs = await page.evaluate(() => [...new Set([...document.querySelectorAll('button[data-a="tab"]')].filter((b) => b.offsetParent).map((b) => b.dataset.v))]);
  for (const t of tabs) {
    await page.evaluate((t) => { const e = [...document.querySelectorAll('button[data-a="tab"]')].find((b) => b.offsetParent && b.dataset.v === t); if (e) e.click(); }, t);
    let st; for (let w = 0; w < 24; w++) { await page.waitForTimeout(500); st = await inspect(page); if (!st.busy) break; }
    if (st.busy) problems.push(`tab "${t}" is still loading after 12 s (${st.busy} loading markers)`);
    if (st.textLen < 20 || !st.app) problems.push(`tab "${t}" rendered (almost) nothing`);
  }
  if (problems.length && process.env.DUMP) console.log('   DUMP', JSON.stringify(await page.evaluate(() => ({ lesson: !!document.querySelector('#lesson'), lessonHidden: document.querySelector('#lesson') && document.querySelector('#lesson').hidden, btns: [...document.querySelectorAll('button')].filter((b) => b.offsetParent).map((b) => (b.dataset.a || '') + ':' + b.innerText.trim().slice(0, 25)).slice(0, 14), dialogs: [...document.querySelectorAll('[role=dialog],.p2-sheet,.modal,.ov')].map((d) => d.className + '|' + d.innerText.slice(0, 80).replace(/\n/g, ' ')), top: document.body.innerText.slice(0, 160).replace(/\n/g, ' ') }))));
  if (problems.length && process.env.DUMP) {
    console.log('   COVER', JSON.stringify(await page.evaluate(() => { const b = document.querySelector('.nav button[data-a="tab"][data-v="home"]'); const r = b.getBoundingClientRect(); const e = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); const chain = []; for (let x = e; x && x !== document.body; x = x.parentElement) { const cs = getComputedStyle(x); chain.push(x.tagName + '#' + x.id + '.' + String(x.className).slice(0, 30) + ' pos=' + cs.position + ' z=' + cs.zIndex + ' vis=' + cs.visibility + ' op=' + cs.opacity + ' disp=' + cs.display + ' h=' + Math.round(x.getBoundingClientRect().height) + ' txt=' + (x.dataset.a || '') + ':' + x.innerText.slice(0, 20).replace(/\n/g, ' ')); } return chain.slice(0, 6); })));
    await page.mouse.click(40, 800).catch(() => {}); await page.waitForTimeout(600);
    console.log('   after a real click on the nav "home":', (await page.evaluate(() => document.querySelector('.hm-cont') ? 'HOME SHOWN' : 'home NOT shown')));
  }
  return problems;
}

const drift = (email) => Number(psql(`select coalesce((select gems from player_state where user_id=u.id),0) - coalesce((select sum(delta) from gem_transactions where user_id=u.id),0) from auth.users u where email='${email}'`) || 0);
function serverChecks(role, email, drift0) {
  const out = [];
  const uid = psql(`select id from auth.users where email='${email}'`);
  if (!uid) return ['account not found'];
  // earlier tests may have set a wallet by hand; what matters is that THIS run never changes the difference between balance and ledger
  if (drift(email) !== drift0) out.push(`gem balance and ledger drifted apart during the run (${drift0} -> ${drift(email)})`);
  if (psql(`select count(*) from (select 1 from gem_transactions where user_id='${uid}' and reason='unlock' group by ref having count(*)>1) x`) !== '0') out.push('a lesson unlock was charged twice');
  if (psql(`select count(*) from gem_transactions where user_id='${uid}' and balance_after<0`) !== '0') out.push('negative balance in the ledger');
  if (psql(`select count(*) from lesson_attempts where user_id='${uid}' and finished_at is not null and started_at>finished_at`) !== '0') out.push('attempt finished before it started');
  return out;
}

for (const role of ROLES) for (const seed of SEEDS) {
  const R = rng(seed * 7919 + (role === 'admin' ? 1 : 0)); const size = role === 'admin' ? [1280, 800] : SIZES[seed % 3 === 0 ? 0 : 1];
  const { ctx, page, errors, calls, email } = await openRole(role, size); const trail = []; const fails = [];
  const drift0 = drift(email);
  for (let i = 0; i < STEPS; i++) {
    try { await act(page, R, trail); } catch (e) { trail.push('ACTION THREW ' + String(e.message).slice(0, 80)); }
    await page.waitForTimeout(90 + Math.floor(R() * 120));
    if (page.isClosed()) { fails.push('page closed'); break; }
    const s = await inspect(page).catch((e) => ({ err: String(e.message).slice(0, 80) }));
    if (s.err) { fails.push('inspect failed: ' + s.err); break; }
    if (s.hscroll > 1) fails.push(`step ${i}: horizontal scroll ${s.hscroll}px at ${await page.evaluate(() => innerWidth)}px`);
    if (!s.app || s.textLen < 5) fails.push(`step ${i}: blank screen`);
    if (s.dlgs > 1) fails.push(`step ${i}: ${s.dlgs} dialogs stacked`);
    if (s.badState.length) fails.push(`step ${i}: corrupt state fields ${s.badState}`);
    if (s.xss) fails.push(`step ${i}: injected script executed`);
    if (s.junk.length && !fails.some((f) => /junk/.test(f))) fails.push(`step ${i}: visible placeholder text ${JSON.stringify(s.junk)}`);
    if (errors.length) fails.push(`step ${i}: ${errors.splice(0).join(' || ')}`);
    if (fails.length) break;
    if (process.env.V) console.log('   ', i, trail[trail.length - 1]);
  }
  if (!fails.length) { const p = await settle(page, role); p.forEach((x) => fails.push('after run: ' + x)); }
  if (!fails.length && errors.length) fails.push('after run: ' + errors.join(' || '));
  // duplicate submissions: more than one successful finish call for one attempt must not exist on the server
  const sc = serverChecks(role, email, drift0); sc.forEach((x) => fails.push('server: ' + x));
  const calls5 = calls.filter((c) => /:5\d\d$/.test(c)); if (calls5.length) fails.push('server errors: ' + calls5.join(','));
  // state after a reload equals the server (no client-side corruption of XP)
  if (!fails.length && role === 'learner') {
    await page.reload(); await page.waitForTimeout(2500);
    const xpDb = Number(psql(`select xp from player_state where user_id=(select id from auth.users where email='${email}')`));
    const xpUi = await page.evaluate(() => window.__ee && window.__ee.S ? window.__ee.S().xp : null);
    if (xpUi !== null && xpUi !== xpDb) fails.push(`UI xp ${xpUi} differs from server xp ${xpDb} after reload`);
  }
  const summary = `${role} seed ${seed}: ${STEPS} random actions, ${calls.length} server calls`;
  ok(!fails.length, summary, fails.slice(0, 4).join(' ## ') + '\n     replay: SEED=' + seed + ' ROLES=' + role + ' node tests/e2e/monkey_random.mjs\n     last actions: ' + trail.slice(-12).join(' > '));
  await ctx.close();
}
await browser.close();
console.log(bad ? `\n${bad} FAILED` : '\nall passed'); process.exit(bad ? 1 : 0);
