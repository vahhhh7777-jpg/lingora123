// Browser end-to-end test: the REAL Lingora app (site/app.js) in cloud mode, talking to the PostgreSQL-backed Supabase stand-in
// (tests/bridge). Not real Supabase. Run via tests/e2e/run.sh.
import { chromium, openApp, psql, cfg, keys, BASE } from './lib.mjs';
import fs from 'node:fs';
const res = []; let bad = 0;
const ok = (c, n, why) => { res.push([c ? 'PASS' : 'FAIL', n, c ? '' : why || '']); console.log(c ? 'PASS' : 'FAIL', n, c ? '' : '- ' + (why || '')); if (!c) bad++; };
const SHOT = process.env.SHOTS || '/tmp/e2e-shots'; fs.mkdirSync(SHOT, { recursive: true });
const PW = 'Secret-pass-1';
const browser = await chromium.launch();
const ev = (page, e) => page.evaluate(e);
async function signup(page, name, email) {
  await page.click('button[data-a="lang"][data-v="en"]').catch(() => {});
  await page.click('button[data-a="authgo"][data-v="signup"]:visible');
  await page.fill('#nm', name); await page.fill('#em', email); await page.fill('#pw', PW); await page.fill('#pw2', PW); await page.locator('#tm').check().catch(() => {});
  await page.click('#authform button[type=submit]'); await page.waitForTimeout(1800);
}
async function login(page, email, pw = PW) {
  await page.click('button[data-a="lang"][data-v="en"]').catch(() => {});
  await page.click('button[data-a="authgo"][data-v="signin"]:visible'); await page.fill('#em', email); await page.fill('#pw', pw); await page.click('#authform button[type=submit]'); await page.waitForTimeout(2200);
}
async function onboard(page) {
  for (let i = 0; i < 6; i++) { await page.waitForTimeout(800); const n = page.locator('button[data-a="onbnext"]'); if (!(await n.count())) break; const ch = page.locator('.choice:not(.sel)').first(); if (i > 0 && await ch.count()) await ch.click().catch(() => {}); await page.waitForTimeout(300); await n.click().catch(() => {}); }
  await page.waitForTimeout(1200);
}
const tab = async (page, t) => { await page.click(`button[data-a="tab"][data-v="${t}"]:visible`); await page.waitForTimeout(900); };

/* ===== 1-2. registration + login (admin account) ===== */
let { ctx: actx, page: ap, errors: aerr } = await openApp(browser, { width: 1200, height: 900 });
await signup(ap, 'Admin Ann', 'ann@lingora.test');
ok(psql("select count(*) from auth.users where email='ann@lingora.test'") === '1', 'E1 registration through the sign-up form creates the account in the database');
ok(psql("select count(*) from profiles where name='Admin Ann'") === '1', 'E1b the profile row exists with the typed name');
await onboard(ap);
ok(await ap.locator('button[data-a="tab"][data-v="admin"]').count() === 0, 'E2 a new account has NO admin tab');
psql("update profiles set is_admin=true, role='super_admin' where id=(select id from auth.users where email='ann@lingora.test')");   // documented first-admin step (README): SQL editor
await ap.locator('button[data-a="langsel"]').first().count();
await ap.goto(keys.url + '/site/index.html'); await ap.waitForTimeout(1800);
ok(await ap.locator('button[data-a="tab"][data-v="admin"]:visible').count() === 1, 'E3 after the SQL promotion the admin tab appears (session restored from storage after reload)');

/* ===== admin: import the built-in course into the database ===== */
await tab(ap, 'admin'); await ap.click('button[data-a="asub"][data-v="courses"]'); await ap.waitForTimeout(600);
const imp = ap.locator('button[data-a="unitimport"]'); ok(await imp.count() === 1, 'E4 admin sees the import-built-in-course button (database catalog empty)');
await imp.click(); await ap.waitForTimeout(9000);
const cnt = psql("select (select count(*) from courses)||'/'||(select count(*) from units)||'/'||(select count(*) from lessons)||'/'||(select count(*) from questions)").split('/').map(Number);
ok(cnt[3] > 1000 && cnt[2] > 100, `E4b admin import wrote the catalog through RLS (${cnt.join(' courses/units/lessons/questions: ')})`);
ok(psql("select count(*) from questions where not private.q_valid(type,data)") === '0', 'E4c every imported question is valid for the server-side checker');
await ap.screenshot({ path: SHOT + '/admin.png' });
// admin logs in from a brand-new browser with the password
await actx.close(); const a2 = await openApp(browser, { width: 1200, height: 900 }); ap = a2.page; aerr = aerr.concat(a2.errors); actx = a2.ctx;
await login(ap, 'ann@lingora.test');
ok(await ap.locator('button[data-a="tab"][data-v="admin"]:visible').count() === 1, 'E5 admin logs in with e-mail + password and sees the admin tab');
await actx.close();

/* ===== learner ===== */
const email = `bob${Date.now()}@lingora.test`;
let { ctx, page, errors } = await openApp(browser, { width: 390, height: 844 });
await signup(page, 'Bob', email); await onboard(page);
ok(psql(`select count(*) from profiles where id=(select id from auth.users where email='${email}')`) === '1', 'E6 learner registered through the UI');
ok(await page.locator('button[data-a="tab"][data-v="admin"]').count() === 0, 'E7 learner has no admin tab');
const uid = psql(`select id from auth.users where email='${email}'`);
await tab(page, 'learn');
const net = []; page.on('response', async (r) => { if (/rpc\/(start_lesson|submit_answer|complete_lesson)/.test(r.url())) { net.push([r.url().split('/rpc/')[1], r.status()]); if (/complete_lesson/.test(r.url())) await r.text().catch(()=>'?'); } });
await page.click('button[data-a="node"][data-i="0"]'); await page.waitForTimeout(1500);
ok(await page.locator('button[data-a="quit"]').count() === 1 && net.some((n) => n[0] === 'start_lesson' && n[1] === 200), 'E8 starting a lesson opens the lesson and calls start_lesson (200)');
ok(psql(`select count(*) from lesson_attempts where user_id='${uid}'`) === '1', 'E8b an attempt row exists in the database');
await page.waitForTimeout(22000);   // a human needs time; the server refuses lessons finished faster than 1.5 s per exercise (tested separately in SQL)
// solver
const Q = JSON.parse(psql("select coalesce(jsonb_agg(jsonb_build_object('type',type,'data',data) order by position),'[]') from questions where lesson_id=(select l.id from lessons l join units u on u.id=l.unit_id where u.course_id='en' order by u.position,l.position limit 1)"));
let wrongPicked = 0;
for (let k = 0; k < 160; k++) {
  if (!(await page.locator('button[data-a="quit"]').count())) break;
  const text = (await page.evaluate(() => document.querySelector('[data-a="quit"]').closest('.lesson').innerText));
  const rt = page.locator('.lesson button[data-a="retry"]'); if (await rt.count()) { console.log('   solver: out of hearts, pressing retry'); await rt.first().click(); await page.waitForTimeout(800); continue; }
  const fg = page.locator('.lesson button[data-a="fixgo"]'); if (await fg.count()) { await fg.first().click(); await page.waitForTimeout(500); continue; }
  const nx = page.locator('.lesson button[data-a="next"]:not([disabled])'); if (await nx.count()) { await nx.first().click(); await page.waitForTimeout(450); continue; }
  const mt = page.locator('.lesson button[data-a="mt"]'); if (await mt.count()) { const n = (await mt.count()) / 2; for (let i = 0; i < n; i++) { await page.locator(`button[data-a="mt"][data-i="${i}"]`).nth(0).click(); await page.locator(`button[data-a="mt"][data-i="${i}"]`).nth(1).click(); } await page.waitForTimeout(700); continue; }
  const texts = await page.locator('.lesson button[data-a="opt"]').allTextContents();
  if (texts.length) {
    const same = Q.filter((q) => q.data.options && q.data.options.length === texts.length && q.data.options.every((x) => texts.some((t) => t.includes(x))));
    const q = same.find((q) => (q.data.prompt && text.includes(q.data.prompt)) || (q.data.speak && text.includes(q.data.speak))) || same.find((q) => !q.data.prompt && !q.data.speak) || same[0];
    let idx = q ? texts.findIndex((t) => t.includes(q.data.answer)) : -1;
    if (idx < 0) { const hy = (Q.find((x) => x.type === 'intro' && x.data.en === (q && q.data.answer)) || Q.find((x) => x.type === 'intro' && text.includes(x.data.en)) || { data: {} }).data.hy; if (hy) idx = texts.findIndex((t) => t.includes(hy)); }
    if (idx < 0) { wrongPicked++; console.log('   solver: no confident answer for', JSON.stringify(texts), '|', text.replace(/\n+/g, ' / ').slice(0, 100)); }
    await page.locator('.lesson button[data-a="opt"]').nth(Math.max(idx, 0)).click(); await page.locator('button[data-a="check"]:not([disabled])').click({ timeout: 2000 }).catch(() => {}); await page.waitForTimeout(600); continue; }
  const inp = page.locator('.lesson input:visible'); if (await inp.count()) { const q = Q.find((q) => q.type === 'type' && (!q.data.prompt || text.includes(q.data.prompt))) || Q.find((q) => q.type === 'type'); await inp.first().fill(q ? q.data.answer : 'x'); await page.locator('button[data-a="check"]:not([disabled])').click({ timeout: 2000 }).catch(() => {}); await page.waitForTimeout(600); continue; }
  const tk = page.locator('.lesson button[data-a="tok"], .lesson button[data-a="word"]'); if (await tk.count()) { const q = Q.find((q) => q.type === 'order'); if (q) { for (const w of String(q.data.sentence || q.data.answer || '').split(' ')) await page.locator('.lesson button:not([data-a="quit"])', { hasText: w }).first().click().catch(() => {}); } await page.locator('button[data-a="check"]:not([disabled])').click({ timeout: 2000 }).catch(() => {}); await page.waitForTimeout(600); continue; }
  console.log('   solver: unknown step:', text.replace(/\n+/g, ' / ').slice(0, 160), await page.evaluate(() => [...document.querySelectorAll('.lesson button,.lesson input')].map((b) => b.dataset.a || b.id).join(',')));
  break;
}
await page.waitForTimeout(2500);
await page.screenshot({ path: SHOT + '/lesson-end.png' });
ok(net.some((n) => n[0] === 'submit_answer' && n[1] === 200), 'E9 answers were checked by the server (submit_answer 200)');
ok(net.some((n) => n[0] === 'complete_lesson' && n[1] === 200), 'E10 completing the lesson called complete_lesson (200)');
const xp = Number(psql(`select xp from player_state where user_id='${uid}'`));
ok(xp > 0, `E11 XP saved in the database (player_state.xp = ${xp})`);
ok(psql(`select count(*) from xp_events where user_id='${uid}' and kind='lesson'`) === '1', 'E11b one lesson XP event stored');
ok(psql(`select count(*) from lesson_completions where user_id='${uid}'`) === '1', 'E12 lesson completion stored');
ok(Number(psql(`select count(*) from lesson_attempts where user_id='${uid}' and finished_at is not null`)) === 1, 'E12b attempt marked completed');

/* ===== refresh: everything must come back from the database ===== */
await page.reload(); await page.waitForTimeout(2200);
const state = await page.evaluate(async ([url, anon]) => { const s = JSON.parse(localStorage.getItem('sb-standin-session')); const r = await fetch(url + '/rest/v1/rpc/get_my_state', { method: 'POST', headers: { apikey: anon, Authorization: 'Bearer ' + s.access_token, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_tz: 0 }) }); return r.json(); }, [keys.url, keys.anon]);
ok(await page.locator('button[data-a="tab"][data-v="learn"]:visible').count() === 1, 'E13 after a page refresh the learner is still signed in');
ok(state.xp === xp && Object.keys(state.done || {}).length === 1, `E13b server state after refresh: xp=${state.xp}, finished lessons=${Object.keys(state.done || {}).length}`);
const xpText = await page.evaluate(() => document.body.innerText);
await tab(page, 'learn'); const doneNodes = await page.evaluate(() => [...document.querySelectorAll('button[data-a="node"]')].filter((n) => /done|complete|gold/.test(n.className)).length);
ok(doneNodes >= 1, `E13c the Learn path shows the finished lesson after refresh (done nodes: ${doneNodes})`);
await page.screenshot({ path: SHOT + '/after-refresh.png' });
// a brand-new browser (no local data at all) logs in and sees the same progress: proves it is server-side, not local mode
const c2 = await openApp(browser, { width: 390, height: 844 });
await login(c2.page, email);
const s2 = await c2.page.evaluate(async ([url, anon]) => { const s = JSON.parse(localStorage.getItem('sb-standin-session')); const r = await fetch(url + '/rest/v1/rpc/get_my_state', { method: 'POST', headers: { apikey: anon, Authorization: 'Bearer ' + s.access_token, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_tz: 0 }) }); return r.json(); }, [keys.url, keys.anon]);
ok(s2.xp === xp, 'E14 a fresh browser logs in with the password and gets the same XP (server-side, not local mode)');
await c2.ctx.close();

/* ===== wrong password / error handling ===== */
const c3 = await openApp(browser); await c3.page.click('button[data-a="lang"][data-v="en"]');
await c3.page.click('button[data-a="authgo"][data-v="signin"]:visible'); await c3.page.fill('#em', email); await c3.page.fill('#pw', 'wrong-password'); await c3.page.click('#authform button[type=submit]'); await c3.page.waitForTimeout(1500);
const authMsg = await c3.page.evaluate(() => (document.querySelector('.msg.err, .msg')?.textContent || '').trim());
ok(authMsg.length > 0 && !(await c3.page.locator('button[data-a="tab"]:visible').count()), `E15 wrong password shows an error and does not sign in ("${authMsg}")`);
await c3.ctx.close();

/* ===== AI coach through the real UI ===== */
psql("insert into settings(key,value) values ('ai','{\"daily_free\":50,\"monthly_budget_micro\":100000000}') on conflict (key) do update set value=excluded.value");
await cfg({ aiKey: 'sk-test-key', provider: 'ok', deployed: true });
await fetch(BASE + '/__test/anthropic-calls?clear=1');
await tab(page, 'home'); await page.click('button[data-a="tab"][data-v="ai"]:visible'); await page.waitForTimeout(900); await page.screenshot({ path: SHOT + '/ai-empty.png' });
ok(await page.locator('#aitext').count() === 1 && await page.locator('button[data-a="ailvl"]').count() === 6, 'E16 AI tab shows the conversation box and the six CEFR level buttons');
if (!(await page.locator('button[data-a="ailvl"]').count())) console.log('   AI view text:', (await page.evaluate(() => document.body.innerText)).replace(/\n+/g,' / ').slice(0,300));
await page.click('button[data-a="ailvl"][data-v="B1"]', { timeout: 4000 }).catch(() => {});
const say = async (txt) => { await page.fill('#aitext', txt); await page.press('#aitext', 'Enter'); await page.waitForTimeout(1800); };
await say('I goes to school every day.');
ok(await page.locator('.tc-me .tc-b').count() === 1 && await page.locator('.tc-ai .tc-b').count() === 1, 'E17 the learner message and the coach reply appear in the thread');
const diff = await page.locator('.tc-diff').first().innerText().catch(() => '');
ok(/I goes/.test(diff) && /I go\b/.test(diff), `E18 the grammar correction is shown with original and corrected text ("${diff.replace(/\n/g, ' ')}")`);
ok((await page.locator('.tc-c p').first().innerText().catch(() => '')).length > 5, 'E18b the correction has an explanation');
await say('Yesterday I went to the park.');
const calls = await (await fetch(BASE + '/__test/anthropic-calls')).json();
const last = calls[calls.length - 1].body;
ok(calls.length === 2 && last.messages.length === 3 && last.messages[0].content.includes('I goes') && last.messages[1].role === 'assistant', 'E19 the second turn sent the conversation history (3 messages) to the model');
ok(last.system.includes('CEFR level B1') && last.system.includes('studying English'), 'E19b the selected CEFR level B1 and the course language reached the model');
ok((await page.locator('.tc-ok').count()) === 1, 'E19c a message without mistakes is shown as "no mistakes"');
ok(psql(`select calls from ai_usage where user_id='${uid}' and day=current_date`) === '2', 'E20 the server counted 2 AI calls for the learner');
// the conversation survives a refresh (sessionStorage) and does not leak the key
await page.reload(); await page.waitForTimeout(2000); await tab(page, 'home'); await page.click('button[data-a="tab"][data-v="ai"]:visible'); await page.waitForTimeout(900);
ok(await page.locator('.tc-b').count() === 4 && await page.locator('button[data-a="ailvl"][data-v="B1"].on').count() === 1, 'E21 the conversation and the chosen level B1 are still there after a page refresh (4 bubbles)');
const html = await page.content(); ok(!html.includes('sk-test-key') && !html.includes(keys.service), 'E22 no secret key appears anywhere in the page');
await page.locator('.tc').scrollIntoViewIfNeeded(); await page.locator('.tc').screenshot({ path: SHOT + '/ai-chat.png' });
// error handling
const errTxt = async () => (await page.locator('.msg.err').first().innerText().catch(() => '')).trim();
await cfg({ aiKey: '' }); await say('Hello again'); let e1 = await errTxt();
ok(e1.length > 10 && await page.locator('#aitext').inputValue() === 'Hello again' && await page.locator('.tc-me').count() === 2, `E23 key missing: clear message, the text stays in the box, no half-sent message in the thread ("${e1.slice(0, 70)}")`);
ok(psql(`select calls from ai_usage where user_id='${uid}' and day=current_date`) === '2', 'E23b a missing key did not use up a call');
await cfg({ aiKey: 'sk-test-key', deployed: false }); await page.press('#aitext', 'Enter'); await page.waitForTimeout(1500); let e2 = await errTxt();
ok(e2.length > 10 && e2 === e1, 'E24 function not deployed (HTTP 404) is reported as "not configured"');
await cfg({ deployed: true, provider: 'error' }); await page.press('#aitext', 'Enter'); await page.waitForTimeout(1800); let e3 = await errTxt();
ok(e3.length > 10 && e3 !== e1 && psql(`select calls from ai_usage where user_id='${uid}' and day=current_date`) === '2', `E25 provider failure: friendly message and the call is refunded ("${e3.slice(0, 60)}")`);
await cfg({ provider: 'ok' }); await ctx.setOffline(true); await page.press('#aitext', 'Enter'); await page.waitForTimeout(1500); let e4 = await errTxt(); await ctx.setOffline(false);
ok(e4.length > 5 && e4 !== e3, `E26 offline: "no connection" message ("${e4.slice(0, 50)}")`);
psql("update settings set value='{\"daily_free\":2,\"monthly_budget_micro\":100000000}' where key='ai'");
await page.press('#aitext', 'Enter'); await page.waitForTimeout(1500); let e5 = await errTxt();
ok(e5.length > 10 && psql(`select calls from ai_usage where user_id='${uid}' and day=current_date`) === '2', `E27 daily limit reached: limit message ("${e5.slice(0, 60)}")`);
psql("delete from settings where key='ai'");
// layout at 320px
await page.setViewportSize({ width: 320, height: 640 }); await page.waitForTimeout(500);
const overflow = await page.evaluate(() => document.scrollingElement.scrollWidth - window.innerWidth);
ok(overflow <= 1, `E28 AI chat has no horizontal scroll at 320px (overflow ${overflow}px)`);
await page.locator('.tc').screenshot({ path: SHOT + '/ai-320.png' });
await page.setViewportSize({ width: 390, height: 844 });

/* ===== sign-out wipes the conversation ===== */
await tab(page, 'me');
const so = page.locator('button[data-a="signout"]'); if (await so.count()) { await so.first().click(); await page.waitForTimeout(1200); }
ok(await page.evaluate(() => Object.keys(sessionStorage).filter((k) => k.startsWith('lingora-aichat:')).length) === 0, 'E29 signing out removes the stored AI conversation');

ok(errors.length === 0, 'E30 no JavaScript errors in the learner session', errors.join(' | ').slice(0, 300));
ok(aerr.length === 0, 'E30b no JavaScript errors in the admin session', aerr.join(' | ').slice(0, 300));
await browser.close();
fs.writeFileSync(SHOT + '/results.json', JSON.stringify(res, null, 1));
console.log(`\n${res.filter((r) => r[0] === 'PASS').length} passed, ${bad} failed`);
process.exit(bad ? 1 : 0);
