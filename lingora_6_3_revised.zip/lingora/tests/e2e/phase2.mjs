// Phase 2 browser test: the REAL app against the PostgreSQL-backed stand-in. Runs after e2e.mjs (needs its accounts and imported course).
// Repetition from real history, Home, Shop (VIP-lesson unlock with coins), Profile, light/dark, phone/desktop layout.
import { chromium, openApp, psql, keys } from './lib.mjs';
import fs from 'node:fs';
const PW = 'Secret-pass-1';
const SHOT = process.env.SHOTS || '/tmp/p2-shots'; fs.mkdirSync(SHOT, { recursive: true });
let bad = 0;
const ok = (c, n, why) => { console.log(c ? 'PASS' : 'FAIL', n, c ? '' : '- ' + (why || '')); if (!c) bad++; };
const browser = await chromium.launch();
const email = psql("select email from auth.users where email like 'bob%' order by created_at desc limit 1");
const uid = psql(`select id from auth.users where email='${email}'`);
async function login(page, em) {
  await page.click('button[data-a="lang"][data-v="en"]').catch(() => {});
  await page.click('button[data-a="authgo"][data-v="signin"]:visible'); await page.fill('#em', em); await page.fill('#pw', PW);
  await page.click('#authform button[type=submit]'); await page.waitForTimeout(2500);
}
// 6.3: a missing tab is now a FAILURE, not a silent no-op (a removed "practice" tab used to make L1/L2 re-test the previous page without anyone noticing)
const tab = async (page, t) => { const found = await page.evaluate((t) => { const e = [...document.querySelectorAll('button[data-a="tab"]')].find((b) => b.offsetParent && b.dataset.v === t); if (e) e.click(); return !!e; }, t); if (!found) { console.log('FAIL T0 navigation target "' + t + '" does not exist on this page'); bad++; } await page.waitForTimeout(900); };
const gems = () => Number(psql(`select gems from player_state where user_id='${uid}'`));
const noOverflow = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
const theme = async (page, th) => { await page.evaluate((th) => { __ee.S().theme = th; __ee.save(); document.documentElement.setAttribute('data-theme', th); const b = [...document.querySelectorAll('.nav [data-a="tab"], nav [data-a="tab"]')].find((x) => x.offsetParent); if (b) b.click(); }, th); await page.waitForTimeout(500); };

/* ---------- setup: two lessons of the free English course become VIP-only (lesson level) with a price ---------- */
const les = psql("select l.id from lessons l join units u on u.id=l.unit_id where u.course_id='en' and not u.vip order by u.position,l.position offset 2 limit 2").split('\n');
psql(`update lessons set vip=true, unlock_price=40 where id='${les[0]}'`);
psql(`update lessons set vip=true, unlock_price=null where id='${les[1]}'`);
ok(les.length === 2 && les[0] && les[1], 'S0 two lesson-level VIP lessons prepared');

let { ctx, page, errors } = await openApp(browser, { width: 390, height: 844 });
await login(page, email);
await theme(page, "light");
ok(await page.locator('button[data-a="tab"][data-v="learn"]:visible').count() === 1, 'P0 learner signed in');

/* ---------- HOME ----------
   6.3: updated for the Home that shipped in 6.0 (the old .hm-mini coin chip and the .hm-rv "Daily review" card were replaced by the
   .hm-kp stat tiles and the "Recommended practice" cards; the Repetition tab was removed and review now happens inside lessons). */
await tab(page, 'home');
await page.evaluate(() => { const S = __ee.S(), ks = Object.keys(S.srs).slice(0, 4), d = (n) => { const x = new Date(Date.now() - n * 864e5); return x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0'); };
  if (ks[0]) S.srs[ks[0]] = { b: 1, d: d(12), t: Date.now() - 20 * 864e5 }; if (ks[1]) { S.srs[ks[1]] = { b: 1, d: d(1), t: Date.now() - 3 * 864e5 }; S.miss[ks[1]] = 3; } if (ks[2]) S.srs[ks[2]] = { b: 2, d: d(0), t: Date.now() - 4 * 864e5 }; __ee.save(); });
await tab(page, 'learn'); await tab(page, 'home');
const home = await page.evaluate(() => ({ cont: !!document.querySelector('.hm-cont .cont-play'), goal: !!document.querySelector('.hm-goal'), prog: !!document.querySelector('.hm-prog'),
  friends: !!document.querySelector('.hm-friends'), tiles: document.querySelectorAll('.tile').length,
  cardsCard: (document.querySelector('.px-card[data-hm="cards"]') || {}).innerText || '',
  coins: (document.querySelector('.hm-kp.gem b') || {}).innerText || '', coinsShown: !!document.querySelector('.hm-kp.gem'),
  cards: document.querySelectorAll('.p2-card,.cont,.c2').length }));
ok(home.cont && home.goal && home.prog, 'H1 Home shows Continue learning, Daily goal and Learning progress');
ok(!home.friends && home.tiles === 0, 'H2 Home no longer carries the friends preview or promo tiles');
ok(home.coinsShown && Number(home.coins.replace(/\D/g, '')) === gems(), `H3 Home shows the coin balance and it equals the server balance (shown ${home.coins}, server ${gems()})`);
ok(/\d+/.test(home.cardsCard) && Number(home.cardsCard.match(/\d+/)[0]) >= 1, 'H4 Home offers the due-cards review because the learner has really learned material', home.cardsCard.replace(/\n+/g, ' / '));
ok(home.cards <= 6, `H5 Home has at most 6 cards (${home.cards})`);
ok(await noOverflow(page), 'H6 Home has no horizontal overflow at 390 px');
await page.screenshot({ path: SHOT + '/home-phone-light.png', fullPage: false });

/* ---------- REPETITION from real history (now built into lessons) ---------- */
await tab(page, 'learn');
const rvInfo = await page.evaluate(() => { const c = __ee.rvCounts(); return { c, items: __ee.rvItems().length, badge: (document.querySelector('.lt-tile[data-px="cards"] .lt-bd') || {}).innerText || '' }; });
ok(rvInfo.items > 0 && rvInfo.c.total === rvInfo.items && Number(rvInfo.badge) >= 1, `R1 Repetition builds a plan from the learner's real history (${rvInfo.items} items: ${JSON.stringify(rvInfo.c)}; Learn flashcards badge "${rvInfo.badge}")`);
const realWords = Number(psql(`select count(*) from questions q where q.type='intro' and q.lesson_id in (select lesson_id from lesson_completions where user_id='${uid}')`));
ok(rvInfo.c.learned >= Math.min(realWords, 1), `R2 the items come from completed lessons only (words in completed lessons: ${realWords})`);
await page.screenshot({ path: SHOT + '/learn-tools-phone-light.png' });
const finBefore = Number(psql(`select count(*) from lesson_attempts where user_id='${uid}' and finished_at is not null`));
await tab(page, 'home');
await page.click('button[data-a="continue"]', { force: true }); await page.waitForTimeout(1500);   // force: the Continue button has an intentional infinite pulse animation, so Playwright never sees it as "stable"
ok(await page.locator('button[data-a="quit"]').count() === 1, 'R3 Continue opens a lesson session');
const attBefore = Number(psql(`select count(*) from lesson_attempts where user_id='${uid}'`));
ok(attBefore >= 1, 'R3b a lesson attempt exists on the server');
const plan = await page.evaluate(() => { const s = __ee.L().steps; return { total: s.length, review: s.filter((x) => x.review).length, tagged: document.querySelectorAll('.lesson .rm-tag').length >= 0 }; });
ok(plan.review >= 1 && plan.review <= 4, `R3c earlier material is mixed into the lesson (${plan.review} review steps of ${plan.total}, never more than 4)`);
await page.waitForTimeout(Math.ceil((plan.total - plan.review) * 1.7) * 1000 + 2000);   // the server refuses lessons finished faster than 1.5 s per exercise
let wrongKey = null, kinds = [];
for (let k = 0; k < 120; k++) {
  const st = await page.evaluate(() => (__ee.L() && !__ee.L().end && document.querySelector('.lesson [data-a="quit"]')) ? { k: __ee.cur().k, ans: __ee.cur().ans, opts: __ee.cur().opts, key: __ee.cur().key, review: !!__ee.cur().review, pairs: (__ee.cur().pairs || []).length, words: __ee.cur().words, tiles: __ee.cur().tiles } : null);
  if (!st) break; kinds.push(st.k); if (process.env.V) console.log('   step', JSON.stringify(st));
  const fg = page.locator('.lesson button[data-a="fixgo"]'); if (await fg.count()) { await fg.first().click(); await page.waitForTimeout(400); continue; }
  const nx = page.locator('.lesson button[data-a="next"]:not([disabled])'); if (await nx.count()) { await nx.first().click(); await page.waitForTimeout(350); continue; }
  const wrongNow = wrongKey === null && st.review && st.key;      // answer the first REVIEW item wrongly on purpose
  if (st.k === 'match') { for (let i = 0; i < st.pairs; i++) { await page.locator(`button[data-a="mt"][data-i="${i}"]`).nth(0).click(); await page.locator(`button[data-a="mt"][data-i="${i}"]`).nth(1).click(); } await page.waitForTimeout(700); continue; }
  if (st.k === 'build') { const used = new Set(); for (const w of st.words) { const i = st.tiles.findIndex((x, j) => x === w && !used.has(j)); used.add(i); await page.locator(`button[data-a="tileAdd"][data-i="${i}"]`).click(); } }
  else if (st.opts && st.opts.length) {
    let idx = st.opts.indexOf(st.ans); if (wrongNow) { wrongKey = st.key; idx = idx === 0 ? 1 : 0; }
    await page.locator('.lesson button[data-a="opt"]').nth(idx).click({ timeout: 4000 });
  } else if (st.k === 'type' || st.k === 'listen_type' || st.k === 'write') {
    if (wrongNow) wrongKey = st.key;
    await page.locator('.lesson input:visible').first().fill(wrongNow ? 'zzzz' : st.ans);
  } else { console.log('   unsolved kind', st.k); break; }
  await page.locator('button[data-a="check"]:not([disabled])').click({ timeout: 3000 }).catch(() => {});
  await page.waitForTimeout(600);
}
await page.waitForTimeout(2500);
ok(wrongKey !== null, `R3d a review step was answered wrongly on purpose (${kinds.join(',')})`);
const sum = await page.evaluate(() => ({ sum: !!document.querySelector('.rm-sum'), txt: (document.querySelector('.rm-sum') || {}).innerText || '', end: !!(__ee.L() && __ee.L().end) }));
ok(sum.end && sum.sum, 'R4 a clear summary is shown after the lesson (what was reinforced from earlier lessons)');
ok(/Reinforced from earlier lessons/i.test(sum.txt) && /correct/i.test(sum.txt) && /\d+\/\d+/.test(sum.txt), 'R5 the summary says what was reviewed and how many were correct', sum.txt.slice(0, 160));
await page.screenshot({ path: SHOT + '/review-summary-phone-light.png' });
const afterS = await page.evaluate((k) => ({ miss: __ee.S().miss[k] || 0, box: __ee.S().srs[k] ? __ee.S().srs[k].b : null, due: __ee.S().srs[k] ? __ee.S().srs[k].d : null, rv: __ee.S().rv, why: (__ee.rvItems().find((i) => i.key === k) || {}).why }), wrongKey);
ok(afterS.miss >= 1 && afterS.box !== null && afterS.box <= 1, `R6 the wrong answer was recorded (miss=${afterS.miss}); SRS box reset to 0, +1 for the corrected retry (box=${afterS.box})`);
ok(afterS.rv && afterS.rv.n >= 1 && afterS.rv.t >= 1, `R7 session counters updated (today ${afterS.rv && afterS.rv.n}, total ${afterS.rv && afterS.rv.t})`);
ok(Number(psql(`select count(*) from lesson_attempts where user_id='${uid}' and finished_at is not null`)) === finBefore + 1, 'R8 the lesson attempt (with its review steps) was completed on the server');
await page.waitForTimeout(2500);
const prog2 = JSON.parse(psql(`select coalesce((select data::text from progress where user_id='${uid}'),'{}')`) || '{}');
ok(prog2.rv && prog2.rv.t >= 1 && prog2.srs && Object.keys(prog2.srs).length >= 1, 'R9 review history (srs + counters) is synced to the database');
await page.locator('button[data-a="exitLesson"]').click().catch(() => {}); await page.waitForTimeout(1200);
ok(afterS.why === 'hard' || afterS.why === 'forgot' || afterS.why === 'due', `R10 the item answered wrongly is queued for repetition again instead of being treated as learned (classified "${afterS.why}")`);
ok(Number(psql(`select coalesce(sum(delta),0) from gem_transactions where user_id='${uid}' and reason='practice'`)) <= 5, 'R11 review coins respect the daily cap');

/* ---------- empty state: a brand-new learner ---------- */
{
  const e2 = await openApp(browser, { width: 390, height: 844 });
  await e2.page.click('button[data-a="lang"][data-v="en"]').catch(() => {});
  await e2.page.click('button[data-a="authgo"][data-v="signup"]:visible');
  await e2.page.fill('#nm', 'Newbie'); await e2.page.fill('#em', `newbie${Date.now()}@lingora.test`); await e2.page.fill('#pw', PW); await e2.page.fill('#pw2', PW); await e2.page.locator('#tm').check().catch(() => {});
  await e2.page.click('#authform button[type=submit]'); await e2.page.waitForTimeout(2200);
  for (let i = 0; i < 6; i++) { await e2.page.waitForTimeout(700); const n = e2.page.locator('button[data-a="onbnext"]'); if (!(await n.count())) break; await n.first().click().catch(() => {}); }
  await e2.page.waitForTimeout(1200);
  /* 6.3: the old empty "Repetition" screen is gone. A brand-new learner (no finished lesson, no SRS history) must have NO review plan, and the
     first lesson must contain NO mixed-in review steps. (Flashcards deliberately preview the first 12 course words for a learner who has met none yet.) */
  await tab(e2.page, 'home');
  await e2.page.click('button[data-a="continue"]', { force: true }); await e2.page.waitForTimeout(1500);
  const em = await e2.page.evaluate(() => ({ plan: __ee.rvCounts().total, steps: __ee.L() ? __ee.L().steps.length : 0, review: __ee.L() ? __ee.L().steps.filter((x) => x.review).length : -1, tag: document.querySelectorAll('.lesson .rm-tag').length }));
  ok(em.plan === 0 && em.steps > 0 && em.review === 0 && em.tag === 0, 'R12 a learner with no history has no review plan and the first lesson has no review steps', JSON.stringify(em));
  await e2.page.screenshot({ path: SHOT + '/first-lesson-new-learner-phone-light.png' });
  await e2.page.locator('button[data-a="quit"]').click().catch(() => {}); await e2.page.waitForTimeout(500);
  await e2.page.locator('button[data-a="quitYes"]').first().click().catch(() => {}); await e2.page.waitForTimeout(800);
  await tab(e2.page, 'home');
  ok(await e2.page.evaluate(() => !document.querySelector('.px-card[data-hm="cards"]')), 'R13 Home shows no review card when there is nothing to review');
  ok(e2.errors.length === 0, 'R14 no JS errors for the new learner', e2.errors.join('|'));
  await e2.ctx.close();
}

/* ---------- SHOP: unlock a VIP lesson with coins ---------- */
psql(`select private.ps_get('${uid}'::uuid)`);
psql(`update player_state set gems=gems where user_id='${uid}'`);
const g0 = gems();
await tab(page, 'shop'); await page.waitForTimeout(1200);
const sh = await page.evaluate(() => ({ cards: [...document.querySelectorAll('.shop-lesson')].map((e) => ({ t: e.querySelector('h3').innerText, cls: e.className, btn: (e.querySelector('.shop-buy') || {}).innerText, dis: !!(e.querySelector('.shop-buy') || {}).disabled })), bal: (document.querySelector('.shop-bal.main b') || {}).innerText }));
ok(sh.cards.length === 2, `K1 the Shop lists both VIP lessons (${sh.cards.length})`);
ok(sh.cards.every((c) => /poor|ok/.test(c.cls)), 'K2 each shows locked state');
await page.screenshot({ path: SHOT + '/shop-phone-light.png' });
psql(`update player_state set gems=0 where user_id='${uid}'`);   // test fixture: start from an empty wallet
psql(`delete from gem_transactions where user_id='${uid}'`);
page.on('console', (m) => { if (/shop load failed/.test(m.text())) console.log('   WARN', m.text().slice(0, 300), m.args().length); });
await page.reload(); await page.waitForTimeout(2200); await tab(page, 'shop'); await page.waitForTimeout(1200);
const poor = await page.evaluate(() => [...document.querySelectorAll('.shop-lesson .shop-buy')].map((b) => b.disabled));
ok(poor.length === 2 && poor.every(Boolean), 'K3 with 0 coins every Unlock button is disabled and says how many are missing', JSON.stringify(poor)+' '+(await page.evaluate(()=>document.body.innerText)).replace(/\n+/g,' / ').slice(0,250)+' gems='+await page.evaluate(()=>__ee.S().gems)+' db='+psql(`select gems from player_state where user_id='${uid}'`));
psql(`select private.gem_add('${uid}'::uuid, 150, 'admin', 'p2e2e-1', '{}'::jsonb)`);
await page.reload(); await page.waitForTimeout(2200); await tab(page, 'shop'); await page.waitForTimeout(1200);
const idA = les[0];
await page.click(`button[data-a="unlock"][data-v="${idA}"]`); await page.waitForTimeout(400);
const dlg = await page.evaluate(() => { const d = document.querySelector('.p2-sheet'); return d ? { role: d.getAttribute('role'), txt: d.innerText } : null; });
ok(dlg && dlg.role === 'dialog' && /40/.test(dlg.txt) && /150/.test(dlg.txt) && /110/.test(dlg.txt), 'K4 a confirmation shows price 40, balance 150 and balance after 110', dlg && dlg.txt.replace(/\n+/g, ' '));
await page.screenshot({ path: SHOT + '/shop-confirm-phone-light.png' });
await page.keyboard.press('Escape'); await page.waitForTimeout(300);
ok(!(await page.locator('.p2-sheet').count()) && gems() === 150, 'K5 Escape cancels: no dialog and nothing was charged');
await page.click(`button[data-a="unlock"][data-v="${idA}"]`); await page.waitForTimeout(300);
await page.click('button[data-a="shopno"]'); await page.waitForTimeout(300);
ok(gems() === 150, 'K6 Cancel charges nothing');
await page.click(`button[data-a="unlock"][data-v="${idA}"]`); await page.waitForTimeout(300);
await page.evaluate(() => { const b = document.getElementById('shopyes'); b.click(); b.click(); b.click(); });   // a frantic triple tap
await page.waitForTimeout(2500);
ok(gems() === 110, `K7 three rapid taps on Confirm charged exactly 40 once (balance ${gems()})`);
ok(psql(`select count(*) from lesson_unlocks where user_id='${uid}' and lesson_id='${idA}'`) === '1' && psql(`select count(*) from gem_transactions where user_id='${uid}' and reason='unlock'`) === '1', 'K8 exactly one unlock row and one ledger row');
const owned = await page.evaluate((id) => { const c = [...document.querySelectorAll('.shop-lesson.own')]; return c.length && c[0].querySelector('[data-a="openles"]') ? true : false; }, idA);
ok(owned, 'K9 the lesson now shows Unlocked with a Start lesson button');
ok(await page.evaluate(() => Number((document.querySelector('.shop-bal.main b') || {}).innerText) === 110), 'K10 the balance shown is the server balance (110)');
const par = await page.evaluate(async (id) => { const r = await Promise.allSettled([__ee.B().unlockLesson(id, 'idem-par-aaaa'), __ee.B().unlockLesson(id, 'idem-par-bbbb')]); return r.map((x) => x.status === 'fulfilled' ? (x.value.duplicate ? 'dup' : 'paid') : 'err:' + (x.reason && x.reason.code)); }, les[1]);
ok(par.filter((x) => x === 'paid').length === 1 && gems() === 110 - 80 && psql(`select count(*) from lesson_unlocks where user_id='${uid}'`) === '2', `K11 two parallel unlock calls charge once (${par.join(',')}, balance ${gems()})`);
ok(psql(`select (select gems from player_state where user_id='${uid}') = coalesce((select sum(delta) from gem_transactions where user_id='${uid}'),0)`) === 't', 'K12 balance equals the ledger after purchases');
await page.reload(); await page.waitForTimeout(2200); await tab(page, 'shop'); await page.waitForTimeout(1200);
ok(await page.locator('.shop-lesson.own').count() === 2, 'K13 purchased lessons stay unlocked after a reload');
await page.click(`button[data-a="openles"][data-v="${idA}"]`); await page.waitForTimeout(1500);
ok(await page.locator('button[data-a="quit"]').count() === 1 && psql(`select count(*) from lesson_attempts where user_id='${uid}' and lesson_id='${idA}'`) === '1', 'K14 Start lesson opens the purchased lesson (server attempt created)');
await page.locator('button[data-a="quit"]').click().catch(() => {}); await page.waitForTimeout(500);
await page.locator('button[data-a="quitYes"]').first().click().catch(() => {}); await page.waitForTimeout(800);
psql(`update player_state set gems=5 where user_id='${uid}'`);
const err = await page.evaluate(async () => { try { await __ee.B().unlockLesson('nope', 'idem-nope-0001'); return 'paid'; } catch (e) { return e.code; } });
ok(err === 'not_found', `K15 an unknown lesson is refused by the server (${err})`);

/* ---------- PROFILE ---------- */
await page.reload(); await page.waitForTimeout(2200); await tab(page, 'me');
const pr = await page.evaluate(() => ({ hero: !!document.querySelector('.p2-hero'), tabs: document.querySelectorAll('.p2-tabs button').length, stats: document.querySelectorAll('.p2-stat').length, av: !!document.querySelector('.p2-hero .pro-av'), name: (document.querySelector('.p2-hero h1') || {}).innerText, txt: document.body.innerText }));
ok(pr.hero && pr.av && pr.tabs === 5 && pr.stats >= 5, `F1 Profile has hero, avatar, 5 sections tabs and ${pr.stats} stat tiles`);
const xpDb = psql(`select xp from player_state where user_id='${uid}'`);
ok(pr.txt.replace(/,/g, '').includes(xpDb), `F2 the XP shown (${xpDb}) is the server value`);
ok(await noOverflow(page), 'F3 Profile has no horizontal overflow at 390 px');
await page.screenshot({ path: SHOT + '/profile-phone-light.png' });
for (const tb of ['stats', 'ach', 'mist', 'set', 'over']) { await page.click(`button[data-a="ptab"][data-v="${tb}"]`); await page.waitForTimeout(500); }
ok(true, 'F4 all five profile sections open');

/* ---------- THEMES + LAYOUTS ---------- */
const pages = [['home', 'home'], ['learn', 'learn'], ['shop', 'shop'], ['me', 'profile']];   // 6.3: 'practice' (Repetition) no longer exists; tab() silently did nothing for it, so that row used to re-test the previous page
for (const th of ['light', 'dark']) {
  await theme(page, th);
  for (const [t, nm] of pages) {
    await tab(page, t); await page.waitForTimeout(500);
    const m = await page.evaluate(() => { window.scrollTo(0, document.body.scrollHeight); const nav = document.querySelector('.nav'); const last = [...document.querySelectorAll('.wrap > *:not(script)')].filter((e) => e.offsetParent).pop();
      return { ow: document.documentElement.scrollWidth <= window.innerWidth + 1, navTop: nav ? nav.getBoundingClientRect().top : 9999, lastBottom: last ? last.getBoundingClientRect().bottom : 0 }; });
    ok(m.ow && m.lastBottom <= m.navTop + 2, `L1 ${nm} (${th}, phone): no horizontal overflow and the last block is not hidden behind the navigation (last ${Math.round(m.lastBottom)} <= nav ${Math.round(m.navTop)})`);
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.screenshot({ path: `${SHOT}/${nm}-phone-${th}.png` });
  }
}
await theme(page, 'light');
ok(errors.length === 0, 'X1 no JavaScript or console errors on the phone run', errors.slice(0, 3).join(' | '));
await ctx.close();
const d = await openApp(browser, { width: 1280, height: 800 });
await login(d.page, email);
for (const th of ['light', 'dark']) {
  await theme(d.page, th);
  for (const [t, nm] of pages) {
    await tab(d.page, t); await d.page.waitForTimeout(400);
    ok(await noOverflow(d.page), `L2 ${nm} (${th}, desktop 1280): no horizontal overflow`);
    await d.page.screenshot({ path: `${SHOT}/${nm}-desktop-${th}.png` });
  }
}
ok(d.errors.length === 0, 'X2 no JavaScript or console errors on the desktop run', d.errors.slice(0, 3).join(' | '));
await d.ctx.close(); await browser.close();
console.log(bad ? `\n${bad} FAILED` : '\nall passed'); process.exit(bad ? 1 : 0);
