// TEST-ONLY browser stand-in for @supabase/supabase-js (the real library cannot be downloaded in this environment).
// Implements just the calls Lingora makes, over fetch, with the same result shapes ({data, error}).
(function () {
  function createClient(url, key, opts) {
    const SK = 'sb-standin-session'; let session = null; const listeners = [];
    try { session = JSON.parse(localStorage.getItem(SK) || 'null'); } catch (e) {}
    const save = (s) => { session = s; try { s ? localStorage.setItem(SK, JSON.stringify(s)) : localStorage.removeItem(SK); } catch (e) {} };
    const bearer = () => (session && session.access_token) || key;
    const H = (extra) => Object.assign({ apikey: key, Authorization: 'Bearer ' + bearer(), 'Content-Type': 'application/json' }, extra || {});
    const err = (j, status) => ({ message: (j && (j.message || j.msg || j.error_description)) || 'error', code: j && (j.code || j.error_code), details: j && j.details, hint: j && j.hint, status });
    const J = async (r) => { const t = await r.text(); try { return t ? JSON.parse(t) : null; } catch (e) { return null; } };
    const netErr = (e) => ({ data: null, error: { message: 'Failed to fetch', name: 'AuthRetryableFetchError', status: 0 } });
    async function refreshIfNeeded() {
      if (!session || !session.expires_at || session.expires_at - 30 > Date.now() / 1000) return;
      const r = await fetch(url + '/auth/v1/token?grant_type=refresh_token', { method: 'POST', headers: { apikey: key, 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: session.refresh_token }) });
      const j = await J(r); if (r.ok) save(j); else save(null);
    }
    const auth = {
      async getSession() { await refreshIfNeeded(); return { data: { session }, error: null }; },
      onAuthStateChange(cb) { listeners.push(cb); return { data: { subscription: { unsubscribe() {} } } }; },
      async signUp({ email, password, options }) {
        try { const r = await fetch(url + '/auth/v1/signup', { method: 'POST', headers: { apikey: key, 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password, data: (options && options.data) || {} }) }); const j = await J(r);
          if (!r.ok) return { data: { user: null, session: null }, error: err(j, r.status) };
          if (j.access_token) { save(j); listeners.forEach((f) => f('SIGNED_IN', j)); return { data: { user: j.user, session: j }, error: null }; }
          return { data: { user: j.user || j, session: null }, error: null }; } catch (e) { return netErr(e); }
      },
      async signInWithPassword({ email, password }) {
        try { const r = await fetch(url + '/auth/v1/token?grant_type=password', { method: 'POST', headers: { apikey: key, 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) }); const j = await J(r);
          if (!r.ok) return { data: { user: null, session: null }, error: err(j, r.status) };
          save(j); listeners.forEach((f) => f('SIGNED_IN', j)); return { data: { user: j.user, session: j }, error: null }; } catch (e) { return netErr(e); }
      },
      async signOut() { try { if (session) await fetch(url + '/auth/v1/logout', { method: 'POST', headers: H() }); } catch (e) {} save(null); listeners.forEach((f) => f('SIGNED_OUT', null)); return { error: null }; },
      async updateUser(attrs) { try { const r = await fetch(url + '/auth/v1/user', { method: 'PUT', headers: H(), body: JSON.stringify(attrs) }); const j = await J(r); return r.ok ? { data: { user: j }, error: null } : { data: null, error: err(j, r.status) }; } catch (e) { return netErr(e); } },
      async resetPasswordForEmail(email) { try { const r = await fetch(url + '/auth/v1/recover', { method: 'POST', headers: H(), body: JSON.stringify({ email }) }); return r.ok ? { data: {}, error: null } : { data: null, error: err(await J(r), r.status) }; } catch (e) { return netErr(e); } },
    };
    const lit = (v) => String(v);
    function builder(table) {
      const q = { method: 'GET', params: new URLSearchParams(), body: null, headers: {}, one: null };
      const b = {
        select(c) { q.params.set('select', c || '*'); return b; },
        insert(rows) { q.method = 'POST'; q.body = rows; return b; },
        upsert(rows, o) { q.method = 'POST'; q.body = rows; q.headers.Prefer = 'resolution=merge-duplicates'; if (o && o.onConflict) q.params.set('on_conflict', o.onConflict); return b; },
        update(o) { q.method = 'PATCH'; q.body = o; return b; },
        delete() { q.method = 'DELETE'; return b; },
        eq(c, v) { q.params.append(c, 'eq.' + lit(v)); return b; }, neq(c, v) { q.params.append(c, 'neq.' + lit(v)); return b; },
        in(c, v) { q.params.append(c, 'in.(' + v.map(lit).join(',') + ')'); return b; },
        match(o) { Object.keys(o).forEach((k) => q.params.append(k, 'eq.' + lit(o[k]))); return b; },
        order(c, o) { const prev = q.params.get('order'); const part = c + '.' + (o && o.ascending === false ? 'desc' : 'asc'); q.params.set('order', prev ? prev + ',' + part : part); return b; },
        limit(n) { q.params.set('limit', n); return b; },
        range(a, z) { q.headers.Range = a + '-' + z; return b; },
        single() { q.one = 'single'; return b; }, maybeSingle() { q.one = 'maybe'; return b; },
        async then(ok, bad) { return run().then(ok, bad); },
      };
      async function run() {
        try {
          await refreshIfNeeded();
          const hasSel = q.params.has('select');
          const r = await fetch(url + '/rest/v1/' + table + (q.params.toString() ? '?' + q.params.toString() : ''), { method: q.method, headers: H(Object.assign({ Prefer: (q.method !== 'GET' && (q.headers.Prefer ? q.headers.Prefer + ',' : '') + (hasSel ? 'return=representation' : 'return=minimal')) || undefined }, q.headers.Range ? { Range: q.headers.Range } : {})), body: q.body ? JSON.stringify(q.body) : undefined });
          const j = await J(r);
          if (!r.ok) return { data: null, error: err(j, r.status), status: r.status };
          let data = j;
          if (q.one && Array.isArray(data)) {
            if (data.length === 1) data = data[0];
            else if (q.one === 'maybe' && data.length === 0) data = null;
            else return { data: null, error: { code: 'PGRST116', message: 'JSON object requested, multiple (or no) rows returned', details: 'The result contains ' + data.length + ' rows' }, status: 406 };
          }
          return { data, error: null, status: r.status };
        } catch (e) { return { data: null, error: { message: 'Failed to fetch' }, status: 0 }; }
      }
      return b;
    }
    return {
      auth, from: builder,
      async rpc(fn, args) { try { await refreshIfNeeded(); const r = await fetch(url + '/rest/v1/rpc/' + fn, { method: 'POST', headers: H(), body: JSON.stringify(args || {}) }); const j = await J(r); return r.ok ? { data: j, error: null } : { data: null, error: err(j, r.status) }; } catch (e) { return { data: null, error: { message: 'Failed to fetch' } }; } },
      functions: { async invoke(name, o) {
        try { await refreshIfNeeded(); const r = await fetch(url + '/functions/v1/' + name, { method: 'POST', headers: H(), body: JSON.stringify((o && o.body) || {}) });
          if (!r.ok) return { data: null, error: { name: 'FunctionsHttpError', message: 'Edge Function returned a non-2xx status code', context: r } };
          const ct = r.headers.get('content-type') || '';
          return { data: ct.includes('json') ? await r.json() : await r.blob(), error: null };
        } catch (e) { return { data: null, error: { name: 'FunctionsFetchError', message: 'Failed to send a request to the Edge Function' } }; } } },
      storage: { from() { return { async upload() { return { data: null, error: { message: 'storage not available in the stand-in' } }; }, async remove() { return { data: null, error: { message: 'storage not available in the stand-in' } }; }, getPublicUrl(p) { return { data: { publicUrl: url + '/storage/v1/object/public/media/' + p } }; } }; } },
    };
  }
  window.supabase = { createClient };
})();
