// TEST-ONLY local stand-in for the Supabase HTTP API, backed by a REAL PostgreSQL database that holds SETUP.sql.
// It speaks the subset of GoTrue (/auth/v1), PostgREST (/rest/v1) and Edge Functions (/functions/v1) that Lingora uses,
// runs every query under the caller's role (anon / authenticated / service_role) so RLS and GRANTs are enforced by PostgreSQL,
// and hosts the REAL ai-coach handler (supabase/functions/_shared/coach.js) against a MOCK model provider.
// It is NOT Supabase: real GoTrue, real PostgREST, the real Deno runtime and a real model are not involved.
// Usage: PGDB=lingora_e2e PORT=54321 node tests/bridge/server.mjs
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { handle as coachHandle } from '../../supabase/functions/_shared/coach.js';

const DB = process.env.PGDB || 'lingora_e2e';
const PORT = Number(process.env.PORT || 54321);
const SECRET = process.env.JWT_SECRET || 'lingora-test-secret-not-for-production';
const ORIGIN = `http://127.0.0.1:${PORT}`;
const SITE = path.resolve(new URL('../../site', import.meta.url).pathname);
export const cfg = { aiKey: 'sk-test-key', provider: 'ok', deployed: true, providerDelayMs: 0, anthropicCalls: [], model: 'claude-haiku-4-5' };

/* ---------- JWT (HS256) ---------- */
const b64 = (b) => Buffer.from(b).toString('base64url');
const sign = (payload) => { const h = b64(JSON.stringify({ alg: 'HS256', typ: 'JWT' })), p = b64(JSON.stringify(payload)); return `${h}.${p}.${crypto.createHmac('sha256', SECRET).update(h + '.' + p).digest('base64url')}`; };
const verify = (tok) => { try { const [h, p, s] = String(tok).split('.'); if (s !== crypto.createHmac('sha256', SECRET).update(h + '.' + p).digest('base64url')) return null; const j = JSON.parse(Buffer.from(p, 'base64url')); if (j.exp && j.exp < Date.now() / 1000) return null; return j; } catch { return null; } };
const ANON = sign({ role: 'anon', iss: 'supabase-test' }), SERVICE = sign({ role: 'service_role', iss: 'supabase-test' });
const userTokens = (u) => { const now = Math.floor(Date.now() / 1000);
  return { access_token: sign({ sub: u.id, role: 'authenticated', email: u.email, aud: 'authenticated', iat: now, exp: now + 3600 }), refresh_token: sign({ sub: u.id, typ: 'refresh', exp: now + 86400 * 7, n: crypto.randomUUID() }), token_type: 'bearer', expires_in: 3600, expires_at: now + 3600 }; };

/* ---------- PostgreSQL through psql (superuser connection; every request switches role like PostgREST does) ---------- */
const lit = (s) => "'" + String(s).replace(/'/g, "''") + "'";
const ident = (s) => { if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(s)) throw Object.assign(new Error('bad identifier'), { status: 400 }); return '"' + s + '"'; };
const dq = () => '$q' + crypto.randomBytes(6).toString('hex') + '$';
function psql(sql) {
  return new Promise((resolve) => {
    const p = spawn('runuser', ['-u', 'postgres', '--', 'psql', '-X', '-q', '-A', '-t', '-d', DB, '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose'], { stdio: ['pipe', 'pipe', 'pipe'] });
    let out = '', err = '';
    p.stdout.on('data', (d) => (out += d)); p.stderr.on('data', (d) => (err += d));
    p.on('close', (code) => {
      if (code === 0) return resolve({ ok: true, out: out.trim() });
      const m = /ERROR:\s+([0-9A-Z]{5}):\s+(.*)/.exec(err) || [];
      resolve({ ok: false, code: m[1] || 'XX000', message: (m[2] || err).trim().split('\n')[0], detail: err });
    });
    p.stdin.end(sql);
  });
}
async function run(role, uid, query) {          // one transaction, one role, JSON in / JSON out
  const claims = JSON.stringify(role === 'anon' ? { role: 'anon' } : role === 'service_role' ? { role: 'service_role' } : { sub: uid, role: 'authenticated' });
  const t = dq();
  return psql(`begin;\nselect set_config('request.jwt.claims', ${lit(claims)}, true) as _c \\gset\nset local role ${role};\n${query};\ncommit;\n${t}`.replace(t, ''));
}
const jtext = (r) => (r.out === '' ? null : JSON.parse(r.out));

let FN_META = null;
async function fnMeta() {
  if (FN_META) return FN_META;
  const r = await psql(`select coalesce(jsonb_agg(jsonb_build_object('name', p.proname, 'args', pg_get_function_arguments(p.oid), 'set', p.proretset, 'ret', p.prorettype::regtype::text)), '[]') from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'public' and p.prokind = 'f'`);
  FN_META = JSON.parse(r.out).map((f) => ({ ...f, args: f.args ? f.args.split(/,\s*(?![^()]*\))/).map((a) => { const m = /^(?:IN\s+)?(\w+)\s+(.+?)(?:\s+DEFAULT\s+.*)?$/.exec(a.trim()); return m ? { name: m[1], type: m[2] } : null; }).filter(Boolean) : [] }));
  return FN_META;
}
const castExpr = (body, a) => {
  const v = `(${body}::jsonb)`;
  if (/^jsonb?$/.test(a.type)) return `${v}->${lit(a.name)}`;
  if (/\[\]$/.test(a.type)) return `(select array_agg(x::${a.type.replace('[]', '')}) from jsonb_array_elements_text(${v}->${lit(a.name)}) x)`;
  return `(${v}->>${lit(a.name)})::${a.type}`;
};
async function rpc(role, uid, name, args) {
  const meta = (await fnMeta()).filter((f) => f.name === name);
  if (!meta.length) return { status: 404, body: { code: 'PGRST202', message: `Could not find the function public.${name} in the schema cache` } };
  const keys = Object.keys(args || {});
  const f = meta.filter((m) => keys.every((k) => m.args.some((a) => a.name === k))).sort((a, b) => a.args.length - b.args.length)[0] || meta[0];
  const t = dq();
  const body = `${t}${JSON.stringify(args || {})}${t}`;
  const call = `public.${ident(name)}(${keys.filter((k) => f.args.some((a) => a.name === k)).map((k) => `${ident(k)} => ${castExpr(body, f.args.find((a) => a.name === k))}`).join(', ')})`;
  const q = f.ret === 'void' ? `select ${call}` : f.set ? `select coalesce(jsonb_agg(to_jsonb(x)), '[]'::jsonb) from ${call} x` : `select to_jsonb(${call})`;
  const r = await run(role, uid, q);
  return pgResult(r, role, f.ret === 'void' ? () => null : jtext);
}
const pgResult = (r, role, parse) => {
  if (r.ok) return { status: 200, body: parse(r) };
  const status = r.code === '42501' ? (role === 'anon' ? 401 : 403) : r.code === '23505' ? 409 : r.code === '42883' ? 404 : 400;
  return { status, body: { code: r.code, message: r.message, details: null, hint: null } };
};
function filters(params) {
  const skip = new Set(['select', 'order', 'limit', 'offset', 'on_conflict', 'columns']);
  const w = [];
  for (const [k, v] of params) {
    if (skip.has(k)) continue;
    const m = /^(not\.)?(eq|neq|gt|gte|lt|lte|like|ilike|is|in)\.(.*)$/.exec(v);
    if (!m) throw Object.assign(new Error('bad filter ' + k), { status: 400 });
    const [, neg, op, val] = m; const c = ident(k);
    let e;
    if (op === 'in') e = `${c} in (${val.replace(/^\(|\)$/g, '').split(',').map((x) => lit(x.replace(/^"|"$/g, ''))).join(',')})`;
    else if (op === 'is') e = `${c} is ${val === 'null' ? 'null' : val === 'true' ? 'true' : 'false'}`;
    else e = `${c} ${{ eq: '=', neq: '<>', gt: '>', gte: '>=', lt: '<', lte: '<=', like: 'like', ilike: 'ilike' }[op]} ${lit(val)}`;
    w.push(neg ? `not (${e})` : e);
  }
  return w.length ? ' where ' + w.join(' and ') : '';
}
async function table(role, uid, method, name, params, headers, bodyText) {
  const tb = `public.${ident(name)}`, prefer = String(headers.prefer || ''), t = dq();
  const ret = /return=representation/.test(prefer);
  const wrap = (inner) => `with r as (${inner}) select coalesce(jsonb_agg(to_jsonb(r)), '[]'::jsonb) from r`;
  let q;
  if (method === 'GET' || method === 'HEAD') {
    const sel = (params.get('select') || '*').split(',').map((c) => (c.trim() === '*' ? '*' : ident(c.trim()))).join(', ');
    const ord = (params.get('order') || '').split(',').filter(Boolean).map((o) => { const [c, d, n] = o.split('.'); return `${ident(c)} ${d === 'desc' ? 'desc' : 'asc'}${n === 'nullsfirst' ? ' nulls first' : n === 'nullslast' ? ' nulls last' : ''}`; });
    let lim = params.get('limit'), off = params.get('offset');
    const range = /^(\d+)-(\d+)$/.exec(headers.range || '');
    if (range) { off = range[1]; lim = Number(range[2]) - Number(range[1]) + 1; }
    q = wrap(`select ${sel} from ${tb}${filters(params)}${ord.length ? ' order by ' + ord.join(', ') : ''}${lim ? ' limit ' + Number(lim) : ''}${off ? ' offset ' + Number(off) : ''}`);
  } else if (method === 'POST') {
    const rows = JSON.parse(bodyText || '[]'); const arr = Array.isArray(rows) ? rows : [rows];
    const cols = [...new Set(arr.flatMap((o) => Object.keys(o)))];
    if (!cols.length) return { status: 400, body: { code: 'PGRST102', message: 'Empty or invalid json' } };
    const data = `${t}${JSON.stringify(arr)}${t}`;
    let conflict = '';
    if (/resolution=(merge|ignore)-duplicates/.test(prefer)) {
      const pk = params.get('on_conflict') ? params.get('on_conflict').split(',') : await pkOf(name);
      conflict = /ignore/.test(prefer) ? ` on conflict (${pk.map(ident).join(',')}) do nothing` : ` on conflict (${pk.map(ident).join(',')}) do update set ${cols.filter((c) => !pk.includes(c)).map((c) => `${ident(c)} = excluded.${ident(c)}`).join(', ') || `${ident(pk[0])} = excluded.${ident(pk[0])}`}`;
    }
    q = wrap(`insert into ${tb} (${cols.map(ident).join(',')}) select ${cols.map(ident).join(',')} from jsonb_populate_recordset(null::${tb}, ${data}::jsonb)${conflict} returning *`);
  } else if (method === 'PATCH') {
    const o = JSON.parse(bodyText || '{}'); const cols = Object.keys(o); const data = `${t}${JSON.stringify(o)}${t}`;
    q = wrap(`update ${tb} set ${cols.map((c) => `${ident(c)} = (jsonb_populate_record(null::${tb}, ${data}::jsonb)).${ident(c)}`).join(', ')}${filters(params)} returning *`);
  } else if (method === 'DELETE') {
    q = wrap(`delete from ${tb}${filters(params)} returning *`);
  } else return { status: 405, body: { message: 'method' } };
  const r = await run(role, uid, q);
  const res = pgResult(r, role, jtext);
  if (res.status === 200 && method !== 'GET') { res.status = method === 'POST' ? 201 : 200; if (!ret) res.body = null; }
  return res;
}
const PK = {};
async function pkOf(name) {
  if (PK[name]) return PK[name];
  const r = await psql(`select coalesce(jsonb_agg(a.attname order by array_position(i.indkey::int2[], a.attnum)), '[]') from pg_index i join pg_attribute a on a.attrelid = i.indrelid and a.attnum = any(i.indkey) where i.indrelid = ('public.' || quote_ident(${lit(name)}))::regclass and i.indisprimary`);
  return (PK[name] = JSON.parse(r.out));
}

/* ---------- GoTrue subset ---------- */
const userJson = (u) => ({ id: u.id, aud: 'authenticated', role: 'authenticated', email: u.email, user_metadata: u.raw_user_meta_data || {}, app_metadata: { provider: 'email' }, created_at: u.created_at, last_sign_in_at: u.last_sign_in_at });
async function authRoute(method, sub, params, headers, bodyText) {
  const body = bodyText ? JSON.parse(bodyText) : {};
  if (sub === '/signup') {
    const email = String(body.email || '').trim().toLowerCase(), pw = String(body.password || '');
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { status: 400, body: { code: 400, error_code: 'validation_failed', msg: 'Unable to validate email address: invalid format' } };
    if (pw.length < 6) return { status: 422, body: { code: 422, error_code: 'weak_password', msg: 'Password should be at least 6 characters.' } };
    const t = dq();
    const r = await psql(`insert into auth.users (email, encrypted_password, raw_user_meta_data, last_sign_in_at) values (${lit(email)}, crypt(${lit(pw)}, gen_salt('bf')), ${t}${JSON.stringify((body.data || {}))}${t}::jsonb, now()) returning to_jsonb(users)`);
    if (!r.ok) return r.code === '23505' ? { status: 422, body: { code: 422, error_code: 'user_already_exists', msg: 'User already registered' } } : { status: 500, body: { msg: r.message } };
    const u = JSON.parse(r.out);
    return { status: 200, body: { ...userTokens(u), user: userJson(u) } };
  }
  if (sub === '/token') {
    const gt = params.get('grant_type');
    let u;
    if (gt === 'password') {
      const r = await psql(`update auth.users set last_sign_in_at = now() where email = ${lit(String(body.email || '').trim().toLowerCase())} and encrypted_password = crypt(${lit(body.password || '')}, encrypted_password) returning to_jsonb(users)`);
      u = r.ok && r.out ? JSON.parse(r.out) : null;
      if (!u) return { status: 400, body: { code: 400, error_code: 'invalid_credentials', msg: 'Invalid login credentials' } };
    } else if (gt === 'refresh_token') {
      const c = verify(body.refresh_token);
      if (!c || c.typ !== 'refresh') return { status: 400, body: { code: 400, error_code: 'refresh_token_not_found', msg: 'Invalid Refresh Token' } };
      const r = await psql(`select to_jsonb(u) from auth.users u where id = ${lit(c.sub)}`); u = r.out ? JSON.parse(r.out) : null;
      if (!u) return { status: 400, body: { code: 400, msg: 'user not found' } };
    } else return { status: 400, body: { msg: 'unsupported grant_type' } };
    return { status: 200, body: { ...userTokens(u), user: userJson(u) } };
  }
  const c = verify((headers.authorization || '').replace(/^Bearer\s+/i, ''));
  if (sub === '/user' && method === 'GET') {
    if (!c || !c.sub) return { status: 401, body: { code: 401, error_code: 'bad_jwt', msg: 'invalid JWT' } };
    const r = await psql(`select to_jsonb(u) from auth.users u where id = ${lit(c.sub)}`);
    return r.out ? { status: 200, body: userJson(JSON.parse(r.out)) } : { status: 401, body: { code: 401, msg: 'user not found' } };
  }
  if (sub === '/user' && method === 'PUT') {
    if (!c || !c.sub) return { status: 401, body: { msg: 'invalid JWT' } };
    if (body.password) await psql(`update auth.users set encrypted_password = crypt(${lit(body.password)}, gen_salt('bf')) where id = ${lit(c.sub)}`);
    const r = await psql(`select to_jsonb(u) from auth.users u where id = ${lit(c.sub)}`);
    return { status: 200, body: userJson(JSON.parse(r.out)) };
  }
  if (sub === '/logout') return { status: 204, body: null };
  if (sub === '/recover') return { status: 200, body: {} };
  return { status: 404, body: { msg: 'not found' } };
}

/* ---------- mock model provider (a RULE-BASED stand-in for the Anthropic Messages API; it is not a language model) ---------- */
function mockAnthropic(body) {
  const sys = String(body.system || ''), msgs = body.messages || [];
  const last = String((msgs[msgs.length - 1] || {}).content || '');
  const tool = body.tools && body.tools[0] && body.tools[0].name;
  const usage = { input_tokens: 200 + sys.length / 4 | 0, output_tokens: 80 };
  if (tool === 'coach_reply') {
    const lang = /studying (\w[\w ()]*?) at CEFR level (\w\d)/.exec(sys) || [];
    const corrections = [];
    if (/\bI goes\b/i.test(last)) corrections.push({ original: 'I goes', corrected: 'I go', type: 'grammar', explanation: 'After "I" the verb has no -s.' });
    if (/\bje suis (\d+) ans\b/i.test(last)) corrections.push({ original: last.match(/je suis \d+ ans/i)[0], corrected: last.match(/je suis \d+ ans/i)[0].replace(/suis/i, 'ai'), type: 'grammar', explanation: 'En français on dit « j\'ai … ans ».' });
    if (/\bhallucinated\b/.test(last)) corrections.push({ original: 'text the learner never wrote', corrected: 'x', type: 'other', explanation: 'must be dropped by the server' });
    return { content: [{ type: 'tool_use', id: 'tu_1', name: 'coach_reply', input: { reply: `[mock ${lang[1] || '?'} ${lang[2] || '?'}] You wrote ${msgs.length} message(s). What did you do today?`, reply_translation: 'MOCK translation', assessment: corrections.length ? 'minor' : 'perfect', corrections, new_words: [{ word: 'today', translation: 'այսօր' }] } }], usage };
  }
  if (tool === 'exercises') return { content: [{ type: 'tool_use', id: 'tu_2', name: 'exercises', input: { exercises: [{ q: 'She ___ to school.', options: ['go', 'goes', 'going'], answer: 'goes', why: 'Third person -s.' }, { q: 'Broken one', options: ['a', 'b', 'c'], answer: 'zzz', why: 'answer not in options: must be dropped' }] } }], usage };
  return { content: [{ type: 'text', text: `[mock text] ${sys.includes('study plan') ? 'PLAN based on: ' + last.slice(0, 80) : 'EXPLANATION of: ' + last.slice(0, 80)}` }], usage };
}
async function anthropicRoute(req, res, bodyText) {
  const body = JSON.parse(bodyText || '{}');
  cfg.anthropicCalls.push({ headers: req.headers, body });
  if (req.headers['x-api-key'] !== cfg.aiKey) return send(res, 401, { type: 'error', error: { type: 'authentication_error', message: 'invalid x-api-key' } });
  if (cfg.providerDelayMs) await new Promise((r) => setTimeout(r, cfg.providerDelayMs));
  if (cfg.provider === 'error') return send(res, 529, { type: 'error', error: { type: 'overloaded_error', message: 'Overloaded' } });
  if (cfg.provider === 'garbage') return send(res, 200, { content: [{ type: 'text', text: 'I will not use the tool' }], usage: { input_tokens: 5, output_tokens: 5 } });
  send(res, 200, mockAnthropic(body));
}

/* ---------- HTTP plumbing ---------- */
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, prefer, range, accept-profile, content-profile, x-supabase-api-version', 'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS', 'Access-Control-Expose-Headers': 'content-range' };
const send = (res, status, body, headers) => { res.writeHead(status, { ...CORS, 'Content-Type': 'application/json', ...(headers || {}) }); res.end(body == null ? '' : JSON.stringify(body)); };
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.webmanifest': 'application/manifest+json', '.json': 'application/json' };
const readBody = (req) => new Promise((r) => { let b = ''; req.on('data', (d) => (b += d)); req.on('end', () => r(b)); });
const coachEnv = (k) => ({ SUPABASE_URL: ORIGIN, SUPABASE_ANON_KEY: ANON, SUPABASE_SERVICE_ROLE_KEY: SERVICE, ANTHROPIC_API_KEY: cfg.aiKey || undefined, ANTHROPIC_BASE_URL: ORIGIN + '/__anthropic', AI_MODEL: cfg.model, AI_TIMEOUT_MS: String(cfg.timeoutMs || ''), ALLOWED_ORIGIN: '*' }[k]);

http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, ORIGIN); const p = u.pathname;
    if (req.method === 'OPTIONS') { res.writeHead(204, CORS); return res.end(); }
    const bodyText = ['GET', 'HEAD', 'DELETE'].includes(req.method) ? '' : await readBody(req);
    if (p === '/__test/keys') return send(res, 200, { url: ORIGIN, anon: ANON, service: SERVICE });
    if (p === '/__test/config') { Object.assign(cfg, JSON.parse(bodyText || '{}')); if ('aiKey' in JSON.parse(bodyText || '{}') && !cfg.aiKey) cfg.aiKey = ''; return send(res, 200, { ...cfg, anthropicCalls: cfg.anthropicCalls.length }); }
    if (p === '/__test/anthropic-calls') { const c = cfg.anthropicCalls; if (u.searchParams.get('clear')) cfg.anthropicCalls = []; return send(res, 200, c); }
    if (p === '/__anthropic/v1/messages') return anthropicRoute(req, res, bodyText);
    if (p.startsWith('/site/') || p === '/site') {
      let f = path.join(SITE, p.replace(/^\/site\/?/, '') || 'index.html'); if (!f.startsWith(SITE)) return send(res, 403, {});
      if (!fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.join(SITE, 'index.html');
      res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-store' }); return res.end(fs.readFileSync(f));
    }
    const h = req.headers;
    if (p.startsWith('/auth/v1')) { const r = await authRoute(req.method, p.slice(8), u.searchParams, h, bodyText); return send(res, r.status, r.body); }
    const key = verify(h.apikey || ''); const bearer = (h.authorization || '').replace(/^Bearer\s+/i, '');
    const claims = bearer ? verify(bearer) : key;
    if (!key) return send(res, 401, { message: 'No API key found in request', hint: 'No `apikey` request header or url param was found.' });
    if (p.startsWith('/rest/v1')) {
      if (!claims) return send(res, 401, { code: 'PGRST301', message: 'JWT expired' });
      const role = claims.role === 'service_role' ? 'service_role' : claims.role === 'authenticated' ? 'authenticated' : 'anon';
      const sub = p.slice(9);
      const r = sub.startsWith('rpc/') ? await rpc(role, claims.sub, sub.slice(4), bodyText ? JSON.parse(bodyText) : {}) : await table(role, claims.sub, req.method, sub, u.searchParams, h, bodyText);
      return send(res, r.status, r.body);
    }
    if (p.startsWith('/functions/v1/')) {
      if (!claims) return send(res, 401, { code: 401, message: 'Invalid JWT' });            // verify_jwt = true
      const name = p.slice(14);
      if (name !== 'ai-coach' || !cfg.deployed) return send(res, 404, { code: 'NOT_FOUND', message: 'Requested function was not found' });   // not deployed
      const r = await coachHandle(new Request(ORIGIN + p, { method: req.method, headers: h, body: req.method === 'POST' ? bodyText : undefined }), coachEnv, { log: () => {} });
      res.writeHead(r.status, { ...Object.fromEntries(r.headers), ...CORS }); return res.end(await r.text());
    }
    send(res, 404, { message: 'not found' });
  } catch (e) { send(res, e.status || 500, { message: String(e.message || e) }); }
}).listen(PORT, '127.0.0.1', () => console.log(`bridge on ${ORIGIN} (db ${DB})`));
