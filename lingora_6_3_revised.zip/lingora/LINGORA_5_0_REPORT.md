# Lingora 5.0 — audit & mobile-first pass

## What was audited
Whole project (48 source modules -> `site/app.js`, `site/styles.css`, 5 SQL migrations + `SETUP.sql`, 4 Edge Functions, 17 test files). Source of truth: `src/js/*` (concatenated by `node build.mjs`; `site/app.js` is generated). No duplicate/competing implementations that needed removal were found; Supabase, RLS and Edge Functions were left unchanged on purpose.

## Changed in this round
- Touch targets: language switch buttons (HY/EN, 30px tall) now have a 44px tappable area (same look).
- App feel: `touch-action: manipulation` (no 300ms tap delay), no page rubber-banding on phones/standalone, text-size-adjust.
- PWA: separate maskable icon (`icon-maskable-512.png`, safe-zone padded), manifest `id`, `categories`, portrait orientation, home-screen shortcuts (Learn / Words / AI Coach), iOS status-bar/title meta tags; service-worker cache bumped to `ee-v25`.
- New test `tests/static/actions.mjs`: every `data-a` action in the markup (193) has a handler in the dispatcher (no dead buttons by construction).
- New test `tests/ui/layout.mjs`: 10 screens (incl. lesson player and admin) x 7 viewports (320, 360, 375, 390, 414, 768, 1280) x light/dark = 140 screens; fails on horizontal scroll, elements outside the viewport, touch targets < 36px, JS errors. Added to `npm run test:ui`.

## Tests actually run (this environment)
| Suite | Result |
|---|---|
| layout (new) | 140 screens, 0 problems (72 small-target findings fixed first) |
| static actions (new) | 193 actions, 0 without handler |
| sync | 21/21 |
| mediacopy | 26/26 |
| contrast | 32 screens, 0 low-contrast |
| reset | 17/17 |
| pay | 7/7 |
| admin | 8/8 |
| phase1 | 22/22 |
| complete (lesson completion) | 34/34 |
| `node build.mjs --check` | OK |

## NOT run / not verified
- `tests/sql`, `tests/e2e`, `tests/ai`, `tests/stripe`: need a PostgreSQL server and the local bridge; only the `psql` client exists here, so they were not executed this round.
- No real Supabase, Stripe, TTS or AI-provider credentials: real cloud login, payments, neural TTS and the AI Coach against a live model are untested (see `AI_COACH_SETUP.md`, `.env.example`).
- A full redesign of every screen was NOT done: the existing design system (one palette, bottom navigation, light/dark) already passes the layout/contrast audits. Per-screen visual review of Admin on phones and the signed-in lesson player at 320px was only covered by the existing functional tests, not a new visual pass.
- Capacitor (native packaging) was not added; the PWA is the supported mobile path. Offline service worker registers only for VIP/admin by design (see `sw.js`).

## Visual review (screenshots, 320/390/1280px, light+dark)
Landing, auth, lesson player, admin (phone dropdown nav + desktop side rail), learn, words, shop, profile were inspected: consistent palette, radii, buttons and bottom navigation; no clipped or overflowing content. The transient 'Progress saved' pill is intentional (shown 2.5 s after a real sync, signed-in only). Landing/auth/admin were captured against the in-memory Supabase stand-in, so 'Could not load' in admin screenshots is the stand-in lacking data, not an app bug.
